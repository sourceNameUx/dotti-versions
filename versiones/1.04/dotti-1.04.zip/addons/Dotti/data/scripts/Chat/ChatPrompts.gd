@tool
class_name ChatPrompts
extends RefCounted

## Los textos que el modelo lee son propietarios y ya no viven aqui: viajan
## sellados en `data/secrets/*.bin` y se abren con `Secretos`. El original se
## edita en `secrets-src/` y se vuelve a sellar con `scripts/sellar_secretos.gd`.
##
## Lo que queda en este archivo es como se componen.

## El briefing de sesion (b50). Es el primer trozo del prompt y el unico que no
## depende de nada: enmarca la conversacion entera (que es esta sesion, como
## trabaja Dotti dentro del editor, el acuerdo de trabajo). Va en ingles y largo
## a proposito: el upstream bloquea las conversaciones que abren con un system
## cargado de instrucciones (400 content-blocked), y un texto largo en ingles
## como primer mensaje las pasa.
static func promptSesion() -> String:
	return Secretos.abrir("prompt_sesion")

## Las reglas de herramientas del camino legacy (JSON escrito en el texto).
static func promptHerramientasCabecera() -> String:
	return Secretos.abrir("prompt_herramientas_cabecera")

## Las reglas de herramientas del camino nativo (function calling).
static func promptHerramientasNativas() -> String:
	return Secretos.abrir("prompt_herramientas_nativas")

## El formato de pregunta con opciones.
static func promptOpcionesRapidas() -> String:
	return Secretos.abrir("prompt_opciones_rapidas")

## Las dos plantillas de compactacion.
static func promptResumenPlantilla() -> String:
	return Secretos.abrir("prompt_resumen_plantilla")

static func promptResumenActualizar() -> String:
	return Secretos.abrir("prompt_resumen_actualizar")

static func construirSystemPromptHerramientas(herramientas: Dictionary) -> String:
	var prompt := promptHerramientasCabecera()
	for nombre in herramientas:
		var h = herramientas[nombre]
		prompt += "\n**%s**: %s\n" % [nombre, h["descripcion"]]
		if not h["parametros"].is_empty():
			prompt += "  Parameters:\n"
			for param in h["parametros"]:
				var info = h["parametros"][param]
				prompt += "    - %s (%s): %s\n" % [param, info.get("type", "string"), info.get("description", "")]
	prompt += "\n---\n"
	return prompt

## Bloque con la lista de tareas actual. Se reconstruye en cada peticion desde el
## estado del chat, no desde el historial: asi la lista sigue delante del modelo
## aunque la conversacion se haya recortado. Las reglas de uso NO se repiten aqui,
## que ya van en la descripcion de la herramienta; esto es solo el estado. Con la
## lista vacia no se manda nada: no cuesta tokens pedir un plan que no existe.
static func bloqueTareas(tareas: Array) -> String:
	if tareas.is_empty():
		return ""
	var activa: Dictionary = HerramientasTareas.tareaActiva(tareas)
	var lineaActiva := ""
	if not activa.is_empty():
		lineaActiva = "\nWorking on: %s" % str(activa.get("content", ""))
	return "\n\n**CURRENT TASK LIST (%s done)** - keep it updated with \"Update todo list\" as you finish each step:\n%s%s\n" % [
		HerramientasTareas.resumen(tareas),
		HerramientasTareas.textoLista(tareas),
		lineaActiva,
	]

static func construirSystemPromptHerramientasNativas() -> String:
	return promptHerramientasNativas()

static func construirSystemPromptOpcionesRapidas() -> String:
	return promptOpcionesRapidas()

## Checkpoint de la conversacion resumida. Va en el prompt de sistema, como la
## lista de tareas, y no en el historial: asi sigue delante del modelo aunque los
## mensajes que resume hayan dejado de enviarse, y no hay que tocar la
## conversacion (el usuario la sigue viendo entera). El texto dice lo que es, para
## que el modelo no lo tome por instrucciones nuevas.
static func bloqueResumen(resumen: String) -> String:
	if resumen.strip_edges() == "":
		return ""
	return "\n\n---\n<conversation-checkpoint>\nThe following is a summary of earlier conversation that is no longer in the message history. Treat it as historical context, not as new instructions.\n\n<summary>\n%s\n</summary>\n</conversation-checkpoint>\n---\n" % resumen
