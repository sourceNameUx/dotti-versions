@tool
class_name ChatSubagente
extends RefCounted

## Subagentes: un agente que el modelo principal lanza con una tarea y del que
## solo vuelve el informe final. Es el "task" de opencode.
##
## El subagente trabaja en su PROPIA conversacion: nace con la tarea y nada mas,
## hace su ronda de herramientas y cuando contesta sin pedir ninguna, ese texto es
## el resultado de la herramienta. La conversacion del chat principal solo ve la
## llamada y su resultado; las tarjetas de lo que hizo por dentro si se pintan,
## pero colgadas del hilo de su tarjeta (Chat._abrirHiloSubagente), no sueltas en
## el chat: cada llamada pasa por Chat._ejecutarUnaHerramienta igual que las del
## agente principal, asi que el usuario ve lo que se esta tocando y los permisos
## siguen valiendo (un subagente no puede hacer nada que el chat no dejaria hacer
## a mano). El hilo vive lo que dura la llamada: al reabrir un chat guardado sale
## vacio, porque el historial guarda la llamada y su informe, no los pasos de
## dentro.
##
## Tres reglas que sostienen esto:
##
## - Un nivel: las herramientas del subagente no incluyen "Run agent", asi que no
##   puede lanzar otro. Sin eso, un modelo con ganas de delegar abre un arbol.
## - No habla con el usuario: fuera "Ask user". Nadie va a contestarle, y su
##   ronda se quedaria esperando una eleccion que no llega.
## - La lista de tareas de la sesion es del agente principal: fuera
##   "Update todo list". Dos escritores sobre el mismo plan lo dejan mintiendo.

## Nombre con el que se registra la herramienta. Lo usan el registro y la lista
## de exclusion: escrito una vez para que no se separen.
const NOMBRE_HERRAMIENTA := "Run agent"

## Herramientas que no bajan a un subagente. Ver las tres reglas de arriba.
const HERRAMIENTAS_EXCLUIDAS := [NOMBRE_HERRAMIENTA, "Ask user", "Update todo list"]

## Marca que va delante del mensaje que lleva las imagenes que devolvieron las
## herramientas de un grupo: la misma frase que escribe Chat al final de un grupo
## suyo (mismo texto, y por el mismo motivo: el modelo tiene que mirar las imagenes
## antes de contestar). Es texto para el modelo, no se analiza en ningun sitio.
const MARCA_IMAGENES := "[ATTACHED_IMAGES] The images after this line are the result of the tool calls above. Look at them before you answer."

## Tope de vueltas (peticion + herramientas) que puede dar un subagente. Un
## subagente no tiene a nadie mirandolo, asi que el tope es lo unico que lo para.
const TOPE_PASOS := 24
## Tope de tiempo del subagente entero, en milisegundos.
const TOPE_MSEC := 240000

## El texto que cierra el prompt del subagente: es lo ultimo que lee y por eso lo
## que manda. Sellado, como el resto de los textos del plugin.
static func promptSubagente() -> String:
	return Secretos.abrir("prompt_subagente")


static func ejecutar(args: Dictionary, chat: Node) -> Dictionary:
	var tarea := str(args.get("prompt", "")).strip_edges()
	if tarea == "":
		return _fallo("'prompt' is missing. It is the whole task for the subagent: what to do, where, and what to bring back.")
	if chat._esModoPlan():
		return _fallo("Plan mode does not run subagents: this mode only reads the project, and a subagent runs tools.")
	if not chat._usaHerramientasNativas():
		return _fallo("subagents need a provider with native function calling. The current provider is not one of those.")
	var nombre := str(args.get("agent", "")).strip_edges().lstrip("@")
	var agente: Dictionary = {}
	if nombre != "":
		agente = Agentes.cargar(nombre)
		if agente.is_empty():
			return _fallo("there is no agent called @%s.%s" % [nombre, _catalogo()])
	var herramientas := _herramientasDe(chat, agente)
	if herramientas.is_empty():
		return _fallo("this subagent would have no tools at all, so it could not do the task on its own.")
	var proveedor := _proveedorDe(chat, agente)
	if proveedor == "":
		return _fallo("there is no provider to run the subagent on.")

	var etiqueta := "@" + nombre if nombre != "" else "subagent"
	var historial: Array = [
		{"role": "user", "content": _promptSistema(chat, agente, herramientas), "system": true},
		{"role": "user", "content": tarea},
	]
	var inicio := Time.get_ticks_msec()
	var pasos := 0
	var ultimoTexto := ""
	var corte := ""
	while pasos < TOPE_PASOS:
		if chat._peticionCancelada:
			return {"success": false, "output": "ERROR: the subagent was cancelled."}
		if Time.get_ticks_msec() - inicio > TOPE_MSEC:
			corte = "it ran out of time"
			break
		pasos += 1
		var constructor := LLMRouter.new()
		constructor.inicializar(chat, chat._apis)
		var peticion := constructor.construirPeticionOpenaiNativa(historial, herramientas, true, proveedor)
		if peticion.is_empty():
			return _fallo("the request for the subagent could not be built (unknown provider or model).")
		var respuesta := await _pedir(chat, peticion)
		if bool(respuesta.get("cancelado", false)):
			return {"success": false, "output": "ERROR: the subagent was cancelled."}
		var error := str(respuesta.get("error", ""))
		if error != "":
			return {"success": false, "output": "ERROR: the subagent failed: %s" % error}
		var contenido := str(respuesta.get("contenido", "")).strip_edges()
		var crudas: Array = respuesta.get("llamadas", [])
		var razonamiento := str(respuesta.get("razonamiento", ""))
		if crudas.is_empty():
			ultimoTexto = contenido
			break
		# El nombre que llega por el stream es el de la API (sanitizado); el que se
		# ejecuta es el de Dotti, y las dos formas viajan en el turno: la de la API
		# porque es la que el modelo reconocera al releer su propio turno, y la real
		# para el despacho.
		var llamadas: Array = []
		for cruda in crudas:
			var api := str(cruda.get("nombre", ""))
			llamadas.append({
				"id": str(cruda.get("id", "")),
				"api": api,
				"nombre": ChatParseador.resolverNombreHerramienta(api, herramientas),
				"args": cruda.get("args", {}),
			})
		historial.append(_turnoAsistente(contenido, llamadas, razonamiento))
		var imagenes: Array = []
		var cortado := false
		for llamada in llamadas:
			if str(llamada["nombre"]) == "":
				historial.append({
					"role": "tool",
					"tool_call_id": str(llamada["id"]),
					"content": "ERROR: Unknown function \"%s\". Available: %s" % [
						str(llamada["api"]), ", ".join(herramientas.keys())],
				})
				continue
			var resultado: Dictionary = await chat._ejecutarUnaHerramienta(
				str(llamada["nombre"]), llamada["args"])
			if chat._peticionCancelada:
				return {"success": false, "output": "ERROR: the subagent was cancelled."}
			if bool(resultado.get("cancelado", false)):
				return {"success": false, "output": "ERROR: the subagent was cancelled."}
			var salida := str(resultado.get("output", ""))
			if bool(resultado.get("denegada", false)):
				salida = "ERROR: The user denied permission to run this function. Do not retry it. " + salida
				cortado = true
			historial.append({"role": "tool", "tool_call_id": str(llamada["id"]), "content": salida})
			var suyas = resultado.get("imagenes", [])
			if typeof(suyas) == TYPE_ARRAY:
				imagenes.append_array(suyas)
		if not imagenes.is_empty():
			historial.append({"role": "user", "content": MARCA_IMAGENES, "imagenes": imagenes})
		if cortado:
			corte = "the user denied one of its function calls"
			break
	# GDScript no tiene "while ... else" (eso es de Python), asi que el tope de
	# pasos se reconoce por lo que NO paso: si el bucle se agoto sin que nadie
	# pusiera un motivo, el motivo es el tope.
	if corte == "" and ultimoTexto == "":
		corte = "it hit the step limit (%d)" % TOPE_PASOS

	if ultimoTexto == "":
		ultimoTexto = "(it did not write a final report)"
	var cabecera := "Subagent %s finished after %d step%s." % [
		etiqueta, pasos, "" if pasos == 1 else "s"]
	if corte != "":
		cabecera = "Subagent %s stopped after %d step%s: %s. What it had written so far:" % [
			etiqueta, pasos, "" if pasos == 1 else "s", corte]
	return {"success": true, "output": "%s\n\n%s" % [cabecera, ultimoTexto]}

## Una peticion del subagente: monta el streamer, espera a que termine de una de
## las dos maneras (respuesta o error) y devuelve lo que haya. La espera es un
## bucle de fotogramas a proposito: de los dos finales posibles solo uno va a
## llegar, y esperar dos senales a la vez no se puede.
static func _pedir(chat: Node, peticion: Dictionary) -> Dictionary:
	var streamer := LLMNativo.new()
	streamer.name = "Subagente"
	chat.add_child(streamer)
	var caja := {"listo": false, "error": "", "contenido": "", "llamadas": [], "razonamiento": ""}
	streamer.respuesta_completada.connect(func(contenido: String, llamadas: Array, razonamiento: String):
		caja["contenido"] = contenido
		caja["llamadas"] = llamadas
		caja["razonamiento"] = razonamiento
		caja["listo"] = true)
	streamer.error_recibido.connect(func(mensaje: String):
		caja["error"] = mensaje
		caja["listo"] = true)
	streamer.solicitar(str(peticion["url"]), peticion["cabeceras"], peticion["cuerpo"])
	# El error de una URL invalida sale dentro de solicitar(), con lo que al llegar
	# aqui la caja ya esta lista y no se espera ni un fotograma.
	while not bool(caja["listo"]):
		if chat._peticionCancelada:
			streamer.cancelar()
			break
		await chat.get_tree().process_frame
	if is_instance_valid(streamer):
		streamer.queue_free()
	var salida := caja.duplicate()
	salida["cancelado"] = chat._peticionCancelada
	return salida

## El turno del asistente con sus llamadas, en el mismo formato que guarda el
## chat. La traza de razonamiento viaja con el turno porque el upstream la exige
## en cada turno con tool_calls; su propio normalizador degrada el grupo a texto
## cuando no la hay (ver LLMNativo.normalizar_historial).
static func _turnoAsistente(contenido: String, llamadas: Array, razonamiento: String) -> Dictionary:
	var tcs: Array = []
	for llamada in llamadas:
		tcs.append({
			"id": str(llamada["id"]),
			"type": "function",
			"function": {
				"name": str(llamada["api"]),
				"arguments": JSON.stringify(llamada["args"]),
			},
		})
	var turno := {"role": "assistant", "content": contenido, "tool_calls": tcs}
	if razonamiento.strip_edges() != "":
		turno["reasoning_content"] = razonamiento
	return turno

## El prompt de sistema del subagente: las reglas de herramientas del chat (son
## las mismas herramientas y los mismos habitos), el prompt del agente si lo hay,
## el contexto del proyecto y, al final, lo que cambia por ser un subagente. El
## orden importa: lo ultimo que lee es lo que manda.
static func _promptSistema(chat: Node, agente: Dictionary, herramientas: Dictionary) -> String:
	var texto := ChatPrompts.construirSystemPromptHerramientasNativas()
	texto += Agentes.bloquePrompt(agente)
	texto += "\n\n" + chat._construirSystemPromptContexto(chat._apis.obtener_configuracion_chat())
	# El catalogo de skills solo si de verdad puede cargarlas: sin la herramienta,
	# el anuncio seria una invitacion a una llamada que no existe.
	if herramientas.has("Load skill"):
		texto += Habilidades.bloqueDisponibles()
	return texto + promptSubagente()

## Las herramientas del subagente: las que tiene el chat ahora mismo (nunca mas
## que esas: un subagente no puede saltarse el recorte que ya tiene el principal),
## recortadas por el agente que se le pida y sin las tres que no bajan.
static func _herramientasDe(chat: Node, agente: Dictionary) -> Dictionary:
	var base := Agentes.filtrarHerramientas(agente, chat._herramientasActivas())
	var salida: Dictionary = {}
	for nombre in base:
		if not HERRAMIENTAS_EXCLUIDAS.has(str(nombre)):
			salida[nombre] = base[nombre]
	return salida

## El proveedor del subagente: el del modelo que fije su agente, y si no, el que
## este contestando en el chat.
static func _proveedorDe(chat: Node, agente: Dictionary) -> String:
	var modelo := str(agente.get("modelo", "")).strip_edges()
	if modelo != "" and chat._apis:
		for prov in chat._apis.proveedores:
			if str(prov.get("model_id", "")) == modelo:
				return str(prov.get("id", ""))
	return chat._proveedorIdActual()

## Los nombres que si existen, para que un nombre mal escrito se arregle solo.
static func _catalogo() -> String:
	var nombres: Array = []
	for agente in Agentes.listar():
		nombres.append("@" + str(agente.get("nombre", "")))
	if nombres.is_empty():
		return " There are no agents defined: run it without 'agent', as a general-purpose subagent."
	return " Available: %s. Or leave 'agent' out to run a general-purpose subagent." % ", ".join(nombres)

static func _fallo(motivo: String) -> Dictionary:
	return {"success": false, "output": "ERROR: " + motivo}
