@tool
class_name ChatUIFactory
extends RefCounted

static func crearBotonTransparente(texto: String, tooltip: String) -> Button:
	var boton := Button.new()
	boton.text = texto
	boton.tooltip_text = tooltip
	boton.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	boton.add_theme_color_override("font_color", ChatEstilos.COLOR_TEXTO_SECUNDARIO)
	boton.add_theme_color_override("font_hover_color", ChatEstilos.COLOR_TEXTO_PRIMARIO)
	boton.add_theme_color_override("font_pressed_color", ChatEstilos.COLOR_TEXTO_PRIMARIO)
	var estiloVacio := StyleBoxEmpty.new()
	boton.add_theme_stylebox_override("normal", estiloVacio)
	boton.add_theme_stylebox_override("hover", estiloVacio)
	boton.add_theme_stylebox_override("pressed", estiloVacio)
	boton.add_theme_stylebox_override("focus", estiloVacio)
	boton.add_theme_stylebox_override("disabled", estiloVacio)
	return boton

## Boton de barra con icono en vez de glifo de texto. El icono se pinta con los
## colores de icono del tema (no con modulate) para que herede el hover igual que el
## texto de crearBotonTransparente: claro al pasar por encima.
##
## "respaldo" es el glifo que se usaba antes y solo se escribe si el icono no se pudo
## rasterizar, para que un fallo del SVG deje un boton feo pero pulsable en vez de un
## hueco invisible.
static func crearBotonIcono(nombreIcono: String, tooltip: String, respaldo: String = "") -> Button:
	var boton := crearBotonTransparente("", tooltip)
	boton.custom_minimum_size = ChatEscala.vec(TAMANO_BOTON_ICONO, TAMANO_BOTON_ICONO)
	boton.focus_mode = Control.FOCUS_NONE
	var textura := ChatIconos.icono(nombreIcono, TAMANO_ICONO)
	if textura == null:
		boton.text = respaldo
		return boton
	boton.icon = textura
	boton.add_theme_color_override("icon_normal_color", ChatEstilos.COLOR_TEXTO_SECUNDARIO)
	boton.add_theme_color_override("icon_hover_color", ChatEstilos.COLOR_TEXTO_PRIMARIO)
	boton.add_theme_color_override("icon_pressed_color", ChatEstilos.COLOR_TEXTO_PRIMARIO)
	boton.add_theme_color_override("icon_focus_color", ChatEstilos.COLOR_TEXTO_PRIMARIO)
	return boton

## Lado del icono de los botones de barra y lado del boton que lo contiene. El boton
## es mas grande que el dibujo para que el area pulsable sea comoda sin agrandar el
## trazo.
##
## Los dos son LOGICOS (la interfaz a escala 1.0). El dibujo se rasteriza al lado de
## verdad dentro de ChatIconos.icono(), que recibe este numero y multiplica; del boton
## se encarga el que lo construye, con ChatEscala. Separarlos importa: el trazo del
## icono se calcula con el lado logico, y si aqui se pasara ya multiplicado el pelo
## saldria mas fino de lo que toca.
const TAMANO_ICONO := 16
const TAMANO_BOTON_ICONO := 26

static func crearSeparadorVertical() -> Control:
	var linea := ColorRect.new()
	linea.color = Color(0.25, 0.25, 0.25, 0.8)
	linea.custom_minimum_size = ChatEscala.vec(1, 18)
	linea.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	return linea

static func crearBotonSelectorPlano(texto: String, tooltip: String) -> Button:
	var boton := Button.new()
	boton.text = texto + " ▾"
	boton.tooltip_text = tooltip
	boton.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	boton.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	boton.focus_mode = Control.FOCUS_NONE
	boton.mouse_default_cursor_shape = Control.CURSOR_POINTING_HAND
	boton.add_theme_color_override("font_color", ChatEstilos.COLOR_TEXTO_SECUNDARIO)
	boton.add_theme_color_override("font_hover_color", ChatEstilos.COLOR_TEXTO_PRIMARIO)
	boton.add_theme_color_override("font_pressed_color", ChatEstilos.COLOR_TEXTO_PRIMARIO)
	var vacio := StyleBoxEmpty.new()
	vacio.content_margin_left = ChatEscala.pxi(6)
	vacio.content_margin_right = ChatEscala.pxi(6)
	vacio.content_margin_top = ChatEscala.pxi(3)
	vacio.content_margin_bottom = ChatEscala.pxi(3)
	boton.add_theme_stylebox_override("normal", vacio)
	boton.add_theme_stylebox_override("hover", vacio)
	boton.add_theme_stylebox_override("pressed", vacio)
	boton.add_theme_stylebox_override("focus", vacio)
	boton.add_theme_stylebox_override("disabled", vacio)
	return boton

static func crearSelectorChip(texto: String, tooltip: String) -> Button:
	var boton := Button.new()
	boton.text = texto + "  ▾"
	boton.tooltip_text = tooltip
	boton.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	boton.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	boton.add_theme_color_override("font_color", ChatEstilos.COLOR_TEXTO_SECUNDARIO)
	boton.add_theme_color_override("font_hover_color", ChatEstilos.COLOR_TEXTO_PRIMARIO)
	boton.add_theme_color_override("font_pressed_color", ChatEstilos.COLOR_TEXTO_PRIMARIO)
	var vacio := StyleBoxEmpty.new()
	vacio.content_margin_left = ChatEscala.pxi(8)
	vacio.content_margin_right = ChatEscala.pxi(8)
	vacio.content_margin_top = ChatEscala.pxi(4)
	vacio.content_margin_bottom = ChatEscala.pxi(4)
	var hover := StyleBoxFlat.new()
	hover.bg_color = Color(0.16, 0.16, 0.16, 0.9)
	hover.corner_radius_top_left = ChatEscala.pxi(2)
	hover.corner_radius_top_right = ChatEscala.pxi(2)
	hover.corner_radius_bottom_left = ChatEscala.pxi(2)
	hover.corner_radius_bottom_right = ChatEscala.pxi(2)
	hover.content_margin_left = ChatEscala.pxi(8)
	hover.content_margin_right = ChatEscala.pxi(8)
	hover.content_margin_top = ChatEscala.pxi(4)
	hover.content_margin_bottom = ChatEscala.pxi(4)
	var pressed := hover.duplicate() as StyleBoxFlat
	pressed.bg_color = Color(0.22, 0.22, 0.22, 0.95)
	boton.add_theme_stylebox_override("normal", vacio)
	boton.add_theme_stylebox_override("hover", hover)
	boton.add_theme_stylebox_override("pressed", pressed)
	boton.add_theme_stylebox_override("focus", vacio)
	boton.add_theme_stylebox_override("disabled", vacio)
	return boton

static func estilizarPopupMenu(popup: PopupMenu) -> void:
	var fondo := StyleBoxFlat.new()
	fondo.bg_color = Color(0.105, 0.105, 0.105, 0.99)
	fondo.border_color = Color(0.22, 0.22, 0.22, 0.95)
	fondo.border_width_left = ChatEscala.pxi(1)
	fondo.border_width_top = ChatEscala.pxi(1)
	fondo.border_width_right = ChatEscala.pxi(1)
	fondo.border_width_bottom = ChatEscala.pxi(1)
	fondo.corner_radius_top_left = ChatEscala.pxi(2)
	fondo.corner_radius_top_right = ChatEscala.pxi(2)
	fondo.corner_radius_bottom_left = ChatEscala.pxi(2)
	fondo.corner_radius_bottom_right = ChatEscala.pxi(2)
	fondo.content_margin_left = ChatEscala.pxi(4)
	fondo.content_margin_right = ChatEscala.pxi(4)
	fondo.content_margin_top = ChatEscala.pxi(4)
	fondo.content_margin_bottom = ChatEscala.pxi(4)
	fondo.shadow_color = Color(0, 0, 0, 0.5)
	fondo.shadow_size = 0
	fondo.shadow_offset = Vector2(0, 2)
	popup.add_theme_stylebox_override("panel", fondo)
	var hover := StyleBoxFlat.new()
	hover.bg_color = Color(0.18, 0.18, 0.18, 0.95)
	hover.corner_radius_top_left = ChatEscala.pxi(2)
	hover.corner_radius_top_right = ChatEscala.pxi(2)
	hover.corner_radius_bottom_left = ChatEscala.pxi(2)
	hover.corner_radius_bottom_right = ChatEscala.pxi(2)
	hover.content_margin_left = ChatEscala.pxi(10)
	hover.content_margin_right = ChatEscala.pxi(10)
	hover.content_margin_top = ChatEscala.pxi(4)
	hover.content_margin_bottom = ChatEscala.pxi(4)
	popup.add_theme_stylebox_override("hover", hover)
	popup.add_theme_color_override("font_color", ChatEstilos.COLOR_TEXTO_PRIMARIO)
	popup.add_theme_color_override("font_hover_color", ChatEstilos.COLOR_TEXTO_PRIMARIO)
	popup.add_theme_color_override("font_accelerator_color", ChatEstilos.COLOR_TEXTO_SECUNDARIO)
	popup.add_theme_color_override("font_disabled_color", ChatEstilos.COLOR_TEXTO_TENUE)
	popup.add_theme_color_override("font_separator_color", ChatEstilos.COLOR_TEXTO_TENUE)

static func crearBotonPermiso(texto: String, esPrimario: bool) -> Button:
	var btn := Button.new()
	btn.text = texto
	btn.custom_minimum_size = ChatEscala.vec(80, 26)
	var normal := StyleBoxFlat.new()
	if esPrimario:
		normal.bg_color = Color(0.18, 0.26, 0.18, 1.0)
		normal.border_color = Color(0.35, 0.5, 0.35, 1.0)
		btn.add_theme_color_override("font_color", Color(0.78, 0.9, 0.78, 1.0))
	else:
		normal.bg_color = Color(0.22, 0.14, 0.14, 1.0)
		normal.border_color = Color(0.45, 0.3, 0.3, 1.0)
		btn.add_theme_color_override("font_color", Color(0.85, 0.72, 0.72, 1.0))
	normal.border_width_left = ChatEscala.pxi(1)
	normal.border_width_top = ChatEscala.pxi(1)
	normal.border_width_right = ChatEscala.pxi(1)
	normal.border_width_bottom = ChatEscala.pxi(1)
	normal.corner_radius_top_left = ChatEscala.pxi(2)
	normal.corner_radius_top_right = ChatEscala.pxi(2)
	normal.corner_radius_bottom_left = ChatEscala.pxi(2)
	normal.corner_radius_bottom_right = ChatEscala.pxi(2)
	normal.content_margin_left = ChatEscala.pxi(10)
	normal.content_margin_right = ChatEscala.pxi(10)
	normal.content_margin_top = ChatEscala.pxi(4)
	normal.content_margin_bottom = ChatEscala.pxi(4)
	var hover := normal.duplicate() as StyleBoxFlat
	if esPrimario:
		hover.bg_color = Color(0.22, 0.32, 0.22, 1.0)
		hover.border_color = Color(0.45, 0.62, 0.45, 1.0)
	else:
		hover.bg_color = Color(0.28, 0.18, 0.18, 1.0)
		hover.border_color = Color(0.55, 0.38, 0.38, 1.0)
	var pressed := normal.duplicate() as StyleBoxFlat
	pressed.bg_color = normal.bg_color.darkened(0.1)
	btn.add_theme_stylebox_override("normal", normal)
	btn.add_theme_stylebox_override("hover", hover)
	btn.add_theme_stylebox_override("pressed", pressed)
	btn.add_theme_stylebox_override("focus", normal)
	return btn

## El boton de una tarjeta del chat que no es una pregunta de permisos -la de
## actualizar el plugin, sin ir mas lejos-: el mismo cuerpo que los de permiso
## pero en gris, que es lo que dice el panel, sin verde ni rojo que ahi no
## significan nada.
static func crearBotonTarjeta(texto: String, esPrimario: bool) -> Button:
	var btn := Button.new()
	btn.text = texto
	btn.custom_minimum_size = ChatEscala.vec(80, 26)
	var normal := StyleBoxFlat.new()
	if esPrimario:
		normal.bg_color = Color(0.21, 0.21, 0.21, 1.0)
		normal.border_color = Color(0.42, 0.42, 0.42, 1.0)
		btn.add_theme_color_override("font_color", ChatEstilos.COLOR_TEXTO_PRIMARIO)
	else:
		normal.bg_color = Color(0.16, 0.16, 0.16, 1.0)
		normal.border_color = Color(0.27, 0.27, 0.27, 1.0)
		btn.add_theme_color_override("font_color", ChatEstilos.COLOR_TEXTO_SECUNDARIO)
	btn.add_theme_color_override("font_disabled_color", ChatEstilos.COLOR_TEXTO_TENUE)
	normal.border_width_left = ChatEscala.pxi(1)
	normal.border_width_top = ChatEscala.pxi(1)
	normal.border_width_right = ChatEscala.pxi(1)
	normal.border_width_bottom = ChatEscala.pxi(1)
	normal.corner_radius_top_left = ChatEscala.pxi(2)
	normal.corner_radius_top_right = ChatEscala.pxi(2)
	normal.corner_radius_bottom_left = ChatEscala.pxi(2)
	normal.corner_radius_bottom_right = ChatEscala.pxi(2)
	normal.content_margin_left = ChatEscala.pxi(10)
	normal.content_margin_right = ChatEscala.pxi(10)
	normal.content_margin_top = ChatEscala.pxi(4)
	normal.content_margin_bottom = ChatEscala.pxi(4)
	var hover := normal.duplicate() as StyleBoxFlat
	hover.bg_color = normal.bg_color.lightened(0.06)
	hover.border_color = normal.border_color.lightened(0.12)
	var pressed := normal.duplicate() as StyleBoxFlat
	pressed.bg_color = normal.bg_color.darkened(0.08)
	var disabled := normal.duplicate() as StyleBoxFlat
	disabled.bg_color = normal.bg_color.darkened(0.12)
	disabled.border_color = normal.border_color.darkened(0.2)
	btn.add_theme_stylebox_override("normal", normal)
	btn.add_theme_stylebox_override("hover", hover)
	btn.add_theme_stylebox_override("pressed", pressed)
	btn.add_theme_stylebox_override("disabled", disabled)
	btn.add_theme_stylebox_override("focus", normal)
	return btn

static func crearBotonChipContexto(texto: String, tooltip: String) -> Button:
	var boton := Button.new()
	boton.text = texto
	boton.tooltip_text = tooltip
	boton.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	boton.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	boton.add_theme_color_override("font_color", ChatEstilos.COLOR_TEXTO_SECUNDARIO)
	boton.add_theme_color_override("font_hover_color", ChatEstilos.COLOR_TEXTO_PRIMARIO)
	boton.add_theme_color_override("font_pressed_color", ChatEstilos.COLOR_TEXTO_PRIMARIO)
	var normal := StyleBoxFlat.new()
	normal.bg_color = Color(0.13, 0.13, 0.13, 0.95)
	normal.border_color = Color(0.22, 0.22, 0.22, 0.95)
	normal.border_width_left = ChatEscala.pxi(1)
	normal.border_width_top = ChatEscala.pxi(1)
	normal.border_width_right = ChatEscala.pxi(1)
	normal.border_width_bottom = ChatEscala.pxi(1)
	normal.corner_radius_top_left = ChatEscala.pxi(2)
	normal.corner_radius_top_right = ChatEscala.pxi(2)
	normal.corner_radius_bottom_left = ChatEscala.pxi(2)
	normal.corner_radius_bottom_right = ChatEscala.pxi(2)
	normal.content_margin_left = ChatEscala.pxi(8)
	normal.content_margin_right = ChatEscala.pxi(8)
	normal.content_margin_top = ChatEscala.pxi(3)
	normal.content_margin_bottom = ChatEscala.pxi(3)
	var hover := normal.duplicate() as StyleBoxFlat
	hover.bg_color = Color(0.17, 0.17, 0.17, 0.98)
	hover.border_color = Color(0.32, 0.32, 0.32, 1.0)
	var pressed := normal.duplicate() as StyleBoxFlat
	pressed.bg_color = Color(0.10, 0.10, 0.10, 1.0)
	boton.add_theme_stylebox_override("normal", normal)
	boton.add_theme_stylebox_override("hover", hover)
	boton.add_theme_stylebox_override("pressed", pressed)
	boton.add_theme_stylebox_override("focus", normal)
	return boton

static func crearChipArchivo(nombre: String, indice: int, callbackQuitar: Callable, ayuda: String = "") -> Control:
	var panel := PanelContainer.new()
	panel.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	if ayuda != "":
		panel.tooltip_text = ayuda
	var estilo := StyleBoxFlat.new()
	estilo.bg_color = Color(0.15, 0.15, 0.15, 0.98)
	estilo.border_color = Color(0.26, 0.26, 0.26, 1.0)
	estilo.border_width_left = ChatEscala.pxi(1)
	estilo.border_width_top = ChatEscala.pxi(1)
	estilo.border_width_right = ChatEscala.pxi(1)
	estilo.border_width_bottom = ChatEscala.pxi(1)
	estilo.corner_radius_top_left = ChatEscala.pxi(2)
	estilo.corner_radius_top_right = ChatEscala.pxi(2)
	estilo.corner_radius_bottom_left = ChatEscala.pxi(2)
	estilo.corner_radius_bottom_right = ChatEscala.pxi(2)
	estilo.content_margin_left = ChatEscala.pxi(8)
	estilo.content_margin_right = ChatEscala.pxi(6)
	estilo.content_margin_top = ChatEscala.pxi(2)
	estilo.content_margin_bottom = ChatEscala.pxi(2)
	panel.add_theme_stylebox_override("panel", estilo)
	var hbox := HBoxContainer.new()
	hbox.add_theme_constant_override("separation", ChatEscala.pxi(6))
	panel.add_child(hbox)
	var etiqueta := Label.new()
	etiqueta.text = nombre
	etiqueta.add_theme_color_override("font_color", ChatEstilos.COLOR_TEXTO_PRIMARIO)
	etiqueta.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	hbox.add_child(etiqueta)
	var btnQuitar := Button.new()
	btnQuitar.text = "✕"
	btnQuitar.tooltip_text = "Remove attachment"
	btnQuitar.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	btnQuitar.add_theme_color_override("font_color", ChatEstilos.COLOR_TEXTO_TENUE)
	btnQuitar.add_theme_color_override("font_hover_color", ChatEstilos.COLOR_TEXTO_PRIMARIO)
	var vacio := StyleBoxEmpty.new()
	btnQuitar.add_theme_stylebox_override("normal", vacio)
	btnQuitar.add_theme_stylebox_override("hover", vacio)
	btnQuitar.add_theme_stylebox_override("pressed", vacio)
	btnQuitar.add_theme_stylebox_override("focus", vacio)
	btnQuitar.pressed.connect(func(): callbackQuitar.call(indice))
	hbox.add_child(btnQuitar)
	return panel

static func crearBotonOpcionRapida(texto: String, callbackPulsar: Callable) -> Button:
	var boton := Button.new()
	boton.text = texto
	boton.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	boton.alignment = HORIZONTAL_ALIGNMENT_LEFT
	boton.focus_mode = Control.FOCUS_NONE
	boton.mouse_default_cursor_shape = Control.CURSOR_POINTING_HAND
	boton.add_theme_color_override("font_color", ChatEstilos.COLOR_TEXTO_SECUNDARIO)
	boton.add_theme_color_override("font_hover_color", ChatEstilos.COLOR_TEXTO_PRIMARIO)
	boton.add_theme_color_override("font_pressed_color", ChatEstilos.COLOR_TEXTO_PRIMARIO)
	var normal := StyleBoxFlat.new()
	normal.bg_color = Color(0, 0, 0, 0)
	normal.border_color = Color(0.22, 0.22, 0.22, 1.0)
	normal.border_width_left = ChatEscala.pxi(1)
	normal.border_width_top = ChatEscala.pxi(1)
	normal.border_width_right = ChatEscala.pxi(1)
	normal.border_width_bottom = ChatEscala.pxi(1)
	normal.corner_radius_top_left = ChatEscala.pxi(2)
	normal.corner_radius_top_right = ChatEscala.pxi(2)
	normal.corner_radius_bottom_left = ChatEscala.pxi(2)
	normal.corner_radius_bottom_right = ChatEscala.pxi(2)
	normal.content_margin_left = ChatEscala.pxi(12)
	normal.content_margin_right = ChatEscala.pxi(12)
	normal.content_margin_top = ChatEscala.pxi(8)
	normal.content_margin_bottom = ChatEscala.pxi(8)
	var hover := normal.duplicate() as StyleBoxFlat
	hover.bg_color = Color(0.14, 0.14, 0.14, 1.0)
	hover.border_color = Color(0.45, 0.45, 0.45, 1.0)
	var pressed := normal.duplicate() as StyleBoxFlat
	pressed.bg_color = Color(0.06, 0.06, 0.06, 1.0)
	boton.add_theme_stylebox_override("normal", normal)
	boton.add_theme_stylebox_override("hover", hover)
	boton.add_theme_stylebox_override("pressed", pressed)
	boton.add_theme_stylebox_override("focus", normal)
	boton.pressed.connect(func(): callbackPulsar.call(texto))
	return boton
