@tool
class_name ChatActualizaciones
extends RefCounted

## El actualizador del plugin: mirar si hay version nueva, bajarla y
## descomprimirla encima del addon.
##
## El sitio de donde se baja es un repositorio publico con una carpeta
## `versiones`: dentro, un `manifest.json` que dice cual es la ultima y donde
## esta su zip, y una carpeta por version con el zip ya compilado. Es el mismo
## patron que usa la plantilla de proyectos de Meteor.
##
## Tres reglas que no se saltan:
##
## - Nada se instala sin que el usuario lo acepte. La comprobacion automatica
##   solo mira; ensena una tarjeta y espera.
## - Nada se escribe sin que el sha256 del zip cuadre con el del manifiesto. Un
##   zip a medias deja el addon inservible y no hay vuelta atras que valga.
## - Antes de escribir se copia el addon entero (CopiasSeguridad) y solo se
##   escribe dentro de `res://addons/Dotti/`: una entrada con `..` no toca nada
##   de fuera.
##
## Lo que se baja y lo que se recuerda vive en `user://`, nunca dentro del
## proyecto.
##
## Quien decide si hay algo nuevo es `esMasNueva`, y corre dentro de la copia
## **instalada**: el plugin que compara es el que el usuario tiene, no el que
## hay publicado. Eso hace que la tabla de reglas de ahi abajo sea tambien un
## contrato entre builds, no una preferencia: cambiarla solo afecta a quien ya
## tiene la nueva, asi que un esquema nuevo no puede depender de ella para
## alcanzar a los viejos. De ahi que la puerta de verdad este tambien en el
## gateway (ver `proxy/production.mjs`).

## El manifiesto. Una linea, y es lo unico que hay que cambiar el dia que el
## repositorio de versiones cambie de sitio.
const URL_MANIFIESTO := "https://raw.githubusercontent.com/sourceNameUx/dotti-versions/main/versiones/manifest.json"

const RUTA_ESTADO := "user://dotti_actualizaciones.cfg"
const RAIZ_DESCARGAS := "user://dotti_actualizaciones/"
const RAIZ_ADDON := "res://addons/Dotti/"
const RUTA_CHAT := "res://addons/Dotti/data/scripts/Chat.gd"

## La misma lista, pero en una pagina que un humano puede abrir y donde puede
## bajar el zip con el navegador. Es la salida manual: si la instalacion desde el
## editor falla, el usuario tiene que poder llegar igual a la version nueva, o el
## bloqueo lo deja sin chat y sin forma de arreglarlo.
const URL_VERSIONES_PUBLICAS := "https://github.com/sourceNameUx/dotti-versions/tree/main/versiones"

const SEGUNDOS_DE_ESPERA := 30.0

## Una comprobacion automatica al dia como mucho.
const SEGUNDOS_AL_DIA := 86400

## Tope del zip: un addon con los binarios nativos no llega ni de lejos, y sin
## tope una respuesta rara puede llenar el disco.
const TAMANO_MAXIMO := 64 * 1024 * 1024


# --------------------------------------------------------------- la version

## La version instalada, leida de donde vive de verdad (`Chat.DOTTI_BUILD`), para
## no tener dos numeros que se puedan separar. Se lee al vuelo y no con un
## `preload`: este archivo lo carga Chat.gd, y pedirle a Chat.gd que se cargue a
## si mismo mientras se esta cargando no es cosa buena.
##
## Se guarda la primera lectura porque ahora se pregunta en cada peticion (es la
## cabecera que distingue un build viejo) y leerla cada vez es abrir y compilar
## Chat.gd por peticion. Una lectura fallida no se guarda: se vuelve a intentar.
static func instalada() -> String:
	if _instalada_leida:
		return _instalada
	var guion = load(RUTA_CHAT)
	if guion == null:
		return ""
	_instalada = str(guion.get_script_constant_map().get("DOTTI_BUILD", ""))
	_instalada_leida = true
	return _instalada


static var _instalada: String = ""
static var _instalada_leida: bool = false


## Despues de escribir el addon, lo que hay en el disco ya no es lo que se leyo.
static func olvidarInstalada() -> void:
	_instalada = ""
	_instalada_leida = false


## Los numeros de un nombre de version, en orden: "b52" -> [52], "0.2.0" ->
## [0, 2, 0]. Se sacan todos y no solo el primero para que una version con puntos
## no se quede en el cero de delante.
static func _numerosDe(version: String) -> Array:
	var numeros: Array = []
	var corrida := ""
	for i in range(String(version).length()):
		var c := String(version)[i]
		if c >= "0" and c <= "9":
			corrida += c
		elif corrida != "":
			numeros.append(int(corrida))
			corrida = ""
	if corrida != "":
		numeros.append(int(corrida))
	return numeros


## Si `candidata` es mas nueva que `actual`. Manda el numero, que es lo que hace
## que b52 sea mas nueva que b9, y se comparan trozo a trozo para que 0.2.0 sea
## mas nueva que 0.1.9.
##
## Sin numeros en alguna de las dos no se ofrece nada: comparar nombres como
## texto diria que b9 es mas nueva que b10, y una version de la que no se sabe el
## numero no es algo que se instale encima de lo que el usuario tiene.
##
## Las reglas, en orden, porque son el contrato con lo ya instalado:
##
## 1. Sin numeros en la candidata o en la actual: no. Nunca.
## 2. Una con puntos contra una sin puntos: gana la de puntos. Es la costura
##    entre el esquema viejo (`b55`) y el nuevo (`1.0`), y sin ella [1, 0]
##    perderia contra [55] y nadie con una `b` saldria de ahi jamas.
## 3. Trozo a trozo, por numero, rellenando con ceros el que sea mas corto.
##    Asi 1.001 es mas nueva que 1.0, y eso es correcto aunque sea el motivo del
##    reinicio: la 1.0 se publico despues de la 1.001 y no puede adelantarla por
##    numero, solo por la regla 2 contra las `b`. Lo que alcanza a las 1.001 ya
##    instaladas es la puerta del gateway, no esta funcion.
static func esMasNueva(candidata: String, actual: String) -> bool:
	var nueva := _numerosDe(candidata)
	var vieja := _numerosDe(actual)
	if nueva.is_empty() or vieja.is_empty():
		return false
	# Migracion de esquema: una version con puntos (1.001) es mas nueva que
	# cualquiera con el esquema viejo (b56). Sin esta regla [1, 1] perderia
	# contra [56] en la comparacion por numeros y nadie saldria nunca de la b.
	var puntos_nueva := "." in candidata
	var puntos_vieja := "." in actual
	if puntos_nueva != puntos_vieja:
		return puntos_nueva
	for i in range(maxi(nueva.size(), vieja.size())):
		var a: int = int(nueva[i]) if i < nueva.size() else 0
		var b: int = int(vieja[i]) if i < vieja.size() else 0
		if a != b:
			return a > b
	return false


# ---------------------------------------------------------------- el estado

## Lo que se recuerda entre sesiones: cuando se comprobo por ultima vez, que
## version dijo el usuario que no quiere, si la comprobacion automatica esta
## puesta y que dijo la ultima lista que respondio.
static func estado() -> Dictionary:
	var config := ConfigFile.new()
	config.load(RUTA_ESTADO)
	return {
		"automatica": bool(config.get_value("actualizaciones", "automatica", true)),
		"ultima_comprobacion": int(config.get_value("actualizaciones", "ultima_comprobacion", 0)),
		"ignorada": str(config.get_value("actualizaciones", "ignorada", "")),
		"version_nueva": str(config.get_value("actualizaciones", "version_nueva", "")),
		"notas_nueva": str(config.get_value("actualizaciones", "notas_nueva", "")),
		"obligatoria_nueva": bool(config.get_value("actualizaciones", "obligatoria_nueva", false)),
		"url_nueva": str(config.get_value("actualizaciones", "url_nueva", "")),
		"sha_nueva": str(config.get_value("actualizaciones", "sha_nueva", "")),
		"tamano_nueva": int(config.get_value("actualizaciones", "tamano_nueva", 0)),
	}


static func guardarEstado(datos: Dictionary) -> void:
	var config := ConfigFile.new()
	config.load(RUTA_ESTADO)
	for clave in datos:
		config.set_value("actualizaciones", clave, datos[clave])
	config.save(RUTA_ESTADO)


static func automatica() -> bool:
	return bool(estado().get("automatica", true))


static func ponerAutomatica(puesta: bool) -> void:
	guardarEstado({"automatica": puesta})


static func marcarComprobado() -> void:
	guardarEstado({"ultima_comprobacion": int(Time.get_unix_time_from_system())})


## Que el usuario dijo que no a esa version: se le deja de ofrecer en la tarjeta
## y en los ajustes. Lo que **no** hace es desbloquear el chat: con una version
## vieja el gateway no atiende la peticion, asi que aplazarlo solo aplaza el
## aviso. Una version mas nueva si se vuelve a ofrecer, porque es otra.
static func ignorar(version: String) -> void:
	guardarEstado({"ignorada": version})


## Apunta lo que dijo la lista, para que el chat sepa que esta atrasado aunque la
## proxima vez no haya red que preguntar. Sin esto, un gateway que rechaza por
## build viejo deja al usuario sin saber por que hasta que vuelva la conexion.
##
## Se apunta tambien de donde se baja y con que hash: la tarjeta que se pinta con
## esto tiene que poder instalar sin volver a preguntar, o el boton Install se
## quedaria diciendo que la lista no dice donde esta el archivo.
static func recordar(evaluado: Dictionary) -> void:
	if not bool(evaluado.get("ok", false)):
		return
	var hay := bool(evaluado.get("hay_nueva", false))
	guardarEstado({
		"version_nueva": str(evaluado.get("version", "")) if hay else "",
		"notas_nueva": str(evaluado.get("notas", "")) if hay else "",
		"obligatoria_nueva": bool(evaluado.get("obligatoria", false)) if hay else false,
		"url_nueva": str(evaluado.get("url", "")) if hay else "",
		"sha_nueva": str(evaluado.get("sha256", "")) if hay else "",
		"tamano_nueva": int(evaluado.get("tamano", 0)) if hay else 0,
	})


## Lo que se sabe de una version nueva sin preguntar a nadie: lo que dejo la
## ultima comprobacion buena, en las mismas claves que `evaluar`. Vacio si no hay
## nada apuntado, o si lo apuntado ya no es mas nuevo que lo instalado (el caso
## de despues de actualizar y reiniciar). Es puro: se puede probar sin red y sin
## disco.
static func pendiente() -> Dictionary:
	var guardado := estado()
	var version := str(guardado.get("version_nueva", ""))
	if version == "" or not esMasNueva(version, instalada()):
		return {}
	return {
		"ok": true,
		"hay_nueva": true,
		"version": version,
		"actual": instalada(),
		"notas": str(guardado.get("notas_nueva", "")),
		"obligatoria": bool(guardado.get("obligatoria_nueva", false)),
		"url": str(guardado.get("url_nueva", "")),
		"sha256": str(guardado.get("sha_nueva", "")),
		"tamano": int(guardado.get("tamano_nueva", 0)),
	}


## Si toca mirar sola: puesta, y con un dia entero desde la ultima vez.
static func tocaComprobar() -> bool:
	if not automatica():
		return false
	var e := estado()
	var ultima := int(e.get("ultima_comprobacion", 0))
	if ultima <= 0:
		return true
	return Time.get_unix_time_from_system() - ultima >= SEGUNDOS_AL_DIA


## Cuanto hace de algo, en palabras: la fila de la ultima comprobacion con una
## fecha cruda no dice nada, y "hace tres dias" si.
static func haceCuanto(momento: int) -> String:
	if momento <= 0:
		return "Never"
	var segundos := int(Time.get_unix_time_from_system()) - momento
	if segundos < 60:
		return "Just now"
	if segundos < 3600:
		var minutos := int(segundos / 60)
		return "%d minute%s ago" % [minutos, "" if minutos == 1 else "s"]
	if segundos < 86400:
		var horas := int(segundos / 3600)
		return "%d hour%s ago" % [horas, "" if horas == 1 else "s"]
	var dias := int(segundos / 86400)
	return "%d day%s ago" % [dias, "" if dias == 1 else "s"]


# ------------------------------------------------------------- la lectura

## El manifiesto, en las claves del plugin: {ok, hay_nueva, version, notas,
## obligatoria, url, sha256, tamano} o {ok: false, error}.
##
## La ruta del zip que trae el manifiesto es relativa al manifiesto mismo, que
## vive dentro de `versiones/` junto a los zips. Se resuelve como en el navegador
## y no contra la raiz del repositorio: asi el plugin no tiene que saber como se
## llama la carpeta para encontrarla.
##
## Es pura a proposito: recibe el JSON ya leido y la version instalada, asi que
## se puede probar sin red y sin tocar el disco.
static func evaluar(manifiesto: Dictionary, actual: String, base: String = "") -> Dictionary:
	var version := str(manifiesto.get("latest", "")).strip_edges()
	if version == "":
		return {"ok": false, "error": "The versions list does not say which one is the latest."}
	var entrada := {}
	for crudo in manifiesto.get("versions", []):
		if typeof(crudo) == TYPE_DICTIONARY and str((crudo as Dictionary).get("version", "")) == version:
			entrada = crudo
			break
	if entrada.is_empty():
		return {"ok": false, "error": "The versions list names %s but does not say where it is." % version}
	var relativo := str(entrada.get("file", "")).strip_edges()
	if relativo == "":
		return {"ok": false, "error": "Version %s has no file in the list." % version}
	var resultado := {
		"ok": true,
		"hay_nueva": esMasNueva(version, actual),
		"version": version,
		"actual": actual,
		"notas": str(entrada.get("notes", manifiesto.get("notes", ""))).strip_edges(),
		"obligatoria": bool(entrada.get("required", false)),
		"url": _urlDelArchivo(base, relativo),
		"sha256": str(entrada.get("sha256", "")).strip_edges().to_lower(),
		"tamano": int(entrada.get("size", 0)),
	}
	return resultado


## Pregunta al repositorio de versiones. Con una direccion puesta se usa esa (es
## lo que permite probarlo contra un servidor de mentira); sin ella, la del
## producto.
##
## El estado se apunta solo cuando la respuesta fue buena: un fallo de red no
## puede dejar la comprobacion marcada como hecha y no repetirse hasta manana.
## Lo que dijo la lista tambien se apunta (`recordar`), que es lo que deja al
## chat saber que esta atrasado sin volver a preguntar.
static func comprobar(nodo: Node, direccion: String = "") -> Dictionary:
	var url := direccion.strip_edges()
	if url == "":
		url = URL_MANIFIESTO
	var respuesta := await _traerJson(nodo, url)
	if not bool(respuesta.get("ok", false)):
		return respuesta
	var actual := instalada()
	var evaluado := evaluar(respuesta.get("datos", {}), actual, url)
	if bool(evaluado.get("ok", false)):
		marcarComprobado()
		recordar(evaluado)
	return evaluado


## Si esa version ya se rechazo antes. Una version mas nueva vuelve a ofrecerse.
static func yaIgnorada(version: String) -> bool:
	return str(estado().get("ignorada", "")) == version


static func _urlDelArchivo(base: String, relativo: String) -> String:
	if relativo.begins_with("http://") or relativo.begins_with("https://"):
		return relativo
	var limpia := base.strip_edges()
	var corte := limpia.rfind("/")
	if corte <= 0:
		return relativo
	return limpia.substr(0, corte) + "/" + relativo


static func _traerJson(nodo: Node, url: String) -> Dictionary:
	var peticion := HTTPRequest.new()
	peticion.timeout = SEGUNDOS_DE_ESPERA
	nodo.add_child(peticion)
	if peticion.request(url) != OK:
		peticion.queue_free()
		return {"ok": false, "error": "Could not reach %s." % url}
	var respuesta: Array = await peticion.request_completed
	peticion.queue_free()
	if int(respuesta[0]) != HTTPRequest.RESULT_SUCCESS:
		return {"ok": false, "error": "The versions list did not answer. Check the connection and try again."}
	var codigo := int(respuesta[1])
	if codigo < 200 or codigo >= 300:
		return {"ok": false, "error": "The versions list answered %d." % codigo}
	var bytes: PackedByteArray = respuesta[3]
	var leido = JSON.parse_string(bytes.get_string_from_utf8())
	if typeof(leido) != TYPE_DICTIONARY:
		return {"ok": false, "error": "The versions list is not readable."}
	return {"ok": true, "datos": leido}


# ------------------------------------------------------------ la descarga

## Baja el zip y comprueba su sha256 antes de dar nada por bueno. El archivo va
## a `user://dotti_actualizaciones/`, que es donde se puede escribir sin pedir
## permiso a nadie y donde no ensucia el proyecto.
static func descargar(nodo: Node, url: String, sha256: String) -> Dictionary:
	var destino := RAIZ_DESCARGAS + url.get_file()
	if destino.get_extension().to_lower() != "zip":
		destino += ".zip"
	DirAccess.make_dir_recursive_absolute(ProjectSettings.globalize_path(RAIZ_DESCARGAS))
	var peticion := HTTPRequest.new()
	peticion.timeout = SEGUNDOS_DE_ESPERA
	# Con `download_file` la respuesta se escribe sola en el disco y no pasa por
	# la memoria: un addon con binarios no cabe en un `PackedByteArray` con
	# gracia.
	peticion.download_file = ProjectSettings.globalize_path(destino)
	nodo.add_child(peticion)
	if peticion.request(url) != OK:
		peticion.queue_free()
		return {"ok": false, "error": "Could not reach %s." % url}
	var respuesta: Array = await peticion.request_completed
	peticion.queue_free()
	if int(respuesta[0]) != HTTPRequest.RESULT_SUCCESS:
		return {"ok": false, "error": "The download did not finish. Try again."}
	var codigo := int(respuesta[1])
	if codigo < 200 or codigo >= 300:
		return {"ok": false, "error": "The download answered %d." % codigo}
	# Con `download_file` el cuerpo no vuelve en la respuesta, asi que el tamano
	# se mira en el disco: es el unico sitio donde esta.
	var archivo := FileAccess.open(destino, FileAccess.READ)
	if archivo == null:
		return {"ok": false, "error": "The download could not be written. Nothing was installed."}
	var tamano := archivo.get_length()
	archivo.close()
	if tamano > TAMANO_MAXIMO:
		_borrar(destino)
		return {"ok": false, "error": "The download is larger than it should be. Nothing was installed."}

	var real := FileAccess.get_sha256(ProjectSettings.globalize_path(destino)).to_lower()
	var esperado := sha256.strip_edges().to_lower()
	if esperado == "":
		_borrar(destino)
		return {"ok": false, "error": "The versions list does not say what the file should hash to. Nothing was installed."}
	if real != esperado:
		_borrar(destino)
		return {
			"ok": false,
			"error": "The download does not match what the list says (expected %s, got %s). Nothing was installed." % [esperado.substr(0, 12), real.substr(0, 12)],
		}
	return {"ok": true, "ruta": destino, "sha256": real}


## Lo que hacen los dos sitios que ofrecen una version nueva -los ajustes y la
## tarjeta del chat-: bajarla e instalarla de una vez.
##
## Va aqui y no en cada pantalla para que las dos hagan exactamente lo mismo: el
## hash se comprueba siempre, porque la comprobacion vive en `descargar`.
static func instalar(nodo: Node, info: Dictionary) -> Dictionary:
	var url := str(info.get("url", "")).strip_edges()
	var sha := str(info.get("sha256", "")).strip_edges()
	if url == "" or sha == "":
		return {"ok": false, "error": "The versions list does not say where the file is. Nothing was installed."}
	var copia := await descargar(nodo, url, sha)
	if not bool(copia.get("ok", false)):
		return copia
	var resultado := aplicar(str(copia.get("ruta", "")))
	# Instalado ya no hace falta el zip: dejarlo ahi solo acumula versiones
	# viejas en user://. Si algo fallo se queda, que es lo unico que permite
	# mirarlo.
	if bool(resultado.get("ok", false)):
		_borrar(str(copia.get("ruta", "")))
	return resultado


# ------------------------------------------------------------- la escritura

## Descomprime el zip encima del addon. Solo desde el editor: en un juego
## exportado `res://` es de solo lectura y no hay nada que actualizar.
##
## Devuelve {ok, escritos, respaldo, error}.
static func aplicar(zip: String) -> Dictionary:
	if not OS.has_feature("editor"):
		return {"ok": false, "error": "The plugin can only update itself from inside the Godot editor."}
	return _descomprimir(zip)


## La escritura en si, sin la puerta del editor: es lo que se puede probar sin
## abrir el editor, y lo que deja `aplicar` cuando la puerta ya paso.
##
## Devuelve {ok, escritos, respaldo, error}, con `respaldo` de la copia entera
## del addon por si hay que volver atras.
static func _descomprimir(zip: String) -> Dictionary:
	if not FileAccess.file_exists(zip):
		return {"ok": false, "error": "The downloaded file is gone."}

	var lector := ZIPReader.new()
	if lector.open(ProjectSettings.globalize_path(zip)) != OK:
		return {"ok": false, "error": "The downloaded file is not a readable zip. Nothing was installed."}
	var entradas := lector.get_files()

	# Se mira todo antes de escribir nada: si una sola entrada no vale, no se
	# toca el addon. Media actualizacion es peor que ninguna.
	for ruta in entradas:
		var problema := _revisarEntrada(str(ruta))
		if problema != "":
			lector.close()
			return {"ok": false, "error": problema}

	var copia := CopiasSeguridad.respaldarArbol(RAIZ_ADDON, "antes de actualizar")
	var escritos := 0
	var fallos: Array = []
	for ruta in entradas:
		var relativa := str(ruta)
		# Las carpetas vienen como entradas propias; no hay nada que escribir en
		# ellas porque cada archivo crea la suya.
		if relativa.ends_with("/"):
			continue
		var bytes := lector.read_file(relativa)
		var destino := "res://" + relativa
		DirAccess.make_dir_recursive_absolute(ProjectSettings.globalize_path(destino.get_base_dir()))
		var f := FileAccess.open(destino, FileAccess.WRITE)
		if f == null:
			fallos.append(relativa)
			continue
		f.store_buffer(bytes)
		f.close()
		escritos += 1
	lector.close()

	if not fallos.is_empty():
		return {
			"ok": false,
			"escritos": escritos,
			"respaldo": str(copia),
			"error": "%d files could not be written (%s). The backup is in %s." % [fallos.size(), ", ".join(fallos.slice(0, 3)), _textoRespaldo(copia)],
		}
	# Lo que hay en el disco ya es otra version: la proxima lectura de
	# `instalada` tiene que volver al archivo y no a lo que se leyo al arrancar.
	olvidarInstalada()
	return {"ok": true, "escritos": escritos, "respaldo": _textoRespaldo(copia)}


## Lo que se le ensena al usuario cuando la copia tiene archivos. Copiar un addon
## entero deja una carpeta por archivo, asi que la ruta util es la raiz.
static func _textoRespaldo(copia: Dictionary) -> String:
	if int(copia.get("copiados", 0)) <= 0:
		return ""
	return CopiasSeguridad.RAIZ


## La entrada de un zip se escribe tal cual se lee, asi que solo pasa si es
## relativa, sin barras invertidas, sin `..` y dentro del addon. Un zip con
## `../../algo` no toca nada de fuera del addon.
static func _revisarEntrada(ruta: String) -> String:
	if ruta.strip_edges() == "":
		return "The file has an entry with no name. Nothing was installed."
	if ruta.begins_with("/") or ruta.contains(":") or ruta.contains("\\"):
		return "The file has an entry that is not a plain path (%s). Nothing was installed." % ruta
	for parte in ruta.split("/", false):
		if parte == "..":
			return "The file has an entry that climbs out of the addon (%s). Nothing was installed." % ruta
	if not ruta.begins_with("addons/Dotti/"):
		return "The file would write outside the plugin (%s). Nothing was installed." % ruta
	return ""


static func _borrar(ruta: String) -> void:
	if FileAccess.file_exists(ruta):
		DirAccess.remove_absolute(ProjectSettings.globalize_path(ruta))
