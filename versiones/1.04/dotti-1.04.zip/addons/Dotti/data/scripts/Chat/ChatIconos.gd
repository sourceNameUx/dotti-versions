@tool
class_name ChatIconos
extends RefCounted

## Iconos de Dotti.
##
## Son SVG de Lucide (https://lucide.dev) guardados como TEXTO en este archivo, no
## como .svg sueltos: asi el addon no depende del importador del proyecto (ni de sus
## ajustes de escala, ni de los .import que genera) y los nombres no dependen de
## EditorIcons, que cambian entre versiones de Godot y no existen fuera del editor.
##
## Se rasterizan en BLANCO y se tinen al pintarlos (modulate, o los colores de icono
## del tema del boton). Asi un mismo SVG sirve para el estado normal y el hover sin
## rasterizar dos veces, y el icono hereda el color de la interfaz en vez de llevarlo
## incrustado.
##
## El trazo se calcula para que en pantalla mida siempre ~1.5 px DE INTERFAZ, que es
## lo que usan los iconos del editor de Godot: a 24 px de viewBox son 1.5, y a 16 px
## son 2.25.
##
## El tamano que se pide es el logico, y de ahi sale el de verdad: un icono de 16 se
## rasteriza a los pixeles que ocupara en pantalla (16 por la escala, ver ChatEscala)
## pero el trazo se sigue calculando con el 16 de la peticion. Asi el pelo mide 1.5
## px de interfaz a cualquier escala, que es lo que hace que un icono grande se vea
## como el mismo icono mas grande y no como uno mas gordo.
##
## ---------------------------------------------------------------------------
## LICENCIAS
##
## ISC License
##
## Copyright (c) 2026 Lucide Icons and Contributors
##
## Permission to use, copy, modify, and/or distribute this software for any
## purpose with or without fee is hereby granted, provided that the above
## copyright notice and this permission notice appear in all copies.
##
## THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
## WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
## MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY
## SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
## WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION
## OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR IN
## CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
##
## El icono "plus" viene del proyecto Feather y va bajo licencia MIT:
##
## The MIT License (MIT)
##
## Copyright (c) 2013-present Cole Bemis
##
## Permission is hereby granted, free of charge, to any person obtaining a copy
## of this software and associated documentation files (the "Software"), to deal
## in the Software without restriction, including without limitation the rights
## to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
## copies of the Software, and to permit persons to whom the Software is
## furnished to do so, subject to the following conditions:
##
## The above copyright notice and this permission notice shall be included in all
## copies or substantial portions of the Software.
##
## THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
## IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
## FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
## AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
## LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
## OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
## SOFTWARE.
## ---------------------------------------------------------------------------

## Lado del viewBox de todos los SVG de abajo. El trazo y la escala se calculan a
## partir de el, asi que no se puede cambiar uno sin cambiar el otro.
const REFERENCIA := 24.0

## Grosor de trazo que se quiere ver EN PANTALLA, en pixeles. Coincide con el de los
## iconos del editor para que los nuestros no se vean ni mas gordos ni mas finos.
const TRAZO_PANTALLA := 1.5

## Los marcadores que se sustituyen al rasterizar. Van entre __ para que no choquen
## con nada del propio SVG.
const MARCA_GROSOR := "__GROSOR__"
const MARCA_COLOR := "__COLOR__"

const ICONOS := {
	"history": "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"__COLOR__\" stroke-width=\"__GROSOR__\" stroke-linecap=\"round\" stroke-linejoin=\"round\"><path d=\"M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8\"/><path d=\"M3 3v5h5\"/><path d=\"M12 7v5l4 2\"/></svg>",
	"plus": "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"__COLOR__\" stroke-width=\"__GROSOR__\" stroke-linecap=\"round\" stroke-linejoin=\"round\"><path d=\"M5 12h14\"/><path d=\"M12 5v14\"/></svg>",
	# La clave es semantica ("settings"), el dibujo es el "cog" de Lucide: su rueda
	# tiene los dientes mas separados que la de "settings" y a 16 px se lee bastante
	# mejor (el agujero del centro no se cierra).
	"settings": "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"__COLOR__\" stroke-width=\"__GROSOR__\" stroke-linecap=\"round\" stroke-linejoin=\"round\"><path d=\"M12 2v2\"/><path d=\"M12 22v-2\"/><path d=\"M2 12h2\"/><path d=\"M22 12h-2\"/><path d=\"m20.66 17-1.73-1\"/><path d=\"m20.66 7-1.73 1\"/><path d=\"m3.34 17 1.73-1\"/><path d=\"m3.34 7 1.73 1\"/><circle cx=\"12\" cy=\"12\" r=\"2\"/><circle cx=\"12\" cy=\"12\" r=\"8\"/></svg>",
	"wrench": "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"__COLOR__\" stroke-width=\"__GROSOR__\" stroke-linecap=\"round\" stroke-linejoin=\"round\"><path d=\"M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.106-3.105c.32-.322.863-.22.983.218a6 6 0 0 1-8.259 7.057l-7.91 7.91a1 1 0 0 1-2.999-3l7.91-7.91a6 6 0 0 1 7.057-8.259c.438.12.54.662.219.984z\"/></svg>",
}

## Texturas ya rasterizadas, por "nombre@tamano". Rasterizar es caro (es un
## interprete de SVG) y los mismos iconos se piden en cada tarjeta de herramienta,
## asi que sin cache un chat largo pagaria el coste una vez por tarjeta.
static var _cache: Dictionary = {}

## Textura BLANCA del icono, rasterizada justo al tamano al que se va a pintar: el
## SVG se dibuja con esa escala, no se escala despues (que emborronaria el trazo).
##
## `tamano` es el lado LOGICO, el de la interfaz a escala 1.0; el de la textura sale
## de multiplicarlo por la escala (ver la cabecera). Devuelve null si el icono no
## esta en ICONOS o si ThorVG no pudo con el SVG; quien llama decide que hacer
## entonces.
static func icono(nombre: String, tamano: int = 16) -> Texture2D:
	var logico := maxi(tamano, 1)
	var lado := ChatEscala.pxi(logico)
	var clave := "%s@%d" % [nombre, lado]
	if _cache.has(clave):
		return _cache[clave]
	var fuente := str(ICONOS.get(nombre, ""))
	if fuente == "":
		push_warning("Dotti: no hay icono llamado '%s'." % nombre)
		return null
	# El trazo se engorda al reducir para que en pantalla mida lo mismo: si no, a
	# 14 px el pelo de 2 unidades del viewBox se queda en poco mas de un pixel. Va
	# con el lado logico, no con el de la textura: el pelo crece con la interfaz en
	# vez de adelgazarse al lado de ella.
	var grosor := TRAZO_PANTALLA * REFERENCIA / float(logico)
	var svg := fuente.replace(MARCA_COLOR, "#ffffff").replace(MARCA_GROSOR, "%.3f" % grosor)
	var img := Image.new()
	var err := img.load_svg_from_string(svg, float(lado) / REFERENCIA)
	if err != OK:
		push_warning("Dotti: no se pudo rasterizar el icono '%s' (error %d)." % [nombre, err])
		return null
	var textura := ImageTexture.create_from_image(img)
	_cache[clave] = textura
	return textura

## Nombres disponibles, para pruebas y para no escribir mal un nombre en el chat.
static func nombres() -> Array:
	return ICONOS.keys()
