@tool
class_name Secretos
extends RefCounted

## Los textos propietarios del plugin, abiertos desde el nucleo nativo.
##
## El briefing de sesion, los prompts de sistema, las reglas de herramientas y
## las plantillas de compactacion ya no son constantes escritas en el addon:
## viajan cifrados en `data/secrets/*.bin` y se abren aqui, en memoria. Abrir un
## archivo de texto del plugin ya no ensena como esta escrito.
##
## La clase nativa no se nombra nunca en el codigo: se busca por `ClassDB`. Si se
## nombrara, el addon no cargaria en una plataforma sin binario -GDScript no
## compila una referencia a una clase que no existe- y el fallo saldria por donde
## menos se ve. Buscandola por nombre, sin extension esto sigue cargando y lo que
## hay es un aviso claro.
##
## Quien avisa de verdad es el chat: mira `faltan()` al arrancar y no manda nada
## a medias. Aqui solo se dice lo que hay.

const CARPETA := "res://addons/Dotti/data/secrets/"

## El nombre de la clase nativa, atado a `dotti_secrets.cpp`.
const CLASE := "DottiSecrets"

## Los secretos que el plugin necesita para funcionar. Si falta uno, el chat lo
## dice y no arranca a medias: medio prompt es peor que ninguno, porque el modelo
## contesta sin las reglas y el usuario no sabe por que.
const NECESARIOS := [
	"prompt_sesion",
	"prompt_sistema_agente",
	"prompt_sistema_plan",
	"prompt_herramientas_cabecera",
	"prompt_herramientas_nativas",
	"prompt_opciones_rapidas",
	"prompt_resumen_plantilla",
	"prompt_resumen_actualizar",
	"prompt_subagente",
]

## El texto se abre una vez por sesion: el briefing son 13 KB y se pide en cada
## peticion.
static var _abiertos: Dictionary = {}
static var _nativo: Object = null
static var _buscado := false


## La instancia del nucleo nativo, o null si no esta. Se busca una sola vez: si
## no estaba al principio de la sesion, no aparece a mitad.
static func nativo() -> Object:
	if _buscado:
		return _nativo
	_buscado = true
	if not ClassDB.class_exists(CLASE):
		return null
	if not ClassDB.can_instantiate(CLASE):
		return null
	_nativo = ClassDB.instantiate(CLASE)
	return _nativo


## Si el nucleo nativo esta cargado. Es lo que distingue "no hay binario para esta
## plataforma" de "el binario esta pero le falta un secreto".
static func disponible() -> bool:
	return nativo() != null


## El texto de un secreto, ya abierto. Vacio si no esta.
static func abrir(nombre: String) -> String:
	if _abiertos.has(nombre):
		return str(_abiertos[nombre])
	var nucleo := nativo()
	if nucleo == null:
		return ""
	var texto := str(nucleo.call("abrir", nombre))
	if texto == "":
		push_warning("Dotti: el secreto '%s' no se pudo abrir. Vuelve a sellarlo con scripts/sellar_secretos.gd." % nombre)
		return ""
	_abiertos[nombre] = texto
	return texto


## Si ese secreto se puede abrir desde donde corre esto.
static func hay(nombre: String) -> bool:
	var nucleo := nativo()
	if nucleo == null:
		return false
	return bool(nucleo.call("hay", nombre))


## Los secretos que hay, tal como los ve el nucleo.
static func nombres() -> PackedStringArray:
	var nucleo := nativo()
	if nucleo == null:
		return PackedStringArray()
	var lista: Variant = nucleo.call("nombres")
	if typeof(lista) != TYPE_PACKED_STRING_ARRAY:
		return PackedStringArray()
	return lista


## Lo que falta de `NECESARIOS`. Lista vacia es que el plugin puede trabajar.
static func faltan() -> PackedStringArray:
	var faltan := PackedStringArray()
	if not disponible():
		return PackedStringArray(NECESARIOS)
	for nombre in NECESARIOS:
		if not hay(nombre):
			faltan.append(nombre)
	return faltan


## Un aviso de una linea, para el mensaje que ve el usuario. Dice que pasa y que
## hacer, sin hablar de binarios ni de plataformas: el usuario no tiene por que
## saber como se llama la pieza que falta.
static func avisoDeLoQueFalta() -> String:
	var faltan := faltan()
	if faltan.is_empty():
		return ""
	if not disponible():
		return "Dotti's native core did not load, so its prompts are not available. Reinstall the plugin, or install the build for this platform."
	return "Dotti could not open %d of its own texts (%s). Reinstall the plugin or run scripts/sellar_secretos.gd." % [faltan.size(), ", ".join(faltan.slice(0, 3))]


## Lo que se ha abierto en esta sesion, para las pruebas y para los ajustes.
static func abiertos() -> Array:
	var lista: Array = _abiertos.keys()
	lista.sort()
	return lista


## Olvida lo abierto. Lo usan las pruebas: en una sesion normal un secreto se abre
## una vez y no cambia.
static func olvidar() -> void:
	_abiertos.clear()
