@tool
class_name ChatEscala
extends RefCounted

## Escala de la interfaz del chat.
##
## El editor multiplica por su "Display Scale" todo lo que sale del tema: las
## fuentes, los margenes de los botones, el alto de las casillas. Lo que NO toca
## es ni una constante escrita en pixeles dentro del codigo, y Dotti dibuja a mano
## casi todo lo suyo: los iconos, el lado de los botones de barra, las
## separaciones, el campo de texto, los rellenos de las tarjetas. El resultado es
## el que se ve en una pantalla grande: el texto grande y los iconos de 16 px
## diminutos al lado. Este archivo es el unico numero que hace falta para
## arreglarlo.
##
## De donde sale el factor, en este orden:
##
## 1. Lo que el usuario haya elegido en Ajustes > Interface, si eligio algo que no
##    sea "Auto". Es la salida para el caso que el resto no cubre: una pantalla
##    grande con el editor a escala 1.0, donde no hay nada que heredar y el
##    usuario quiere la interfaz mas grande igual.
## 2. La escala del editor (`EditorInterface.get_editor_scale()`), que es la que
##    el usuario ya ajusto para leer comodo. Heredarla es lo que hace que el chat
##    no desentone con el resto de la interfaz.
## 3. 1.0, que es lo que hay fuera del editor: en el banco de pruebas headless y
##    en cualquier sitio donde no exista el singleton. A 1.0 todas las cuentas de
##    aqui devuelven el mismo numero que estaba escrito a mano, asi que correr sin
##    editor es exactamente como corria antes de que esto existiera.
##
## El singleton se busca con `Engine.is_editor_hint()` y `Engine.has_singleton`,
## no nombrando la clase: un guion que nombre una clase que no esta no compila, y
## `EditorInterface` no existe fuera del editor. Es la misma regla que sigue
## `Secretos` con el nucleo nativo.

## Donde se guarda lo que el usuario eligio. Fuera del proyecto, como el resto de
## lo suyo.
const RUTA_AJUSTES := "user://dotti_interfaz.cfg"
const SECCION := "interfaz"
const CLAVE := "escala"

## El valor guardado que significa "la del editor". Cero no es una escala
## valida, asi que sirve de centinela y ademas es lo que contesta un fichero que
## todavia no existe.
const AUTOMATICA := 0.0

## Tope por arriba y por abajo. El de abajo es 1.0 a proposito: por debajo de 1.0
## el chat se vuelve ilegible antes de que sea util, y el editor tampoco ofrece
## menos. El de arriba acota lo que puede crecer una ventana antes de que deje de
## caber en cualquier pantalla.
const MINIMO := 1.0
const MAXIMO := 3.0

## Las escalas que ofrece Ajustes, con su etiqueta. La primera es la automatica.
const OPCIONES := [
	{"valor": AUTOMATICA, "texto": "Auto"},
	{"valor": 1.0, "texto": "1.00x"},
	{"valor": 1.25, "texto": "1.25x"},
	{"valor": 1.5, "texto": "1.50x"},
	{"valor": 2.0, "texto": "2.00x"},
]

## El factor ya resuelto. -1.0 es "todavia no se ha mirado". Se cachea porque
## `px()` se llama decenas de veces al construir el panel y cada llamada leeria
## el fichero de ajustes.
static var _factor: float = -1.0

## El factor de escala de esta sesion.
static func factor() -> float:
	if _factor > 0.0:
		return _factor
	_factor = _resolver()
	return _factor


## Un lado en pixeles de interfaz, redondeado a pixel entero: el SVG se rasteriza
## a este tamano y un lado con decimales sale borroso.
static func px(n: float) -> float:
	return roundf(n * factor())


## Lo mismo, para lo que pide un entero (separaciones y margenes del tema).
static func pxi(n: int) -> int:
	return int(roundf(float(n) * factor()))


## Un par de medidas, para los `custom_minimum_size`.
static func vec(x: float, y: float) -> Vector2:
	return Vector2(px(x), px(y))


## Lo que el usuario eligio, o AUTOMATICA si no eligio nada.
static func guardada() -> float:
	var ajustes := ConfigFile.new()
	if ajustes.load(RUTA_AJUSTES) != OK:
		return AUTOMATICA
	return clampf(float(ajustes.get_value(SECCION, CLAVE, AUTOMATICA)), AUTOMATICA, MAXIMO)


## Guarda la eleccion y olvida el factor cacheado, para que lo que se construya
## despues de esto (la ventana de ajustes, sin ir mas lejos) ya salga con ella.
## El chat y los iconos que ya estan pintados no se rehacen solos: por eso la
## pagina avisa de que hay que reiniciar, igual que hace el propio editor cuando
## se le cambia la escala.
static func guardar(valor: float) -> void:
	var ajustes := ConfigFile.new()
	ajustes.load(RUTA_AJUSTES)
	ajustes.set_value(SECCION, CLAVE, clampf(valor, AUTOMATICA, MAXIMO))
	ajustes.save(RUTA_AJUSTES)
	olvidar()


## Tira el factor cacheado. Lo usan `guardar()` y las pruebas, que necesitan
## forzar un factor sin depender de lo que haya en el disco.
static func olvidar() -> void:
	_factor = -1.0


## El factor resuelto, escrito como se lee en la pagina de ajustes ("1.50x").
static func etiqueta() -> String:
	return "%.2fx" % factor()


## La escala que ofrece el editor, sin contar lo que el usuario haya elegido aqui.
## Es el numero que se ensena entre parentesis en la opcion "Auto", y sirve ademas
## de diagnostico: con el editor a 2.00 y esto diciendo 1.00, lo que falla es la
## lectura del singleton, no el dibujo.
static func delEditor() -> float:
	return clampf(_escalaDelEditor(), MINIMO, MAXIMO)


## De donde salio el factor, para poder decirlo en los ajustes.
static func origen() -> String:
	if guardada() != AUTOMATICA:
		return "chosen"
	if delEditor() != 1.0:
		return "editor"
	return "default"


static func _resolver() -> float:
	var elegida := guardada()
	if elegida > AUTOMATICA:
		return clampf(elegida, MINIMO, MAXIMO)
	return clampf(_escalaDelEditor(), MINIMO, MAXIMO)


## La escala del editor, o 1.0 si no hay editor que preguntar.
##
## Las dos guardas son necesarias y por motivos distintos: fuera del editor
## `get_singleton` suelta un ERROR y devuelve nulo -`has_singleton` contesta que
## si aunque el singleton no se pueda sacar-, asi que primero se pregunta si
## estamos en el editor y solo despues se toca. Un `ERROR` en cada arranque del
## banco de pruebas es ruido que tapa los de verdad.
static func _escalaDelEditor() -> float:
	if not Engine.is_editor_hint():
		return 1.0
	if not Engine.has_singleton("EditorInterface"):
		return 1.0
	var editor: Object = Engine.get_singleton("EditorInterface")
	if editor == null or not editor.has_method("get_editor_scale"):
		return 1.0
	return float(editor.call("get_editor_scale"))
