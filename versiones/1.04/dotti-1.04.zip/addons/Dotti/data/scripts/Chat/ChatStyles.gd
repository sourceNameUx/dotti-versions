@tool
class_name ChatEstilos
extends RefCounted

const COLOR_ACENTO := Color(0.88, 0.88, 0.88, 1.0)
const COLOR_ACENTO_SUAVE := Color(0.60, 0.60, 0.60, 0.75)
const COLOR_USUARIO_BG := Color(0.16, 0.16, 0.16, 0.98)
const COLOR_USUARIO_BORDE := Color(0.28, 0.28, 0.28, 0.85)
const COLOR_ASISTENTE_BG := Color(0.098, 0.098, 0.098, 0.96)
const COLOR_ASISTENTE_BORDE := Color(0.22, 0.22, 0.22, 0.75)
const COLOR_TEXTO_PRIMARIO := Color(0.90, 0.90, 0.90, 1.0)
const COLOR_TEXTO_SECUNDARIO := Color(0.62, 0.62, 0.62, 1.0)
const COLOR_TEXTO_TENUE := Color(0.43, 0.43, 0.43, 1.0)
const COLOR_PANEL_FONDO := Color(0.094, 0.094, 0.094, 0.96)
const COLOR_PANEL_BORDE := Color(0.20, 0.20, 0.20, 0.9)
const COLOR_SPINNER := Color(0.80, 0.80, 0.80, 1.0)
const COLOR_ESTADO_OK := Color(0.78, 0.78, 0.78, 1.0)
const COLOR_ESTADO_WARN := Color(0.72, 0.68, 0.60, 1.0)
const COLOR_ESTADO_ERR := Color(0.75, 0.50, 0.50, 1.0)

static func crearEstiloBarraSuperior() -> StyleBoxFlat:
	var estilo := StyleBoxFlat.new()
	estilo.bg_color = Color(0, 0, 0, 0)
	estilo.border_width_left = 0
	estilo.border_width_top = 0
	estilo.border_width_right = 0
	estilo.border_width_bottom = 0
	estilo.corner_radius_top_left = 0
	estilo.corner_radius_top_right = 0
	estilo.corner_radius_bottom_left = 0
	estilo.corner_radius_bottom_right = 0
	estilo.content_margin_left = ChatEscala.pxi(4)
	estilo.content_margin_right = ChatEscala.pxi(4)
	estilo.content_margin_top = ChatEscala.pxi(4)
	estilo.content_margin_bottom = ChatEscala.pxi(4)
	estilo.shadow_size = 0
	return estilo

static func crearEstiloMarcoNormal() -> StyleBoxFlat:
	var estilo := StyleBoxFlat.new()
	estilo.bg_color = Color(0.082, 0.082, 0.082, 0.98)
	estilo.border_color = COLOR_PANEL_BORDE
	estilo.border_width_left = ChatEscala.pxi(1)
	estilo.border_width_top = ChatEscala.pxi(1)
	estilo.border_width_right = ChatEscala.pxi(1)
	estilo.border_width_bottom = ChatEscala.pxi(1)
	estilo.corner_radius_top_left = ChatEscala.pxi(2)
	estilo.corner_radius_top_right = ChatEscala.pxi(2)
	estilo.corner_radius_bottom_left = ChatEscala.pxi(2)
	estilo.corner_radius_bottom_right = ChatEscala.pxi(2)
	estilo.content_margin_left = ChatEscala.pxi(12)
	estilo.content_margin_right = ChatEscala.pxi(10)
	estilo.content_margin_top = ChatEscala.pxi(8)
	estilo.content_margin_bottom = ChatEscala.pxi(8)
	estilo.shadow_color = Color(0, 0, 0, 0.4)
	estilo.shadow_size = 0
	estilo.shadow_offset = Vector2(0, 2)
	return estilo

## Marco del razonamiento: casi sin marco. El usuario lo pidio mas transparente y
## mas minimalista, asi que en vez de una caja con borde va un velo apenas visible
## y una barra fina a la izquierda que lo distingue del fondo sin gritar.
static func crearEstiloRazonamiento() -> StyleBoxFlat:
	var estilo := StyleBoxFlat.new()
	estilo.bg_color = Color(1, 1, 1, 0.022)
	estilo.border_color = Color(1, 1, 1, 0.10)
	estilo.border_width_left = ChatEscala.pxi(2)
	estilo.border_width_top = 0
	estilo.border_width_right = 0
	estilo.border_width_bottom = 0
	estilo.corner_radius_top_left = ChatEscala.pxi(3)
	estilo.corner_radius_top_right = ChatEscala.pxi(3)
	estilo.corner_radius_bottom_left = ChatEscala.pxi(3)
	estilo.corner_radius_bottom_right = ChatEscala.pxi(3)
	estilo.content_margin_left = ChatEscala.pxi(10)
	estilo.content_margin_right = ChatEscala.pxi(6)
	estilo.content_margin_top = ChatEscala.pxi(4)
	estilo.content_margin_bottom = ChatEscala.pxi(4)
	estilo.shadow_size = 0
	return estilo

