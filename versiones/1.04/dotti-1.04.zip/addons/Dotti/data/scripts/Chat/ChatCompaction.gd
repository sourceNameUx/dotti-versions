@tool
class_name ChatCompactacion
extends RefCounted

## Compactacion del contexto (P8). Cuando la conversacion se acerca a la ventana
## del modelo, lo viejo se resume en un checkpoint y deja de enviarse. El resumen
## es ESTADO del chat, no un mensaje: se vuelve a inyectar en el prompt de sistema
## en cada peticion (ver ChatPrompts.bloqueResumen), y asi sobrevive a reabrir el
## chat y a que la conversacion se recorte.
##
## El historial NO se toca: el usuario sigue viendo su conversacion entera, lo que
## se acorta es lo que viaja al modelo. Los numeros son los de opencode: un margen
## por debajo de la ventana (lo que ocupara la respuesta que viene) y una cola
## reciente que no se resume, que es donde esta el trabajo en curso.

## Hueco libre que hay que dejar por debajo de la ventana del modelo antes de
## compactar: minimo, porque la salida configurada puede pedir mas.
const MARGEN := 20000
## Tokens de conversacion reciente que se conservan tal cual, sin resumir.
const CONSERVADOS := 8000
## Tope de la respuesta del resumen.
const MAX_SALIDA_RESUMEN := 4096
## Tope de cada resultado de herramienta dentro de lo que se resume: un archivo
## entero leido no cabe (ni aporta al resumen).
const MAX_CARACTERES_RESULTADO := 2000

## Cuanto ocupa algo, en tokens, a ojo: 4 caracteres por token. Es la cuenta de
## opencode (Token.estimate) y sirve para decidir, no para informar al usuario.
static func estimarTokens(valor: Variant) -> int:
	var texto := valor if typeof(valor) == TYPE_STRING else JSON.stringify(valor)
	return int(ceil(float(str(texto).length()) / 4.0))

## Si la conversacion que se va a enviar ya no deja sitio para la respuesta. El
## uso que manda el proveedor manda sobre la estimacion, pero cuidado: es el de la
## peticion ANTERIOR, asi que se coge el mayor de los dos. Con ventana desconocida
## no se compacta: sin saber donde esta el techo, cualquier recorte es a ciegas.
static func debeCompactar(modelo: String, uso: Dictionary, estimado: int, salida: int) -> bool:
	var ventana := ChatModelos.contexto_max(modelo)
	if ventana <= 0:
		return false
	var reserva := maxi(salida, MARGEN)
	if reserva >= ventana:
		return false
	var gastado := maxi(absi(int(uso.get("total", 0))), estimado)
	return gastado > ventana - reserva

## Indice del primer mensaje que se conserva tal cual. Se camina desde el final
## sumando lo que ocupa cada mensaje hasta pasarse del presupuesto, que es la
## cuenta de opencode: la cola reciente es donde esta el trabajo en curso y no se
## toca. Despues el corte se aparta de los grupos de herramientas (ver
## `_alejarDeGrupos`). Devuelve 0 cuando no hay nada que resumir.
static func corteDeMensajes(mensajes: Array, tokensConservados: int = CONSERVADOS) -> int:
	if mensajes.size() < 3:
		return 0
	var total := 0
	var corte := 1
	for i in range(mensajes.size() - 1, 0, -1):
		var peso := estimarTokens(mensajes[i])
		# El ultimo mensaje entra siempre, aunque el solo pase del presupuesto.
		if total > 0 and total + peso > tokensConservados:
			break
		total += peso
		corte = i
	if corte <= 1:
		return 0
	corte = _alejarDeGrupos(mensajes, corte)
	# Si apartarse del grupo se llevo por delante hasta el ultimo mensaje, no hay
	# corte posible: mas vale no compactar que dejar la peticion sin cola.
	if corte >= mensajes.size():
		return 0
	return corte

## Corte de la compactacion a mano (el clic en el contador). Si la conversacion
## todavia no llega al presupuesto de cola, se resume todo lo anterior al ultimo
## turno del usuario, que es lo que uno espera cuando la pide a mano.
static func corteManual(mensajes: Array) -> int:
	var corte := corteDeMensajes(mensajes)
	if corte > 1:
		return corte
	var ultimo := 0
	for i in range(1, mensajes.size()):
		if esUsuarioReal(mensajes[i]):
			ultimo = i
	if ultimo <= 1:
		return 0
	var ajustado := _alejarDeGrupos(mensajes, ultimo)
	if ajustado >= mensajes.size():
		return 0
	return ajustado

## Un corte no puede caer ENTRE una llamada y su resultado: el upstream rechaza la
## peticion entera ("tool_use ids were found without tool_result blocks") si un
## resultado viaja sin la llamada que lo pide. Si el corte cae ahi, se adelanta
## hasta dejar el grupo entero resumido. El otro lado no puede romperse: una
## llamada que se conserva siempre tiene sus resultados detras, o sea dentro.
static func _alejarDeGrupos(mensajes: Array, corte: int) -> int:
	var llamadaDe := {}
	for i in range(mensajes.size()):
		for id in _idsDeLlamada(mensajes[i]):
			llamadaDe[id] = i
	var i := corte
	while i < mensajes.size():
		var id := _idDeResultado(mensajes[i])
		if id != "" and llamadaDe.has(id) and int(llamadaDe[id]) < corte:
			i += 1
			continue
		break
	return i

## Ids de las llamadas que pide un mensaje del asistente.
static func _idsDeLlamada(mensaje: Variant) -> Array:
	if typeof(mensaje) != TYPE_DICTIONARY:
		return []
	var m: Dictionary = mensaje
	if str(m.get("role", "")) != "assistant" or not m.has("tool_calls"):
		return []
	var llamadas = m["tool_calls"]
	if typeof(llamadas) != TYPE_ARRAY:
		return []
	var ids: Array = []
	for llamada in llamadas:
		ids.append(LLMNativo.idDeToolCall(llamada))
	return ids

## Id de la llamada que responde un mensaje, o "" si no es un resultado.
static func _idDeResultado(mensaje: Variant) -> String:
	if typeof(mensaje) != TYPE_DICTIONARY:
		return ""
	var m: Dictionary = mensaje
	if str(m.get("role", "")) != "tool":
		return ""
	return str(m.get("tool_call_id", ""))

## Turno escrito por el usuario de verdad: ni el prompt de sistema ni los mensajes
## internos que llevan resultados de herramientas o imagenes de acarreo.
static func esUsuarioReal(mensaje: Variant) -> bool:
	if typeof(mensaje) != TYPE_DICTIONARY:
		return false
	var m: Dictionary = mensaje
	if str(m.get("role", "")) != "user":
		return false
	if bool(m.get("system", false)):
		return false
	var contenido := str(m.get("content", ""))
	return not contenido.begins_with("[HIDDEN_RESULT]") and not contenido.begins_with("[ATTACHED_IMAGES]")

## La conversacion en texto plano y con etiquetas, para que el modelo la resuma:
## los mensajes del protocolo (llamadas y resultados de herramientas) se escriben
## como se leen, no como JSON crudo. El razonamiento NO entra: abulta y lo que
## importa (que se hizo y que falta) ya esta en las llamadas y sus resultados.
static func serializar(mensajes: Array, desde: int, hasta: int) -> String:
	var lineas: Array[String] = []
	for i in range(maxi(desde, 0), mini(hasta, mensajes.size())):
		var texto := serializarMensaje(mensajes[i])
		if texto != "":
			lineas.append(texto)
	return "\n\n".join(lineas)

static func serializarMensaje(mensaje: Variant) -> String:
	if typeof(mensaje) != TYPE_DICTIONARY:
		return ""
	var m: Dictionary = mensaje
	if bool(m.get("system", false)):
		return ""
	var contenido := str(m.get("content", "")).strip_edges()
	if contenido == "<null>":
		contenido = ""
	match str(m.get("role", "")):
		"user":
			var partes: Array[String] = []
			if contenido.begins_with("[HIDDEN_RESULT]"):
				var salida := contenido.trim_prefix("[HIDDEN_RESULT]").strip_edges()
				partes.append("[Tool result]: " + _recortar(salida))
			elif contenido != "" and not contenido.begins_with("[ATTACHED_IMAGES]"):
				partes.append("[User]: " + contenido)
			var imagenes := _lineaImagenes(m)
			if imagenes != "":
				partes.append(imagenes)
			return "\n".join(partes)
		"assistant":
			var partes: Array[String] = []
			if contenido != "":
				partes.append("[Assistant]: " + contenido)
			var llamadas = m.get("tool_calls", [])
			if typeof(llamadas) == TYPE_ARRAY:
				for llamada in llamadas:
					partes.append("[Assistant tool call]: %s(%s)" % [
						LLMNativo.nombreDeToolCall(llamada),
						JSON.stringify(LLMNativo.argsDeToolCall(llamada)),
					])
			return "\n".join(partes)
		"tool":
			# En el camino nativo el resultado ya viene limpio; en el de texto lleva
			# delante el prefijo interno, que al resumen no le dice nada.
			var salida := contenido.trim_prefix("[HIDDEN_RESULT]").strip_edges()
			if salida == "":
				return "[Tool result]: (empty)"
			return "[Tool result]: " + _recortar(salida)
	return ""

## La peticion del resumen. Sin resumen previo es un resumen nuevo; con uno, las
## instrucciones de fusion, que es lo que hace que el checkpoint no se degrade
## turno a turno: lo que no se copie al nuevo, se pierde.
static func construirPrompt(conversacion: String, resumenPrevio: String = "") -> String:
	var partes: Array[String] = [
		"Here is the conversation so far:\n\n<conversation>\n%s\n</conversation>" % conversacion,
	]
	if resumenPrevio.strip_edges() == "":
		partes.append("Create a new anchored summary from the conversation history in the <conversation> tags above so another coding agent can continue the work.")
	else:
		partes.append("Here is the summary of the conversation before the <conversation> above:\n\n<prior-summary>\n%s\n</prior-summary>" % resumenPrevio)
		partes.append(ChatPrompts.promptResumenActualizar())
	partes.append(ChatPrompts.promptResumenPlantilla())
	return "\n\n".join(partes)

## Limpia lo que devolvio el modelo: espacios, un bloque de codigo que envuelva
## todo el resumen (algunos modelos lo hacen aunque se les pida que no) y las
## lineas vacias de los extremos. Vacio quiere decir "no hay resumen".
static func limpiarResumen(texto: String) -> String:
	var limpio := texto.strip_edges()
	if limpio.begins_with("```"):
		var salto := limpio.find("\n")
		if salto >= 0:
			limpio = limpio.substr(salto + 1)
		if limpio.ends_with("```"):
			limpio = limpio.substr(0, limpio.length() - 3)
	limpio = limpio.strip_edges()
	if limpio == "<null>":
		return ""
	return limpio

## Texto de la fila de la compactacion: cuantos mensajes entraron y a que hora
## se hizo el corte. El mensaje 0 es el prompt de sistema, que no se resume.
##
## El instante se guarda con el chat y llega aqui: al reabrir, la fila tiene que
## decir la misma hora que decia en vivo, y esa hora no se puede recalcular.
## `ahora` existe para las pruebas, que no pueden esperar a manana para mirar el
## formato con fecha.
static func textoFila(corte: int, ts: int = 0, ahora: int = 0) -> String:
	var resumidos := maxi(corte - 1, 0)
	var recuento := "%d earlier messages summarized" % resumidos
	if resumidos == 1:
		recuento = "1 earlier message summarized"
	# Chat cortado antes de que la fila dijera la hora: se queda con el recuento a
	# secas, que inventarse un instante seria peor que no decirlo.
	if ts <= 0:
		return "Context compacted: " + recuento
	var desfase := _desfaseLocal()
	var cuando := Time.get_datetime_dict_from_unix_time(ts + desfase)
	if ahora <= 0:
		ahora = int(Time.get_unix_time_from_system())
	var hora := "%02d:%02d" % [int(cuando["hour"]), int(cuando["minute"])]
	if _mismoDia(cuando, Time.get_datetime_dict_from_unix_time(ahora + desfase)):
		return "Context compacted at %s — %s" % [hora, recuento]
	return "Context compacted on %04d-%02d-%02d at %s — %s" % [int(cuando["year"]), int(cuando["month"]), int(cuando["day"]), hora, recuento]

## Cuanto hay que sumarle a un instante unix para leerlo en hora local.
## get_datetime_dict_from_unix_time trabaja en UTC, y un "compacted at 14:32" en
## UTC seria mentira en medio mundo.
static func _desfaseLocal() -> int:
	var ahora := int(Time.get_unix_time_from_system())
	return int(Time.get_unix_time_from_datetime_dict(Time.get_datetime_dict_from_system())) - ahora

## Si dos fechas caen el mismo dia del calendario. La hora suelta solo vale
## cuando el corte es de hoy.
static func _mismoDia(a: Dictionary, b: Dictionary) -> bool:
	return (int(a["year"]) == int(b["year"])
		and int(a["month"]) == int(b["month"])
		and int(a["day"]) == int(b["day"]))

static func _lineaImagenes(mensaje: Dictionary) -> String:
	var rutas = mensaje.get("imagenes", [])
	if typeof(rutas) != TYPE_ARRAY or rutas.is_empty():
		return ""
	var lineas: Array[String] = []
	for ruta in rutas:
		lineas.append("[Attached image: %s]" % str(ruta))
	return "\n".join(lineas)

static func _recortar(texto: String) -> String:
	if texto.length() <= MAX_CARACTERES_RESULTADO:
		return texto
	return texto.substr(0, MAX_CARACTERES_RESULTADO) + "\n[truncated]"
