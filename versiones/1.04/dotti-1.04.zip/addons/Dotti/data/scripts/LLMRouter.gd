class_name LLMRouter
extends RefCounted

signal respuesta_recibida(contenido: String)
signal error_recibido(mensaje: String)
signal razonamiento_recibido(texto: String)
signal razonamiento_finalizado
## Tokens que costo la peticion, ya normalizados (ver ChatModelos.usoNormalizado).
## Puede no llegar nunca: hay proveedores que no los cuentan.
signal uso_recibido(uso: Dictionary)

var _apis: Apis
var _httpRequest: HTTPRequest
var _nodo: Node
var _peticionCancelada: bool = false

func inicializar(nodo: Node, apis: Apis) -> void:
	_nodo = nodo
	_apis = apis

func cancelar() -> void:
	_peticionCancelada = true

## Construye una peticion OpenAI con herramientas NATIVAS y streaming para que
## LLMNativo la ejecute. Retorna {} si el proveedor actual no es tipo openai.
## Incluye: {url, cabeceras, cuerpo}. No realiza la llamada.
##
## `proveedor_id` vacio es lo normal: manda la configuracion del chat. Se rellena
## cuando el chat tiene un agente con modelo propio (P9) y hay que hablarle a otro
## proveedor del catalogo sin tocar lo que el usuario tiene elegido.
func construirPeticionOpenaiNativa(historial: Array, herramientas: Dictionary, stream: bool = true, proveedor_id: String = "") -> Dictionary:
	_apis.cargar_proveedores()
	var config_chat := _apis.obtener_configuracion_chat()
	if proveedor_id == "":
		proveedor_id = str(config_chat.get("proveedor_id", _apis.proveedor_actual_id))
	if proveedor_id == "":
		return {}
	var proveedor := _apis.obtener_proveedor(proveedor_id)
	if proveedor.is_empty():
		return {}
	if str(proveedor.get("tipo", "openai")) != "openai":
		return {}
	var modelo: String = proveedor.get("model_id", "")
	if modelo == "":
		return {}
	var max_tokens: int = config_chat.get("maxTokens", proveedor.get("max_tokens", 8192))
	var techo := ChatModelos.salida_max(modelo)
	if techo > 0:
		max_tokens = mini(max_tokens, techo)
	var cuerpo := _cuerpo_openai(LLMNativo.normalizar_historial(historial), modelo, max_tokens)
	if not herramientas.is_empty():
		cuerpo["tools"] = LLMNativo.esquema_herramientas(herramientas)
		cuerpo["tool_choice"] = "auto"
	# Niveles de razonamiento del modelo (none/high/max, default high).
	var nivel := str(config_chat.get("nivel_razonamiento", "high")).to_lower()
	if nivel != "none" and nivel != "high" and nivel != "max":
		nivel = "high"
	cuerpo["reasoning_effort"] = nivel
	cuerpo["thinking"] = {"type": "disabled" if nivel == "none" else "enabled"}
	if stream:
		cuerpo["stream"] = true
		cuerpo["stream_options"] = {"include_usage": true}
	var url := _construir_url_openai(str(proveedor.get("base_url", "")))
	return {
		"url": url,
		"cabeceras": _cabeceras_openai(str(proveedor.get("api_key", "")), bool(proveedor.get("oficial", false))),
		"cuerpo": cuerpo,
	}

## Manda la peticion por el camino legacy (JSON en texto + HTTPRequest).
## `proveedor_id` es el mismo override que en construirPeticionOpenaiNativa.
func realizarPeticion(historial: Array, proveedor_id: String = "") -> void:
	if _peticionCancelada:
		return

	_apis.cargar_proveedores()

	var config_chat := _apis.obtener_configuracion_chat()
	if proveedor_id == "":
		proveedor_id = str(config_chat.get("proveedor_id", _apis.proveedor_actual_id))
	if proveedor_id == "":
		error_recibido.emit("No provider selected")
		return

	var proveedor := _apis.obtener_proveedor(proveedor_id)
	if proveedor.is_empty():
		error_recibido.emit("Provider not found")
		return

	var tipo: String = proveedor.get("tipo", "openai")
	var modelo: String = proveedor.get("model_id", "")
	var max_tokens: int = config_chat.get("maxTokens", proveedor.get("max_tokens", 8192))
	var api_key: String = proveedor.get("api_key", "")
	var base_url: String = proveedor.get("base_url", "")

	if modelo == "":
		error_recibido.emit("Model ID is empty for this provider")
		return

	var url: String
	var cabeceras: Array
	var cuerpo: Dictionary

	match tipo:
		"openai":
			url = _construir_url_openai(base_url)
			cabeceras = _cabeceras_openai(api_key, bool(proveedor.get("oficial", false)))
			# Misma normalizacion que el camino nativo: un turno con tool_calls
			# sin su reasoning_content real hace que el upstream devuelva 400
			# ("The `reasoning_content` in the thinking mode must be passed
			# back to the API") en toda la conversacion.
			cuerpo = _cuerpo_openai(LLMNativo.normalizar_historial(historial), modelo, max_tokens)
		"anthropic":
			url = _construir_url_anthropic(base_url)
			cabeceras = _cabeceras_anthropic(api_key)
			cuerpo = _cuerpo_anthropic(historial, modelo, max_tokens)
		"gemini":
			url = "https://generativelanguage.googleapis.com/v1beta/models" + "/" + modelo + ":generateContent?key=" + api_key
			cabeceras = _cabeceras_gemini()
			cuerpo = _cuerpo_gemini(historial, max_tokens)
		_:
			error_recibido.emit("Unsupported provider type: " + tipo)
			return

	if is_instance_valid(_httpRequest):
		_httpRequest.cancel_request()

	_httpRequest = HTTPRequest.new()
	_httpRequest.use_threads = true
	_nodo.add_child(_httpRequest)
	_httpRequest.request_completed.connect(_al_recibir_respuesta.bind(tipo), CONNECT_ONE_SHOT)
	var error := _httpRequest.request(url, cabeceras, HTTPClient.METHOD_POST, JSON.stringify(cuerpo))
	if error != OK:
		error_recibido.emit("Failed to send request (code %d)." % error)

func _al_recibir_respuesta(resultado: int, codigo_http: int, _cabeceras: PackedStringArray, cuerpo: PackedByteArray, tipo: String) -> void:
	if _peticionCancelada:
		return

	if resultado != HTTPRequest.RESULT_SUCCESS:
		var mensajes_error := {
			HTTPRequest.RESULT_CANT_CONNECT: "Cannot connect to the server.",
			HTTPRequest.RESULT_CANT_RESOLVE: "Cannot resolve host.",
			HTTPRequest.RESULT_CONNECTION_ERROR: "Connection error.",
			HTTPRequest.RESULT_TLS_HANDSHAKE_ERROR: "TLS handshake error.",
			HTTPRequest.RESULT_NO_RESPONSE: "No response from server.",
			HTTPRequest.RESULT_BODY_SIZE_LIMIT_EXCEEDED: "Response too large.",
			HTTPRequest.RESULT_REQUEST_FAILED: "Request failed.",
			HTTPRequest.RESULT_TIMEOUT: "Request timed out.",
		}
		error_recibido.emit(mensajes_error.get(resultado, "Network error (code %d)." % resultado))
		return

	var texto_respuesta := cuerpo.get_string_from_utf8()

	var json := JSON.new()
	if json.parse(texto_respuesta) != OK:
		error_recibido.emit("Invalid JSON response from API.")
		return

	var datos = json.get_data()

	if typeof(datos) == TYPE_DICTIONARY and datos.has("error"):
		var msg = datos["error"]
		if typeof(msg) == TYPE_DICTIONARY:
			error_recibido.emit("API Error: " + str(msg.get("message", "Unknown error")))
		else:
			error_recibido.emit("API Error: " + str(msg))
		return

	if codigo_http >= 400:
		var msg_http := "HTTP %d" % codigo_http
		if typeof(datos) == TYPE_DICTIONARY and datos.has("message"):
			msg_http += ": " + str(datos["message"])
		error_recibido.emit(msg_http)
		return

	var razonamiento: String = ""
	var contenido: String = ""
	match tipo:
		"openai":
			razonamiento = _extraer_razonamiento_openai(datos)
			contenido = _extraer_openai(datos)
		"anthropic":
			razonamiento = _extraer_razonamiento_anthropic(datos)
			contenido = _extraer_anthropic(datos)
		"gemini":
			contenido = _extraer_gemini(datos)

	# Los tokens que costo la peticion, para que el chat pueda decir cuanto
	# contexto lleva gastado. Si el proveedor no los manda, no se emite nada.
	if typeof(datos) == TYPE_DICTIONARY:
		var uso := ChatModelos.usoNormalizado(datos.get("usage", null))
		if not uso.is_empty():
			uso_recibido.emit(uso)

	if not _peticionCancelada and razonamiento.strip_edges() != "":
		razonamiento_recibido.emit(razonamiento)
		razonamiento_finalizado.emit()

	if contenido.strip_edges() == "":
		error_recibido.emit("Empty response received.")
		return
	respuesta_recibida.emit(contenido)

func _construir_url_final(base: String, sufijo: String) -> String:
	var url = base.strip_edges()
	if url.ends_with("/"):
		url = url.left(url.length() - 1)
	if url.ends_with(sufijo):
		return url
	if not sufijo.begins_with("/"):
		sufijo = "/" + sufijo
	return url + sufijo

func _construir_url_openai(base_url: String) -> String:
	var url_limpia = base_url.strip_edges().rstrip("/")
	if url_limpia.ends_with("/v1"):
		return url_limpia + "/chat/completions"
	elif url_limpia.ends_with("/v1/chat/completions"):
		return url_limpia
	else:
		return _construir_url_final(base_url, "/v1/chat/completions")

## El nombre de la cabecera con la que el plugin dice que build es. El gateway la
## lee para no atender a un plugin que ya no se sirve; sin ella, para el gateway,
## quien llama es un build viejo (los que se publicaron antes de que existiera).
const CABECERA_BUILD := "x-dotti-build"


## Las cabeceras del camino OpenAI. La version viaja solo a la base oficial, que
## es la unica que la necesita: a un proveedor propio del usuario no le hace
## falta y es informacion suya que no tiene por que salir de aqui. Quien dice si
## la base es la oficial es `Apis._resolver_proveedor`, que ya lo deja apuntado
## en el proveedor resuelto.
func _cabeceras_openai(api_key: String, oficial: bool = false) -> Array:
	var cabeceras := [
		"Content-Type: application/json",
		"Authorization: Bearer " + api_key,
	]
	if oficial:
		cabeceras.append(CABECERA_BUILD + ": " + ChatActualizaciones.instalada())
	return cabeceras

func _cuerpo_openai(historial: Array, modelo: String, max_tokens: int) -> Dictionary:
	var mensajes: Array = []
	for msg in historial:
		var rol = msg["role"]
		var contenido = msg.get("content", "")
		if rol == "assistant" and msg.has("tool_calls"):
			var tcs = msg["tool_calls"]
			if typeof(tcs) == TYPE_ARRAY and not (tcs as Array).is_empty():
				var entrada_asistente := {"role": "assistant", "content": contenido, "tool_calls": tcs}
				if str(msg.get("reasoning_content", "")) != "":
					entrada_asistente["reasoning_content"] = str(msg["reasoning_content"])
				mensajes.append(entrada_asistente)
				continue
		if rol == "tool":
			var entrada_tool := {"role": "tool", "content": str(contenido)}
			if str(msg.get("tool_call_id", "")) != "":
				entrada_tool["tool_call_id"] = str(msg.get("tool_call_id"))
			mensajes.append(entrada_tool)
			continue
		match rol:
			"system", "user", "assistant":
				mensajes.append(Adjuntos.mensajeOpenai(rol, str(contenido), msg.get("imagenes", [])))
			_:
				mensajes.append({"role": "user", "content": str(contenido)})
	return {
		"model": modelo,
		"messages": mensajes,
		"max_tokens": max_tokens
	}

func _extraer_openai(datos: Dictionary) -> String:
	var choices = datos.get("choices", [])
	if choices.is_empty():
		return ""
	var mensaje = choices[0].get("message", {})
	return mensaje.get("content", "")

func _extraer_razonamiento_openai(datos: Dictionary) -> String:
	var choices = datos.get("choices", [])
	if typeof(choices) != TYPE_ARRAY or choices.is_empty():
		return ""
	var primero = choices[0]
	if typeof(primero) != TYPE_DICTIONARY:
		return ""
	var mensaje = primero.get("message", {})
	if typeof(mensaje) != TYPE_DICTIONARY:
		return ""
	var rc = mensaje.get("reasoning_content", "")
	if typeof(rc) == TYPE_STRING and String(rc).strip_edges() != "":
		return String(rc)
	var r = mensaje.get("reasoning", "")
	if typeof(r) == TYPE_STRING and String(r).strip_edges() != "":
		return String(r)
	if typeof(r) == TYPE_DICTIONARY:
		var rt = r.get("content", "")
		if typeof(rt) == TYPE_STRING and String(rt).strip_edges() != "":
			return String(rt)
		var rs = r.get("summary", "")
		if typeof(rs) == TYPE_ARRAY:
			var partes: Array = []
			for it in rs:
				if typeof(it) == TYPE_DICTIONARY:
					partes.append(str(it.get("text", "")))
				else:
					partes.append(str(it))
			return "\n".join(partes)
	if typeof(r) == TYPE_ARRAY:
		var partes2: Array = []
		for it in r:
			if typeof(it) == TYPE_DICTIONARY:
				partes2.append(str(it.get("text", it.get("content", ""))))
			else:
				partes2.append(str(it))
		return "\n".join(partes2)
	var rs2 = mensaje.get("reasoning_summary", "")
	if typeof(rs2) == TYPE_STRING and String(rs2).strip_edges() != "":
		return String(rs2)
	var rd = mensaje.get("reasoning_details", "")
	if typeof(rd) == TYPE_ARRAY:
		var partes3: Array = []
		for it in rd:
			if typeof(it) == TYPE_DICTIONARY:
				partes3.append(str(it.get("text", it.get("content", ""))))
			else:
				partes3.append(str(it))
		return "\n".join(partes3)
	return ""

func _construir_url_anthropic(base_url: String) -> String:
	var url_limpia = base_url.strip_edges().rstrip("/")
	if url_limpia.ends_with("/v1/messages"):
		return url_limpia
	return _construir_url_final(base_url, "/v1/messages")

func _cabeceras_anthropic(api_key: String) -> Array:
	return [
		"Content-Type: application/json",
		"x-api-key: " + api_key,
		"anthropic-version: 2023-06-01"
	]

func _cuerpo_anthropic(historial: Array, modelo: String, max_tokens: int) -> Dictionary:
	var system_prompt := ""
	var mensajes: Array = []
	for msg in historial:
		var rol = msg["role"]
		var contenido = msg["content"]
		if rol == "system":
			system_prompt = contenido
		elif rol == "user":
			mensajes.append({"role": "user", "content": contenido})
		elif rol == "assistant":
			mensajes.append({"role": "assistant", "content": contenido})

	var cuerpo := {
		"model": modelo,
		"max_tokens": max_tokens,
		"messages": mensajes
	}
	if system_prompt != "":
		cuerpo["system"] = system_prompt
	return cuerpo

func _extraer_anthropic(datos: Dictionary) -> String:
	var content = datos.get("content", [])
	if typeof(content) != TYPE_ARRAY or content.is_empty():
		return ""
	var textos: Array = []
	for bloque in content:
		if typeof(bloque) != TYPE_DICTIONARY:
			continue
		var t := str(bloque.get("type", ""))
		if t == "text" or t == "":
			textos.append(str(bloque.get("text", "")))
	return "\n".join(textos)

func _extraer_razonamiento_anthropic(datos: Dictionary) -> String:
	var content = datos.get("content", [])
	if typeof(content) != TYPE_ARRAY or content.is_empty():
		return ""
	var textos: Array = []
	for bloque in content:
		if typeof(bloque) != TYPE_DICTIONARY:
			continue
		var t := str(bloque.get("type", ""))
		if t == "thinking" or t == "redacted_thinking":
			var th = bloque.get("thinking", bloque.get("text", ""))
			if typeof(th) == TYPE_STRING and String(th).strip_edges() != "":
				textos.append(String(th))
	return "\n".join(textos)

func _cabeceras_gemini() -> Array:
	return ["Content-Type: application/json"]

func _cuerpo_gemini(historial: Array, max_tokens: int) -> Dictionary:
	var contenidos: Array = []
	for msg in historial:
		var rol = msg["role"]
		var gemini_role = "user"
		if rol == "assistant":
			gemini_role = "model"
		contenidos.append({
			"role": gemini_role,
			"parts": [{"text": msg["content"]}]
		})
	return {
		"contents": contenidos,
		"generationConfig": {"maxOutputTokens": max_tokens}
	}

func _extraer_gemini(datos: Dictionary) -> String:
	var candidates = datos.get("candidates", [])
	if candidates.is_empty():
		return ""
	return candidates[0].get("content", {}).get("parts", [{}])[0].get("text", "")
