@tool
extends EditorPlugin

## Dotti vive SOLO en el panel inferior del editor.
##
## Antes este plugin metia ademas dos botones ("Chat" e "Interpret") dentro del
## editor de codigo, encima del arbol de scripts, y cada uno abria su propia copia
## del chat ahi mismo. Se quito entero: el chat del editor de codigo no se veia
## (el prompt le pedia al modelo responder solo con herramientas), duplicaba el
## estado de la conversacion y no aportaba nada que no hiciera ya el panel de abajo.

var escenaChat: Control


func _enter_tree() -> void:
	escenaChat = preload("res://addons/Dotti/data/scenes/001.tscn").instantiate()
	add_control_to_bottom_panel(escenaChat, "Chat")


func _exit_tree() -> void:
	if escenaChat:
		remove_control_from_bottom_panel(escenaChat)
		escenaChat.queue_free()
		escenaChat = null
