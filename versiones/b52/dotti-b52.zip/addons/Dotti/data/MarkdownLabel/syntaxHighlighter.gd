@tool
extends RefCounted

var colorPalabraClave := "ff7b9c"
var colorTipo := "7dd3fc"
var colorCadena := "fde68a"
var colorComentario := "64748b"
var colorNumero := "c4b5fd"
var colorFuncion := "86efac"
var colorAnotacion := "fbbf24"
var colorOperador := "e2e8f0"

const PALABRAS_GDSCRIPT := [
	"if", "elif", "else", "for", "while", "match", "break", "continue",
	"pass", "return", "class", "class_name", "extends", "is", "in",
	"as", "self", "signal", "func", "static", "const", "enum", "var",
	"breakpoint", "preload", "await", "yield", "assert", "void",
	"true", "false", "null", "not", "and", "or",
	"export", "onready", "tool", "master", "puppet", "slave",
	"remotesync", "sync", "remote",
]

const TIPOS_GDSCRIPT := [
	"int", "float", "bool", "String", "Vector2", "Vector3", "Vector4",
	"Vector2i", "Vector3i", "Vector4i", "Color", "Rect2", "Rect2i",
	"Transform2D", "Transform3D", "Basis", "Quaternion", "AABB",
	"Plane", "Projection", "RID", "Callable", "Signal", "Dictionary",
	"Array", "PackedByteArray", "PackedInt32Array", "PackedInt64Array",
	"PackedFloat32Array", "PackedFloat64Array", "PackedStringArray",
	"PackedVector2Array", "PackedVector3Array", "PackedColorArray",
	"NodePath", "StringName", "Node", "Node2D", "Node3D", "Control",
	"Resource", "Object", "RefCounted", "Variant",
	"CharacterBody2D", "CharacterBody3D", "RigidBody2D", "RigidBody3D",
	"Area2D", "Area3D", "CollisionShape2D", "CollisionShape3D",
	"Sprite2D", "Sprite3D", "AnimatedSprite2D", "Camera2D", "Camera3D",
	"Timer", "Label", "Button", "TextureRect", "RichTextLabel",
	"AudioStreamPlayer", "TileMap", "TileMapLayer", "PanelContainer",
	"VBoxContainer", "HBoxContainer", "MarginContainer", "ScrollContainer",
	"StyleBoxFlat", "Font", "FontFile", "Theme", "Tween",
]

const PALABRAS_PYTHON := [
	"if", "elif", "else", "for", "while", "break", "continue", "pass",
	"return", "def", "class", "import", "from", "as", "with", "try",
	"except", "finally", "raise", "yield", "lambda", "global", "nonlocal",
	"assert", "del", "in", "is", "not", "and", "or",
	"True", "False", "None", "async", "await",
]

const TIPOS_PYTHON := [
	"int", "float", "str", "bool", "list", "dict", "tuple", "set",
	"bytes", "bytearray", "type", "object", "range", "enumerate",
	"zip", "map", "filter", "print", "len", "isinstance", "super",
]

const PALABRAS_JS := [
	"if", "else", "for", "while", "do", "switch", "case", "default",
	"break", "continue", "return", "function", "var", "let", "const",
	"class", "extends", "new", "delete", "typeof", "instanceof",
	"try", "catch", "finally", "throw", "async", "await", "yield",
	"import", "export", "from", "of", "in",
	"true", "false", "null", "undefined", "this", "super",
]

const TIPOS_JS := [
	"Array", "Object", "String", "Number", "Boolean", "Map", "Set",
	"Promise", "Date", "RegExp", "Error", "Symbol", "BigInt",
	"console", "document", "window", "Math", "JSON",
]

const PALABRAS_CSHARP := [
	"if", "else", "for", "foreach", "while", "do", "switch", "case",
	"default", "break", "continue", "return", "class", "struct", "enum",
	"interface", "namespace", "using", "new", "public", "private",
	"protected", "internal", "static", "readonly", "const", "override",
	"virtual", "abstract", "sealed", "partial", "async", "await",
	"try", "catch", "finally", "throw", "var", "out", "ref", "in",
	"is", "as", "typeof", "sizeof", "void", "get", "set",
	"true", "false", "null", "this", "base", "yield",
]

const TIPOS_CSHARP := [
	"int", "float", "double", "decimal", "bool", "string", "char",
	"byte", "short", "long", "uint", "ulong", "object",
	"List", "Dictionary", "Task", "Action", "Func",
	"Vector2", "Vector3", "GodotObject", "Node", "Resource",
]

const PALABRAS_BASH := [
	"if", "then", "else", "elif", "fi", "for", "while", "do", "done",
	"case", "esac", "in", "function", "return", "exit",
	"echo", "read", "local", "export", "source", "alias", "unalias",
	"set", "unset", "shift", "trap", "eval", "exec",
	"true", "false",
]

const PALABRAS_C := [
	"if", "else", "for", "while", "do", "switch", "case", "default",
	"break", "continue", "return", "struct", "enum", "union", "typedef",
	"sizeof", "static", "const", "volatile", "extern", "register",
	"auto", "inline", "void", "goto",
	"#include", "#define", "#ifdef", "#ifndef", "#endif", "#pragma",
	"true", "false", "NULL",
]

const TIPOS_C := [
	"int", "float", "double", "char", "long", "short", "unsigned",
	"signed", "size_t", "uint8_t", "uint16_t", "uint32_t", "uint64_t",
	"int8_t", "int16_t", "int32_t", "int64_t", "bool",
	"FILE", "string", "vector", "map", "set", "pair",
	"std", "cout", "cin", "endl", "nullptr",
]

## Cache de expresiones regulares compiladas y de los patrones por lenguaje.
## Antes, cada linea de un bloque de codigo compilaba una expresion por palabra
## clave y otra por tipo (~120 en GDScript, cada una recorriendo la linea): eso
## era el grueso del coste de un bloque de codigo.
static var _cacheRegex := {}
static var _cachePatrones := {}

static func _regex(patron: String) -> RegEx:
	var compilada: RegEx = _cacheRegex.get(patron)
	if compilada != null:
		return compilada
	compilada = RegEx.new()
	compilada.compile(patron)
	_cacheRegex[patron] = compilada
	return compilada

## Todas las palabras (o los tipos) en una sola alternancia, para resolver la
## linea de una pasada en vez de una por palabra. El resultado es el mismo: los
## extremos de palabra se siguen exigiendo con los mismos lookarounds.
static func _patronLenguaje(clave: String, items: Array) -> String:
	var guardado: String = _cachePatrones.get(clave, "")
	if guardado != "":
		return guardado
	var partes := PackedStringArray()
	for item in items:
		partes.append(str(item).replace("+", "\\+").replace("#", "\\#"))
	var patron := "(?<![a-zA-Z_])(" + "|".join(partes) + ")(?![a-zA-Z0-9_])"
	_cachePatrones[clave] = patron
	return patron

func obtenerPalabras(lenguaje: String) -> Array:
	match lenguaje:
		"gdscript", "gd": return PALABRAS_GDSCRIPT
		"python", "py": return PALABRAS_PYTHON
		"javascript", "js", "typescript", "ts": return PALABRAS_JS
		"csharp", "cs", "c#": return PALABRAS_CSHARP
		"bash", "sh", "shell", "zsh": return PALABRAS_BASH
		"c", "cpp", "c++", "h", "hpp": return PALABRAS_C
	return PALABRAS_GDSCRIPT

func obtenerTipos(lenguaje: String) -> Array:
	match lenguaje:
		"gdscript", "gd": return TIPOS_GDSCRIPT
		"python", "py": return TIPOS_PYTHON
		"javascript", "js", "typescript", "ts": return TIPOS_JS
		"csharp", "cs", "c#": return TIPOS_CSHARP
		"c", "cpp", "c++", "h", "hpp": return TIPOS_C
	return TIPOS_GDSCRIPT

func obtenerPrefijoComentario(lenguaje: String) -> String:
	match lenguaje:
		"gdscript", "gd": return "#"
		"python", "py": return "#"
		"bash", "sh", "shell", "zsh": return "#"
	return "//"

func resaltar(codigo: String, lenguaje: String, funcionEscape: Callable) -> String:
	var charComentario := obtenerPrefijoComentario(lenguaje)
	var patronPalabras := _patronLenguaje("palabras:" + lenguaje, obtenerPalabras(lenguaje))
	var patronTipos := _patronLenguaje("tipos:" + lenguaje, obtenerTipos(lenguaje))
	var resultado := ""
	for linea in codigo.split("\n"):
		if resultado != "":
			resultado += "\n"
		resultado += _resaltarLinea(linea, patronPalabras, patronTipos, charComentario, lenguaje, funcionEscape)
	return resultado

func _resaltarLinea(linea: String, patronPalabras: String, patronTipos: String, charComentario: String, lenguaje: String, funcionEscape: Callable) -> String:
	var escapada: String = funcionEscape.call(linea)
	var recortada := escapada.strip_edges()
	if recortada.begins_with(funcionEscape.call(charComentario)):
		return "[color=#%s]%s[/color]" % [colorComentario, escapada]

	var parteCodigo := escapada
	var parteComentario := ""
	var comentarioEscapado: String = funcionEscape.call(charComentario)
	var enCadena := false
	var charCadena := ""
	var i := 0
	while i < parteCodigo.length():
		var ch := parteCodigo[i]
		if not enCadena:
			if ch == "\"" or ch == "'":
				enCadena = true
				charCadena = ch
			elif parteCodigo.substr(i).begins_with(comentarioEscapado):
				parteComentario = "[color=#%s]%s[/color]" % [colorComentario, parteCodigo.substr(i)]
				parteCodigo = parteCodigo.substr(0, i)
				break
		else:
			if ch == charCadena and (i == 0 or parteCodigo[i - 1] != "\\"):
				enCadena = false
		i += 1

	var coloreado := parteCodigo

	var regexCadena := _regex("(\"\"\"[\\s\\S]*?\"\"\"|'''[\\s\\S]*?'''|\"(?:[^\"\\\\]|\\\\.)*\"|'(?:[^'\\\\]|\\\\.)*')")
	var temporal := coloreado
	for r in regexCadena.search_all(temporal):
		var pos := temporal.find(r.get_string())
		if pos == -1:
			continue
		temporal = temporal.substr(0, pos) + "[color=#%s]" % colorCadena + r.get_string() + "[/color]" + temporal.substr(pos + r.get_string().length())
	coloreado = temporal

	coloreado = _aplicarColor(coloreado, "(?<![a-zA-Z_#])\\b(0x[0-9a-fA-F]+|0b[01]+|[0-9]+\\.?[0-9]*(?:e[+-]?[0-9]+)?)\\b", colorNumero)

	if lenguaje in ["gdscript", "gd", "python", "py", "java", "kotlin"]:
		coloreado = _aplicarColor(coloreado, "(@[a-zA-Z_][a-zA-Z0-9_]*)", colorAnotacion)

	coloreado = _aplicarColor(coloreado, patronPalabras, colorPalabraClave)
	coloreado = _aplicarColor(coloreado, patronTipos, colorTipo)

	temporal = coloreado
	var regexFuncion := _regex("([a-zA-Z_][a-zA-Z0-9_]*)\\(")
	var resultadosFunc := regexFuncion.search_all(temporal)
	var posiciones := []
	for r in resultadosFunc:
		var antes := temporal.substr(0, r.get_start())
		if antes.count("[color=") > antes.count("[/color]"):
			continue
		posiciones.append({"inicio": r.get_start(1), "fin": r.get_end(1), "texto": r.get_string(1)})
	posiciones.reverse()
	for fp in posiciones:
		temporal = temporal.substr(0, fp.inicio) + "[color=#%s]%s[/color]" % [colorFuncion, fp.texto] + temporal.substr(fp.fin)
	coloreado = temporal

	return coloreado + parteComentario

func _aplicarColor(texto: String, patron: String, color: String) -> String:
	var regex := _regex(patron)
	var resultados := regex.search_all(texto)
	var posiciones := []
	for r in resultados:
		var antes := texto.substr(0, r.get_start())
		if antes.count("[color=") > antes.count("[/color]"):
			continue
		posiciones.append({"inicio": r.get_start(), "fin": r.get_end(), "texto": r.get_string()})
	posiciones.reverse()
	for p in posiciones:
		texto = texto.substr(0, p.inicio) + "[color=#%s]%s[/color]" % [color, p.texto] + texto.substr(p.fin)
	return texto
