@tool
class_name MarkdownLabel
extends VBoxContainer

signal enlaceNoManejadoClicado(meta: Variant)
signal tareaCasillaClicada(id: int, linea: int, marcada: bool, textoTarea: String)
signal codigoCopiado(lenguaje: String, codigo: String)

@export_multiline var textoMarkdown: String = "": set = _establecerTextoMarkdown

@export_group("Enlaces")
@export var enlacesAutomaticos: bool = true
@export var asumirHttps: bool = true

@export_group("Tipografía")
@export var colorTexto: Color = Color("e5e7eb"): set = _establecerColorTexto
@export var fuenteMonoespaciada: FontFile

@export_group("Tarjeta de código")
@export var colorFondoTarjeta: Color = Color(0.075, 0.075, 0.075, 0.98): set = _establecerColorFondoTarjeta
@export var colorEncabezadoTarjeta: Color = Color(0.11, 0.11, 0.11, 0.98): set = _establecerColorEncabezadoTarjeta
@export var colorBordeTarjeta: Color = Color(0.22, 0.22, 0.22, 0.85): set = _establecerColorBordeTarjeta
@export var colorTextoLenguaje: Color = Color(0.62, 0.62, 0.62, 1.0): set = _establecerColorTextoLenguaje
@export var colorTextoCodigo: Color = Color(0.90, 0.90, 0.90, 1.0): set = _establecerColorTextoCodigo
@export var colorBotonCopiar: Color = Color(0, 0, 0, 0): set = _establecerColorBotonCopiar
@export var colorBotonCopiarHover: Color = Color(1.0, 1.0, 1.0, 0.06): set = _establecerColorBotonHover
@export var colorAccentoCopiado: Color = Color(0.78, 0.78, 0.78, 1.0): set = _establecerColorAcento
@export var radioTarjeta: int = 8: set = _establecerRadioTarjeta
@export var margenInternoTarjeta: int = 14: set = _establecerMargenTarjeta
@export var resaltadoHabilitado: bool = true: set = _establecerResaltado

@export_group("Tareas")
@export var habilitarClicksCasillas: bool = true: set = _establecerClicksCasillas
@export var caracterNoMarcado: String = "☐": set = _establecerCharNoMarcado
@export var caracterMarcado: String = "☑": set = _establecerCharMarcado

@export_group("Separadores")
@export_range(0, 99, 1, "suffix:px") var alturaSeparador: int = 2: set = _establecerAlturaSeparador
@export_range(0, 100, 1, "suffix:%") var anchoSeparador: float = 100: set = _establecerAnchoSeparador
@export_enum("left", "center", "right") var alineacionSeparador: String = "left": set = _establecerAlineacionSeparador
@export var colorSeparador: Color = Color("334155"): set = _establecerColorSeparador

@export_group("Encabezados")
@export var h1: FormatoEncabezado: set = _establecerH1
@export var h2: FormatoEncabezado: set = _establecerH2
@export var h3: FormatoEncabezado: set = _establecerH3
@export var h4: FormatoEncabezado: set = _establecerH4
@export var h5: FormatoEncabezado: set = _establecerH5
@export var h6: FormatoEncabezado: set = _establecerH6

const CLAVE_CASILLA := "markdownlabel-checkbox"
const REGEX_FRONTMATTER := r"^(?:(?:---|\+\+\+)\r?\n([\s\S]*?)\r?\n(?:---|\+\+\+)\r?\n)?(?:\r?\n)?([\s\S]*)$"

var _sucio: bool = false
var _frontmatter: String = ""
var _analizador: AnalizadorMarkdown = AnalizadorMarkdown.new()
var _etiquetasTexto: Array[RichTextLabel] = []
var _fuenteMonoPorDefecto: FontFile

func _init(pTextoMarkdown: String = "") -> void:
	add_theme_constant_override("separation", 10)
	if h1 == null: h1 = FormatoEncabezado.new(1.85, true, false, false, false, Color.WHITE, true)
	if h2 == null: h2 = FormatoEncabezado.new(1.55, true, false, false, false, Color.WHITE, true)
	if h3 == null: h3 = FormatoEncabezado.new(1.3, true, false, false, false, Color.WHITE, false)
	if h4 == null: h4 = FormatoEncabezado.new(1.15, true, false, false, false, Color.WHITE, false)
	if h5 == null: h5 = FormatoEncabezado.new(1.0, true, false, false, false, Color.WHITE, false)
	if h6 == null: h6 = FormatoEncabezado.new(0.9, true, true, false, true, Color("cbd5e1"), false)
	textoMarkdown = pTextoMarkdown

func _ready() -> void:
	_conectarEncabezado(h1)
	_conectarEncabezado(h2)
	_conectarEncabezado(h3)
	_conectarEncabezado(h4)
	_conectarEncabezado(h5)
	_conectarEncabezado(h6)
	marcarSucio()

func _conectarEncabezado(formato: FormatoEncabezado) -> void:
	if formato == null:
		return
	if not formato.changed.is_connected(marcarSucio):
		formato.changed.connect(marcarSucio)

func _process(_delta: float) -> void:
	if _sucio:
		_actualizar()

func _notification(que: int) -> void:
	if que == NOTIFICATION_TRANSLATION_CHANGED:
		marcarSucio()

func _set(propiedad: StringName, valor: Variant) -> bool:
	if propiedad == "markdown_text" or propiedad == "text":
		textoMarkdown = valor
		return true
	return false

func _get(propiedad: StringName) -> Variant:
	if propiedad == "markdown_text" or propiedad == "text":
		return textoMarkdown
	return null

func display_file(rutaArchivo: String, manejarFrontmatter: bool = true) -> Error:
	return mostrarArchivo(rutaArchivo, manejarFrontmatter)

func mostrarArchivo(rutaArchivo: String, manejarFrontmatter: bool = true) -> Error:
	var contenido: String = FileAccess.get_file_as_string(rutaArchivo)
	if not contenido:
		return FileAccess.get_open_error()
	if manejarFrontmatter:
		var regex := RegEx.create_from_string(REGEX_FRONTMATTER)
		var resultado := regex.search(contenido)
		if resultado:
			_frontmatter = resultado.get_string(1).strip_edges()
			textoMarkdown = resultado.get_string(2)
			return OK
	_frontmatter = ""
	textoMarkdown = contenido
	return OK

func obtenerFrontmatter() -> String:
	return _frontmatter

func marcarSucio() -> void:
	_sucio = true

func establecerTexto(nuevoTexto: String) -> void:
	textoMarkdown = nuevoTexto

func _establecerTextoMarkdown(nuevoTexto: String) -> void:
	textoMarkdown = nuevoTexto
	marcarSucio()

func _actualizar() -> void:
	_sucio = false
	for hijo in get_children():
		hijo.queue_free()
	_etiquetasTexto.clear()
	var fuente := textoMarkdown
	if _puedeAutotraducir():
		fuente = TranslationServer.translate(fuente)
	if fuente.strip_edges().is_empty():
		return
	_configurarAnalizador()
	var segmentos := AnalizadorMarkdown.dividirSegmentos(fuente)
	for segmento in segmentos:
		if segmento.type == "text":
			var contenido: String = segmento.content.strip_edges()
			if contenido.is_empty():
				continue
			var burbuja := _crearBurbujaTexto(segmento.content)
			if burbuja:
				add_child(burbuja)
		elif segmento.type == "code":
			var tarjeta := _crearTarjetaCodigo(segmento.content, segmento.language)
			add_child(tarjeta)

func _puedeAutotraducir() -> bool:
	var version := Engine.get_version_info()
	if version.hex >= 0x040300 and has_method("can_auto_translate"):
		return call("can_auto_translate")
	return auto_translate

func _configurarAnalizador() -> void:
	_analizador.h1 = h1
	_analizador.h2 = h2
	_analizador.h3 = h3
	_analizador.h4 = h4
	_analizador.h5 = h5
	_analizador.h6 = h6
	_analizador.caracterNoMarcado = caracterNoMarcado
	_analizador.caracterMarcado = caracterMarcado
	_analizador.habilitarClicksCasillas = habilitarClicksCasillas
	_analizador.alturaSeparador = alturaSeparador
	_analizador.anchoSeparador = anchoSeparador
	_analizador.alineacionSeparador = alineacionSeparador
	_analizador.colorSeparador = colorSeparador
	_analizador.resaltadoHabilitado = resaltadoHabilitado

func _crearBurbujaTexto(contenido: String) -> RichTextLabel:
	var etiqueta := RichTextLabel.new()
	etiqueta.bbcode_enabled = true
	etiqueta.fit_content = true
	etiqueta.selection_enabled = true
	etiqueta.context_menu_enabled = true
	etiqueta.deselect_on_focus_loss_enabled = true
	etiqueta.scroll_active = false
	etiqueta.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	etiqueta.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	etiqueta.add_theme_color_override("default_color", colorTexto)
	etiqueta.add_theme_color_override("selection_color", Color(0.23, 0.51, 0.96, 0.35))
	etiqueta.add_theme_color_override("font_selected_color", Color.WHITE)
	var fuenteMono := _obtenerFuenteMono()
	if fuenteMono:
		etiqueta.add_theme_font_override("mono_font", fuenteMono)
	etiqueta.meta_clicked.connect(_alMetaClicado)
	var bbcode := _analizador.analizar(contenido)
	etiqueta.parse_bbcode(bbcode)
	_etiquetasTexto.append(etiqueta)
	return etiqueta

func _crearTarjetaCodigo(codigo: String, lenguaje: String) -> PanelContainer:
	var tarjeta := PanelContainer.new()
	tarjeta.size_flags_horizontal = Control.SIZE_EXPAND_FILL

	var estiloTarjeta := StyleBoxFlat.new()
	estiloTarjeta.bg_color = colorFondoTarjeta
	estiloTarjeta.border_color = colorBordeTarjeta
	estiloTarjeta.set_border_width_all(1)
	estiloTarjeta.set_corner_radius_all(radioTarjeta)
	estiloTarjeta.content_margin_left = 0
	estiloTarjeta.content_margin_right = 0
	estiloTarjeta.content_margin_top = 0
	estiloTarjeta.content_margin_bottom = 0
	estiloTarjeta.shadow_color = Color(0, 0, 0, 0.25)
	estiloTarjeta.shadow_size = 4
	estiloTarjeta.shadow_offset = Vector2(0, 1)
	tarjeta.add_theme_stylebox_override("panel", estiloTarjeta)

	var contenedor := VBoxContainer.new()
	contenedor.add_theme_constant_override("separation", 0)
	tarjeta.add_child(contenedor)

	var encabezado := _crearEncabezadoTarjeta(codigo, lenguaje)
	contenedor.add_child(encabezado)

	var separadorSuperior := ColorRect.new()
	separadorSuperior.color = colorBordeTarjeta
	separadorSuperior.custom_minimum_size = Vector2(0, 1)
	contenedor.add_child(separadorSuperior)

	var cuerpoMargen := MarginContainer.new()
	cuerpoMargen.add_theme_constant_override("margin_left", margenInternoTarjeta)
	cuerpoMargen.add_theme_constant_override("margin_right", margenInternoTarjeta)
	cuerpoMargen.add_theme_constant_override("margin_top", margenInternoTarjeta)
	cuerpoMargen.add_theme_constant_override("margin_bottom", margenInternoTarjeta)
	contenedor.add_child(cuerpoMargen)

	var etiquetaCodigo := RichTextLabel.new()
	etiquetaCodigo.bbcode_enabled = true
	etiquetaCodigo.fit_content = true
	etiquetaCodigo.selection_enabled = true
	etiquetaCodigo.context_menu_enabled = true
	etiquetaCodigo.scroll_active = false
	etiquetaCodigo.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	etiquetaCodigo.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	etiquetaCodigo.add_theme_color_override("default_color", colorTextoCodigo)
	etiquetaCodigo.add_theme_color_override("selection_color", Color(0.23, 0.51, 0.96, 0.4))
	etiquetaCodigo.add_theme_color_override("font_selected_color", Color.WHITE)
	etiquetaCodigo.add_theme_constant_override("line_separation", 2)
	var fuenteMono := _obtenerFuenteMono()
	if fuenteMono:
		etiquetaCodigo.add_theme_font_override("normal_font", fuenteMono)
		etiquetaCodigo.add_theme_font_override("bold_font", fuenteMono)
		etiquetaCodigo.add_theme_font_override("italics_font", fuenteMono)
		etiquetaCodigo.add_theme_font_override("mono_font", fuenteMono)
	cuerpoMargen.add_child(etiquetaCodigo)

	var bbcodeCodigo := _analizador.resaltarCodigo(codigo, lenguaje)
	etiquetaCodigo.parse_bbcode(bbcodeCodigo)

	return tarjeta

func _crearEncabezadoTarjeta(codigo: String, lenguaje: String) -> PanelContainer:
	var encabezadoFondo := PanelContainer.new()
	var estiloEncabezado := StyleBoxFlat.new()
	estiloEncabezado.bg_color = colorEncabezadoTarjeta
	estiloEncabezado.corner_radius_top_left = radioTarjeta
	estiloEncabezado.corner_radius_top_right = radioTarjeta
	estiloEncabezado.content_margin_left = 12
	estiloEncabezado.content_margin_right = 6
	estiloEncabezado.content_margin_top = 6
	estiloEncabezado.content_margin_bottom = 6
	encabezadoFondo.add_theme_stylebox_override("panel", estiloEncabezado)

	var fila := HBoxContainer.new()
	fila.add_theme_constant_override("separation", 10)
	fila.alignment = BoxContainer.ALIGNMENT_CENTER
	encabezadoFondo.add_child(fila)

	var indicador := _crearIndicadorLenguaje()
	fila.add_child(indicador)

	var etiquetaLenguaje := Label.new()
	var nombre := lenguaje.strip_edges() if lenguaje != "" else "texto"
	etiquetaLenguaje.text = nombre.to_upper()
	etiquetaLenguaje.add_theme_color_override("font_color", colorTextoLenguaje)
	etiquetaLenguaje.add_theme_constant_override("outline_size", 0)
	etiquetaLenguaje.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	etiquetaLenguaje.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	var fuenteMono := _obtenerFuenteMono()
	if fuenteMono:
		etiquetaLenguaje.add_theme_font_override("font", fuenteMono)
	fila.add_child(etiquetaLenguaje)

	var botonCopiar := _crearBotonCopiar(codigo, lenguaje)
	fila.add_child(botonCopiar)

	return encabezadoFondo

func _crearIndicadorLenguaje() -> Control:
	var barra := Panel.new()
	barra.custom_minimum_size = Vector2(2, 12)
	var estilo := StyleBoxFlat.new()
	estilo.bg_color = Color(0.50, 0.50, 0.50, 0.75)
	estilo.set_corner_radius_all(1)
	barra.add_theme_stylebox_override("panel", estilo)
	var marco := CenterContainer.new()
	marco.add_child(barra)
	return marco

func _crearBotonCopiar(codigo: String, lenguaje: String) -> Button:
	var boton := Button.new()
	boton.text = "Copy"
	boton.icon = _crearIconoCopiar(Color(0.72, 0.72, 0.72, 0.95))
	boton.expand_icon = false
	boton.focus_mode = Control.FOCUS_NONE
	boton.add_theme_color_override("font_color", Color(0.72, 0.72, 0.72, 0.95))
	boton.add_theme_color_override("font_hover_color", Color(0.95, 0.95, 0.95, 1.0))
	boton.add_theme_color_override("font_pressed_color", Color(0.95, 0.95, 0.95, 1.0))
	boton.add_theme_color_override("font_focus_color", Color(0.95, 0.95, 0.95, 1.0))
	boton.add_theme_constant_override("h_separation", 6)

	var estiloNormal := _estiloBoton(colorBotonCopiar, false)
	var estiloHover := _estiloBoton(colorBotonCopiarHover, true)
	var estiloPresionado := _estiloBoton(Color(1.0, 1.0, 1.0, 0.10), true)
	boton.add_theme_stylebox_override("normal", estiloNormal)
	boton.add_theme_stylebox_override("hover", estiloHover)
	boton.add_theme_stylebox_override("pressed", estiloPresionado)
	boton.add_theme_stylebox_override("focus", estiloNormal)
	boton.mouse_default_cursor_shape = Control.CURSOR_POINTING_HAND
	boton.pressed.connect(_alCopiarCodigo.bind(boton, codigo, lenguaje))
	return boton

func _estiloBoton(color: Color, conBorde: bool) -> StyleBoxFlat:
	var estilo := StyleBoxFlat.new()
	estilo.bg_color = color
	estilo.set_corner_radius_all(6)
	estilo.content_margin_left = 10
	estilo.content_margin_right = 10
	estilo.content_margin_top = 5
	estilo.content_margin_bottom = 5
	if conBorde:
		estilo.border_color = Color(1.0, 1.0, 1.0, 0.08)
		estilo.set_border_width_all(1)
	else:
		estilo.set_border_width_all(0)
	return estilo

func _crearIconoCopiar(color: Color) -> ImageTexture:
	var tamano := 14
	var imagen := Image.create(tamano, tamano, false, Image.FORMAT_RGBA8)
	imagen.fill(Color(0, 0, 0, 0))
	var rectFrente := Rect2i(1, 1, 9, 9)
	var rectFondo := Rect2i(4, 4, 9, 9)
	_dibujarRectBorde(imagen, rectFondo, color)
	_dibujarRectBorde(imagen, rectFrente, color)
	return ImageTexture.create_from_image(imagen)

func _dibujarRectBorde(imagen: Image, rect: Rect2i, color: Color) -> void:
	var x0 := rect.position.x
	var y0 := rect.position.y
	var x1 := rect.position.x + rect.size.x - 1
	var y1 := rect.position.y + rect.size.y - 1
	for x in range(x0, x1 + 1):
		if x >= 0 and x < imagen.get_width():
			if y0 >= 0 and y0 < imagen.get_height():
				imagen.set_pixel(x, y0, color)
			if y1 >= 0 and y1 < imagen.get_height():
				imagen.set_pixel(x, y1, color)
	for y in range(y0, y1 + 1):
		if y >= 0 and y < imagen.get_height():
			if x0 >= 0 and x0 < imagen.get_width():
				imagen.set_pixel(x0, y, color)
			if x1 >= 0 and x1 < imagen.get_width():
				imagen.set_pixel(x1, y, color)

func _crearIconoCheck(color: Color) -> ImageTexture:
	var tamano := 14
	var imagen := Image.create(tamano, tamano, false, Image.FORMAT_RGBA8)
	imagen.fill(Color(0, 0, 0, 0))
	var puntos := [
		Vector2i(2, 7), Vector2i(3, 8), Vector2i(4, 9), Vector2i(5, 10),
		Vector2i(6, 9), Vector2i(7, 8), Vector2i(8, 7), Vector2i(9, 6),
		Vector2i(10, 5), Vector2i(11, 4),
		Vector2i(3, 7), Vector2i(4, 8), Vector2i(5, 9),
		Vector2i(6, 8), Vector2i(7, 7), Vector2i(8, 6), Vector2i(9, 5), Vector2i(10, 4)
	]
	for p in puntos:
		if p.x >= 0 and p.x < tamano and p.y >= 0 and p.y < tamano:
			imagen.set_pixel(p.x, p.y, color)
	return ImageTexture.create_from_image(imagen)

func _alCopiarCodigo(boton: Button, codigo: String, lenguaje: String) -> void:
	DisplayServer.clipboard_set(codigo)
	boton.text = "Copied"
	boton.icon = _crearIconoCheck(colorAccentoCopiado)
	boton.add_theme_color_override("font_color", colorAccentoCopiado)
	boton.add_theme_color_override("font_hover_color", colorAccentoCopiado)
	boton.add_theme_stylebox_override("normal", _estiloBoton(colorBotonCopiar, false))
	boton.add_theme_stylebox_override("hover", _estiloBoton(colorBotonCopiarHover, true))
	codigoCopiado.emit(lenguaje, codigo)
	var temporizador := get_tree().create_timer(1.5)
	temporizador.timeout.connect(_restaurarBoton.bind(boton))

func _restaurarBoton(boton: Button) -> void:
	if not is_instance_valid(boton):
		return
	boton.text = "Copy"
	boton.icon = _crearIconoCopiar(Color(0.72, 0.72, 0.72, 0.95))
	boton.add_theme_color_override("font_color", Color(0.72, 0.72, 0.72, 0.95))
	boton.add_theme_color_override("font_hover_color", Color(0.95, 0.95, 0.95, 1.0))
	boton.add_theme_stylebox_override("normal", _estiloBoton(colorBotonCopiar, false))
	boton.add_theme_stylebox_override("hover", _estiloBoton(colorBotonCopiarHover, true))

func _obtenerFuenteMono() -> FontFile:
	if fuenteMonoespaciada:
		return fuenteMonoespaciada
	return _fuenteMonoPorDefecto

func _alMetaClicado(meta: Variant) -> void:
	if typeof(meta) != TYPE_STRING:
		enlaceNoManejadoClicado.emit(meta)
		return
	if meta.begins_with("{") and CLAVE_CASILLA in meta:
		var analizado: Dictionary = JSON.parse_string(meta)
		if analizado[CLAVE_CASILLA] and _analizador.registroCasillas.has(int(analizado.id)):
			_alCasillaClicada(int(analizado.id), analizado.checked)
		return
	if not enlacesAutomaticos:
		enlaceNoManejadoClicado.emit(meta)
		return
	if meta.begins_with("http") or meta.begins_with("ftp") or meta.contains("@"):
		OS.shell_open(meta)
	elif asumirHttps:
		OS.shell_open("https://" + meta)
	else:
		enlaceNoManejadoClicado.emit(meta)

func _alCasillaClicada(id: int, estabaMarcada: bool) -> void:
	var iLinea: int = _analizador.registroCasillas[id]
	var lineas := textoMarkdown.split("\n")
	var cadenaVieja := "[x]" if estabaMarcada else "[ ]"
	var cadenaNueva := "[ ]" if estabaMarcada else "[x]"
	var i := lineas[iLinea].find(cadenaVieja)
	if i == -1:
		return
	lineas[iLinea] = lineas[iLinea].erase(i, cadenaVieja.length()).insert(i, cadenaNueva)
	textoMarkdown = "\n".join(lineas)
	tareaCasillaClicada.emit(id, iLinea, not estabaMarcada, lineas[iLinea].substr(i + 4))

func _establecerTamanoFuente(valor: int) -> void:
	marcarSucio()

func _establecerColorTexto(valor: Color) -> void:
	colorTexto = valor
	marcarSucio()

func _establecerColorFondoTarjeta(valor: Color) -> void:
	colorFondoTarjeta = valor
	marcarSucio()

func _establecerColorEncabezadoTarjeta(valor: Color) -> void:
	colorEncabezadoTarjeta = valor
	marcarSucio()

func _establecerColorBordeTarjeta(valor: Color) -> void:
	colorBordeTarjeta = valor
	marcarSucio()

func _establecerColorTextoLenguaje(valor: Color) -> void:
	colorTextoLenguaje = valor
	marcarSucio()

func _establecerColorTextoCodigo(valor: Color) -> void:
	colorTextoCodigo = valor
	marcarSucio()

func _establecerColorBotonCopiar(valor: Color) -> void:
	colorBotonCopiar = valor
	marcarSucio()

func _establecerColorBotonHover(valor: Color) -> void:
	colorBotonCopiarHover = valor
	marcarSucio()

func _establecerColorAcento(valor: Color) -> void:
	colorAccentoCopiado = valor
	marcarSucio()

func _establecerRadioTarjeta(valor: int) -> void:
	radioTarjeta = valor
	marcarSucio()

func _establecerMargenTarjeta(valor: int) -> void:
	margenInternoTarjeta = valor
	marcarSucio()

func _establecerResaltado(valor: bool) -> void:
	resaltadoHabilitado = valor
	marcarSucio()

func _establecerClicksCasillas(valor: bool) -> void:
	habilitarClicksCasillas = valor
	marcarSucio()

func _establecerCharNoMarcado(valor: String) -> void:
	caracterNoMarcado = valor
	marcarSucio()

func _establecerCharMarcado(valor: String) -> void:
	caracterMarcado = valor
	marcarSucio()

func _establecerAlturaSeparador(valor: int) -> void:
	alturaSeparador = valor
	marcarSucio()

func _establecerAnchoSeparador(valor: float) -> void:
	anchoSeparador = valor
	marcarSucio()

func _establecerAlineacionSeparador(valor: String) -> void:
	alineacionSeparador = valor
	marcarSucio()

func _establecerColorSeparador(valor: Color) -> void:
	colorSeparador = valor
	marcarSucio()

func _establecerH1(valor: FormatoEncabezado) -> void:
	h1 = valor
	if h1 and not h1.changed.is_connected(marcarSucio):
		h1.changed.connect(marcarSucio)
	marcarSucio()

func _establecerH2(valor: FormatoEncabezado) -> void:
	h2 = valor
	if h2 and not h2.changed.is_connected(marcarSucio):
		h2.changed.connect(marcarSucio)
	marcarSucio()

func _establecerH3(valor: FormatoEncabezado) -> void:
	h3 = valor
	if h3 and not h3.changed.is_connected(marcarSucio):
		h3.changed.connect(marcarSucio)
	marcarSucio()

func _establecerH4(valor: FormatoEncabezado) -> void:
	h4 = valor
	if h4 and not h4.changed.is_connected(marcarSucio):
		h4.changed.connect(marcarSucio)
	marcarSucio()

func _establecerH5(valor: FormatoEncabezado) -> void:
	h5 = valor
	if h5 and not h5.changed.is_connected(marcarSucio):
		h5.changed.connect(marcarSucio)
	marcarSucio()

func _establecerH6(valor: FormatoEncabezado) -> void:
	h6 = valor
	if h6 and not h6.changed.is_connected(marcarSucio):
		h6.changed.connect(marcarSucio)
	marcarSucio()
