@tool
class_name FormatoEncabezado
extends Resource

@export var tamanoRelativo: float = 1.0: set = _establecerTamano
@export var negrita: bool = true: set = _establecerNegrita
@export var cursiva: bool = false: set = _establecerCursiva
@export var subrayado: bool = false: set = _establecerSubrayado
@export var sobrescribirColor: bool = false: set = _establecerSobrescribirColor
@export var colorFuente: Color = Color.WHITE: set = _establecerColorFuente
@export var dibujarLineaInferior: bool = false: set = _establecerLineaInferior

func _init(
	pTamano: float = 1.0,
	pNegrita: bool = true,
	pCursiva: bool = false,
	pSubrayado: bool = false,
	pSobrescribir: bool = false,
	pColor: Color = Color.WHITE,
	pLinea: bool = false
) -> void:
	resource_local_to_scene = true
	tamanoRelativo = pTamano
	negrita = pNegrita
	cursiva = pCursiva
	subrayado = pSubrayado
	sobrescribirColor = pSobrescribir
	colorFuente = pColor
	dibujarLineaInferior = pLinea

func _establecerTamano(valor: float) -> void:
	tamanoRelativo = valor
	emit_changed()

func _establecerNegrita(valor: bool) -> void:
	negrita = valor
	emit_changed()

func _establecerCursiva(valor: bool) -> void:
	cursiva = valor
	emit_changed()

func _establecerSubrayado(valor: bool) -> void:
	subrayado = valor
	emit_changed()

func _establecerSobrescribirColor(valor: bool) -> void:
	sobrescribirColor = valor
	emit_changed()

func _establecerColorFuente(valor: Color) -> void:
	colorFuente = valor
	emit_changed()

func _establecerLineaInferior(valor: bool) -> void:
	dibujarLineaInferior = valor
	emit_changed()
