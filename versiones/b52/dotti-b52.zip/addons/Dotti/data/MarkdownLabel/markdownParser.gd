@tool
extends RefCounted
class_name AnalizadorMarkdown

const MARCADOR_ESCAPE := ";$\uFFFD:%s$;"
const CARACTERES_ESCAPABLES := "\\*_~`[]()\"<>#-+.!"
const REGEX_CARACTERES_ESCAPABLES := "[\\\\\\*\\_\\~`\\[\\]\\(\\)\\\"\\<\\>#\\-\\+\\.\\!]"
const CLAVE_CASILLA := "markdownlabel-checkbox"

var textoConvertido: String
var nivelIndentacion: int
var mapaEscapes := {}
var parrafoActual: int = 0
var anclasEncabezado := {}
var dentroTabla := false
var filaTabla := -1
var omitirSaltoLinea := false
var idCasilla: int = 0
var lineaActual: int = 0
var registroCasillas := {}
var modoDepuracion := false

var _dentroBacktick := false
var _dentroTilde := false
var _cantidadCercaActual: int = 0
var _lenguajeBloqueCodigo := ""
var _lineasBloqueCodigo: PackedStringArray = []

var _espaciosIndent := []
var _tiposIndent := []

const _ScriptResaltador = preload("syntaxHighlighter.gd")
var _resaltador = _ScriptResaltador.new()
var resaltadoHabilitado := true

## Cache de expresiones regulares compiladas. Los patrones de este analizador
## son fijos, pero se compilaban de nuevo en cada llamada y estas funciones se
## llaman una vez por linea: en un texto con formato eso pesaba mas que el
## propio analisis. Ahora cada patron se compila una sola vez y se comparte
## entre lineas e instancias (search/search_all no dejan estado en el RegEx).
static var _cacheRegex := {}

static func _regex(patron: String) -> RegEx:
	var compilada: RegEx = _cacheRegex.get(patron)
	if compilada != null:
		return compilada
	compilada = RegEx.new()
	compilada.compile(patron)
	_cacheRegex[patron] = compilada
	return compilada

## Version del motor, consultada una sola vez. Engine.get_version_info() arma un
## diccionario nuevo cada vez y se llamaba en cada linea (separadores) y en cada
## encabezado.
static var _versionHex := int(Engine.get_version_info().hex)

var h1: FormatoEncabezado
var h2: FormatoEncabezado
var h3: FormatoEncabezado
var h4: FormatoEncabezado
var h5: FormatoEncabezado
var h6: FormatoEncabezado

var tamanoFuenteBase: int = 16

var caracterNoMarcado: String = "☐"
var caracterMarcado: String = "☑"
var habilitarClicksCasillas: bool = true
var alturaSeparador: int = 2
var anchoSeparador: float = 90
var alineacionSeparador: String = "center"
var colorSeparador: Color = Color("475569")
var colorFondoCodigoInline: String = "111827"

static func dividirSegmentos(textoFuente: String) -> Array:
	var segmentos := []
	var lineas := textoFuente.split("\n")
	var lineasTextoActual: PackedStringArray = []
	var lineasCodigoActual: PackedStringArray = []
	var enCodigo := false
	var lenguajeCodigo := ""
	var charCerca := ""
	var cantidadCerca := 0

	for linea in lineas:
		var recortada := linea.strip_edges()
		if not enCodigo:
			var bc := _contarCercaEstatico(recortada, "`")
			var tc := _contarCercaEstatico(recortada, "~")
			if bc >= 3:
				if lineasTextoActual.size() > 0:
					segmentos.append({"type": "text", "content": "\n".join(lineasTextoActual)})
					lineasTextoActual = PackedStringArray()
				enCodigo = true
				charCerca = "`"
				cantidadCerca = bc
				lenguajeCodigo = recortada.substr(bc).strip_edges().to_lower()
				lineasCodigoActual = PackedStringArray()
			elif tc >= 3:
				if lineasTextoActual.size() > 0:
					segmentos.append({"type": "text", "content": "\n".join(lineasTextoActual)})
					lineasTextoActual = PackedStringArray()
				enCodigo = true
				charCerca = "~"
				cantidadCerca = tc
				lenguajeCodigo = recortada.substr(tc).strip_edges().to_lower()
				lineasCodigoActual = PackedStringArray()
			else:
				lineasTextoActual.append(linea)
		else:
			var cc := _contarCercaEstatico(recortada, charCerca)
			if cc >= cantidadCerca and recortada == charCerca.repeat(cc):
				segmentos.append({"type": "code", "language": lenguajeCodigo, "content": "\n".join(lineasCodigoActual)})
				lineasCodigoActual = PackedStringArray()
				enCodigo = false
			else:
				lineasCodigoActual.append(linea)

	if enCodigo:
		segmentos.append({"type": "code", "language": lenguajeCodigo, "content": "\n".join(lineasCodigoActual)})
	if lineasTextoActual.size() > 0:
		segmentos.append({"type": "text", "content": "\n".join(lineasTextoActual)})
	return segmentos

static func _contarCercaEstatico(lineaRecortada: String, caracter: String) -> int:
	var contador := 0
	for c in lineaRecortada:
		if c == caracter:
			contador += 1
		else:
			break
	return contador

func resaltarCodigo(codigo: String, lenguaje: String) -> String:
	if not resaltadoHabilitado or lenguaje == "":
		return escaparBbcode(codigo)
	return _resaltador.resaltar(codigo, lenguaje, Callable(self, "escaparBbcode"))

func analizar(textoFuente: String) -> String:
	textoConvertido = ""
	var lineas := textoFuente.split("\n")
	lineaActual = 0
	nivelIndentacion = -1
	_espaciosIndent.clear()
	_tiposIndent.clear()
	_dentroBacktick = false
	_dentroTilde = false
	_cantidadCercaActual = 0
	_lenguajeBloqueCodigo = ""
	_lineasBloqueCodigo.clear()
	dentroTabla = false
	filaTabla = -1
	omitirSaltoLinea = false
	idCasilla = 0
	parrafoActual = 0
	anclasEncabezado.clear()
	mapaEscapes.clear()
	registroCasillas.clear()

	for linea: String in lineas:
		linea = linea.trim_suffix("\r")
		var enBloqueCodigo := _dentroTilde or _dentroBacktick
		if lineaActual > 0 and not omitirSaltoLinea and not enBloqueCodigo:
			textoConvertido += "\n"
			parrafoActual += 1
		omitirSaltoLinea = false
		lineaActual += 1

		if not _dentroTilde and _esCercaBloqueCodigo(linea, "`"):
			if _dentroBacktick:
				if _contarCaracteresCerca(linea.strip_edges(), "`") >= _cantidadCercaActual:
					_vaciarBloqueCodigo()
					_dentroBacktick = false
					continue
			else:
				_dentroBacktick = true
				_cantidadCercaActual = _contarCaracteresCerca(linea.strip_edges(), "`")
				_lenguajeBloqueCodigo = _extraerLenguaje(linea.strip_edges(), "`")
				_lineasBloqueCodigo.clear()
				continue
		elif not _dentroBacktick and _esCercaBloqueCodigo(linea, "~"):
			if _dentroTilde:
				if _contarCaracteresCerca(linea.strip_edges(), "~") >= _cantidadCercaActual:
					_vaciarBloqueCodigo()
					_dentroTilde = false
					continue
			else:
				_dentroTilde = true
				_cantidadCercaActual = _contarCaracteresCerca(linea.strip_edges(), "~")
				_lenguajeBloqueCodigo = _extraerLenguaje(linea.strip_edges(), "~")
				_lineasBloqueCodigo.clear()
				continue

		if enBloqueCodigo:
			_lineasBloqueCodigo.append(linea)
			continue

		var procesada := linea
		procesada = _procesarCaracteresEscapados(procesada)
		procesada = _procesarTabla(procesada)
		procesada = _procesarLista(procesada)
		procesada = _procesarCodigoInline(procesada)
		procesada = _procesarImagen(procesada)
		procesada = _procesarEnlace(procesada)
		procesada = _procesarSeparadorHorizontal(procesada)
		procesada = _procesarFormatoTexto(procesada)
		procesada = _procesarEncabezado(procesada)
		procesada = _resetearCaracteresEscapados(procesada)

		textoConvertido += procesada

	if _dentroBacktick or _dentroTilde:
		_vaciarBloqueCodigo()
	for i in range(nivelIndentacion, -1, -1):
		textoConvertido += "[/%s]" % _tiposIndent[i]
	if dentroTabla:
		textoConvertido += "\n[/table]"

	return textoConvertido

func _extraerLenguaje(lineaRecortada: String, caracter: String) -> String:
	var cantidad := _contarCaracteresCerca(lineaRecortada, caracter)
	var resto := lineaRecortada.substr(cantidad).strip_edges()
	return resto.to_lower()

func _vaciarBloqueCodigo() -> void:
	var textoCodigo := "\n".join(_lineasBloqueCodigo)
	var aperturaBg := "[bgcolor=#%s]" % colorFondoCodigoInline
	var cierreBg := "[/bgcolor]"
	if resaltadoHabilitado and _lenguajeBloqueCodigo != "":
		var resaltado := _resaltador.resaltar(textoCodigo, _lenguajeBloqueCodigo, Callable(self, "escaparBbcode"))
		textoConvertido += aperturaBg + "[code]" + resaltado + "[/code]" + cierreBg
	else:
		textoConvertido += aperturaBg + "[code]" + escaparBbcode(textoCodigo) + "[/code]" + cierreBg
	_lineasBloqueCodigo.clear()
	_lenguajeBloqueCodigo = ""

func _procesarLista(linea: String) -> String:
	var procesada := ""
	if linea.length() == 0 and nivelIndentacion >= 0:
		for i in range(nivelIndentacion, -1, -1):
			textoConvertido += "[/%s]" % _tiposIndent[nivelIndentacion]
			nivelIndentacion -= 1
			_espaciosIndent.pop_back()
			_tiposIndent.pop_back()
		textoConvertido += "\n"
		return ""
	if nivelIndentacion == -1:
		if linea.length() > 2 and linea[0] in "-*+" and linea[1] == " ":
			nivelIndentacion = 0
			_espaciosIndent.append(0)
			_tiposIndent.append("ul")
			textoConvertido += "[ul]"
			procesada = linea.substr(2)
			procesada = _procesarElementoTarea(procesada)
		elif linea.length() > 3 and linea[0] == "1" and linea[1] == "." and linea[2] == " ":
			nivelIndentacion = 0
			_espaciosIndent.append(0)
			_tiposIndent.append("ol")
			textoConvertido += "[ol]"
			procesada = linea.substr(3)
		else:
			procesada = linea
		return procesada
	var nEspacios := 0
	for c in linea:
		if c == " " or c == "\t":
			nEspacios += 1
			continue
		elif c in "-*+":
			if linea.length() > nEspacios + 2 and linea[nEspacios + 1] == " ":
				if nEspacios == _espaciosIndent[nivelIndentacion]:
					procesada = linea.substr(nEspacios + 2)
					procesada = _procesarElementoTarea(procesada)
					break
				elif nEspacios > _espaciosIndent[nivelIndentacion]:
					nivelIndentacion += 1
					_espaciosIndent.append(nEspacios)
					_tiposIndent.append("ul")
					textoConvertido += "[ul]"
					procesada = linea.substr(nEspacios + 2)
					procesada = _procesarElementoTarea(procesada)
					break
				else:
					for i in range(nivelIndentacion, -1, -1):
						if nEspacios < _espaciosIndent[i]:
							textoConvertido += "[/%s]" % _tiposIndent[nivelIndentacion]
							nivelIndentacion -= 1
							_espaciosIndent.pop_back()
							_tiposIndent.pop_back()
						else:
							break
					textoConvertido += "\n"
					procesada = linea.substr(nEspacios + 2)
					procesada = _procesarElementoTarea(procesada)
					break
		elif c in "123456789":
			if linea.length() > nEspacios + 3 and linea[nEspacios + 1] == "." and linea[nEspacios + 2] == " ":
				if nEspacios == _espaciosIndent[nivelIndentacion]:
					procesada = linea.substr(nEspacios + 3)
					break
				elif nEspacios > _espaciosIndent[nivelIndentacion]:
					nivelIndentacion += 1
					_espaciosIndent.append(nEspacios)
					_tiposIndent.append("ol")
					textoConvertido += "[ol]"
					procesada = linea.substr(nEspacios + 3)
					break
				else:
					for i in range(nivelIndentacion, -1, -1):
						if nEspacios < _espaciosIndent[i]:
							textoConvertido += "[/%s]" % _tiposIndent[nivelIndentacion]
							nivelIndentacion -= 1
							_espaciosIndent.pop_back()
							_tiposIndent.pop_back()
						else:
							break
					textoConvertido += "\n"
					procesada = linea.substr(nEspacios + 3)
					break
	if procesada.is_empty():
		for i in range(nivelIndentacion, -1, -1):
			textoConvertido += "[/%s]" % _tiposIndent[i]
			nivelIndentacion -= 1
			_espaciosIndent.pop_back()
			_tiposIndent.pop_back()
		textoConvertido += "\n"
		procesada = linea
	return procesada

func _procesarElementoTarea(item: String) -> String:
	if item.length() <= 3 or item[0] != "[" or item[2] != "]" or item[3] != " " or not item[1] in " x":
		return item
	var procesado := item.erase(0, 3)
	var casilla: String
	var meta := {
		CLAVE_CASILLA: true,
		"id": idCasilla
	}
	registroCasillas[idCasilla] = lineaActual - 1
	idCasilla += 1
	if item[1] == " ":
		casilla = caracterNoMarcado
		meta.checked = false
	elif item[1] == "x":
		casilla = caracterMarcado
		meta.checked = true
	if habilitarClicksCasillas:
		procesado = procesado.insert(0, "[url=%s]%s[/url]" % [JSON.stringify(meta), casilla])
	else:
		procesado = procesado.insert(0, casilla)
	return procesado

func _procesarCodigoInline(linea: String) -> String:
	if linea.find("`") == -1:
		return linea
	var regex := _regex("(`+)(.+?)\\1")
	var procesada := linea
	while true:
		var resultado := regex.search(procesada)
		if not resultado:
			break
		var inicio := resultado.get_start()
		var fin := resultado.get_end()
		var contenido := _resetearCaracteresEscapados(resultado.get_string(2), true)
		contenido = escaparBbcode(contenido)
		contenido = _escaparCaracteres(contenido)
		procesada = procesada.erase(inicio, fin - inicio).insert(inicio, "[bgcolor=#1f2937] [color=#f8fafc][code]%s[/code][/color] [/bgcolor]" % contenido)
	return procesada

func _procesarImagen(linea: String) -> String:
	if linea.find("![") == -1:
		return linea
	var procesada := linea
	var regexImagen := _regex("\\!\\[(.*?)\\]\\((.*?)\\)")
	var regexEtiqueta := _regex("\\[(.*?)\\]")
	var regexTitulo := _regex("\\\"(.*?)\\\"")
	while true:
		var resultado := regexImagen.search(procesada)
		if not resultado:
			break
		var coincidenciaValida := false
		var inicio := resultado.get_start()
		var fin := resultado.get_end()
		var textos := regexEtiqueta.search_all(resultado.get_string())
		for texto in textos:
			if resultado.get_string()[texto.get_end()] != "(":
				continue
			coincidenciaValida = true
			var textoAlt := resultado.get_string(1)
			var resultadoTitulo := regexTitulo.search(resultado.get_string(2))
			var titulo: String
			var url := resultado.get_string(2)
			if resultadoTitulo:
				titulo = resultadoTitulo.get_string(1)
				url = url.rstrip(" ").trim_suffix(resultadoTitulo.get_string()).rstrip(" ")
			url = _escaparCaracteres(url)
			procesada = procesada.erase(inicio, fin - inicio).insert(inicio, "[img%s%s]%s[/img]" % [
				" alt=\"%s\"" % textoAlt if textoAlt else "",
				" tooltip=\"%s\"" % titulo if resultadoTitulo and titulo else "",
				url,
			])
			break
		if not coincidenciaValida:
			break
	return procesada

func _procesarEnlace(linea: String) -> String:
	var procesada := linea
	var regexEnlace := _regex("\\[(.*?)\\]\\((.*?)\\)")
	var regexEtiqueta := _regex("\\[(.*?)\\]")
	var regexTitulo := _regex("\\\"(.*?)\\\"")
	# El patron exige "](" en algun punto: sin eso no hay enlace que buscar.
	if procesada.find("](") != -1:
		while true:
			var resultado := regexEnlace.search(procesada)
			if not resultado:
				break
			var coincidenciaValida := false
			var inicio := resultado.get_start()
			var fin := resultado.get_end()
			var textos := regexEtiqueta.search_all(resultado.get_string())
			for texto in textos:
				if resultado.get_string()[texto.get_end()] != "(":
					continue
				coincidenciaValida = true
				var resultadoTitulo := regexTitulo.search(resultado.get_string(2))
				var titulo: String
				var url := resultado.get_string(2)
				if resultadoTitulo:
					titulo = resultadoTitulo.get_string(1)
					url = url.rstrip(" ").trim_suffix(resultadoTitulo.get_string()).rstrip(" ")
				url = _escaparCaracteres(url)
				procesada = procesada.erase(
					inicio + texto.get_start(),
					fin - inicio - texto.get_start()
				).insert(
					inicio + texto.get_start(),
					"[url=%s][color=#60a5fa][u]%s[/u][/color][/url]" % [url, texto.get_string(1)]
				)
				if resultadoTitulo and titulo:
					procesada = procesada.insert(
						inicio + texto.get_start() + 12 + url.length() + texto.get_string(1).length(),
						"[/hint]"
					).insert(inicio + texto.get_start(), "[hint=%s]" % titulo)
				break
			if not coincidenciaValida:
				break
	var regexAngulo := _regex("\\<(.*?)\\>")
	var regexCorreo := _regex("^\\s*?([^\\s]+\\@[^\\s]+\\.[^\\s]+)\\s*?$")
	if procesada.find("<") != -1:
		while true:
			var resultado := regexAngulo.search(procesada)
			if not resultado:
				break
			var inicio := resultado.get_start()
			var fin := resultado.get_end()
			var url := resultado.get_string(1)
			var correo := regexCorreo.search(resultado.get_string(1))
			if correo:
				url = correo.get_string(1)
			url = _escaparCaracteres(url)
			if correo:
				procesada = procesada.erase(inicio, fin - inicio).insert(inicio, "[url=mailto:%s][color=#60a5fa][u]%s[/u][/color][/url]" % [url, url])
			else:
				procesada = procesada.erase(inicio, fin - inicio).insert(inicio, "[url=%s][color=#60a5fa][u]%s[/u][/color][/url]" % [url, url])
	return procesada

func _procesarFormatoTexto(linea: String) -> String:
	var procesada := linea
	var regexNegrita := _regex("(\\*\\*|\\_\\_)(.+?)\\1")
	while true:
		var resultado := regexNegrita.search(procesada)
		if not resultado:
			break
		var inicio := resultado.get_start()
		var fin := resultado.get_end()
		procesada = procesada.erase(inicio, 2).insert(inicio, "[b]")
		procesada = procesada.erase(fin - 1, 2).insert(fin - 1, "[/b]")

	var regexCursiva := _regex("(\\*|_)(.+?)\\1")
	while true:
		var resultado := regexCursiva.search(procesada)
		if not resultado:
			break
		var inicio := resultado.get_start()
		var fin := resultado.get_end()
		var cadena := resultado.get_string(2)
		var aperturaB := false
		var cierreB := false
		if cadena.begins_with("[b]") and cadena.find("[/b]") == -1:
			aperturaB = true
		elif cadena.ends_with("[/b]") and cadena.find("[b]") == -1:
			cierreB = true
		if aperturaB:
			procesada = procesada.erase(inicio, 4).insert(inicio, "[b][i]")
			procesada = procesada.erase(fin - 2, 1).insert(fin - 2, "[/i]")
		elif cierreB:
			procesada = procesada.erase(inicio, 1).insert(inicio, "[i]")
			procesada = procesada.erase(fin - 3, 5).insert(fin - 3, "[/i][/b]")
		else:
			procesada = procesada.erase(inicio, 1).insert(inicio, "[i]")
			procesada = procesada.erase(fin + 1, 1).insert(fin + 1, "[/i]")

	var regexTachado := _regex("(\\~\\~)(.+?)\\1")
	while true:
		var resultado := regexTachado.search(procesada)
		if not resultado:
			break
		var inicio := resultado.get_start()
		procesada = procesada.erase(inicio, 2).insert(inicio, "[s]")
		var fin := resultado.get_end()
		procesada = procesada.erase(fin - 1, 2).insert(fin - 1, "[/s]")

	return procesada

func _procesarEncabezado(linea: String) -> String:
	if not linea.begins_with("#"):
		return linea
	var procesada := linea
	var regex := _regex("^#+\\s*[^\\s].*")
	while true:
		var resultado := regex.search(procesada)
		if not resultado:
			break
		var n := 0
		for c in resultado.get_string():
			if c != "#" or n == 6:
				break
			n += 1
		var nEspacios := 0
		for c in resultado.get_string().substr(n):
			if c != " ":
				break
			nEspacios += 1
		var formato: FormatoEncabezado = _obtenerFormatoEncabezado(n)
		var inicio := resultado.get_start()
		var aperturas := _obtenerEtiquetasEncabezado(formato)
		procesada = procesada.erase(inicio, n + nEspacios).insert(inicio, aperturas)
		var fin := resultado.get_end()
		procesada = procesada.insert(fin - (n + nEspacios) + aperturas.length(), _obtenerEtiquetasEncabezado(formato, true))
		anclasEncabezado[_obtenerReferenciaEncabezado(resultado.get_string())] = parrafoActual
		if formato and formato.dibujarLineaInferior:
			if _versionHex >= 0x040500:
				procesada += "\n[hr height=%d width=%d%% align=left color=%s]" % [
					alturaSeparador, anchoSeparador, colorSeparador.to_html(),
				]
				lineaActual += 1
				parrafoActual += 1
	return procesada

func _procesarTabla(linea: String) -> String:
	if linea.count("|") < 2:
		if dentroTabla:
			dentroTabla = false
			return "[/table]\n" + linea
		else:
			return linea
	filaTabla += 1
	var partes := linea.trim_prefix("|").trim_suffix("|").split("|")
	var procesada := ""
	if not dentroTabla:
		procesada += "[table=%d]\n" % partes.size()
		dentroTabla = true
	elif filaTabla == 1:
		var esDelimitador := true
		for celda in partes:
			var recortada := celda.strip_edges()
			if recortada.count("-") + recortada.count(":") != recortada.length():
				esDelimitador = false
				break
		if esDelimitador:
			omitirSaltoLinea = true
			return ""
	for i in range(partes.size()):
		var celda := partes[i].strip_edges()
		procesada += "[cell]%s[/cell]" % celda
	return procesada

func _procesarSeparadorHorizontal(linea: String) -> String:
	if _versionHex < 0x040500:
		return linea
	var procesada := linea
	var regex := _regex(r"^[ ]{0,3}([\-_*])\1{2,}\s*$")
	var resultado := regex.search(procesada)
	if resultado:
		procesada = "[hr height=%d width=%d%% align=%s color=%s]" % [
			alturaSeparador, anchoSeparador, alineacionSeparador, colorSeparador.to_html(),
		]
	return procesada

func escaparBbcode(fuente: String) -> String:
	return fuente.replacen("[", MARCADOR_ESCAPE).replacen("]", "[rb]").replacen(MARCADOR_ESCAPE, "[lb]")

func _escaparCaracteres(texto: String) -> String:
	var escapado := texto
	for c: String in CARACTERES_ESCAPABLES:
		if not c in mapaEscapes:
			mapaEscapes[c] = mapaEscapes.size()
		escapado = escapado.replacen(c, MARCADOR_ESCAPE % mapaEscapes[c])
	return escapado

func _resetearCaracteresEscapados(texto: String, esCodigo := false) -> String:
	var desescapado := texto
	for c in CARACTERES_ESCAPABLES:
		if not c in mapaEscapes:
			continue
		desescapado = desescapado.replacen(MARCADOR_ESCAPE % mapaEscapes[c], "\\" + c if esCodigo else c)
	return desescapado

func _esCercaBloqueCodigo(linea: String, caracter: String) -> bool:
	var recortada := linea.strip_edges()
	var cantidad := _contarCaracteresCerca(recortada, caracter)
	if cantidad < 3:
		return false
	var resto := recortada.substr(cantidad).strip_edges()
	if resto.is_empty() or (not caracter in resto and not " " in resto):
		return true
	return false

func _contarCaracteresCerca(lineaRecortada: String, caracter: String) -> int:
	var contador := 0
	for c in lineaRecortada:
		if c == caracter:
			contador += 1
		else:
			break
	return contador

func _procesarCaracteresEscapados(linea: String) -> String:
	if linea.find("\\") == -1:
		return linea
	var regex := _regex("\\\\" + REGEX_CARACTERES_ESCAPABLES)
	var procesada := linea
	while true:
		var resultado := regex.search(procesada)
		if not resultado:
			break
		var inicio := resultado.get_start()
		var caracterEscapado := resultado.get_string()[1]
		if not caracterEscapado in mapaEscapes:
			mapaEscapes[caracterEscapado] = mapaEscapes.size()
		procesada = procesada.erase(inicio, 2).insert(inicio, MARCADOR_ESCAPE % mapaEscapes[caracterEscapado])
	return procesada

func _obtenerFormatoEncabezado(nivel: int) -> FormatoEncabezado:
	match nivel:
		1: return h1
		2: return h2
		3: return h3
		4: return h4
		5: return h5
		6: return h6
	return null

func _obtenerEtiquetasEncabezado(formato: FormatoEncabezado, cierre := false) -> String:
	if not formato:
		return ""
	var etiquetas := ""
	if not cierre:
		if formato.tamanoRelativo > 0:
			etiquetas += "[font_size=%d]" % int(formato.tamanoRelativo * tamanoFuenteBase)
		if formato.sobrescribirColor:
			etiquetas += "[color=#%s]" % formato.colorFuente.to_html()
		if formato.negrita:
			etiquetas += "[b]"
		if formato.cursiva:
			etiquetas += "[i]"
		if formato.subrayado:
			etiquetas += "[u]"
	else:
		if formato.subrayado:
			etiquetas += "[/u]"
		if formato.cursiva:
			etiquetas += "[/i]"
		if formato.negrita:
			etiquetas += "[/b]"
		if formato.sobrescribirColor:
			etiquetas += "[/color]"
		if formato.tamanoRelativo > 0:
			etiquetas += "[/font_size]"
	return etiquetas

func _obtenerReferenciaEncabezado(textoEncabezado: String) -> String:
	var regex := _regex("[^a-z0-9\\s-]")
	var ref := textoEncabezado.to_lower().strip_edges().trim_prefix("#").strip_edges()
	ref = regex.sub(ref, "", true).replace(" ", "-")
	return "#" + ref
