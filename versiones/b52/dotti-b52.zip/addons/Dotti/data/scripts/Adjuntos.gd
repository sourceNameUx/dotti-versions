@tool
class_name Adjuntos

## Adjuntos del chat: imagenes que el usuario pega o elige, guardadas en user://.
##
## Al adjuntar una imagen se copia a user://dotti_adjuntos ya recortada a un
## tamano razonable. No se guarda la ruta original a proposito: el archivo de
## origen puede moverse o borrarse mientras el chat sigue abierto, y el chat
## guardado tiene que poder reenviar la imagen al reabrirlo.
##
## Igual que las copias de seguridad, vive en user:// y no en el proyecto: son
## archivos de trabajo del chat, no del juego.
##
## Los adjuntos de texto NO pasan por aqui: van pegados en el mensaje.

const RAIZ := "user://dotti_adjuntos/"

## Tipos que el upstream acepta como imagen (los mismos que opencode:
## jpeg, png, gif y webp).
const EXTENSIONES_IMAGEN := ["png", "jpg", "jpeg", "gif", "webp"]

## Lado maximo al guardar. Mas grande no aporta nada al modelo y multiplica el
## peso de cada turno (la imagen va en base64 y se reenvia en cada peticion que
## la incluya).
const LADO_MAXIMO := 1536

## Si el PNG pasa de aqui y la imagen no tiene transparencia, se recodifica en
## JPEG. Una captura de 1536 px en PNG ronda los 2 MB; en JPEG, una decima parte.
const BYTES_ANTES_DE_JPEG := 1_500_000

## Dias que se conservan los adjuntos que ya no usa ningun chat abierto.
const DIAS_RETENCION := 30

## Techo de archivos guardados. Se poda lo mas viejo.
const MAX_ARCHIVOS := 500


## Extension que el modelo entiende como imagen.
static func esImagen(ruta: String) -> bool:
	return EXTENSIONES_IMAGEN.has(ruta.get_extension().to_lower())


static func mime(ruta: String) -> String:
	match ruta.get_extension().to_lower():
		"png":
			return "image/png"
		"jpg", "jpeg":
			return "image/jpeg"
		"gif":
			return "image/gif"
		"webp":
			return "image/webp"
	return "application/octet-stream"


## Imagen del portapapeles, ya guardada. "" si el portapapeles no trae imagen.
static func delPortapapeles() -> String:
	# El driver headless no tiene portapapeles y pedirlo escupe un error en
	# consola: se pregunta antes si existe la funcion.
	if not DisplayServer.has_feature(DisplayServer.FEATURE_CLIPBOARD):
		return ""
	if not DisplayServer.clipboard_has_image():
		return ""
	var img := DisplayServer.clipboard_get_image()
	if img == null or img.is_empty():
		return ""
	return guardarImagen(img, "pasted")


## Texto del portapapeles. "" si el driver no tiene portapapeles.
static func delPortapapelesTexto() -> String:
	if not DisplayServer.has_feature(DisplayServer.FEATURE_CLIPBOARD):
		return ""
	return DisplayServer.clipboard_get()


## Copia una imagen de disco a user://, recortada. "" si no se pudo leer.
static func normalizar(ruta: String) -> String:
	var img := Image.new()
	if img.load(ruta) != OK:
		# load() falla con los formatos que Godot no decodifica (svg, por
		# ejemplo). Se intenta por bytes antes de rendirse.
		var f := FileAccess.open(ruta, FileAccess.READ)
		if f == null:
			return ""
		var bytes := f.get_buffer(f.get_length())
		f.close()
		if img.load_png_from_buffer(bytes) != OK and img.load_jpg_from_buffer(bytes) != OK and img.load_webp_from_buffer(bytes) != OK:
			return ""
	return guardarImagen(img, ruta.get_file().get_basename())


## Guarda una imagen en RAIZ. Devuelve su ruta, o "" si no se pudo.
static func guardarImagen(img: Image, nombre: String) -> String:
	if img == null or img.is_empty():
		return ""
	var trabajo := Image.new()
	trabajo.copy_from(img)
	_ajustarTamano(trabajo)
	var bytes := trabajo.save_png_to_buffer()
	var extension := "png"
	if bytes.size() > BYTES_ANTES_DE_JPEG and trabajo.detect_alpha() == Image.ALPHA_NONE:
		var jpg := trabajo.save_jpg_to_buffer(0.85)
		if not jpg.is_empty() and jpg.size() < bytes.size():
			bytes = jpg
			extension = "jpg"
	if bytes.is_empty():
		return ""
	var destino := _rutaLibre(nombre, extension)
	if destino == "":
		return ""
	if DirAccess.make_dir_recursive_absolute(ProjectSettings.globalize_path(RAIZ)) != OK:
		return ""
	var out := FileAccess.open(destino, FileAccess.WRITE)
	if out == null:
		return ""
	out.store_buffer(bytes)
	out.close()
	return destino


## Parte image_url con la imagen en data URL base64, que es lo que espera el
## upstream. Las imagenes que ya no esten en disco se omiten sin romper el
## mensaje: el chat guardado puede ser mas viejo que la retencion.
static func partesOpenai(rutas: Array) -> Array:
	var partes: Array = []
	for ruta in rutas:
		var r := str(ruta)
		if not FileAccess.file_exists(r):
			continue
		var f := FileAccess.open(r, FileAccess.READ)
		if f == null:
			continue
		var bytes := f.get_buffer(f.get_length())
		f.close()
		if bytes.is_empty():
			continue
		partes.append({
			"type": "image_url",
			"image_url": {"url": "data:%s;base64,%s" % [mime(r), Marshalls.raw_to_base64(bytes)]}
		})
	return partes


## Mensaje de la API con el texto y las imagenes adjuntas. Sin imagenes devuelve
## el texto plano de siempre: los proveedores que no son multimodales no saben
## leer una lista de partes.
static func mensajeOpenai(rol: String, texto: String, imagenes: Variant) -> Dictionary:
	if typeof(imagenes) != TYPE_ARRAY:
		return {"role": rol, "content": texto}
	var partes := partesOpenai(imagenes as Array)
	if partes.is_empty():
		return {"role": rol, "content": texto}
	var contenido: Array = []
	if texto != "":
		contenido.append({"type": "text", "text": texto})
	contenido.append_array(partes)
	return {"role": rol, "content": contenido}


## Borra los adjuntos mas viejos que la retencion y los que pasen del techo.
## Se llama al abrir el chat: los adjuntos de un chat viejo que ya no se abre no
## tienen por que seguir ocupando disco.
static func limpiarViejos() -> void:
	var rutas := _listar()
	if rutas.is_empty():
		return
	var ahora := Time.get_unix_time_from_system()
	var limite := ahora - DIAS_RETENCION * 86400
	for ruta in rutas:
		if FileAccess.get_modified_time(ruta) < limite:
			DirAccess.remove_absolute(ProjectSettings.globalize_path(ruta))
	var quedan := _listar()
	if quedan.size() <= MAX_ARCHIVOS:
		return
	for i in range(MAX_ARCHIVOS, quedan.size()):
		DirAccess.remove_absolute(ProjectSettings.globalize_path(quedan[i]))


## De mas nuevo a mas viejo.
static func _listar() -> Array:
	var salida: Array = []
	var d := DirAccess.open(RAIZ)
	if d == null:
		return salida
	d.list_dir_begin()
	var n := d.get_next()
	while n != "":
		if not d.current_is_dir():
			salida.append(RAIZ + n)
		n = d.get_next()
	d.list_dir_end()
	salida.sort_custom(func(a, b): return FileAccess.get_modified_time(a) > FileAccess.get_modified_time(b))
	return salida


static func _ajustarTamano(img: Image) -> void:
	var lado := maxi(img.get_width(), img.get_height())
	if lado <= LADO_MAXIMO:
		return
	var factor := float(LADO_MAXIMO) / float(lado)
	img.resize(maxi(1, int(img.get_width() * factor)), maxi(1, int(img.get_height() * factor)), Image.INTERPOLATE_LANCZOS)


## True si el texto del portapapeles es la ruta de un archivo que existe (copiar
## un archivo en el explorador lo deja asi). Una sola linea y con pinta de ruta:
## asi pegar codigo o una frase con dos puntos no se confunde con un adjunto.
static func esRutaDeArchivo(texto: String) -> bool:
	if texto == "" or texto.contains("\n") or texto.length() > 400:
		return false
	if not (texto.begins_with("res://") or texto.begins_with("user://") or texto.begins_with("/") or texto.contains(":")):
		return false
	return FileAccess.file_exists(texto.replace("\\", "/"))


## Prepara un adjunto: {ruta, nombre, imagen}, o {} si el archivo no se puede
## usar. Las imagenes se copian a user:// y el resto se queda con su ruta.
static func preparar(ruta: String, nombreMostrado: String = "") -> Dictionary:
	var real := ruta.replace("\\", "/")
	if real == "" or not FileAccess.file_exists(real):
		return {}
	var imagen := esImagen(real)
	var guardada := real
	if imagen:
		# La copia es lo que permite reabrir el chat manana: el archivo original
		# puede haberse movido o borrado.
		guardada = normalizar(real)
		if guardada == "":
			return {}
	var nombre := nombreMostrado
	if nombre == "":
		nombre = real.get_file()
	return {"ruta": guardada, "nombre": nombre, "imagen": imagen}


## Ruta que no pisa un adjunto existente: el nombre lleva la fecha y, si aun asi
## coincide, un contador.
static func _rutaLibre(nombre: String, extension: String) -> String:
	var base := _limpiarNombre(nombre)
	var marca := Time.get_datetime_string_from_system(false, true).replace(":", "-").replace(" ", "_")
	var intento := RAIZ + "%s_%s.%s" % [base, marca, extension]
	var n := 1
	while FileAccess.file_exists(intento):
		n += 1
		intento = RAIZ + "%s_%s_%d.%s" % [base, marca, n, extension]
	return intento


## Nombre de archivo seguro: nada de separadores ni de "..".
static func _limpiarNombre(nombre: String) -> String:
	var out := ""
	for i in nombre.length():
		var c := nombre.substr(i, 1)
		if (c >= "a" and c <= "z") or (c >= "A" and c <= "Z") or (c >= "0" and c <= "9") or c == "_" or c == "-" or c == ".":
			out += c
		else:
			out += "_"
	out = out.strip_edges()
	if out == "" or out == "." or out == "..":
		return "imagen"
	return out
