@tool
class_name CopiasSeguridad

## Copias de seguridad automaticas de los archivos del proyecto antes de tocarlos.
##
## Viven en user:// y NO en el proyecto: el usuario no quiere respaldos mezclados
## con su codigo ni viendolos en el file system del editor. Antes de que una
## herramienta escriba, mueva o borre un archivo, su contenido actual se copia a
## user://dotti_backups/<origen>/<nombre>.<fecha>.bak.
##
## La copia es byte a byte y ocurre ANTES de la escritura, asi que todo cambio
## tiene vuelta atras aunque el modelo no se acuerde de pedirla. La herramienta
## "Restore file backup" es la que la deshace.
##
## Nota: en GDScript str(null) es "<null>", no "null"; aqui no se compara texto
## que venga de JSON, pero se mantiene la costumbre de mirar tipos.

const RAIZ := "user://dotti_backups/"

## Copias que se conservan por archivo. Al pasar de aqui se borra la mas vieja.
const MAX_POR_ARCHIVO := 20
## Archivos mas grandes que esto no se copian (son assets, no codigo).
const MAX_BYTES_ARCHIVO := 4 * 1024 * 1024
## Techo global de archivos de copia; al superarlo se poda lo mas viejo. Es el
## unico limite global: los archivos de codigo pesan poco y un tope de bytes
## obligaria a medir los 2000 en cada escritura.
const MAX_ARCHIVOS_GLOBAL := 2000


## Copia el archivo indicado si existe. Devuelve la ruta de la copia, o "" si no
## habia nada que copiar (archivo nuevo, ruta no respaldable o demasiado grande).
static func respaldar(path: String, motivo: String = "", podar_global: bool = true) -> String:
	if path == "" or path.begins_with(RAIZ):
		return ""
	if not FileAccess.file_exists(path):
		return ""
	var destino := _rutaDeCopia(path)
	if destino == "":
		return ""
	var f := FileAccess.open(path, FileAccess.READ)
	if f == null:
		return ""
	var bytes := f.get_buffer(f.get_length())
	f.close()
	if bytes.size() > MAX_BYTES_ARCHIVO:
		return ""
	var err := DirAccess.make_dir_recursive_absolute(ProjectSettings.globalize_path(destino.get_base_dir()))
	if err != OK:
		return ""
	var out := FileAccess.open(destino, FileAccess.WRITE)
	if out == null:
		return ""
	out.store_buffer(bytes)
	out.close()
	_podar(path)
	if podar_global:
		_podarGlobal()
	return destino


## Cola que las herramientas anaden a su resultado para que el modelo sepa que hay
## copia y donde. Va en la salida de la herramienta y no en un aviso aparte: asi
## lo tiene delante si el cambio sale mal.
static func sufijoAviso(copia: String) -> String:
	if copia == "":
		return ""
	return "\nPrevious content backed up to: " + copia


## Copia el archivo de la escena abierta en el editor, si ya tiene uno. Va antes
## de guardar: la escena vive en memoria y el editor la escribe sin pasar por
## ninguna herramienta de archivos.
static func respaldarEscenaAbierta() -> String:
	if not Engine.is_editor_hint():
		return ""
	var root := EditorInterface.get_edited_scene_root()
	if root == null:
		return ""
	return respaldar(str(root.get("scene_file_path")), "scene save")


## Copia recursiva de una carpeta a punto de ser borrada o reemplazada. Cada
## archivo va a parar al mismo arbol relativo que respaldar(), asi que despues se
## puede restaurar archivo por archivo. Devuelve el recuento de lo copiado.
static func respaldarArbol(dir: String, motivo: String = "") -> Dictionary:
	var copiados := 0
	var omitidos := 0
	# La poda global se deja para el final: recorre y ordena TODAS las copias, y
	# hacerlo una vez por archivo convertia respaldar una carpeta en minutos.
	for ruta in _archivosDe(dir):
		if respaldar(ruta, motivo, false) == "":
			omitidos += 1
		else:
			copiados += 1
	_podarGlobal()
	return {"copiados": copiados, "omitidos": omitidos}


## Copias existentes de un archivo, de la mas reciente a la mas antigua.
static func listar(path: String) -> Array:
	var salida := _copiasDe(path)
	_ordenarPorFecha(salida)
	return salida


## Las copias de un archivo, SIN ordenar. Ordenarlas pregunta la fecha de
## modificacion dos veces por comparacion, asi que quien solo necesita saber
## cuantas hay -la poda, sin ir mas lejos- usa esta y no `listar`.
static func _copiasDe(path: String) -> Array:
	var carpeta := _carpetaDeCopia(path)
	var prefijo := _nombreBase(path) + "."
	var salida: Array = []
	var d := DirAccess.open(carpeta)
	if d == null:
		return salida
	d.list_dir_begin()
	var n := d.get_next()
	while n != "":
		if not d.current_is_dir() and _esCopiaDe(n, prefijo):
			salida.append(carpeta.path_join(n))
		n = d.get_next()
	d.list_dir_end()
	return salida


## Todas las copias guardadas, de la mas reciente a la mas antigua.
static func listarTodo() -> Array:
	var salida := _todasLasCopias()
	_ordenarPorFecha(salida)
	return salida


## Todas las copias, SIN ordenar. Igual que `_copiasDe`: ordenar una lista larga
## solo para saber si pasa del techo es trabajo tirado.
static func _todasLasCopias() -> Array:
	var salida: Array = []
	_recogerCopias(RAIZ, salida)
	return salida


## De mas nueva a mas vieja. Manda la fecha de modificacion y, si empatan (dos
## copias del mismo segundo), el nombre, que lleva el sufijo con ceros.
static func _ordenarPorFecha(rutas: Array) -> void:
	# La fecha se pregunta UNA vez por copia y no dos por comparacion: con miles
	# de copias, preguntarla dentro del comparador es lo que hacia que listarlas
	# tardara segundos.
	var fechas := {}
	for ruta in rutas:
		fechas[ruta] = FileAccess.get_modified_time(ruta)
	rutas.sort_custom(func(a, b):
		var ta: int = fechas[a]
		var tb: int = fechas[b]
		if ta == tb:
			return str(a) > str(b)
		return ta > tb)


## Devuelve el archivo original al estado de la copia indicada. Antes de pisar,
## guarda el contenido actual (restaurar tambien es destructivo y tambien tiene
## que poder deshacerse). El destino se puede dar a mano cuando la copia no
## permite deducir de donde salio.
static func restaurar(copia: String, destino: String = "") -> Dictionary:
	if not FileAccess.file_exists(copia):
		return {"ok": false, "mensaje": "Backup not found: " + copia}
	var objetivo := destino
	if objetivo == "":
		objetivo = _rutaOriginal(copia)
	if objetivo == "":
		return {"ok": false, "mensaje": "Cannot tell which file this backup came from. Pass destination explicitly."}
	if objetivo.begins_with(RAIZ):
		return {"ok": false, "mensaje": "Refusing to restore inside the backup folder."}
	var f := FileAccess.open(copia, FileAccess.READ)
	if f == null:
		return {"ok": false, "mensaje": "Could not read the backup: " + copia}
	var bytes := f.get_buffer(f.get_length())
	f.close()
	respaldar(objetivo, "before restore")
	var out := FileAccess.open(objetivo, FileAccess.WRITE)
	if out == null:
		return {"ok": false, "mensaje": "Could not write to: " + objetivo}
	out.store_buffer(bytes)
	out.close()
	HerramientasArchivos.refrescarScriptSiAbierto(objetivo)
	return {"ok": true, "mensaje": "Restored: %s (%d bytes)" % [objetivo, bytes.size()], "destino": objetivo}


## Ruta de la copia que le corresponde a un archivo de proyecto. "" si el archivo
## esta fuera de res:// y user:// (fuera del proyecto no se toca nada).
static func _rutaDeCopia(path: String) -> String:
	var rel := _relativo(path)
	if rel == "":
		return ""
	var carpeta := RAIZ.path_join(rel).get_base_dir()
	var nombre := _nombreBase(path)
	var prefijo := nombre + "."
	# La secuencia no se reutiliza nunca: es lo que hace que ordenar por nombre sea
	# ordenar por fecha. Buscar "el primer nombre libre" fallaba: al podar quedaba
	# libre el nombre base y la copia nueva ordenaba como la mas vieja, justo la
	# que la retencion borra. Y en rafagas de escrituras dentro del mismo segundo,
	# que es lo normal en un bucle de herramientas, pasaba siempre.
	var secuencia := _siguienteSecuencia(carpeta, prefijo)
	return carpeta.path_join("%s%s_%05d.bak" % [prefijo, _marcaDeTiempo(), secuencia])


## Siguiente numero de copia de un archivo: el mayor que ya existe mas uno. Como
## solo crece, dos copias nunca comparten nombre y el orden del nombre es el orden
## real.
static func _siguienteSecuencia(carpeta: String, prefijo: String) -> int:
	var mayor := 0
	var d := DirAccess.open(carpeta)
	if d == null:
		return 1
	d.list_dir_begin()
	var n := d.get_next()
	while n != "":
		if not d.current_is_dir() and _esCopiaDe(n, prefijo):
			var cuerpo := n.substr(prefijo.length(), n.length() - prefijo.length() - 4)
			var corte := cuerpo.rfind("_")
			if corte != -1:
				mayor = max(mayor, cuerpo.substr(corte + 1).to_int())
		n = d.get_next()
	d.list_dir_end()
	return mayor + 1


## Un nombre es copia de un archivo si empieza por "<archivo>." y sigue con la
## marca de tiempo. El digito de despues evita que las copias de "Player.gd"
## cuenten tambien como copias de "Player.gd.uid".
static func _esCopiaDe(nombre: String, prefijo: String) -> bool:
	if not nombre.begins_with(prefijo) or not nombre.ends_with(".bak"):
		return false
	var siguiente := nombre.substr(prefijo.length(), 1)
	return siguiente >= "0" and siguiente <= "9"


static func _carpetaDeCopia(path: String) -> String:
	var rel := _relativo(path)
	if rel == "":
		return ""
	return RAIZ.path_join(rel).get_base_dir()


## "res://a/b.gd" -> "res/a/b.gd". Cada segmento se limpia para que no pueda
## escapar de la carpeta de copias con "..".
static func _relativo(path: String) -> String:
	var p := path.replace("\\", "/")
	var cuerpo := ""
	if p.begins_with("res://"):
		cuerpo = "res/" + p.substr(6)
	elif p.begins_with("user://"):
		cuerpo = "user/" + p.substr(7)
	else:
		return ""
	var partes := cuerpo.split("/", false)
	var limpias: PackedStringArray = []
	for parte in partes:
		limpias.append(_limpiarSegmento(parte))
	return "/".join(limpias)


static func _limpiarSegmento(s: String) -> String:
	var out := ""
	for i in s.length():
		var c := s.substr(i, 1)
		if (c >= "a" and c <= "z") or (c >= "A" and c <= "Z") or (c >= "0" and c <= "9") or c == "_" or c == "-" or c == ".":
			out += c
		else:
			out += "_"
	if out == "" or out == "." or out == "..":
		return "_"
	return out


static func _nombreBase(path: String) -> String:
	return path.replace("\\", "/").get_file()


## Marca de tiempo ordenable como texto: "2026-09-22_11-30-05". Si dos escrituras
## caen en el mismo segundo se anade un sufijo para no pisar la copia anterior.
static func _marcaDeTiempo() -> String:
	var s := Time.get_datetime_string_from_system(false, true)
	s = s.replace(":", "-").replace(" ", "_")
	return s


## De la copia al archivo original. Solo se puede deducir cuando la copia salio
## de res:// o user://, que es el unico caso en el que se respalda.
static func _rutaOriginal(copia: String) -> String:
	var p := copia.replace("\\", "/")
	if not p.begins_with(RAIZ):
		return ""
	var rel := p.substr(RAIZ.length())
	# Quita "<nombre>.<fecha>.bak": dos puntos, la fecha, y la extension.
	var corte := rel.rfind(".")
	if corte == -1:
		return ""
	var sinBak := rel.substr(0, corte)
	var punto := sinBak.rfind(".")
	if punto == -1:
		return ""
	var soloRuta := sinBak.substr(0, punto)
	if soloRuta.begins_with("res/"):
		return "res://" + soloRuta.substr(4)
	if soloRuta.begins_with("user/"):
		return "user://" + soloRuta.substr(5)
	return ""


static func _archivosDe(dir: String) -> Array:
	var salida: Array = []
	var d := DirAccess.open(dir)
	if d == null:
		return salida
	d.list_dir_begin()
	var n := d.get_next()
	while n != "":
		if n != "." and n != "..":
			var hijo := dir.path_join(n)
			if d.current_is_dir():
				salida.append_array(_archivosDe(hijo))
			else:
				salida.append(hijo)
		n = d.get_next()
	d.list_dir_end()
	return salida


static func _recogerCopias(dir: String, salida: Array) -> void:
	for ruta in _archivosDe(dir):
		if ruta.ends_with(".bak"):
			salida.append(ruta)


## Se queda con las MAX_POR_ARCHIVO copias mas recientes de un archivo.
static func _podar(path: String) -> void:
	var copias := _copiasDe(path)
	if copias.size() <= MAX_POR_ARCHIVO:
		return
	_ordenarPorFecha(copias)
	for i in range(MAX_POR_ARCHIVO, copias.size()):
		DirAccess.remove_absolute(ProjectSettings.globalize_path(copias[i]))


## Poda global por cantidad y por peso, de lo mas viejo a lo mas nuevo.
static func _podarGlobal() -> void:
	var todas := _todasLasCopias()
	if todas.size() <= MAX_ARCHIVOS_GLOBAL:
		return
	_ordenarPorFecha(todas)
	for i in range(MAX_ARCHIVOS_GLOBAL, todas.size()):
		DirAccess.remove_absolute(ProjectSettings.globalize_path(todas[i]))
