class_name Historial
extends Window

signal chatSeleccionado(idChat: String)
signal chatNuevoSolicitado

const RUTA_HISTORIAL := "user://meteor_ia_historial/"
const RUTA_INDICE := "user://meteor_ia_historial/_index.json"
const LOTE_RENDERIZADO := 8

const COLOR_FONDO := Color(0.094, 0.094, 0.094, 1.0)
const COLOR_PANEL_FONDO := Color(0.094, 0.094, 0.094, 0.96)
const COLOR_PANEL_BORDE := Color(0.20, 0.20, 0.20, 0.9)
const COLOR_USUARIO_BG := Color(0.16, 0.16, 0.16, 0.98)
const COLOR_USUARIO_BORDE := Color(0.28, 0.28, 0.28, 0.85)
const COLOR_ASISTENTE_BG := Color(0.098, 0.098, 0.098, 0.96)
const COLOR_ASISTENTE_BORDE := Color(0.22, 0.22, 0.22, 0.75)
const COLOR_TEXTO_PRIMARIO := Color(0.90, 0.90, 0.90, 1.0)
const COLOR_TEXTO_SECUNDARIO := Color(0.62, 0.62, 0.62, 1.0)
const COLOR_TEXTO_TENUE := Color(0.43, 0.43, 0.43, 1.0)
const COLOR_ACENTO := Color(0.88, 0.88, 0.88, 1.0)
const COLOR_ACENTO_SUAVE := Color(0.60, 0.60, 0.60, 0.75)
const COLOR_PELIGRO := Color(0.75, 0.50, 0.50, 1.0)

var _contenedorLista: VBoxContainer
var _dialogoConfirmacion: ConfirmationDialog
var _dialogoBorrarTodo: ConfirmationDialog
var _idParaEliminar: String = ""
var _inputBusqueda: LineEdit
var _labelContador: Label
var _chatsCache: Array = []
var _filtroActual: String = ""
var _panelCarga: Control = null
var _labelCargaEstado: Label = null
var _renderTokenActual: int = 0
var _cargando: bool = false

func _ready() -> void:
	var windowSize = DisplayServer.window_get_size()
	title = "History — Dotti"
	min_size = windowSize * 0.6
	wrap_controls = true
	transient = true
	unresizable = false

	close_requested.connect(queue_free)

	var fondo := Panel.new()
	fondo.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	fondo.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var estiloFondo := StyleBoxFlat.new()
	estiloFondo.bg_color = COLOR_FONDO
	fondo.add_theme_stylebox_override("panel", estiloFondo)
	add_child(fondo)

	_dialogoConfirmacion = ConfirmationDialog.new()
	_dialogoConfirmacion.title = "Delete chat"
	_dialogoConfirmacion.dialog_text = "Are you sure you want to delete this chat? This action cannot be undone."
	_dialogoConfirmacion.confirmed.connect(_confirmarEliminacion)
	add_child(_dialogoConfirmacion)

	_dialogoBorrarTodo = ConfirmationDialog.new()
	_dialogoBorrarTodo.title = "Delete all chats"
	_dialogoBorrarTodo.dialog_text = "Are you sure you want to delete ALL saved chats? This action cannot be undone."
	_dialogoBorrarTodo.confirmed.connect(_confirmarBorrarTodo)
	add_child(_dialogoBorrarTodo)

	var margen := MarginContainer.new()
	margen.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	margen.add_theme_constant_override("margin_left", 18)
	margen.add_theme_constant_override("margin_right", 18)
	margen.add_theme_constant_override("margin_top", 16)
	margen.add_theme_constant_override("margin_bottom", 18)
	add_child(margen)

	var columna := VBoxContainer.new()
	columna.add_theme_constant_override("separation", 14)
	margen.add_child(columna)

	var encabezado := _construirEncabezado()
	columna.add_child(encabezado)

	var filaBusqueda := _construirFilaBusqueda()
	columna.add_child(filaBusqueda)

	var filaAcciones := _construirFilaAcciones()
	columna.add_child(filaAcciones)

	var scroll := ScrollContainer.new()
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	scroll.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	columna.add_child(scroll)

	_contenedorLista = VBoxContainer.new()
	_contenedorLista.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_contenedorLista.add_theme_constant_override("separation", 8)
	scroll.add_child(_contenedorLista)

	_panelCarga = _construirPanelCarga()
	_contenedorLista.add_child(_panelCarga)
	popup_centered()
	await get_tree().process_frame
	_cargarCacheAsync()
	await get_tree().process_frame
	if _inputBusqueda:
		_inputBusqueda.grab_focus()

func _construirEncabezado() -> Control:
	var panel := PanelContainer.new()
	var estilo := StyleBoxFlat.new()
	estilo.bg_color = COLOR_ASISTENTE_BG
	estilo.border_color = COLOR_PANEL_BORDE
	estilo.border_width_left = 1
	estilo.border_width_top = 1
	estilo.border_width_right = 1
	estilo.border_width_bottom = 1
	estilo.corner_radius_top_left = 2
	estilo.corner_radius_top_right = 2
	estilo.corner_radius_bottom_left = 2
	estilo.corner_radius_bottom_right = 2
	estilo.content_margin_left = 16
	estilo.content_margin_right = 12
	estilo.content_margin_top = 12
	estilo.content_margin_bottom = 12
	panel.add_theme_stylebox_override("panel", estilo)

	var fila := HBoxContainer.new()
	fila.add_theme_constant_override("separation", 10)
	panel.add_child(fila)

	var textos := VBoxContainer.new()
	textos.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	textos.add_theme_constant_override("separation", 2)
	fila.add_child(textos)

	var titulo := Label.new()
	titulo.text = "Chat history"
	titulo.add_theme_color_override("font_color", COLOR_TEXTO_PRIMARIO)
	textos.add_child(titulo)

	_labelContador = Label.new()
	_labelContador.text = "0 chats"
	_labelContador.add_theme_color_override("font_color", COLOR_TEXTO_SECUNDARIO)
	textos.add_child(_labelContador)

	var botonNuevo := _crearBotonIconoPlano("+", "New chat")
	botonNuevo.pressed.connect(_alSolicitarNuevoChat)
	fila.add_child(botonNuevo)

	return panel

func _crearBotonIconoPlano(icono: String, tooltip: String) -> Button:
	var b := Button.new()
	b.text = icono
	b.tooltip_text = tooltip
	b.flat = true
	b.focus_mode = Control.FOCUS_NONE
	b.custom_minimum_size = Vector2(30, 30)
	b.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	b.mouse_default_cursor_shape = Control.CURSOR_POINTING_HAND
	b.add_theme_color_override("font_color", COLOR_TEXTO_SECUNDARIO)
	b.add_theme_color_override("font_hover_color", COLOR_TEXTO_PRIMARIO)
	b.add_theme_color_override("font_pressed_color", COLOR_TEXTO_PRIMARIO)

	var normal := StyleBoxFlat.new()
	normal.bg_color = Color(0, 0, 0, 0)
	normal.corner_radius_top_left = 2
	normal.corner_radius_top_right = 2
	normal.corner_radius_bottom_left = 2
	normal.corner_radius_bottom_right = 2
	normal.content_margin_left = 6
	normal.content_margin_right = 6
	normal.content_margin_top = 2
	normal.content_margin_bottom = 2
	var hover := normal.duplicate() as StyleBoxFlat
	hover.bg_color = Color(1, 1, 1, 0.06)
	var pressed := normal.duplicate() as StyleBoxFlat
	pressed.bg_color = Color(1, 1, 1, 0.10)

	b.add_theme_stylebox_override("normal", normal)
	b.add_theme_stylebox_override("hover", hover)
	b.add_theme_stylebox_override("pressed", pressed)
	b.add_theme_stylebox_override("focus", normal)
	b.add_theme_stylebox_override("disabled", normal)
	return b

func _construirFilaBusqueda() -> Control:
	var panel := PanelContainer.new()
	panel.add_theme_stylebox_override("panel", _estiloInput(false))

	var fila := HBoxContainer.new()
	fila.add_theme_constant_override("separation", 8)
	panel.add_child(fila)

	var lupa := Label.new()
	lupa.text = "⌕"
	lupa.add_theme_color_override("font_color", COLOR_TEXTO_SECUNDARIO)
	lupa.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	fila.add_child(lupa)

	_inputBusqueda = LineEdit.new()
	_inputBusqueda.placeholder_text = "Search chats..."
	_inputBusqueda.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_inputBusqueda.add_theme_color_override("font_color", COLOR_TEXTO_PRIMARIO)
	_inputBusqueda.add_theme_color_override("font_placeholder_color", COLOR_TEXTO_SECUNDARIO)
	_inputBusqueda.add_theme_color_override("caret_color", COLOR_TEXTO_PRIMARIO)
	_inputBusqueda.add_theme_color_override("selection_color", Color(1, 1, 1, 0.18))
	var vacio := StyleBoxEmpty.new()
	_inputBusqueda.add_theme_stylebox_override("normal", vacio)
	_inputBusqueda.add_theme_stylebox_override("focus", vacio)
	_inputBusqueda.text_changed.connect(_alCambiarBusqueda)
	fila.add_child(_inputBusqueda)

	return panel

func _construirFilaAcciones() -> Control:
	var fila := HBoxContainer.new()
	fila.add_theme_constant_override("separation", 8)
	fila.size_flags_horizontal = Control.SIZE_EXPAND_FILL

	var spacer := Control.new()
	spacer.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	fila.add_child(spacer)

	var botonBorrarTodo := _crearBotonIconoPlano("×", "Delete all chats")
	botonBorrarTodo.add_theme_color_override("font_hover_color", COLOR_PELIGRO)
	botonBorrarTodo.pressed.connect(func(): _dialogoBorrarTodo.popup_centered())
	fila.add_child(botonBorrarTodo)

	return fila

func _estiloInput(foco: bool) -> StyleBoxFlat:
	var e := StyleBoxFlat.new()
	e.bg_color = Color(0.082, 0.082, 0.082, 0.98)
	e.border_color = COLOR_ACENTO_SUAVE if foco else COLOR_PANEL_BORDE
	e.border_width_left = 1
	e.border_width_top = 1
	e.border_width_right = 1
	e.border_width_bottom = 1
	e.corner_radius_top_left = 2
	e.corner_radius_top_right = 2
	e.corner_radius_bottom_left = 2
	e.corner_radius_bottom_right = 2
	e.content_margin_left = 12
	e.content_margin_right = 12
	e.content_margin_top = 9
	e.content_margin_bottom = 9
	return e

func _alCambiarBusqueda(texto: String) -> void:
	_filtroActual = texto.strip_edges().to_lower()
	_renderizarLista()

func _alSolicitarNuevoChat() -> void:
	chatNuevoSolicitado.emit()
	queue_free()

func _construirPanelCarga() -> Control:
	var panel := PanelContainer.new()
	panel.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	var estilo := StyleBoxFlat.new()
	estilo.bg_color = Color(0.10, 0.10, 0.10, 0.95)
	estilo.border_color = COLOR_PANEL_BORDE
	estilo.border_width_left = 2
	estilo.corner_radius_top_left = 2
	estilo.corner_radius_top_right = 2
	estilo.corner_radius_bottom_left = 2
	estilo.corner_radius_bottom_right = 2
	estilo.content_margin_left = 16
	estilo.content_margin_right = 16
	estilo.content_margin_top = 22
	estilo.content_margin_bottom = 22
	panel.add_theme_stylebox_override("panel", estilo)
	var vbox := VBoxContainer.new()
	vbox.alignment = BoxContainer.ALIGNMENT_CENTER
	vbox.add_theme_constant_override("separation", 10)
	panel.add_child(vbox)
	var fila := HBoxContainer.new()
	fila.alignment = BoxContainer.ALIGNMENT_CENTER
	fila.add_theme_constant_override("separation", 10)
	vbox.add_child(fila)
	var spinner := Label.new()
	spinner.name = "SpinnerCarga"
	spinner.text = "⠋"
	spinner.add_theme_color_override("font_color", COLOR_ACENTO)
	fila.add_child(spinner)
	_labelCargaEstado = Label.new()
	_labelCargaEstado.text = "Loading chats..."
	_labelCargaEstado.add_theme_color_override("font_color", COLOR_TEXTO_PRIMARIO)
	fila.add_child(_labelCargaEstado)
	var frames := ["⠋", "⠙", "⠹", "⠸", "⠼", "⠴", "⠦", "⠧", "⠇", "⠏"]
	var frame := [0]
	var timer := Timer.new()
	timer.wait_time = 0.08
	timer.one_shot = false
	# Por bandera: este panel se construye antes de que la ventana este arriba.
	timer.autostart = true
	panel.add_child(timer)
	timer.timeout.connect(func():
		if is_instance_valid(spinner):
			frame[0] = (frame[0] + 1) % frames.size()
			spinner.text = frames[frame[0]]
	)
	return panel

func _cargarCacheAsync() -> void:
	if _cargando:
		return
	_cargando = true
	await get_tree().process_frame
	_chatsCache = _cargarDesdeIndice()
	if _chatsCache.is_empty():
		if is_instance_valid(_labelCargaEstado):
			_labelCargaEstado.text = "Scanning chat files..."
		await get_tree().process_frame
		_chatsCache = await _cargarTodosLosChatsProgresivo()
		_reconstruirIndice(_chatsCache)
	_chatsCache.sort_custom(func(a, b): return a["timestamp"] > b["timestamp"])
	_cargando = false
	if is_instance_valid(_panelCarga):
		_panelCarga.queue_free()
		_panelCarga = null
	_renderizarLista()

func _cargarCache() -> void:
	_chatsCache = _cargarDesdeIndice()
	if _chatsCache.is_empty():
		_chatsCache = _cargarTodosLosChats()
		_reconstruirIndice(_chatsCache)
	_chatsCache.sort_custom(func(a, b): return a["timestamp"] > b["timestamp"])

func _cargarDesdeIndice() -> Array:
	var resultado: Array = []
	if not FileAccess.file_exists(RUTA_INDICE):
		return resultado
	var f := FileAccess.open(RUTA_INDICE, FileAccess.READ)
	if f == null:
		return resultado
	var texto := f.get_as_text()
	f.close()
	var json := JSON.new()
	if json.parse(texto) != OK:
		return resultado
	var datos = json.get_data()
	if typeof(datos) != TYPE_ARRAY:
		return resultado
	for item in datos:
		if typeof(item) != TYPE_DICTIONARY:
			continue
		var id := str(item.get("id", ""))
		if id == "":
			continue
		var ruta := RUTA_HISTORIAL + id + ".json"
		if not FileAccess.file_exists(ruta):
			continue
		resultado.append({
			"id": id,
			"titulo": str(item.get("titulo", "")),
			"timestamp": int(item.get("timestamp", 0))
		})
	return resultado

func _reconstruirIndice(chats: Array) -> void:
	var lista: Array = []
	for chat in chats:
		lista.append({
			"id": str(chat.get("id", "")),
			"titulo": str(chat.get("titulo", "")),
			"timestamp": int(chat.get("timestamp", 0))
		})
	var f := FileAccess.open(RUTA_INDICE, FileAccess.WRITE)
	if f == null:
		return
	f.store_string(JSON.stringify(lista))
	f.close()

func _cargarTodosLosChatsProgresivo() -> Array:
	var resultado: Array = []
	if not DirAccess.dir_exists_absolute(RUTA_HISTORIAL):
		return resultado
	var dir := DirAccess.open(RUTA_HISTORIAL)
	if dir == null:
		return resultado
	dir.list_dir_begin()
	var nombre := dir.get_next()
	var contador := 0
	while nombre != "":
		if nombre.ends_with(".json") and nombre != "_index.json":
			var ruta := RUTA_HISTORIAL + nombre
			var archivo := FileAccess.open(ruta, FileAccess.READ)
			if archivo:
				var json := JSON.new()
				if json.parse(archivo.get_as_text()) == OK:
					var datos = json.get_data()
					if typeof(datos) == TYPE_DICTIONARY:
						resultado.append({
							"id": str(datos.get("id", nombre.get_basename())),
							"titulo": str(datos.get("titulo", "")),
							"timestamp": int(datos.get("timestamp", 0))
						})
				archivo.close()
			contador += 1
			if contador % 10 == 0:
				if is_instance_valid(_labelCargaEstado):
					_labelCargaEstado.text = "Scanning chat files... (%d)" % contador
				await get_tree().process_frame
		nombre = dir.get_next()
	dir.list_dir_end()
	return resultado

func _renderizarLista() -> void:
	for hijo in _contenedorLista.get_children():
		hijo.queue_free()

	var filtrados: Array = []
	if _filtroActual == "":
		filtrados = _chatsCache
	else:
		for chat in _chatsCache:
			var titulo: String = str(chat.get("titulo", "")).to_lower()
			if titulo.find(_filtroActual) != -1:
				filtrados.append(chat)

	if _labelContador:
		if _filtroActual == "":
			_labelContador.text = "%d chat%s" % [_chatsCache.size(), "s" if _chatsCache.size() != 1 else ""]
		else:
			_labelContador.text = "%d of %d match" % [filtrados.size(), _chatsCache.size()]

	if filtrados.is_empty():
		var vacio := Label.new()
		if _chatsCache.is_empty():
			vacio.text = "No saved chats yet."
		else:
			vacio.text = "No chats match your search."
		vacio.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		vacio.add_theme_color_override("font_color", COLOR_TEXTO_TENUE)
		var margenVacio := MarginContainer.new()
		margenVacio.add_theme_constant_override("margin_top", 40)
		margenVacio.add_theme_constant_override("margin_bottom", 40)
		margenVacio.add_child(vacio)
		_contenedorLista.add_child(margenVacio)
		return

	_renderTokenActual += 1
	_renderizarPorLotes(filtrados, _renderTokenActual)

func _renderizarPorLotes(filtrados: Array, token: int) -> void:
	var i := 0
	while i < filtrados.size():
		if token != _renderTokenActual:
			return
		var fin: int = mini(i + LOTE_RENDERIZADO, filtrados.size())
		for j in range(i, fin):
			_crearEntradaChat(filtrados[j])
		i = fin
		if i < filtrados.size():
			await get_tree().process_frame

func _crearEntradaChat(chat: Dictionary) -> void:
	var idChat := str(chat.get("id", ""))

	var tarjeta := PanelContainer.new()
	tarjeta.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	tarjeta.mouse_filter = Control.MOUSE_FILTER_STOP
	tarjeta.mouse_default_cursor_shape = Control.CURSOR_POINTING_HAND

	var estiloNormal := _estiloTarjetaChat(false)
	var estiloHover := _estiloTarjetaChat(true)
	tarjeta.add_theme_stylebox_override("panel", estiloNormal)

	tarjeta.mouse_entered.connect(func():
		if is_instance_valid(tarjeta):
			tarjeta.add_theme_stylebox_override("panel", estiloHover)
	)
	tarjeta.mouse_exited.connect(func():
		if is_instance_valid(tarjeta):
			tarjeta.add_theme_stylebox_override("panel", estiloNormal)
	)
	tarjeta.gui_input.connect(func(evento):
		if evento is InputEventMouseButton and evento.pressed and evento.button_index == MOUSE_BUTTON_LEFT:
			_alSeleccionarChat(idChat)
	)
	_contenedorLista.add_child(tarjeta)

	var fila := HBoxContainer.new()
	fila.add_theme_constant_override("separation", 10)
	fila.mouse_filter = Control.MOUSE_FILTER_IGNORE
	tarjeta.add_child(fila)

	var infoContenedor := VBoxContainer.new()
	infoContenedor.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	infoContenedor.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	infoContenedor.add_theme_constant_override("separation", 2)
	infoContenedor.mouse_filter = Control.MOUSE_FILTER_IGNORE
	fila.add_child(infoContenedor)

	var labelTitulo := Label.new()
	labelTitulo.text = chat.get("titulo", "Untitled chat")
	labelTitulo.text_overrun_behavior = TextServer.OVERRUN_TRIM_ELLIPSIS
	labelTitulo.clip_text = true
	labelTitulo.add_theme_color_override("font_color", COLOR_TEXTO_PRIMARIO)
	labelTitulo.mouse_filter = Control.MOUSE_FILTER_IGNORE
	infoContenedor.add_child(labelTitulo)

	var fecha_raw = chat.get("timestamp", 0)
	var dict_fecha = Time.get_datetime_dict_from_unix_time(fecha_raw)
	var texto_fecha = "%02d/%02d/%d  %02d:%02d" % [dict_fecha.day, dict_fecha.month, dict_fecha.year, dict_fecha.hour, dict_fecha.minute]

	var labelFecha := Label.new()
	labelFecha.text = texto_fecha
	labelFecha.add_theme_color_override("font_color", COLOR_TEXTO_TENUE)
	labelFecha.mouse_filter = Control.MOUSE_FILTER_IGNORE
	infoContenedor.add_child(labelFecha)

	var botonEliminar := _crearBotonIconoPlano("✕", "Delete chat")
	botonEliminar.add_theme_color_override("font_color", COLOR_TEXTO_TENUE)
	botonEliminar.add_theme_color_override("font_hover_color", COLOR_PELIGRO)
	botonEliminar.custom_minimum_size = Vector2(28, 28)
	botonEliminar.pressed.connect(_intentarEliminarChat.bind(idChat))
	fila.add_child(botonEliminar)

func _estiloTarjetaChat(hover: bool) -> StyleBoxFlat:
	var e := StyleBoxFlat.new()
	e.bg_color = COLOR_USUARIO_BG if hover else COLOR_ASISTENTE_BG
	e.border_color = COLOR_USUARIO_BORDE if hover else COLOR_ASISTENTE_BORDE
	e.border_width_left = 3
	e.border_width_top = 1
	e.border_width_right = 1
	e.border_width_bottom = 1
	e.corner_radius_top_left = 2
	e.corner_radius_top_right = 2
	e.corner_radius_bottom_left = 2
	e.corner_radius_bottom_right = 2
	e.content_margin_left = 14
	e.content_margin_right = 10
	e.content_margin_top = 10
	e.content_margin_bottom = 10
	e.shadow_color = Color(0, 0, 0, 0.2)
	e.shadow_size = 0
	e.shadow_offset = Vector2(0, 1)
	return e

func _alSeleccionarChat(idChat: String) -> void:
	chatSeleccionado.emit(idChat)
	queue_free()

func _intentarEliminarChat(idChat: String) -> void:
	_idParaEliminar = idChat
	_dialogoConfirmacion.popup_centered()

func _confirmarEliminacion() -> void:
	if _idParaEliminar == "": return
	var ruta := RUTA_HISTORIAL + _idParaEliminar + ".json"
	if FileAccess.file_exists(ruta):
		DirAccess.remove_absolute(ruta)
	var idEliminado := _idParaEliminar
	_idParaEliminar = ""
	var nuevaCache: Array = []
	for c in _chatsCache:
		if str(c.get("id", "")) != idEliminado:
			nuevaCache.append(c)
	_chatsCache = nuevaCache
	_reconstruirIndice(_chatsCache)
	_renderizarLista()

func _confirmarBorrarTodo() -> void:
	if not DirAccess.dir_exists_absolute(RUTA_HISTORIAL):
		return
	var dir := DirAccess.open(RUTA_HISTORIAL)
	if dir == null:
		return
	dir.list_dir_begin()
	var nombre := dir.get_next()
	while nombre != "":
		if nombre.ends_with(".json"):
			DirAccess.remove_absolute(RUTA_HISTORIAL + nombre)
		nombre = dir.get_next()
	dir.list_dir_end()
	_chatsCache.clear()
	_reconstruirIndice(_chatsCache)
	_renderizarLista()

func _cargarTodosLosChats() -> Array:
	var resultado: Array = []
	if not DirAccess.dir_exists_absolute(RUTA_HISTORIAL):
		return resultado
	var dir := DirAccess.open(RUTA_HISTORIAL)
	if dir == null:
		return resultado
	dir.list_dir_begin()
	var nombre := dir.get_next()
	while nombre != "":
		if nombre.ends_with(".json"):
			var ruta    := RUTA_HISTORIAL + nombre
			var archivo := FileAccess.open(ruta, FileAccess.READ)
			if archivo:
				var json := JSON.new()
				if json.parse(archivo.get_as_text()) == OK:
					var datos = json.get_data()
					if typeof(datos) == TYPE_DICTIONARY:
						resultado.append(datos)
				archivo.close()
		nombre = dir.get_next()
	dir.list_dir_end()
	return resultado

static func guardarChat(idChat: String, titulo: String, mensajes: Array, timestamp: int, tituloIA: bool = false, tareas: Array = [], resumen: String = "", corte: int = 0, agente: String = "", fechaResumen: int = 0) -> void:
	var dir := DirAccess.open("user://")
	if not dir.dir_exists("meteor_ia_historial"):
		dir.make_dir("meteor_ia_historial")
	var datos := {
		"id":        idChat,
		"titulo":    titulo,
		"timestamp": timestamp,
		"mensajes":  mensajes,
	}
	# Marca de "este titulo lo escribio la IA": evita volver a pedirlo al reabrir
	# el chat. Los chats viejos no traen el campo y se leen como false.
	if tituloIA:
		datos["titulo_ia"] = true
	# Lista de tareas de la sesion (la de "Update todo list"). Va aqui y no en los
	# mensajes porque es estado, no conversacion: al reabrir el chat el panel vuelve
	# a salir con lo que quedaba pendiente. Vacia no se guarda.
	if not tareas.is_empty():
		datos["tareas"] = tareas
	# Checkpoint de la compactacion: el resumen de lo que ya no se envia y hasta
	# que mensaje del historial llega. Sin resumen no se guarda nada (un chat que
	# nunca se ha recortado no trae los campos, como los chats viejos).
	if resumen.strip_edges() != "" and corte > 1:
		datos["resumen"] = resumen
		datos["corte"] = corte
		# Cuando se corto. La fila de la compactacion lo dice ("at 14:32") y esa
		# hora no se puede recalcular al reabrir. Los chats cortados antes de
		# que existiera el campo se leen con el recuento a secas.
		if fechaResumen > 0:
			datos["fechaResumen"] = fechaResumen
	# Agente activo del chat (P9): nombre del archivo, no el prompt entero, que el
	# prompt se relee del disco al reabrir y asi un arreglo en el archivo vale ya.
	if agente.strip_edges() != "":
		datos["agente"] = agente.strip_edges()
	var archivo := FileAccess.open(RUTA_HISTORIAL + idChat + ".json", FileAccess.WRITE)
	if archivo:
		archivo.store_string(JSON.stringify(datos))
		archivo.close()
	_actualizarIndiceEntrada(idChat, titulo, timestamp)

static func _actualizarIndiceEntrada(idChat: String, titulo: String, timestamp: int) -> void:
	var lista: Array = []
	if FileAccess.file_exists(RUTA_INDICE):
		var f := FileAccess.open(RUTA_INDICE, FileAccess.READ)
		if f:
			var j := JSON.new()
			if j.parse(f.get_as_text()) == OK:
				var d = j.get_data()
				if typeof(d) == TYPE_ARRAY:
					lista = d
			f.close()
	var encontrado := false
	for i in range(lista.size()):
		if typeof(lista[i]) == TYPE_DICTIONARY and str(lista[i].get("id", "")) == idChat:
			lista[i] = {"id": idChat, "titulo": titulo, "timestamp": timestamp}
			encontrado = true
			break
	if not encontrado:
		lista.append({"id": idChat, "titulo": titulo, "timestamp": timestamp})
	var fw := FileAccess.open(RUTA_INDICE, FileAccess.WRITE)
	if fw:
		fw.store_string(JSON.stringify(lista))
		fw.close()

static func cargarChat(idChat: String) -> Dictionary:
	var ruta := RUTA_HISTORIAL + idChat + ".json"
	if not FileAccess.file_exists(ruta):
		return {}
	var archivo := FileAccess.open(ruta, FileAccess.READ)
	if not archivo:
		return {}
	var json := JSON.new()
	if json.parse(archivo.get_as_text()) != OK:
		archivo.close()
		return {}
	archivo.close()
	var datos = json.get_data()
	if typeof(datos) == TYPE_DICTIONARY:
		return datos
	return {}

static func generarTitulo(primerMensaje: String) -> String:
	var titulo := primerMensaje.strip_edges()
	if titulo.length() > 40:
		titulo = titulo.substr(0, 40) + "…"
	return titulo

static func generarId() -> String:
	return "chat_" + str(Time.get_unix_time_from_system())
