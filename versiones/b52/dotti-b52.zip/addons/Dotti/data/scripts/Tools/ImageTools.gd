@tool
class_name HerramientasImagenes

## Herramientas de imagen: que el modelo VEA una imagen del proyecto y que pueda
## pedir una captura de lo que se esta viendo (el editor) o del juego en marcha.
##
## Las dos devuelven rutas de user://dotti_adjuntos (Adjuntos), que es lo que el
## chat convierte en parte image_url al mandar y en miniatura al pintar.
##
## El juego en ejecucion vive en OTRO proceso: su ventana no esta en ninguna
## textura del editor (comprobado en 4.7: la ventana de la vista de juego se
## dibuja fuera, y la textura del GameView solo trae su barra). La unica forma de
## ver sus pixeles es que se haga la foto el mismo, asi que se lanza con una escena
## envoltorio que espera y guarda un PNG. Esa escena y ese script viven en
## user://: el proyecto del usuario no se toca.

## Envoltorio y foto de usar y tirar.
const RAIZ_CAPTURAS := "user://dotti_captura/"
const ENVOLTORIO_GD := RAIZ_CAPTURAS + "envoltorio.gd"
const ENVOLTORIO_TSCN := RAIZ_CAPTURAS + "envoltorio.tscn"
const FOTO_JUEGO := RAIZ_CAPTURAS + "juego.png"

## Vistas que sabe capturar.
const VISTAS := ["editor", "2d", "3d", "game"]

## Una vista que no esta en pantalla se dibuja en un viewport de 2x2. Por debajo
## de esto la textura no es una vista: es un hueco, y hay que traerla al frente.
const LADO_MINIMO := 32

## Margen de espera de la foto del juego, ademas de los segundos pedidos.
const MARGEN_ESPERA := 20.0

## Tope del retoque de espera de dibujo, en segundos.
const TOPE_DIBUJO := 1.0


static func registrar(chat: Node) -> void:
	chat.registrarHerramienta(
		"View image",
		"Open an image file and look at it. The image is attached to the conversation. Use it for sprites, textures, tilesets, mockups, diagrams and any screenshot you need to see with your own eyes.",
		{"path": {"type": "string", "description": "Image path: a project one (res://..., or relative) or a user:// one. Formats: png, jpg, jpeg, gif, webp."}},
		["path"],
		_verImagen
	)
	chat.registrarHerramienta(
		"Capture view",
		"Take a screenshot and look at it. view=\"editor\" captures the whole editor window, \"2d\" the 2D editor view, \"3d\" the 3D editor view and \"game\" runs the project scene and captures the running game itself. For view=game the scene has to be started by this tool, so a scene that is already running is restarted and whatever was happening in it is lost. The image is attached to the conversation.",
		{
			"view": {"type": "string", "description": "What to capture: editor, 2d, 3d or game. Defaults to editor."},
			"scene": {"type": "string", "description": "Only for view=game: scene to run, e.g. res://levels/level_1.tscn. Defaults to the project main scene."},
			"seconds": {"type": "number", "description": "Only for view=game: seconds to let the scene run before the shot, so it has time to load and settle. Defaults to 1.5."},
		},
		["view"],
		_capturarVista
	)


## Abre una imagen y la deja lista para mandarsela al modelo. Se copia a user://
## (Adjuntos la recorta a 1536 px): la del proyecto puede cambiar o desaparecer, y
## el chat guardado tiene que seguir pudiendo reenviarla manana.
static func _verImagen(args: Dictionary) -> Dictionary:
	var resolucion := Rutas.imagen(args.get("path", ""))
	if not bool(resolucion["ok"]):
		return _error(str(resolucion["motivo"]))
	var ruta: String = str(resolucion["ruta"])
	if not FileAccess.file_exists(ruta):
		return _error("File not found: %s" % ruta)
	if not Adjuntos.esImagen(ruta):
		return _error("%s is not an image. Supported formats: %s." % [ruta, ", ".join(Adjuntos.EXTENSIONES_IMAGEN)])
	var preparado := Adjuntos.preparar(ruta)
	if preparado.is_empty():
		return _error("Could not decode %s as an image. It may be corrupt or in a format Godot cannot read." % ruta)
	var guardada := str(preparado.get("ruta", ""))
	return {
		"success": true,
		"output": "Attached %s as an image%s. Look at it before answering." % [ruta, _tamano(guardada)],
		"imagenes": [guardada],
	}


static func _capturarVista(args: Dictionary) -> Dictionary:
	var vista := str(args.get("view", "editor")).strip_edges().to_lower()
	if vista == "":
		vista = "editor"
	if not VISTAS.has(vista):
		return _error("Invalid view '%s'. Choose from: %s." % [vista, ", ".join(VISTAS)])
	if vista == "game":
		return await _capturarJuego(args)
	return await _capturarEditor(vista)


## Captura lo que el editor esta ensenando. Una vista que no esta en primer plano
## no se dibuja: se trae un momento, se saca la foto y se deja el editor como
## estaba.
static func _capturarEditor(vista: String) -> Dictionary:
	if not Engine.is_editor_hint():
		return _error("Not running in editor context.")
	var vp: Viewport = null
	var etiqueta := ""
	var pantalla := ""
	match vista:
		"editor":
			var base := EditorInterface.get_base_control()
			if base == null:
				return _error("The editor window is not available.")
			vp = base.get_viewport()
			etiqueta = "the editor window"
		"2d":
			vp = EditorInterface.get_editor_viewport_2d()
			etiqueta = "the 2D editor view"
			pantalla = "2D"
		"3d":
			vp = EditorInterface.get_editor_viewport_3d(0)
			etiqueta = "the 3D editor view"
			pantalla = "3D"
	if vp == null:
		return _error("This Godot build does not expose %s." % etiqueta)
	var img := _imagenDe(vp)
	var volver := ""
	if img == null and pantalla != "":
		volver = _pantallaActual()
		EditorInterface.set_main_screen_editor(pantalla)
		await _esperarFotogramas(3)
		img = _imagenDe(vp)
		if volver != "" and volver != pantalla:
			EditorInterface.set_main_screen_editor(volver)
			await _esperarFotogramas(2)
	if img == null:
		return _error("The editor did not draw %s. Open that view in the editor and try again." % etiqueta)
	var guardada := Adjuntos.guardarImagen(img, "captura_" + vista)
	if guardada == "":
		return _error("Could not save the screenshot.")
	return {
		"success": true,
		"output": "Attached %s (%dx%d) as an image." % [etiqueta, img.get_width(), img.get_height()],
		"imagenes": [guardada],
	}


## Captura del juego en marcha. Se lanza la escena con un envoltorio que se hace
## la foto a si misma y la deja en user://; aqui solo se espera el archivo.
static func _capturarJuego(args: Dictionary) -> Dictionary:
	if not Engine.is_editor_hint():
		return _error("Not running in editor context.")
	var escena := str(args.get("scene", "")).strip_edges()
	if escena != "":
		var resolucion := Rutas.proyecto(escena, "scene")
		if not bool(resolucion["ok"]):
			return _error(str(resolucion["motivo"]))
		escena = str(resolucion["ruta"])
	if escena == "":
		escena = str(ProjectSettings.get_setting("application/run/main_scene", ""))
	if escena == "" or not ResourceLoader.exists(escena):
		return _error("There is no scene to run. Set a main scene in the project or pass 'scene'.")
	if escena.contains("\"") or escena.contains("\n"):
		return _error("Invalid scene path: %s" % escena)
	var segundos := clampf(float(args.get("seconds", 1.5)), 0.1, 10.0)
	var reiniciado := EditorInterface.is_playing_scene()
	if reiniciado:
		EditorInterface.stop_playing_scene()
		await _esperarFotogramas(2)
	DirAccess.make_dir_recursive_absolute(ProjectSettings.globalize_path(RAIZ_CAPTURAS))
	_borrar(FOTO_JUEGO)
	var fallo := _escribirEnvoltorio(escena, segundos)
	if fallo != "":
		return _error(fallo)
	EditorInterface.play_custom_scene(ENVOLTORIO_TSCN)
	var llego := await _esperarFoto(FOTO_JUEGO, segundos + MARGEN_ESPERA)
	EditorInterface.stop_playing_scene()
	var img := Image.new()
	var leida := llego and img.load(FOTO_JUEGO) == OK
	_borrar(FOTO_JUEGO)
	_borrar(ENVOLTORIO_GD)
	_borrar(ENVOLTORIO_TSCN)
	if not leida:
		return _error("Running %s produced no screenshot after %.1f s. The scene may need more time (pass 'seconds') or may be failing to start: check \"Get editor log\"." % [escena, segundos + MARGEN_ESPERA])
	var guardada := Adjuntos.guardarImagen(img, "juego")
	if guardada == "":
		return _error("Could not save the screenshot.")
	var aviso := " The scene that was running was restarted." if reiniciado else ""
	return {
		"success": true,
		"output": "Ran %s and attached the game view (%dx%d) as an image.%s" % [escena, img.get_width(), img.get_height(), aviso],
		"imagenes": [guardada],
	}


## Escribe el envoltorio: un script que se hace la foto a si mismo y la escena que
## lo arranca con la escena pedida dentro. Devuelve "" si salio bien.
static func _escribirEnvoltorio(escena: String, segundos: float) -> String:
	var guion := """extends Node

# Envoltorio de usar y tirar de Dotti: arranca la escena pedida, la deja correr
# y guarda una foto del fotograma. Vive en user:// para no dejar nada en el
# proyecto del usuario.

const ESPERA := %.3f
const FOTO := "%s"


func _ready() -> void:
	await get_tree().create_timer(ESPERA).timeout
	DirAccess.make_dir_recursive_absolute(ProjectSettings.globalize_path(FOTO.get_base_dir()))
	var imagen := get_viewport().get_texture().get_image()
	if imagen == null:
		return
	imagen.save_png(FOTO)
""" % [segundos, FOTO_JUEGO]
	var tscn := """[gd_scene load_steps=3 format=3]

[ext_resource type="Script" path="%s" id="1"]
[ext_resource type="PackedScene" path="%s" id="2"]

[node name="DottiCaptura" type="Node"]
script = ExtResource("1")

[node name="Escena" parent="." instance=ExtResource("2")]
""" % [ENVOLTORIO_GD, escena]
	var fallo := _escribir(ENVOLTORIO_GD, guion)
	if fallo != "":
		return fallo
	return _escribir(ENVOLTORIO_TSCN, tscn)


static func _escribir(ruta: String, texto: String) -> String:
	var f := FileAccess.open(ruta, FileAccess.WRITE)
	if f == null:
		return "Could not write %s (error %d)." % [ruta, FileAccess.get_open_error()]
	f.store_string(texto)
	f.close()
	return ""


## Espera a que el juego deje la foto. Se comprueba que se pueda LEER, no solo que
## exista: el archivo aparece en cuanto empieza a escribirse.
static func _esperarFoto(ruta: String, tope: float) -> bool:
	var arbol := Engine.get_main_loop() as SceneTree
	var esperado := 0.0
	while esperado < tope:
		if FileAccess.file_exists(ruta):
			var sonda := Image.new()
			if sonda.load(ruta) == OK:
				return true
		if arbol == null:
			break
		await arbol.create_timer(0.25).timeout
		esperado += 0.25
	return false


## Textura de un viewport, o null si ese viewport no se esta dibujando.
static func _imagenDe(vp: Viewport) -> Image:
	var tex := vp.get_texture()
	if tex == null:
		return null
	var img := tex.get_image()
	if img == null or img.get_width() < LADO_MINIMO or img.get_height() < LADO_MINIMO:
		return null
	return img


## Pantalla que el editor tiene delante ahora mismo ("2D", "3D" o "").
static func _pantallaActual() -> String:
	var principal := EditorInterface.get_editor_main_screen()
	if principal == null:
		return ""
	for hijo in principal.get_children():
		if hijo is Control and (hijo as Control).visible:
			return _nombrePantalla((hijo as Control).get_class())
	return ""


static func _nombrePantalla(clase: String) -> String:
	match clase:
		"CanvasItemEditor":
			return "2D"
		"Node3DEditor":
			return "3D"
		"ScriptEditor":
			return "Script"
	return ""


## Deja pasar fotogramas de verdad y espera a que se dibuje: cambiar de pantalla
## no pinta nada hasta el fotograma siguiente, y la textura de un viewport solo
## esta al dia despues de dibujar.
static func _esperarFotogramas(n: int) -> void:
	var arbol := Engine.get_main_loop() as SceneTree
	if arbol == null:
		return
	for i in range(n):
		await arbol.process_frame
	if DisplayServer.get_name() == "headless":
		return
	# Con la ventana minimizada puede no llegar a dibujarse nunca: la espera se
	# corta sola en vez de dejar el chat girando para siempre.
	var esperando := [true]
	RenderingServer.frame_post_draw.connect(func(): esperando[0] = false, CONNECT_ONE_SHOT)
	var tope := arbol.create_timer(TOPE_DIBUJO)
	tope.timeout.connect(func(): esperando[0] = false)
	while esperando[0]:
		await arbol.process_frame


static func _tamano(ruta: String) -> String:
	var img := Image.new()
	if img.load(ruta) != OK:
		return ""
	return " (%dx%d)" % [img.get_width(), img.get_height()]


static func _borrar(ruta: String) -> void:
	if FileAccess.file_exists(ruta):
		DirAccess.remove_absolute(ProjectSettings.globalize_path(ruta))


static func _error(mensaje: String) -> Dictionary:
	return {"success": false, "output": "ERROR: " + mensaje}
