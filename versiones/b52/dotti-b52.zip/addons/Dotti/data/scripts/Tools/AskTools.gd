@tool
class_name HerramientasPregunta

## Herramienta NATIVA para preguntar al usuario en mitad del bucle agente.
## El modelo la llama con pregunta + opciones; Dotti muestra la tarjeta,
## el usuario elige y la seleccion vuelve como resultado del tool.
## No pide permiso: responder ya es el permiso.

static func registrar(chat: Node) -> void:
	chat.registrarHerramienta(
		"Ask user",
		"Ask the user a clarifying question when you need a decision to continue. The options are shown as buttons and the chosen one comes back as the tool result. Call this tool to ask; never write the question as JSON text or as a plain message.",
		{
			"pregunta": {"type": "string", "description": "The question for the user."},
			"opciones": {
				"type": "array",
				"description": "Answer options shown as buttons.",
				"items": {"type": "string"},
			},
		},
		["pregunta", "opciones"],
		_preguntar.bind(chat)
	)

static func _preguntar(args: Dictionary, chat: Node) -> Dictionary:
	var pregunta := str(args.get("pregunta", "")).strip_edges()
	var opciones: Array = []
	var crudo = args.get("opciones", [])
	if typeof(crudo) == TYPE_ARRAY:
		for o in crudo:
			var t := str(o).strip_edges()
			if t != "" and not opciones.has(t):
				opciones.append(t)
	if pregunta == "" or opciones.is_empty():
		return {"success": false, "output": "ERROR: Ask user requires 'pregunta' and a non-empty 'opciones' array."}
	var elegida: String = await chat._preguntarUsuarioNativo(pregunta, opciones)
	if elegida == "":
		return {"success": false, "output": "Cancelled", "denegada": false, "cancelado": true, "crudo": false}
	return {"success": true, "output": elegida, "denegada": false, "cancelado": false, "crudo": false}
