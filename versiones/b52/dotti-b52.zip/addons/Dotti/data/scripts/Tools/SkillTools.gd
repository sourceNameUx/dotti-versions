@tool
class_name HerramientasSkills

## Skills del proyecto (P9b): procedimientos escritos que el modelo carga solo
## cuando le hacen falta. En el prompt de sistema solo viaja el nombre con su
## descripcion (Habilidades.bloqueDisponibles); esto trae el cuerpo entero.
##
## La herramienta se registra siempre, haya skills o no: la lista de
## herramientas se arma una sola vez, al arrancar, y volver a montarla cada vez
## que alguien deja una carpeta en user:// seria peor que una herramienta que a
## veces contesta "no hay ninguno".

static func registrar(chat: Node) -> void:
	chat.registrarHerramienta(
		"Load skill",
		"Read the full instructions of one of this project's skills. The system prompt lists the available skills with a one-line summary of each: when one of them covers what you are about to do, load it and follow it instead of improvising, and do not load one that does not apply. Loading a skill replaces nothing: it adds instructions for the rest of the task.",
		{
			"name": {"type": "string", "description": "Name of the skill, exactly as it appears in the available skills list."},
		},
		["name"],
		_cargar
	)

static func _cargar(args: Dictionary) -> Dictionary:
	var nombre := str(args.get("name", "")).strip_edges()
	if nombre == "":
		return _fallo("'name' is missing. Skills available: %s." % _lista())
	var skill := Habilidades.cargar(nombre)
	if skill.is_empty():
		return _fallo("there is no skill called '%s'. Skills available: %s." % [nombre, _lista()])
	return {"success": true, "output": Habilidades.cuerpoParaModelo(skill)}

static func _fallo(motivo: String) -> Dictionary:
	return {"success": false, "output": "ERROR: %s" % motivo}

## Los nombres que hay, para el mensaje de error: un modelo al que le falla el
## nombre puede corregirlo en la misma respuesta si se los damos.
static func _lista() -> String:
	var nombres: Array = []
	for skill in Habilidades.listar():
		nombres.append(str(skill.get("nombre", "")))
	if nombres.is_empty():
		return "there are none in this project"
	return ", ".join(nombres)
