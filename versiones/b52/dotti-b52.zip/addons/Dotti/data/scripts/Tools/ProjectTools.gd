class_name HerramientasProyecto

static func registrar(chat: Node) -> void:
	chat.registrarHerramienta(
		"Get project info",
		"Returns key information about the current Godot project: name, version, main scene, window size, and physics FPS.",
		{},
		[],
		infoProyecto
	)
	chat.registrarHerramienta(
		"Get project setting",
		"Reads a value from ProjectSettings (project.godot).",
		{
			"setting": {"type": "string", "description": "Setting key path, e.g. application/config/name or display/window/size/viewport_width"}
		},
		["setting"],
		obtenerConfiguracionProyecto
	)
	chat.registrarHerramienta(
		"Set project setting",
		"Writes a value to ProjectSettings and saves project.godot immediately. Value is parsed as a GDScript expression.",
		{
			"setting": {"type": "string", "description": "Setting key path, e.g. display/window/size/viewport_width"},
			"value":   {"type": "string", "description": "New value as a GDScript expression, e.g. 1920 or true or 'MyGame'"}
		},
		["setting", "value"],
		establecerConfiguracionProyecto
	)
	chat.registrarHerramienta(
		"Get available node types",
		"Returns all instantiable Godot Node class names. Use the filter to narrow results. Use this before \"Add node\" or \"Create scene\" to get valid type names.",
		{
			"filter": {"type": "string", "description": "Optional substring filter, e.g. 2D or Body or Sprite. Leave empty for all."}
		},
		[],
		obtenerTiposNodosDisponibles
	)
	chat.registrarHerramienta(
		"Get class property schema",
		"Returns the list of exported properties and their types for any Godot class, without needing an instance. Use before creating nodes to know what properties exist.",
		{
			"class_name_str": {"type": "string", "description": "Godot class name, e.g. Sprite2D, CharacterBody2D, Label, RigidBody3D"}
		},
		["class_name_str"],
		obtenerEsquemaPropiedadesClase
	)

static func infoProyecto(_args: Dictionary) -> Dictionary:
	var info := {
		"project_name":    ProjectSettings.get_setting("application/config/name", "Unknown"),
		"godot_version":   Engine.get_version_info().get("string", "4.x"),
		"main_scene":      ProjectSettings.get_setting("application/run/main_scene", "Not set"),
		"viewport_width":  ProjectSettings.get_setting("display/window/size/viewport_width", 0),
		"viewport_height": ProjectSettings.get_setting("display/window/size/viewport_height", 0),
		"physics_fps":     ProjectSettings.get_setting("physics/common/physics_ticks_per_second", 60),
		"renderer":        ProjectSettings.get_setting("rendering/renderer/rendering_method", "forward_plus")
	}
	return {"success": true, "output": JSON.stringify(info)}

static func obtenerConfiguracionProyecto(args: Dictionary) -> Dictionary:
	var setting := args.get("setting", "")
	if setting == "":
		return {"success": false, "output": "Missing required argument: setting."}
	if not ProjectSettings.has_setting(setting):
		return {"success": false, "output": "Setting not found: " + setting}
	var valor := ProjectSettings.get_setting(setting)
	return {"success": true, "output": "%s = %s" % [setting, var_to_str(valor)]}

static func establecerConfiguracionProyecto(args: Dictionary) -> Dictionary:
	var setting := args.get("setting", "")
	var valorStr := args.get("value", "")
	if setting == "" or valorStr == "":
		return {"success": false, "output": "Missing required arguments: setting or value."}
	var valor = str_to_var(valorStr)
	if valor == null and valorStr.strip_edges() != "null":
		valor = valorStr
	ProjectSettings.set_setting(setting, valor)
	var copia: String = CopiasSeguridad.respaldar("res://project.godot", "project setting")
	var err := ProjectSettings.save()
	if err != OK:
		return {"success": false, "output": "Could not save project.godot (error %d)." % err}
	return {"success": true, "output": "Saved: %s = %s%s" % [setting, var_to_str(valor), CopiasSeguridad.sufijoAviso(copia)]}

static func obtenerTiposNodosDisponibles(args: Dictionary) -> Dictionary:
	var filtro := ChatParseador.textoDe(args, "filter", "").to_lower()
	var clases := ClassDB.get_class_list()
	var nodos: Array = []
	for clase in clases:
		if ClassDB.is_parent_class(clase, "Node") and ClassDB.can_instantiate(clase):
			if filtro == "" or clase.to_lower().contains(filtro):
				nodos.append(clase)
	nodos.sort()
	return {"success": true, "output": "\n".join(nodos)}

static func obtenerEsquemaPropiedadesClase(args: Dictionary) -> Dictionary:
	var classNameStr := args.get("class_name_str", "")
	if classNameStr == "":
		return {"success": false, "output": "Missing required argument: class_name_str."}
	if not ClassDB.class_exists(classNameStr):
		return {"success": false, "output": "Class not found: " + classNameStr + ". Use \"Get available node types\" to find valid names."}
	var lista := ClassDB.class_get_property_list(classNameStr, false)
	var resultado := {}
	for p in lista:
		var uso: int = p.get("usage", 0)
		if (uso & PROPERTY_USAGE_EDITOR) and not (uso & PROPERTY_USAGE_INTERNAL):
			resultado[p["name"]] = {
				"type":        type_string(p["type"]),
				"hint_string": p.get("hint_string", "")
			}
	return {"success": true, "output": JSON.stringify(resultado)}
