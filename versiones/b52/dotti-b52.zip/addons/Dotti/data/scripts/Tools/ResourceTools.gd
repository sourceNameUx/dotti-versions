class_name HerramientasRecursos

static func registrar(chat: Node) -> void:
	chat.registrarHerramienta(
		"Create resource",
		"Creates a new resource of the given type (e.g., RectangleShape2D, StandardMaterial3D) and optionally saves it to a file. Returns the resource path or a temporary reference.",
		{
			"resource_type": {"type": "string", "description": "Godot resource class name, e.g. RectangleShape2D, CircleShape2D, StandardMaterial3D, Curve, Gradient"},
			"save_path":     {"type": "string", "description": "Optional path to save the resource, e.g. res://shapes/my_shape.tres. If omitted, the resource is not saved to disk."},
			"properties":    {"type": "string", "description": "Optional JSON dictionary of initial properties to set on the resource."}
		},
		["resource_type"],
		crearRecurso
	)
	chat.registrarHerramienta(
		"Assign resource to property",
		"Assigns a resource (by file path or by creating a new one) to a node's property. Handles Resource types correctly.",
		{
			"node_path":     {"type": "string", "description": "Path to the target node, relative to scene root"},
			"property":      {"type": "string", "description": "Name of the property to set, e.g. shape, material, texture"},
			"resource_path": {"type": "string", "description": "Path to an existing resource file, e.g. res://shapes/my_shape.tres. If empty, create a new resource with resource_type."},
			"resource_type": {"type": "string", "description": "If resource_path is empty, the type of resource to create (e.g. RectangleShape2D)."},
			"save_path":     {"type": "string", "description": "If creating a new resource, optional path to save it."},
			"properties":    {"type": "string", "description": "Optional JSON dictionary of initial properties for the new resource."}
		},
		["node_path", "property"],
		asignarRecursoAPropiedad
	)

static func _escanerFs() -> void:
	if Engine.is_editor_hint():
		var fs := EditorInterface.get_resource_filesystem()
		if fs:
			fs.scan()

static func _buscarNodo(ruta: String) -> Node:
	if not Engine.is_editor_hint():
		return null
	var root := EditorInterface.get_edited_scene_root()
	if root == null:
		return null
	ruta = ruta.strip_edges()
	if ruta == "" or ruta == "." or ruta == root.name:
		return root
	if ruta.begins_with(root.name + "/"):
		ruta = ruta.substr(root.name.length() + 1)
	return root.get_node_or_null(ruta)

static func crearRecurso(args: Dictionary) -> Dictionary:
	var resourceType := args.get("resource_type", "")
	var savePath := str(args.get("save_path", "")).strip_edges()
	if savePath != "":
		var resolucion := Rutas.proyecto(savePath, "save_path")
		if not bool(resolucion["ok"]):
			return {"success": false, "output": str(resolucion["motivo"])}
		savePath = str(resolucion["ruta"])
	var propertiesStr := args.get("properties", "")
	if resourceType == "":
		return {"success": false, "output": "Missing required argument: resource_type."}
	if not ClassDB.class_exists(resourceType):
		return {"success": false, "output": "Unknown resource class: " + resourceType}
	if not ClassDB.is_parent_class(resourceType, "Resource"):
		return {"success": false, "output": "Class is not a Resource: " + resourceType}
	if not ClassDB.can_instantiate(resourceType):
		return {"success": false, "output": "Class cannot be instantiated: " + resourceType}
	var resource = ClassDB.instantiate(resourceType)
	if resource == null:
		return {"success": false, "output": "Could not instantiate: " + resourceType}
	if propertiesStr != "":
		var jsonConv = JSON.new()
		var err = jsonConv.parse(propertiesStr)
		if err == OK:
			var props = jsonConv.get_data()
			if typeof(props) == TYPE_DICTIONARY:
				for prop in props:
					var val = str_to_var(str(props[prop]))
					if val == null and str(props[prop]).strip_edges() != "null":
						val = props[prop]
					resource.set(prop, val)
	if savePath != "":
		CopiasSeguridad.respaldar(savePath, "resource overwrite")
		var errSave := ResourceSaver.save(resource, savePath)
		if errSave != OK:
			return {"success": false, "output": "Could not save resource to %s (error %d)" % [savePath, errSave]}
		_escanerFs()
		return {"success": true, "output": "Resource created and saved: %s" % savePath}
	else:
		return {"success": true, "output": "Resource created (not saved): %s" % resourceType}

static func asignarRecursoAPropiedad(args: Dictionary) -> Dictionary:
	var nodePath := args.get("node_path", "")
	var property := args.get("property", "")
	var resourcePath := str(args.get("resource_path", "")).strip_edges()
	if resourcePath != "":
		var rutaRecurso := Rutas.proyecto(resourcePath, "resource_path")
		if not bool(rutaRecurso["ok"]):
			return {"success": false, "output": str(rutaRecurso["motivo"])}
		resourcePath = str(rutaRecurso["ruta"])
	var resourceType := args.get("resource_type", "")
	var savePath := str(args.get("save_path", "")).strip_edges()
	if savePath != "":
		var rutaGuardado := Rutas.proyecto(savePath, "save_path")
		if not bool(rutaGuardado["ok"]):
			return {"success": false, "output": str(rutaGuardado["motivo"])}
		savePath = str(rutaGuardado["ruta"])
	var propertiesStr := args.get("properties", "")
	if nodePath == "" or property == "":
		return {"success": false, "output": "Missing required arguments: node_path or property."}
	var nodo := _buscarNodo(nodePath)
	if nodo == null:
		return {"success": false, "output": "Node not found: " + nodePath}
	var resource
	if resourcePath != "":
		if not FileAccess.file_exists(resourcePath):
			return {"success": false, "output": "Resource file not found: " + resourcePath}
		resource = load(resourcePath)
		if resource == null:
			return {"success": false, "output": "Could not load resource: " + resourcePath}
	else:
		if resourceType == "":
			return {"success": false, "output": "Either resource_path or resource_type must be provided."}
		if not ClassDB.class_exists(resourceType):
			return {"success": false, "output": "Unknown resource class: " + resourceType}
		if not ClassDB.is_parent_class(resourceType, "Resource"):
			return {"success": false, "output": "Class is not a Resource: " + resourceType}
		if not ClassDB.can_instantiate(resourceType):
			return {"success": false, "output": "Class cannot be instantiated: " + resourceType}
		resource = ClassDB.instantiate(resourceType)
		if resource == null:
			return {"success": false, "output": "Could not instantiate: " + resourceType}
		if propertiesStr != "":
			var jsonConv = JSON.new()
			var err = jsonConv.parse(propertiesStr)
			if err == OK:
				var props = jsonConv.get_data()
				if typeof(props) == TYPE_DICTIONARY:
					for prop in props:
						var val = str_to_var(str(props[prop]))
						if val == null and str(props[prop]).strip_edges() != "null":
							val = props[prop]
						resource.set(prop, val)
		if savePath != "":
			CopiasSeguridad.respaldar(savePath, "resource overwrite")
			var errSave := ResourceSaver.save(resource, savePath)
			if errSave != OK:
				return {"success": false, "output": "Could not save resource to %s (error %d)" % [savePath, errSave]}
			_escanerFs()
	nodo.set(property, resource)
	if Engine.is_editor_hint():
		var inspector := EditorInterface.get_inspector()
		if inspector:
			inspector.refresh()
	return {"success": true, "output": "Assigned resource to %s.%s" % [nodo.name, property]}
