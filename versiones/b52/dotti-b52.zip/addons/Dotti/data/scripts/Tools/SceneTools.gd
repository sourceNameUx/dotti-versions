class_name HerramientasEscenas

static func registrar(chat: Node) -> void:
	chat.registrarHerramienta(
		"Open scene",
		"Opens a .tscn or .scn scene file in the Godot editor.",
		{
			"path": {"type": "string", "description": "Path to the scene file, e.g. res://scenes/Main.tscn"}
		},
		["path"],
		abrirScene
	)
	chat.registrarHerramienta(
		"Save current scene",
		"Saves the currently edited scene to disk.",
		{},
		[],
		guardarSceneActual
	)
	chat.registrarHerramienta(
		"Save scene as",
		"Saves the currently edited scene to a new file path.",
		{
			"path": {"type": "string", "description": "Destination path for the scene, e.g. res://scenes/NewScene.tscn"}
		},
		["path"],
		guardarSceneComo
	)
	chat.registrarHerramienta(
		"Reload scene",
		"Reloads a scene file from disk, discarding any unsaved changes.",
		{
			"path": {"type": "string", "description": "Path to the scene to reload, e.g. res://scenes/Main.tscn"}
		},
		["path"],
		recargarScene
	)
	chat.registrarHerramienta(
		"Get open scenes",
		"Returns a list of all scene paths currently open as tabs in the editor.",
		{},
		[],
		obtenerScenesAbiertas
	)
	chat.registrarHerramienta(
		"Get current scene",
		"Returns the root node name, class, file path, and child count of the scene currently being edited.",
		{},
		[],
		obtenerSceneActual
	)
	chat.registrarHerramienta(
		"Create scene",
		"Creates a new .tscn scene file on disk with the specified root node type and name, then optionally opens it in the editor.",
		{
			"path":       {"type": "string", "description": "Destination path for the new scene, e.g. res://scenes/Enemy.tscn"},
			"root_type":  {"type": "string", "description": "Godot class name for the root node, e.g. Node2D, CharacterBody2D, Control"},
			"root_name":  {"type": "string", "description": "Name to give the root node"},
			"open_after": {"type": "string", "description": "Whether to open the scene after creating it. true or false (default true)"}
		},
		["path", "root_type", "root_name"],
		crearScene
	)
	chat.registrarHerramienta(
		"Instantiate scene in scene",
		"Instantiates a PackedScene (.tscn) and adds it as a child of a node in the currently open scene.",
		{
			"scene_path":  {"type": "string", "description": "Path to the .tscn file to instantiate, e.g. res://scenes/Enemy.tscn"},
			"parent_path": {"type": "string", "description": "Node path for the parent, use . for scene root"},
			"node_name":   {"type": "string", "description": "Optional name override for the instanced root node. Leave empty to keep the scene's default name."}
		},
		["scene_path", "parent_path"],
		instanciarSceneEnScene
	)

static func _escanerFs() -> void:
	if Engine.is_editor_hint():
		var fs := EditorInterface.get_resource_filesystem()
		if fs:
			fs.scan()

static func _buscarNodo(ruta: String) -> Node:
	if not Engine.is_editor_hint():
		return null
	var root := EditorInterface.get_edited_scene_root()
	if root == null:
		return null
	ruta = ruta.strip_edges()
	if ruta == "" or ruta == "." or ruta == root.name:
		return root
	if ruta.begins_with(root.name + "/"):
		ruta = ruta.substr(root.name.length() + 1)
	return root.get_node_or_null(ruta)

static func _setOwnerRecursivo(node: Node, owner: Node) -> void:
	node.owner = owner
	for hijo in node.get_children():
		_setOwnerRecursivo(hijo, owner)

static func _setOwnerSoloRaiz(instancia: Node, owner: Node) -> void:
	instancia.owner = owner

static func abrirScene(args: Dictionary) -> Dictionary:
	if not Engine.is_editor_hint():
		return {"success": false, "output": "Not running in editor context."}
	var resolucion := Rutas.proyecto(args.get("path", ""))
	if not bool(resolucion["ok"]):
		return {"success": false, "output": str(resolucion["motivo"])}
	var path: String = str(resolucion["ruta"])
	if not FileAccess.file_exists(path):
		return {"success": false, "output": "Scene file not found: " + path}
	EditorInterface.open_scene_from_path(path)
	return {"success": true, "output": "Opened scene: " + path}

static func guardarSceneActual(_args: Dictionary) -> Dictionary:
	if not Engine.is_editor_hint():
		return {"success": false, "output": "Not running in editor context."}
	var copia: String = CopiasSeguridad.respaldarEscenaAbierta()
	var err := EditorInterface.save_scene()
	if err != OK:
		return {"success": false, "output": "Could not save scene (error %d)." % err}
	return {"success": true, "output": "Current scene saved successfully." + CopiasSeguridad.sufijoAviso(copia)}

static func guardarSceneComo(args: Dictionary) -> Dictionary:
	if not Engine.is_editor_hint():
		return {"success": false, "output": "Not running in editor context."}
	var resolucion := Rutas.proyecto(args.get("path", ""))
	if not bool(resolucion["ok"]):
		return {"success": false, "output": str(resolucion["motivo"])}
	var path: String = str(resolucion["ruta"])
	var copia: String = CopiasSeguridad.respaldar(path, "save scene as")
	EditorInterface.save_scene_as(path, false)
	return {"success": true, "output": "Scene saved as: " + path + CopiasSeguridad.sufijoAviso(copia)}

static func recargarScene(args: Dictionary) -> Dictionary:
	if not Engine.is_editor_hint():
		return {"success": false, "output": "Not running in editor context."}
	var resolucion := Rutas.proyecto(args.get("path", ""))
	if not bool(resolucion["ok"]):
		return {"success": false, "output": str(resolucion["motivo"])}
	var path: String = str(resolucion["ruta"])
	if not FileAccess.file_exists(path):
		return {"success": false, "output": "Scene file not found: " + path}
	EditorInterface.reload_scene_from_path(path)
	return {"success": true, "output": "Reloaded from disk: " + path}

static func obtenerScenesAbiertas(_args: Dictionary) -> Dictionary:
	if not Engine.is_editor_hint():
		return {"success": false, "output": "Not running in editor context."}
	var escenas := EditorInterface.get_open_scenes()
	if escenas.is_empty():
		return {"success": true, "output": "No scenes currently open."}
	return {"success": true, "output": "\n".join(escenas)}

static func obtenerSceneActual(_args: Dictionary) -> Dictionary:
	if not Engine.is_editor_hint():
		return {"success": false, "output": "Not running in editor context."}
	var root := EditorInterface.get_edited_scene_root()
	if root == null:
		return {"success": false, "output": "No scene is currently open."}
	var info := {
		"root_name":   root.name,
		"root_class":  root.get_class(),
		"scene_path":  root.scene_file_path if root.scene_file_path != "" else "(unsaved)",
		"child_count": root.get_child_count()
	}
	return {"success": true, "output": JSON.stringify(info)}

static func crearScene(args: Dictionary) -> Dictionary:
	var resolucion := Rutas.proyecto(args.get("path", ""))
	if not bool(resolucion["ok"]):
		return {"success": false, "output": str(resolucion["motivo"])}
	var path: String = str(resolucion["ruta"])
	var rootType := args.get("root_type", "Node")
	var rootName := args.get("root_name", "Root")
	var abrir := ChatParseador.booleanoDe(args, "open_after", true)
	if path == "":
		return {"success": false, "output": "Missing required argument: path."}
	if not ClassDB.class_exists(rootType):
		return {"success": false, "output": "Unknown class: " + rootType + ". Use \"Get available node types\" to find valid names."}
	if not ClassDB.is_parent_class(rootType, "Node"):
		return {"success": false, "output": "Class is not a Node subclass: " + rootType}
	if not ClassDB.can_instantiate(rootType):
		return {"success": false, "output": "Class cannot be instantiated: " + rootType}
	var root := ClassDB.instantiate(rootType) as Node
	if root == null:
		return {"success": false, "output": "Could not instantiate: " + rootType}
	root.name = rootName
	CopiasSeguridad.respaldar(path, "scene overwrite")
	var packed := PackedScene.new()
	var packErr := packed.pack(root)
	root.free()
	if packErr != OK:
		return {"success": false, "output": "Could not pack scene (error %d)." % packErr}
	var saveErr := ResourceSaver.save(packed, path)
	if saveErr != OK:
		return {"success": false, "output": "Could not save scene file (error %d)." % saveErr}
	_escanerFs()
	if abrir and Engine.is_editor_hint():
		EditorInterface.open_scene_from_path(path)
	return {"success": true, "output": "Scene created: %s  root: %s [%s]" % [path, rootName, rootType]}

static func instanciarSceneEnScene(args: Dictionary) -> Dictionary:
	if not Engine.is_editor_hint():
		return {"success": false, "output": "Not running in editor context."}
	var scenePath := args.get("scene_path", "")
	var parentPath := args.get("parent_path", ".")
	var nodeName := args.get("node_name", "")
	if scenePath == "":
		return {"success": false, "output": "Missing required argument: scene_path."}
	if not FileAccess.file_exists(scenePath):
		return {"success": false, "output": "Scene file not found: " + scenePath}
	var packed := load(scenePath) as PackedScene
	if packed == null:
		return {"success": false, "output": "Could not load PackedScene: " + scenePath}
	var padre := _buscarNodo(parentPath)
	if padre == null:
		return {"success": false, "output": "Parent node not found: " + parentPath}
	var root := EditorInterface.get_edited_scene_root()
	var instancia := packed.instantiate()
	if nodeName != "":
		instancia.name = nodeName
	padre.add_child(instancia)
	_setOwnerSoloRaiz(instancia, root)
	return {"success": true, "output": "Instantiated %s as '%s' under %s" % [scenePath, instancia.name, padre.name]}
