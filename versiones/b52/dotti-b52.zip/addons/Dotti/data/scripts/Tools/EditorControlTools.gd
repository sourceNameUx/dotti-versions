class_name HerramientasControlEditor

static func registrar(chat: Node) -> void:
	chat.registrarHerramienta(
		"Switch editor view",
		"Switches the main editor panel. Valid values: 2D, 3D, Script, AssetLib.",
		{
			"view": {"type": "string", "description": "Target view: 2D, 3D, Script, or AssetLib"}
		},
		["view"],
		cambiarVistaEditor
	)
	chat.registrarHerramienta(
		"Play scene",
		"Starts playing the game in the editor. mode: current plays the scene being edited, main plays the project main scene.",
		{
			"mode": {"type": "string", "description": "Play mode: current or main (default: current)"}
		},
		[],
		ejecutarScene
	)
	chat.registrarHerramienta(
		"Stop scene",
		"Stops the currently running game/scene in the editor.",
		{},
		[],
		detenerScene
	)
	chat.registrarHerramienta(
		"Inspect node",
		"Shows a specific node from the current scene in the Inspector dock.",
		{
			"node_path": {"type": "string", "description": "Path to the node to inspect, relative to scene root"}
		},
		["node_path"],
		inspeccionarNodo
	)
	chat.registrarHerramienta(
		"Select file in filesystem",
		"Highlights and selects a file in the FileSystem dock of the editor.",
		{
			"path": {"type": "string", "description": "Path to the file to select, e.g. res://scenes/Main.tscn"}
		},
		["path"],
		seleccionarArchivoEnFilesystem
	)
	chat.registrarHerramienta(
		"Refresh filesystem",
		"Forces the editor FileSystem to rescan the project directory, picking up any external file changes.",
		{},
		[],
		refrescarFilesystem
	)
	chat.registrarHerramienta(
		"Refresh inspector",
		"Forces the Inspector dock to refresh, reflecting the latest property values. Use after programmatic changes.",
		{},
		[],
		refrescarInspector
	)
	chat.registrarHerramienta(
		"Force node property update",
		"Re-selects a node and forces its property list to update, useful after assigning a script or modifying exported properties programmatically.",
		{
			"node_path": {"type": "string", "description": "Path to the node, relative to scene root"}
		},
		["node_path"],
		forzarActualizacionPropiedadesNodo
	)
	chat.registrarHerramienta(
		"Execute editor script",
		"Executes GDScript inside the editor context, so it can manipulate the current scene, resources or editor state. Send either a whole script with a `func _execute()` that returns the value, or just the body of the code (it is wrapped in a function for you, so `return` works). Everything runs in memory: nothing is written to the project.",
		{
			"code": {"type": "string", "description": "GDScript code to execute. It can use the `EditorInterface` singleton. Use `return` to pass a value back."}
		},
		["code"],
		ejecutarScriptEnEditor
	)
	chat.registrarHerramienta(
		"Get editor log",
		"Retrieves the most recent errors, warnings, or messages from the Godot editor's Output panel. Useful for debugging after script or scene changes.",
		{
			"max_lines":        {"type": "string", "description": "Maximum number of log lines to return (default 50)."},
			"include_errors":   {"type": "string", "description": "Include errors (default true)."},
			"include_warnings": {"type": "string", "description": "Include warnings (default true)."},
			"include_info":     {"type": "string", "description": "Include info/debug messages (default false)."}
		},
		[],
		obtenerLogEditor
	)
	chat.registrarHerramienta(
		"Wait for filesystem scan",
		"Waits until the EditorFileSystem has finished scanning. Use after creating or modifying files to ensure they are recognized by the editor.",
		{
			"timeout_ms": {"type": "string", "description": "Maximum wait time in milliseconds (default 5000)."}
		},
		[],
		esperarEscaneoFilesystem
	)

static func _buscarNodo(ruta: String) -> Node:
	if not Engine.is_editor_hint():
		return null
	var root := EditorInterface.get_edited_scene_root()
	if root == null:
		return null
	ruta = ruta.strip_edges()
	if ruta == "" or ruta == "." or ruta == root.name:
		return root
	if ruta.begins_with(root.name + "/"):
		ruta = ruta.substr(root.name.length() + 1)
	return root.get_node_or_null(ruta)

static func cambiarVistaEditor(args: Dictionary) -> Dictionary:
	if not Engine.is_editor_hint():
		return {"success": false, "output": "Not running in editor context."}
	var vista := args.get("view", "")
	var validas := ["2D", "3D", "Script", "AssetLib"]
	if not vista in validas:
		return {"success": false, "output": "Invalid view '%s'. Choose from: %s" % [vista, ", ".join(validas)]}
	EditorInterface.set_main_screen_editor(vista)
	return {"success": true, "output": "Switched to: " + vista}

static func ejecutarScene(args: Dictionary) -> Dictionary:
	if not Engine.is_editor_hint():
		return {"success": false, "output": "Not running in editor context."}
	if EditorInterface.is_playing_scene():
		return {"success": false, "output": "A scene is already playing. Call \"Stop scene\" first."}
	var modo := ChatParseador.textoDe(args, "mode", "current").to_lower()
	if modo == "main":
		EditorInterface.play_main_scene()
		return {"success": true, "output": "Playing main scene."}
	else:
		EditorInterface.play_current_scene()
		return {"success": true, "output": "Playing current scene."}

static func detenerScene(_args: Dictionary) -> Dictionary:
	if not Engine.is_editor_hint():
		return {"success": false, "output": "Not running in editor context."}
	if not EditorInterface.is_playing_scene():
		return {"success": false, "output": "No scene is currently playing."}
	EditorInterface.stop_playing_scene()
	return {"success": true, "output": "Scene stopped."}

static func inspeccionarNodo(args: Dictionary) -> Dictionary:
	if not Engine.is_editor_hint():
		return {"success": false, "output": "Not running in editor context."}
	var nodePath := args.get("node_path", "")
	if nodePath == "":
		return {"success": false, "output": "Missing required argument: node_path."}
	var nodo := _buscarNodo(nodePath)
	if nodo == null:
		return {"success": false, "output": "Node not found: " + nodePath}
	EditorInterface.inspect_object(nodo)
	return {"success": true, "output": "Now inspecting: " + nodo.name}

static func seleccionarArchivoEnFilesystem(args: Dictionary) -> Dictionary:
	if not Engine.is_editor_hint():
		return {"success": false, "output": "Not running in editor context."}
	var resolucion := Rutas.proyecto(args.get("path", ""))
	if not bool(resolucion["ok"]):
		return {"success": false, "output": str(resolucion["motivo"])}
	var path: String = str(resolucion["ruta"])
	EditorInterface.select_file(path)
	return {"success": true, "output": "Selected in FileSystem dock: " + path}

static func refrescarFilesystem(_args: Dictionary) -> Dictionary:
	if not Engine.is_editor_hint():
		return {"success": false, "output": "Not running in editor context."}
	var fs := EditorInterface.get_resource_filesystem()
	if fs == null:
		return {"success": false, "output": "FileSystem not available."}
	fs.scan()
	return {"success": true, "output": "FileSystem rescan started."}

static func refrescarInspector(_args: Dictionary) -> Dictionary:
	if not Engine.is_editor_hint():
		return {"success": false, "output": "Not running in editor context."}
	var inspector := EditorInterface.get_inspector()
	if inspector == null:
		return {"success": false, "output": "Inspector not available."}
	inspector.refresh()
	return {"success": true, "output": "Inspector refreshed."}

static func forzarActualizacionPropiedadesNodo(args: Dictionary) -> Dictionary:
	if not Engine.is_editor_hint():
		return {"success": false, "output": "Not running in editor context."}
	var nodePath := args.get("node_path", "")
	if nodePath == "":
		return {"success": false, "output": "Missing required argument: node_path."}
	var nodo := _buscarNodo(nodePath)
	if nodo == null:
		return {"success": false, "output": "Node not found: " + nodePath}
	var seleccion := EditorInterface.get_selection()
	seleccion.clear()
	seleccion.add_node(nodo)
	EditorInterface.edit_node(nodo)
	var inspector := EditorInterface.get_inspector()
	if inspector:
		inspector.refresh()
	return {"success": true, "output": "Property list updated for node: " + nodo.name}

static func ejecutarScriptEnEditor(args: Dictionary) -> Dictionary:
	if not Engine.is_editor_hint():
		return {"success": false, "output": "Not running in editor context."}
	var code := str(args.get("code", ""))
	if code.strip_edges() == "":
		return {"success": false, "output": "Missing required argument: code."}
	return _ejecutarCodigo(code)

## Compila y ejecuta el codigo. Todo pasa en memoria: no se escribe NINGUN
## archivo, ni en el proyecto del usuario ni en user://.
##
## El modelo manda las dos formas: un script entero con su `_execute()`, o el
## cuerpo suelto ("return Engine.get_version_info().string"). La segunda no
## compila tal cual -GDScript no deja un `return` en el cuerpo de la clase-, asi
## que se prueba entera primero y, si no vale, envuelta en una funcion.
##
## Antes esto escribia un .gd de usar y tirar DENTRO del proyecto del usuario
## (res://addons/ai_helper/) y lo cargaba del disco. Ademas de dejarle basura en
## el repo, la segunda llamada cargaba el script cacheado de la primera y
## ejecutaba el codigo viejo con el argumento nuevo.
static func _ejecutarCodigo(code: String) -> Dictionary:
	var guion := GDScript.new()
	guion.source_code = code
	if guion.reload() == OK:
		var instancia = guion.new()
		if instancia != null and instancia.has_method("_execute"):
			return _resultado(instancia.call("_execute"))
		return {"success": false, "output": "The script compiled but has no `_execute()` to run. Send the body of the code instead (it is wrapped for you), or add `func _execute():` with the `return` inside."}
	var envuelto := GDScript.new()
	envuelto.source_code = _envolverCodigo(code)
	var error := envuelto.reload()
	if error != OK:
		# El error que se le ensena al modelo es el del codigo que escribio, no el
		# del envoltorio: el sangrado de mas solo confundiria.
		return {"success": false, "output": "Script compilation failed (error %d)." % error}
	var instanciaEnvuelta = envuelto.new()
	if instanciaEnvuelta == null:
		return {"success": false, "output": "Script compiled but could not be instantiated."}
	return _resultado(instanciaEnvuelta.call("_execute"))

## El cuerpo suelto, metido en una funcion. Se sangra cada linea no vacia un
## escalon para que el codigo de dentro siga siendo el mismo.
static func _envolverCodigo(code: String) -> String:
	var cuerpo := PackedStringArray()
	for linea in code.split("\n"):
		cuerpo.append("\t" + linea if linea.strip_edges() != "" else "")
	return "extends RefCounted\n\n\nfunc _execute():\n" + "\n".join(cuerpo) + "\n"

static func _resultado(valor) -> Dictionary:
	return {"success": true, "output": var_to_str(valor) if valor != null else "Executed successfully."}

static func obtenerLogEditor(args: Dictionary) -> Dictionary:
	if not Engine.is_editor_hint():
		return {"success": false, "output": "Not running in editor context."}
	var maxLines := ChatParseador.enteroDe(args, "max_lines", 50)
	var includeErrors := ChatParseador.booleanoDe(args, "include_errors", true)
	var includeWarnings := ChatParseador.booleanoDe(args, "include_warnings", true)
	var includeInfo := ChatParseador.booleanoDe(args, "include_info", false)
	var logText := ""
	var editorLog := EditorInterface.get_editor_main_screen().get_child(0)
	if editorLog and editorLog.has_method("get_text"):
		logText = editorLog.get_text()
	else:
		for child in EditorInterface.get_base_control().get_children():
			if child is TextEdit and "Output" in child.name:
				logText = child.text
				break
	if logText == "":
		return {"success": true, "output": "No log content available."}
	var lines := logText.split("\n")
	var collected := []
	for line in lines:
		var isErr := "error" in line.to_lower()
		var isWarn := "warning" in line.to_lower()
		var isInfo := not (isErr or isWarn)
		if (includeErrors and isErr) or (includeWarnings and isWarn) or (includeInfo and isInfo):
			collected.append(line)
		if collected.size() >= maxLines:
			break
	return {"success": true, "output": "\n".join(collected)}

static func esperarEscaneoFilesystem(args: Dictionary) -> Dictionary:
	if not Engine.is_editor_hint():
		return {"success": false, "output": "Not running in editor context."}
	var timeoutMs := ChatParseador.enteroDe(args, "timeout_ms", 5000)
	var fs := EditorInterface.get_resource_filesystem()
	if fs == null:
		return {"success": false, "output": "FileSystem not available."}
	var elapsed := 0
	var step := 50
	while fs.is_scanning() and elapsed < timeoutMs:
		OS.delay_msec(step)
		elapsed += step
	if fs.is_scanning():
		return {"success": false, "output": "FileSystem scan still in progress after %d ms." % timeoutMs}
	return {"success": true, "output": "FileSystem scan completed."}
