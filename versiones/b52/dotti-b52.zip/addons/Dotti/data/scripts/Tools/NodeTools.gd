class_name HerramientasNodos

static func registrar(chat: Node) -> void:
	chat.registrarHerramienta(
		"Get scene tree",
		"Returns the full node hierarchy of the currently edited scene as an indented tree. Each entry shows: NodeName [ClassName] → script_path.",
		{
			"include_scripts": {"type": "string", "description": "Whether to include script paths. true or false (default true)"}
		},
		[],
		obtenerArbolScene
	)
	chat.registrarHerramienta(
		"Get node info",
		"Returns detailed information about a specific node: class, scene path, attached script, groups, and list of direct children.",
		{
			"node_path": {"type": "string", "description": "Node path relative to scene root, e.g. Player or Player/Sprite2D. Use . for the root."}
		},
		["node_path"],
		obtenerInfoNodo
	)
	chat.registrarHerramienta(
		"Get node properties",
		"Returns all editable properties and their current values for a node. Use this before \"Set node property\" to discover available property names.",
		{
			"node_path": {"type": "string", "description": "Node path relative to scene root, e.g. Player or Player/Sprite2D"}
		},
		["node_path"],
		obtenerPropiedadesNodo
	)
	chat.registrarHerramienta(
		"Set node property",
		"Sets the value of a property on a node. Values are parsed as GDScript expressions: Vector2(10,20), true, 42, 3.14, Color(1,0,0,1), 'text'. For NodePath properties, use a string like 'Path/To/Node'. Call \"Get node properties\" first to see available properties.",
		{
			"node_path": {"type": "string", "description": "Node path relative to scene root"},
			"property":  {"type": "string", "description": "Property name, e.g. position, visible, modulate, scale"},
			"value":     {"type": "string", "description": "New value as GDScript expression, e.g. Vector2(100, 200) or true or 42"}
		},
		["node_path", "property", "value"],
		establecerPropiedadNodo
	)
	chat.registrarHerramienta(
		"Add node",
		"Creates a new node of the given type and adds it as a child of an existing node in the current scene.",
		{
			"parent_path": {"type": "string", "description": "Path to the parent node. Use . for scene root."},
			"node_type":   {"type": "string", "description": "Godot class name, e.g. Node2D, Sprite2D, Label, CollisionShape2D, AudioStreamPlayer"},
			"node_name":   {"type": "string", "description": "Name to assign to the new node"}
		},
		["parent_path", "node_type", "node_name"],
		agregarNodo
	)
	chat.registrarHerramienta(
		"Remove node",
		"Removes a node and all its children from the current scene. Cannot remove the scene root.",
		{
			"node_path": {"type": "string", "description": "Path to the node to remove, relative to scene root"}
		},
		["node_path"],
		eliminarNodo
	)
	chat.registrarHerramienta(
		"Rename node",
		"Renames a node in the current scene.",
		{
			"node_path": {"type": "string", "description": "Current path to the node, relative to scene root"},
			"new_name":  {"type": "string", "description": "New name for the node"}
		},
		["node_path", "new_name"],
		renombrarNodo
	)
	chat.registrarHerramienta(
		"Assign script to node",
		"Attaches an existing .gd script file to a node in the current scene.",
		{
			"node_path":   {"type": "string", "description": "Path to the target node, relative to scene root"},
			"script_path": {"type": "string", "description": "Path to the .gd script to assign, e.g. res://scripts/Player.gd"}
		},
		["node_path", "script_path"],
		asignarScriptANodo
	)
	chat.registrarHerramienta(
		"Remove script from node",
		"Detaches (removes) the script currently attached to a node.",
		{
			"node_path": {"type": "string", "description": "Path to the node, relative to scene root"}
		},
		["node_path"],
		quitarScriptDeNodo
	)
	chat.registrarHerramienta(
		"Select node",
		"Selects a node in the editor scene tree and shows it in the Inspector dock.",
		{
			"node_path": {"type": "string", "description": "Path to the node to select, relative to scene root"}
		},
		["node_path"],
		seleccionarNodo
	)
	chat.registrarHerramienta(
		"Get selected nodes",
		"Returns information about all nodes currently selected in the editor.",
		{},
		[],
		obtenerNodosSeleccionados
	)
	chat.registrarHerramienta(
		"Duplicate node",
		"Duplicates a node (including all its children) and adds the copy under the same parent.",
		{
			"node_path": {"type": "string", "description": "Path to the node to duplicate, relative to scene root"},
			"new_name":  {"type": "string", "description": "Name for the duplicated node. Leave empty to auto-generate."}
		},
		["node_path"],
		duplicarNodo
	)
	chat.registrarHerramienta(
		"Reparent node",
		"Moves a node to a different parent within the current scene, preserving all its children.",
		{
			"node_path":       {"type": "string", "description": "Path to the node to move, relative to scene root"},
			"new_parent_path": {"type": "string", "description": "Path to the new parent node. Use . for scene root."}
		},
		["node_path", "new_parent_path"],
		reparentarNodo
	)
	chat.registrarHerramienta(
		"Add node to group",
		"Adds a node to a named group. Groups are used for batch processing and signals.",
		{
			"node_path":  {"type": "string", "description": "Path to the node, relative to scene root"},
			"group_name": {"type": "string", "description": "Name of the group, e.g. enemies or hud_elements"}
		},
		["node_path", "group_name"],
		agregarNodoAGrupo
	)
	chat.registrarHerramienta(
		"Validate node path",
		"Checks whether a given node path resolves to an existing node in the current scene.",
		{
			"node_path": {"type": "string", "description": "Node path relative to scene root, e.g. Player/Sprite2D. Use . for root."}
		},
		["node_path"],
		validarNodePath
	)
	chat.registrarHerramienta(
		"Get script exported properties",
		"Returns all exported properties of a script, including their types and hints. Useful for understanding what can be set on nodes with that script.",
		{
			"script_path": {"type": "string", "description": "Path to the .gd script file, e.g. res://scripts/Player.gd"}
		},
		["script_path"],
		obtenerPropiedadesExportadasScript
	)
	chat.registrarHerramienta(
		"Assign node to export",
		"Assigns a node reference to an exported Node or NodePath variable on another node. Handles both @export var node: Node and @export var node_path: NodePath.",
		{
			"target_node_path": {"type": "string", "description": "Path to the node that has the exported variable"},
			"property":         {"type": "string", "description": "Name of the exported variable"},
			"source_node_path": {"type": "string", "description": "Path to the node to assign (relative to scene root)"}
		},
		["target_node_path", "property", "source_node_path"],
		asignarNodoAExport
	)

static func _buscarNodo(ruta: String) -> Node:
	if not Engine.is_editor_hint():
		return null
	var root := EditorInterface.get_edited_scene_root()
	if root == null:
		return null
	ruta = ruta.strip_edges()
	if ruta == "" or ruta == "." or ruta == root.name:
		return root
	if ruta.begins_with(root.name + "/"):
		ruta = ruta.substr(root.name.length() + 1)
	return root.get_node_or_null(ruta)

static func _arbolATexto(node: Node, mostrarScripts: bool, depth: int) -> String:
	var indent := "  ".repeat(depth)
	var scriptTag := ""
	if mostrarScripts:
		var scr := node.get_script()
		if scr and scr.resource_path != "":
			scriptTag = " → " + scr.resource_path
	var resultado := "%s%s [%s]%s\n" % [indent, node.name, node.get_class(), scriptTag]
	for hijo in node.get_children():
		resultado += _arbolATexto(hijo, mostrarScripts, depth + 1)
	return resultado

static func _setOwnerRecursivo(node: Node, owner: Node) -> void:
	node.owner = owner
	for hijo in node.get_children():
		_setOwnerRecursivo(hijo, owner)

static func obtenerArbolScene(args: Dictionary) -> Dictionary:
	if not Engine.is_editor_hint():
		return {"success": false, "output": "Not running in editor context."}
	var root := EditorInterface.get_edited_scene_root()
	if root == null:
		return {"success": false, "output": "No scene is currently open."}
	var mostrarScripts := ChatParseador.booleanoDe(args, "include_scripts", true)
	return {"success": true, "output": _arbolATexto(root, mostrarScripts, 0)}

static func obtenerInfoNodo(args: Dictionary) -> Dictionary:
	var nodePath := args.get("node_path", ".")
	var nodo := _buscarNodo(nodePath)
	if nodo == null:
		return {"success": false, "output": "Node not found: " + nodePath}
	var scr := nodo.get_script()
	var hijos: Array = []
	for hijo in nodo.get_children():
		hijos.append("%s [%s]" % [hijo.name, hijo.get_class()])
	var info := {
		"name":        nodo.name,
		"class":       nodo.get_class(),
		"full_path":   str(nodo.get_path()),
		"script":      scr.resource_path if scr else "",
		"groups":      nodo.get_groups(),
		"child_count": nodo.get_child_count(),
		"children":    hijos
	}
	return {"success": true, "output": JSON.stringify(info)}

static func obtenerPropiedadesNodo(args: Dictionary) -> Dictionary:
	var nodePath := args.get("node_path", ".")
	var nodo := _buscarNodo(nodePath)
	if nodo == null:
		return {"success": false, "output": "Node not found: " + nodePath}
	var props := {}
	for p in nodo.get_property_list():
		var uso: int = p.get("usage", 0)
		if (uso & PROPERTY_USAGE_EDITOR) and not (uso & PROPERTY_USAGE_INTERNAL):
			var nombreProp: String = p["name"]
			var valor = nodo.get(nombreProp)
			props[nombreProp] = var_to_str(valor)
	return {"success": true, "output": JSON.stringify(props)}

static func establecerPropiedadNodo(args: Dictionary) -> Dictionary:
	var nodePath := args.get("node_path", ".")
	var propiedad := args.get("property", "")
	var valorStr := args.get("value", "")
	if propiedad == "":
		return {"success": false, "output": "Missing required argument: property."}
	var nodo := _buscarNodo(nodePath)
	if nodo == null:
		return {"success": false, "output": "Node not found: " + nodePath}
	var propType := TYPE_NIL
	for p in nodo.get_property_list():
		if p["name"] == propiedad:
			propType = p["type"]
			break
	var valor
	if propType == TYPE_NODE_PATH and valorStr.strip_edges() != "null":
		valor = NodePath(valorStr)
	else:
		valor = str_to_var(valorStr)
		if valor == null and valorStr.strip_edges() != "null":
			valor = valorStr
	nodo.set(propiedad, valor)
	var nuevoValor = nodo.get(propiedad)
	return {"success": true, "output": "Set %s.%s = %s" % [nodo.name, propiedad, var_to_str(nuevoValor)]}

static func agregarNodo(args: Dictionary) -> Dictionary:
	if not Engine.is_editor_hint():
		return {"success": false, "output": "Not running in editor context."}
	var parentPath := args.get("parent_path", ".")
	var nodeType := args.get("node_type", "")
	var nodeName := args.get("node_name", "")
	if nodeType == "" or nodeName == "":
		return {"success": false, "output": "Missing required arguments: node_type or node_name."}
	if not ClassDB.class_exists(nodeType):
		return {"success": false, "output": "Unknown class: " + nodeType + ". Use \"Get available node types\" to find valid names."}
	if not ClassDB.is_parent_class(nodeType, "Node"):
		return {"success": false, "output": "Class is not a Node subclass: " + nodeType}
	if not ClassDB.can_instantiate(nodeType):
		return {"success": false, "output": "Class cannot be instantiated: " + nodeType}
	var padre := _buscarNodo(parentPath)
	if padre == null:
		return {"success": false, "output": "Parent node not found: " + parentPath}
	var root := EditorInterface.get_edited_scene_root()
	var nuevo := ClassDB.instantiate(nodeType) as Node
	if nuevo == null:
		return {"success": false, "output": "Could not instantiate: " + nodeType}
	nuevo.name = nodeName
	padre.add_child(nuevo)
	nuevo.owner = root
	return {"success": true, "output": "Added '%s' [%s] as child of '%s'" % [nuevo.name, nodeType, padre.name]}

static func eliminarNodo(args: Dictionary) -> Dictionary:
	if not Engine.is_editor_hint():
		return {"success": false, "output": "Not running in editor context."}
	var nodePath := args.get("node_path", "")
	if nodePath == "":
		return {"success": false, "output": "Missing required argument: node_path."}
	var root := EditorInterface.get_edited_scene_root()
	if root == null:
		return {"success": false, "output": "No scene is currently open."}
	var nodo := _buscarNodo(nodePath)
	if nodo == null:
		return {"success": false, "output": "Node not found: " + nodePath}
	if nodo == root:
		return {"success": false, "output": "Cannot remove the scene root node."}
	var nombre := nodo.name
	nodo.get_parent().remove_child(nodo)
	nodo.queue_free()
	return {"success": true, "output": "Removed node: " + nombre}

static func renombrarNodo(args: Dictionary) -> Dictionary:
	if not Engine.is_editor_hint():
		return {"success": false, "output": "Not running in editor context."}
	var nodePath := args.get("node_path", "")
	var nuevoNombre := args.get("new_name", "")
	if nodePath == "" or nuevoNombre == "":
		return {"success": false, "output": "Missing required arguments: node_path or new_name."}
	var nodo := _buscarNodo(nodePath)
	if nodo == null:
		return {"success": false, "output": "Node not found: " + nodePath}
	var viejo := nodo.name
	nodo.name = nuevoNombre
	return {"success": true, "output": "Renamed '%s' → '%s'" % [viejo, nodo.name]}

static func asignarScriptANodo(args: Dictionary) -> Dictionary:
	if not Engine.is_editor_hint():
		return {"success": false, "output": "Not running in editor context."}
	var nodePath := args.get("node_path", "")
	var scriptPath := args.get("script_path", "")
	if nodePath == "" or scriptPath == "":
		return {"success": false, "output": "Missing required arguments: node_path or script_path."}
	var nodo := _buscarNodo(nodePath)
	if nodo == null:
		return {"success": false, "output": "Node not found: " + nodePath}
	if not FileAccess.file_exists(scriptPath):
		return {"success": false, "output": "Script file not found: " + scriptPath}
	var script := load(scriptPath)
	if script == null:
		return {"success": false, "output": "Could not load script: " + scriptPath}
	nodo.set_script(script)
	if Engine.is_editor_hint():
		var seleccion := EditorInterface.get_selection()
		seleccion.clear()
		seleccion.add_node(nodo)
		EditorInterface.edit_node(nodo)
	return {"success": true, "output": "Assigned script '%s' to node '%s'" % [scriptPath, nodo.name]}

static func quitarScriptDeNodo(args: Dictionary) -> Dictionary:
	if not Engine.is_editor_hint():
		return {"success": false, "output": "Not running in editor context."}
	var nodePath := args.get("node_path", "")
	if nodePath == "":
		return {"success": false, "output": "Missing required argument: node_path."}
	var nodo := _buscarNodo(nodePath)
	if nodo == null:
		return {"success": false, "output": "Node not found: " + nodePath}
	if nodo.get_script() == null:
		return {"success": false, "output": "Node '%s' has no script attached." % nodo.name}
	nodo.set_script(null)
	return {"success": true, "output": "Removed script from node: " + nodo.name}

static func seleccionarNodo(args: Dictionary) -> Dictionary:
	if not Engine.is_editor_hint():
		return {"success": false, "output": "Not running in editor context."}
	var nodePath := args.get("node_path", "")
	if nodePath == "":
		return {"success": false, "output": "Missing required argument: node_path."}
	var nodo := _buscarNodo(nodePath)
	if nodo == null:
		return {"success": false, "output": "Node not found: " + nodePath}
	var seleccion := EditorInterface.get_selection()
	seleccion.clear()
	seleccion.add_node(nodo)
	EditorInterface.edit_node(nodo)
	return {"success": true, "output": "Selected node: " + nodo.name}

static func obtenerNodosSeleccionados(_args: Dictionary) -> Dictionary:
	if not Engine.is_editor_hint():
		return {"success": false, "output": "Not running in editor context."}
	var seleccion := EditorInterface.get_selection()
	var nodos := seleccion.get_selected_nodes()
	if nodos.is_empty():
		return {"success": true, "output": "No nodes currently selected."}
	var resultado: Array = []
	for n in nodos:
		var scr := n.get_script()
		resultado.append("%s [%s] path=%s script=%s" % [n.name, n.get_class(), str(n.get_path()), scr.resource_path if scr else "none"])
	return {"success": true, "output": "\n".join(resultado)}

static func duplicarNodo(args: Dictionary) -> Dictionary:
	if not Engine.is_editor_hint():
		return {"success": false, "output": "Not running in editor context."}
	var nodePath := args.get("node_path", "")
	var nuevoNombre := args.get("new_name", "")
	if nodePath == "":
		return {"success": false, "output": "Missing required argument: node_path."}
	var nodo := _buscarNodo(nodePath)
	if nodo == null:
		return {"success": false, "output": "Node not found: " + nodePath}
	var root := EditorInterface.get_edited_scene_root()
	if nodo == root:
		return {"success": false, "output": "Cannot duplicate the scene root."}
	var copia := nodo.duplicate() as Node
	if copia == null:
		return {"success": false, "output": "Could not duplicate node: " + nodePath}
	if nuevoNombre != "":
		copia.name = nuevoNombre
	nodo.get_parent().add_child(copia)
	_setOwnerRecursivo(copia, root)
	return {"success": true, "output": "Duplicated '%s' → new node named '%s'" % [nodo.name, copia.name]}

static func reparentarNodo(args: Dictionary) -> Dictionary:
	if not Engine.is_editor_hint():
		return {"success": false, "output": "Not running in editor context."}
	var nodePath := args.get("node_path", "")
	var newParentPath := args.get("new_parent_path", "")
	if nodePath == "" or newParentPath == "":
		return {"success": false, "output": "Missing required arguments: node_path or new_parent_path."}
	var root := EditorInterface.get_edited_scene_root()
	if root == null:
		return {"success": false, "output": "No scene is currently open."}
	var nodo := _buscarNodo(nodePath)
	var nuevoPadre := _buscarNodo(newParentPath)
	if nodo == null:
		return {"success": false, "output": "Node not found: " + nodePath}
	if nuevoPadre == null:
		return {"success": false, "output": "Parent node not found: " + newParentPath}
	if nodo == root:
		return {"success": false, "output": "Cannot reparent the scene root."}
	nodo.reparent(nuevoPadre)
	_setOwnerRecursivo(nodo, root)
	return {"success": true, "output": "Reparented '%s' → child of '%s'" % [nodo.name, nuevoPadre.name]}

static func agregarNodoAGrupo(args: Dictionary) -> Dictionary:
	var nodePath := args.get("node_path", "")
	var groupName := args.get("group_name", "")
	if nodePath == "" or groupName == "":
		return {"success": false, "output": "Missing required arguments: node_path or group_name."}
	var nodo := _buscarNodo(nodePath)
	if nodo == null:
		return {"success": false, "output": "Node not found: " + nodePath}
	if nodo.is_in_group(groupName):
		return {"success": true, "output": "Node '%s' is already in group '%s'." % [nodo.name, groupName]}
	nodo.add_to_group(groupName, true)
	return {"success": true, "output": "Added '%s' to group '%s'" % [nodo.name, groupName]}

static func validarNodePath(args: Dictionary) -> Dictionary:
	if not Engine.is_editor_hint():
		return {"success": false, "output": "Not running in editor context."}
	var nodePath := args.get("node_path", "")
	if nodePath == "":
		return {"success": false, "output": "Missing required argument: node_path."}
	var nodo := _buscarNodo(nodePath)
	if nodo != null:
		return {"success": true, "output": "VALID: node '%s' exists." % nodo.name}
	else:
		return {"success": false, "output": "INVALID: path '%s' does not resolve to a node." % nodePath}

static func obtenerPropiedadesExportadasScript(args: Dictionary) -> Dictionary:
	var scriptPath := args.get("script_path", "")
	if scriptPath == "":
		return {"success": false, "output": "Missing required argument: script_path."}
	if not FileAccess.file_exists(scriptPath):
		return {"success": false, "output": "Script file not found: " + scriptPath}
	var script = load(scriptPath)
	if script == null:
		return {"success": false, "output": "Could not load script: " + scriptPath}
	var props = script.get_script_property_list()
	var resultado := {}
	for p in props:
		var uso: int = p.get("usage", 0)
		if (uso & PROPERTY_USAGE_EDITOR) and not (uso & PROPERTY_USAGE_INTERNAL):
			resultado[p["name"]] = {
				"type": type_string(p["type"]),
				"hint_string": p.get("hint_string", "")
			}
	return {"success": true, "output": JSON.stringify(resultado)}

static func asignarNodoAExport(args: Dictionary) -> Dictionary:
	if not Engine.is_editor_hint():
		return {"success": false, "output": "Not running in editor context."}
	var targetNodePath := args.get("target_node_path", "")
	var property := args.get("property", "")
	var sourceNodePath := args.get("source_node_path", "")
	if targetNodePath == "" or property == "" or sourceNodePath == "":
		return {"success": false, "output": "Missing required arguments."}
	var targetNodo := _buscarNodo(targetNodePath)
	if targetNodo == null:
		return {"success": false, "output": "Target node not found: " + targetNodePath}
	var sourceNodo := _buscarNodo(sourceNodePath)
	if sourceNodo == null:
		return {"success": false, "output": "Source node not found: " + sourceNodePath}
	var propType := TYPE_NIL
	for p in targetNodo.get_property_list():
		if p["name"] == property:
			propType = p["type"]
			break
	if propType == TYPE_NIL:
		return {"success": false, "output": "Property '%s' not found on target node." % property}
	if propType == TYPE_NODE_PATH:
		targetNodo.set(property, sourceNodo.get_path())
	elif propType == TYPE_OBJECT and ClassDB.is_parent_class(targetNodo.get(property).get_class(), "Node"):
		targetNodo.set(property, sourceNodo)
	else:
		return {"success": false, "output": "Property '%s' is not a Node or NodePath type (type %d)." % [property, propType]}
	return {"success": true, "output": "Assigned '%s' to %s.%s" % [sourceNodo.name, targetNodo.name, property]}
