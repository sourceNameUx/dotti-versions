@tool
class_name HerramientasTareas

## Lista de tareas de la sesion (el "todo" de opencode). El modelo manda la lista
## COMPLETA en cada llamada y esto la sustituye entera: no hay altas ni bajas
## sueltas, asi que la lista que se ve es siempre la ultima que escribio.
##
## Vive en Chat, no en el historial, y por eso se puede volver a inyectar delante
## del modelo cuando la conversacion se recorta. Las claves que viajan
## (content/status/priority) son las que manda el modelo y no se traducen: son
## datos suyos, no identificadores de aqui.

const ESTADOS := ["pending", "in_progress", "completed", "cancelled"]
const PRIORIDADES := ["high", "medium", "low"]
const MAX_TAREAS := 50

## Marca de cada estado, en ASCII: es lo que ve el modelo en el resultado y en el
## bloque del prompt, y lo que pinta el panel del chat.
const MARCAS := {
	"pending": "[ ]",
	"in_progress": "[>]",
	"completed": "[x]",
	"cancelled": "[-]",
}

static func registrar(chat: Node) -> void:
	chat.registrarHerramienta(
		"Update todo list",
		"Create or update the task list of this session. Send the FULL list every time: it replaces the previous one, so include the tasks you already finished with their new status. An empty list clears it. Use it for work with three or more steps, mark one task in_progress before starting it, and mark it completed only when the work is really done and checked. Statuses: pending, in_progress, completed, cancelled. Priorities: high, medium, low.",
		{
			"todos": {
				"type": "array",
				"description": "The whole task list, in order.",
				"items": {
					"type": "object",
					"properties": {
						"content": {"type": "string", "description": "Short description of the task."},
						"status": {"type": "string", "description": "pending, in_progress, completed or cancelled."},
						"priority": {"type": "string", "description": "high, medium or low."},
					},
					"required": ["content", "status"],
				},
			},
		},
		["todos"],
		_actualizar.bind(chat)
	)

## Valida, normaliza y publica la lista. Un fallo aqui no deja la lista a medias:
## o entra entera o no entra, para que el modelo no trabaje sobre algo que cree
## escrito y no lo esta.
static func _actualizar(args: Dictionary, chat: Node) -> Dictionary:
	# La clave tiene que venir aunque sea vacia: sin ella el modelo casi siempre
	# olvido la lista, no pidio borrarla, y borrar por accidente el plan que esta
	# siguiendo es peor que fallar y que lo repita.
	if not args.has("todos"):
		return _fallo("'todos' is missing. Send the whole list, or an empty array to clear it.")
	var crudo = args.get("todos", [])
	if typeof(crudo) != TYPE_ARRAY:
		return _fallo("'todos' must be an array of objects.")
	if crudo.size() > MAX_TAREAS:
		return _fallo("too many tasks (%d). Keep the list under %d items." % [crudo.size(), MAX_TAREAS])
	var lista: Array = []
	for i in range(crudo.size()):
		var item = crudo[i]
		if typeof(item) != TYPE_DICTIONARY:
			return _fallo("item %d is not an object with content, status and priority." % (i + 1))
		var texto := str(item.get("content", "")).strip_edges()
		if texto == "":
			return _fallo("item %d has no 'content'." % (i + 1))
		var estado := str(item.get("status", "pending")).strip_edges().to_lower()
		if not ESTADOS.has(estado):
			return _fallo("item %d has status '%s'. Valid statuses: %s." % [i + 1, estado, ", ".join(ESTADOS)])
		var prioridad := str(item.get("priority", "medium")).strip_edges().to_lower()
		if not PRIORIDADES.has(prioridad):
			return _fallo("item %d has priority '%s'. Valid priorities: %s." % [i + 1, prioridad, ", ".join(PRIORIDADES)])
		lista.append({"content": texto, "status": estado, "priority": prioridad})
	# Una sola tarea en curso, y mientras quede algo pendiente no puede haber cero:
	# esa es la regla que hace que la lista diga de verdad en que se esta trabajando.
	var enCurso := 0
	var pendientes := 0
	for t in lista:
		if str(t["status"]) == "in_progress":
			enCurso += 1
		elif str(t["status"]) == "pending":
			pendientes += 1
	if enCurso > 1:
		return _fallo("%d tasks are in_progress. Only one task can be in progress at a time." % enCurso)
	if pendientes > 0 and enCurso == 0:
		return _fallo("there are %d pending tasks and none in progress. Mark the one you are working on as in_progress." % pendientes)
	chat._actualizarTareas(lista)
	if lista.is_empty():
		return {"success": true, "output": "Todo list cleared. There is no task list now."}
	return {"success": true, "output": "Todo list updated (%s done).\n%s" % [resumen(lista), textoLista(lista)]}

static func _fallo(motivo: String) -> Dictionary:
	return {
		"success": false,
		"output": "ERROR: %s The list was NOT changed; send the whole list again, fixed." % motivo,
	}

## Lista en texto plano, una tarea por linea. Es el formato que ve el modelo en el
## resultado de la herramienta y en el bloque del prompt.
static func textoLista(tareas: Array) -> String:
	var lineas: Array = []
	for i in range(tareas.size()):
		var t: Dictionary = tareas[i]
		var estado := str(t.get("status", "pending"))
		var marca := str(MARCAS.get(estado, "[ ]"))
		lineas.append("%s %d. %s (%s, %s)" % [marca, i + 1, str(t.get("content", "")), estado, str(t.get("priority", "medium"))])
	return "\n".join(lineas)

## "3/7": hechas del total. Lo usan el resultado, el bloque del prompt y el panel.
static func resumen(tareas: Array) -> String:
	var hechas := 0
	for t in tareas:
		if str((t as Dictionary).get("status", "")) == "completed":
			hechas += 1
	return "%d/%d" % [hechas, tareas.size()]

## La tarea que el panel ensena en la cabecera plegada: la que esta en curso, y si
## no hay, la primera pendiente, y si no queda nada por hacer, la ultima hecha
## (que es lo que acaba de pasar). Vacio con una lista vacia.
static func tareaActiva(tareas: Array) -> Dictionary:
	var primeraPendiente := {}
	for t in tareas:
		var d: Dictionary = t
		if str(d.get("status", "")) == "in_progress":
			return d
		if primeraPendiente.is_empty() and str(d.get("status", "")) == "pending":
			primeraPendiente = d
	if not primeraPendiente.is_empty():
		return primeraPendiente
	for i in range(tareas.size() - 1, -1, -1):
		if str((tareas[i] as Dictionary).get("status", "")) == "completed":
			return tareas[i]
	return {}
