@tool
class_name HerramientasCopias

## Herramientas para deshacer: listar las copias de seguridad que Dotti guarda
## solo (ver CopiasSeguridad) y devolver un archivo a una de ellas.
##
## El modelo no tiene que pedir la copia antes de editar: ya esta hecha. Esta
## herramienta existe para el camino de vuelta, cuando un cambio dejo el proyecto
## peor que antes.

static func registrar(chat: Node) -> void:
	chat.registrarHerramienta(
		"Restore file backup",
		"Every time a file is written, moved or deleted, Dotti saves a copy of its previous content in user://dotti_backups before touching it. Use action='list' to see the available copies of a file, and action='restore' to put one back (the current content is backed up first, so a restore can also be undone).",
		{
			"action": {"type": "string", "description": "'list' to see the copies of a file, 'restore' to bring one back."},
			"path": {"type": "string", "description": "The project file whose copies you want ('list'), or the backup file to restore ('restore')."},
			"destination": {"type": "string", "description": "Only for 'restore': the file to overwrite. Optional; by default the original the backup came from."},
		},
		["action", "path"],
		_deshacer.bind(chat)
	)


static func _deshacer(args: Dictionary, _chat: Node) -> Dictionary:
	var accion := str(args.get("action", "")).strip_edges().to_lower()
	# La ruta que manda el modelo no es la misma cosa en las dos acciones: al
	# listar es un archivo del proyecto, al restaurar es la copia (que vive en
	# user://dotti_backups). Cada una tiene su puerta.
	var resolucion := Rutas.copia(args.get("path", "")) if accion == "restore" else Rutas.proyecto(args.get("path", ""))
	if not bool(resolucion["ok"]):
		return {"success": false, "output": str(resolucion["motivo"])}
	var path: String = str(resolucion["ruta"])
	if accion == "list":
		return _listar(path)
	if accion == "restore":
		var destino := str(args.get("destination", "")).strip_edges()
		if destino != "":
			var rutaDestino := Rutas.proyecto(destino, "destination")
			if not bool(rutaDestino["ok"]):
				return {"success": false, "output": str(rutaDestino["motivo"])}
			destino = str(rutaDestino["ruta"])
		var r := CopiasSeguridad.restaurar(path, destino)
		return {"success": bool(r.get("ok", false)), "output": str(r.get("mensaje", ""))}
	return {"success": false, "output": "Unknown action: '%s'. Use 'list' or 'restore'." % accion}


static func _listar(path: String) -> Dictionary:
	var copias := CopiasSeguridad.listar(path)
	if copias.is_empty():
		return {"success": true, "output": "No backups for: " + path + " (nothing has changed it since it was created)."}
	var lineas: PackedStringArray = []
	for copia in copias:
		lineas.append("%s  (%s)" % [copia, _peso(copia)])
	return {"success": true, "output": "Backups of %s, newest first:\n%s" % [path, "\n".join(lineas)]}


static func _peso(path: String) -> String:
	var f := FileAccess.open(path, FileAccess.READ)
	if f == null:
		return "?"
	var bytes := f.get_length()
	f.close()
	if bytes < 1024:
		return "%d bytes" % bytes
	return "%.1f KB" % (float(bytes) / 1024.0)
