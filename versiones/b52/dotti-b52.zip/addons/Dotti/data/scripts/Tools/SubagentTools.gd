@tool
class_name HerramientasSubagentes

## Subagentes (el "task" de opencode). El agente principal lanza uno con una
## tarea y solo le vuelve el informe: la conversacion de dentro no entra en la
## del chat. Sirve para lo que ensucia el hilo principal -- barrer el proyecto
## buscando algo, mirar veinte archivos para responder una pregunta, un trabajo
## largo con su propio plan -- y para lo que pide otra persona: un agente del
## catalogo con sus herramientas y su prompt.
##
## Toda la maquinaria esta en Chat/Subagent.gd; aqui solo va el registro.

static func registrar(chat: Node) -> void:
	chat.registrarHerramienta(
		ChatSubagente.NOMBRE_HERRAMIENTA,
		"Hand one task to a subagent and get its report back. The subagent works in its own conversation: it does not see this chat, and only its last message comes back to you. Use it for work that would fill this conversation with noise (sweeping the project for something, reading many files to answer one question, a long job with its own plan) or when the task fits one of the available agents. Write the prompt as a complete brief: what to do, where to look, and what to bring back. It cannot ask the user anything and cannot launch another subagent, so anything you leave out of the brief is lost.",
		{
			"prompt": {
				"type": "string",
				"description": "The whole task for the subagent, as if it knew nothing about this conversation: what to do, where to look, and what to report back.",
			},
			"agent": {
				"type": "string",
				"description": "Name of the agent to run as, without the @. Leave it out for a general-purpose subagent with your own tools.",
			},
		},
		["prompt"],
		ChatSubagente.ejecutar.bind(chat)
	)
