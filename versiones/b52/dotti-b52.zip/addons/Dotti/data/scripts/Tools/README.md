# Tools

Everything the model can actually do to the project lives here. One file per
area, one static function per tool.

## Shape of a tool file

```gdscript
@tool
class_name HerramientasEjemplo
extends RefCounted

static func registrar(chat: Node) -> void:
	chat.registrarHerramienta("Do the thing", "One line, in English, for the model.",
		{"path": {"type": "string", "description": "res:// path of the file"}},
		["path"], _doTheThing)

static func _doTheThing(args: Dictionary) -> Dictionary:
	var ruta := str(args.get("path", ""))
	...
	return {"success": true, "output": "What happened. The model reads this."}
```

`HerramientasChat.registrarTodas()` calls every `registrar()` once, from
`Chat._ready()`. The registration order is the order in the prompt, so tools that
are used together stay together.

## Rules

- `output` is read by the model, not by the user. Say what changed, where, and
  what the next step is. No emojis, no chatty tone, and keep it short: it is
  tokens on every following turn.
- Anything that writes, moves or deletes a file calls
  `CopiasSeguridad.guardarAntesDeEscribir(ruta)` first and mentions the backup
  path in `output`. Backups go to `user://dotti_backups/`, never into the
  project.
- Tools that need the editor must check for it and fail with a useful message
  when running outside the editor; `Engine.is_editor_hint()` is not enough.
- Never return a raw exception or an empty string. `{"success": false, "output":
  "why it failed"}` is what lets the model recover.
- A tool that needs permission is fine: `Chat` asks the user before running it in
  the ask-permission modes.

## The budget

Every registered tool is sent to the model on every request, name, description
and parameters included. Before adding a tool, check whether an existing one
covers it; before keeping two, pick one. The names and the count are part of the
prompt, so this file is the first place to look when the context fills up.

## Inventory

- `AskTools.gd` - `Ask user`: asks the user a question with options and renders
  the answer as buttons.
- `BackupTools.gd` - `Restore file backup`: lists and restores the backups kept
  in `user://dotti_backups/`.
- `FileTools.gd` - files and folders on disk: create or update, read, search and
  replace, list, create folder, delete, move, exists, plus the script-specific
  variants (create script, update script, check script errors, replace in script,
  insert in script, replace lines in script, append to script).
- `SceneTools.gd` - open, save, save as, reload, create and list scenes,
  instantiate a scene inside a scene, get the current scene.
- `NodeTools.gd` - the scene tree: get the tree, node info, properties, add,
  remove, rename, duplicate, reparent, assign or remove scripts, groups, validate
  paths, exported properties.
- `ResourceTools.gd` - create a resource, assign it to a node property.
- `ProjectTools.gd` - project info, read and write project settings, list
  available node types, class property schemas.
- `EditorScriptTools.gd` - what the open script window is doing: current script,
  open scripts, lines and ranges, selection, set text, insert, replace, save, go
  to line, cursor position, search, symbols, built-in script of a scene node,
  script errors.
- `EditorControlTools.gd` - the editor itself: switch view, play and stop the
  scene, inspect a node, select a file in the filesystem dock, refresh the
  filesystem and the inspector, force a property update, run an editor script,
  read the editor log, wait for the filesystem scan. The editor script is
  compiled and run in memory (a whole script with `_execute()`, or a bare body
  that is wrapped in one), so nothing is ever written into the user's project.
- `ImageTools.gd` - `View image` opens an image file and attaches it to the
  conversation, `Capture view` screenshots the editor window, its 2D or 3D view,
  or runs the project and screenshots the running game. Both return the stored
  copy in `imagenes`, which is what turns into an `image_url` part; see below.
- `TaskTools.gd` - `Update todo list`: the task list of the session. The model
  sends the whole list every time and it replaces the previous one; see below.
- `SkillTools.gd` - `Load skill`: hands over the full text of one of the project's
  skills, which is the half of a skill the system prompt does not carry; see
  below.
- `SubagentTools.gd` - `Run agent`: hands one task to a subagent and gets its
  report back; see below.

## Skills

A skill is a written procedure the model loads when it needs it, instead of
carrying it in every request. A skill is a folder with a `SKILL.md` inside: the
frontmatter carries `description`, the body is the procedure, and the folder name
is the skill name. `Chat/Skills.gd` (`Habilidades`) reads them, `Chat.gd` puts
the catalogue in the system prompt and this file's tool hands over the body.

Those are the two halves, and the split is the whole point: what the model sees
before loading a skill is its name and one line of description, a few lines per
skill; what it gets when it loads one is the body, once. Twenty skills cost
twenty lines until one is used.

```
user://dotti_skills/<name>/SKILL.md      the user's own
res://.dotti/skills/<name>/SKILL.md      in the repo, shared with the team
```

A user skill shadows a project one with the same name. A skill with no
`description` falls back to the first line of its body, because a skill nobody
can see is a skill nobody loads. The folder may hold other files next to the
`SKILL.md`, and the body can tell the model to read them with `Read file`.

`Load skill` asks for permission, like `Read file` does: both read a file from
disk. It is in `Agentes.HERRAMIENTAS_SOLO_LECTURA`, so a read-only agent can load
skills, and the catalogue is only announced when the tool is really in the
request: Plan mode and an agent with `tools: none` get no announcement to act on.
`Run agent` is not in that list either: no subagents down there.

## Subagents

`Run agent` is how the main agent splits off work: it writes a brief, a subagent
runs it in its own conversation, and the only thing that comes back is the
subagent's last message. The chat's history sees the call and the report, not the
twenty files behind it. It is opencode's `task`.

The machinery is in `Chat/Subagent.gd` (`ChatSubagente`); this file only
registers the tool. What the tool file has to keep straight is the brief:

- `prompt` is the whole task. The subagent does not see the conversation, so
  anything left out of the brief is lost.
- `agent` is optional: the name (no `@`) of one of the user's agents, run with
  that prompt and those tools. Left out, it is a general-purpose subagent with
  the same tools as the chat.

Three tools never reach a subagent, and each is a rule rather than a taste:
`Run agent` itself (a model in the mood to delegate would otherwise open a tree),
`Ask user` (nobody is there to answer, so the round would wait forever) and
`Update todo list` (the session plan is the main agent's; two writers leave it
lying). Every call inside a subagent goes through `Chat._ejecutarUnaHerramienta`,
so the cards are painted, the permission modes still ask, and a denied call ends
the subagent with what it had written so far.

## The task list

The list is state, not conversation: it lives in `Chat._tareas`, `Chat` paints it
in the panel above the input box, and `ChatPrompts.bloqueTareas()` puts the
current list at the end of the system prompt on every request. That last part is
why it is kept out of the message history: after the conversation is compacted
the history no longer holds the `Update todo list` calls, but the block is
rebuilt from live state, so the model still sees its own list. It also survives a
chat reload, saved next to the messages in `user://meteor_ia_historial/`.

Two things the tool enforces in code rather than in the prompt, because a plan
the model believes it wrote but did not write is worse than no plan: the whole
list enters or nothing does (a rejected call says so and leaves the previous list
untouched), and while anything is pending exactly one task may be `in_progress`.

## Images

A tool can return an `"imagenes"` array of `user://` paths next to its `output`.
`Chat` turns that into an image part for the model and into a thumbnail in the
tool card, and it survives a chat reload because the history keeps the paths.

Two things worth knowing before touching this:

- The running game is a separate process. Its window is not in any texture the
  editor owns (verified on 4.7: the embedded game view texture holds only its
  toolbar), so a game screenshot is taken by the game itself. `ImageTools` writes
  a throwaway wrapper scene into `user://dotti_captura/`, plays it with
  `EditorInterface.play_custom_scene()`, and the wrapper waits, grabs
  `get_viewport().get_texture().get_image()` and saves a PNG that the editor then
  reads. Nothing is written into the user's project.
- An editor view that is not on screen renders at 2x2, so a capture has to check
  the texture size and, if needed, bring the view to the front for a frame.
