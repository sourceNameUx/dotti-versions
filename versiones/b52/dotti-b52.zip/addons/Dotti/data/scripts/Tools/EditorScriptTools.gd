class_name HerramientasEditorScripts

static func registrar(chat: Node) -> void:
	chat.registrarHerramienta(
		"Open script in editor",
		"Opens a script file in the Godot script editor and optionally jumps to a specific line. Works with both external (.gd files) and built-in scripts embedded in scenes (path format: res://scene.tscn::GDScript_XXXXX).",
		{
			"path": {"type": "string", "description": "Path to the script to open. For external scripts: 'res://scripts/Player.gd'. For built-in scripts embedded in a scene: 'res://scene.tscn::GDScript_XXXXX' (use \"Get open scripts\" to find these paths)."},
			"line": {"type": "string", "description": "Optional line number to jump to (as string), e.g. '42'. Default 0."}
		},
		["path"],
		abrirScriptEnEditor
	)
	chat.registrarHerramienta(
		"Get current editor script",
		"Returns the path and full source code of the script currently active in the script editor tab. Works for both external scripts and built-in scripts embedded in scenes. For built-in scripts, reads directly from the CodeEdit widget to capture unsaved changes.",
		{},
		[],
		obtenerScriptActualEnEditor
	)
	chat.registrarHerramienta(
		"Get open scripts",
		"Returns a list of all scripts currently open in the script editor, including built-in scripts embedded in scenes. For each script, returns its path, whether it is built-in (embedded in a scene), and whether it is currently active.",
		{},
		[],
		obtenerScriptsAbiertos
	)
	chat.registrarHerramienta(
		"Get current script info",
		"Returns comprehensive information about the script currently active in the script editor: path, full source code (from CodeEdit, capturing unsaved changes), cursor position, selection, line count, and whether it is a built-in script embedded in a scene.",
		{},
		[],
		obtenerInfoScriptActual
	)
	chat.registrarHerramienta(
		"Get script line",
		"Returns the text content of a specific line in the currently active script editor.",
		{
			"line": {"type": "string", "description": "Line number (1-based, as string), e.g. '10'."}
		},
		["line"],
		obtenerLineaScript
	)
	chat.registrarHerramienta(
		"Get script line range",
		"Returns the text of a range of lines from the currently active script editor.",
		{
			"from_line": {"type": "string", "description": "Start line number (1-based, as string)."},
			"to_line": {"type": "string", "description": "End line number (1-based, inclusive, as string)."}
		},
		["from_line", "to_line"],
		obtenerRangoLineasScript
	)
	chat.registrarHerramienta(
		"Get selected text in script",
		"Returns the currently selected text in the active script editor. If no selection exists, returns the word at the cursor position.",
		{},
		[],
		obtenerTextoSeleccionadoScript
	)
	chat.registrarHerramienta(
		"Replace selected text in script",
		"Replaces the currently selected text in the active script editor with the provided text. If nothing is selected, inserts at the cursor position.",
		{
			"new_text": {"type": "string", "description": "The text to replace the current selection with."}
		},
		["new_text"],
		reemplazarTextoSeleccionadoScript
	)
	chat.registrarHerramienta(
		"Set script text",
		"Replaces the entire content of the currently open script. For external scripts, also saves to disk. For built-in scripts embedded in scenes, updates the Script resource and the CodeEdit widget (the scene file must be saved separately with the \"Save current scene\" tool).",
		{
			"content": {"type": "string", "description": "The new full script content."}
		},
		["content"],
		establecerTextoScript
	)
	chat.registrarHerramienta(
		"Insert text at cursor in script",
		"Inserts the given text at the current cursor position in the active script editor.",
		{
			"text": {"type": "string", "description": "The text to insert at the cursor."}
		},
		["text"],
		insertarTextoEnCursorScript
	)
	chat.registrarHerramienta(
		"Insert line at",
		"Inserts a new line of text at the specified line number in the active script editor, pushing existing lines down.",
		{
			"line": {"type": "string", "description": "Line number (1-based) at which to insert the new line."},
			"text": {"type": "string", "description": "The text content of the new line."}
		},
		["line", "text"],
		insertarLineaEn
	)
	chat.registrarHerramienta(
		"Replace line",
		"Replaces the entire content of a specific line in the active script editor.",
		{
			"line": {"type": "string", "description": "Line number (1-based, as string) to replace."},
			"new_text": {"type": "string", "description": "The new content for that line (without newline character)."}
		},
		["line", "new_text"],
		reemplazarLinea
	)
	chat.registrarHerramienta(
		"Replace text in script",
		"Finds and replaces text in the active script editor. Can replace the first occurrence or all occurrences.",
		{
			"search": {"type": "string", "description": "The text to search for."},
			"replacement": {"type": "string", "description": "The text to replace it with."},
			"replace_all": {"type": "string", "description": "If 'true', replaces all occurrences. If 'false' or omitted, replaces only the first occurrence."}
		},
		["search", "replacement"],
		reemplazarTextoEnScript
	)
	chat.registrarHerramienta(
		"Save current script",
		"Saves the currently active script to disk by syncing the CodeEdit content, writing the file, and triggering a filesystem scan. For built-in scripts embedded in scenes, syncs source but the scene must be saved separately with the \"Save current scene\" tool. Call this when the editor shows parse errors that only appear until the script is saved.",
		{},
		[],
		guardarScriptActual
	)
	# "Save current scene" vive en SceneTools (HerramientasEscenas): ahi se
	# registra con el mismo nombre, asi que una segunda copia aqui solo pisaba
	# la descripcion buena y dejaba el aviso de copia de seguridad fuera.
	chat.registrarHerramienta(
		"Goto line in script",
		"Moves the cursor to the specified line in the active script editor and centers the view on it.",
		{
			"line": {"type": "string", "description": "Line number (1-based, as string) to jump to."}
		},
		["line"],
		irALineaScript
	)
	chat.registrarHerramienta(
		"Get cursor position",
		"Returns the current cursor line and column in the active script editor.",
		{},
		[],
		obtenerPosicionCursor
	)
	chat.registrarHerramienta(
		"Set cursor position",
		"Moves the cursor to the specified line and column in the active script editor.",
		{
			"line": {"type": "string", "description": "Line number (1-based, as string)."},
			"column": {"type": "string", "description": "Column number (0-based, as string). Defaults to 0 if omitted."}
		},
		["line"],
		establecerPosicionCursor
	)
	chat.registrarHerramienta(
		"Select text range",
		"Selects a range of text in the active script editor from a start line/column to an end line/column.",
		{
			"from_line": {"type": "string", "description": "Start line number (1-based)."},
			"from_column": {"type": "string", "description": "Start column (0-based)."},
			"to_line": {"type": "string", "description": "End line number (1-based)."},
			"to_column": {"type": "string", "description": "End column (0-based)."}
		},
		["from_line", "from_column", "to_line", "to_column"],
		seleccionarRangoTexto
	)
	chat.registrarHerramienta(
		"Search in script",
		"Searches for a text pattern in the currently active script. Returns the line number and column of the first match, or all matches if find_all is true.",
		{
			"pattern": {"type": "string", "description": "The text to search for."},
			"find_all": {"type": "string", "description": "If 'true', returns all matches. If 'false' or omitted, returns only the first match."},
			"match_case": {"type": "string", "description": "If 'true', the search is case-sensitive. Default is 'false'."}
		},
		["pattern"],
		buscarEnScript
	)
	chat.registrarHerramienta(
		"Get script symbols",
		"Returns a list of all function and variable definitions found in the currently active script, with their line numbers.",
		{},
		[],
		obtenerSimbolosScript
	)
	chat.registrarHerramienta(
		"Open built-in script from scene node",
		"Opens the built-in script attached to a node in the currently edited scene. Use the node path relative to the scene root (e.g. 'Player' or 'UI/Button').",
		{
			"node_path": {"type": "string", "description": "Path to the node relative to the edited scene root, e.g. 'Player' or 'UI/HUD/Label'."}
		},
		["node_path"],
		abrirScriptIntegradoDesdNodo
	)
	chat.registrarHerramienta(
		"Get script errors",
		"Parses the currently active script for errors by compiling it in a temporary GDScript instance. Returns a list of errors with exact line number, column, and error message — the same format Godot shows in the editor (e.g. line 29, col 17: Identifier 'Regex' not declared in the current scope). Use this before editing to know exactly what is wrong and where.",
		{},
		[],
		obtenerErroresScript
	)

static func _escanerFs() -> void:
	if Engine.is_editor_hint():
		var fs := EditorInterface.get_resource_filesystem()
		if fs:
			fs.scan()

static func _obtenerCodeEditActual():
	if not Engine.is_editor_hint():
		return null
	var scriptEditor := EditorInterface.get_script_editor()
	if not scriptEditor:
		return null
	var currentEditor := scriptEditor.get_current_editor()
	if not currentEditor:
		return null
	var baseEditor := currentEditor.get_base_editor()
	if baseEditor and baseEditor is CodeEdit:
		return baseEditor
	return null

static func _obtenerScriptActualConFallback():
	var scriptEditor := EditorInterface.get_script_editor()
	if not scriptEditor:
		return null
	var script := scriptEditor.get_current_script()
	if script:
		return script
	var currentEditor := scriptEditor.get_current_editor()
	if not currentEditor:
		return null
	var baseEditor := currentEditor.get_base_editor()
	if not baseEditor or not (baseEditor is CodeEdit):
		return null
	var editedScriptEditors := scriptEditor.get_open_script_editors()
	var openScripts := scriptEditor.get_open_scripts()
	for i in range(editedScriptEditors.size()):
		if editedScriptEditors[i] == currentEditor:
			if i < openScripts.size():
				return openScripts[i]
	return null

static func _esScriptIntegrado(script) -> bool:
	if not script:
		return false
	var path = script.resource_path
	return path.contains("::")

static func _obtenerContenidoScript(script, codeEdit) -> String:
	if codeEdit and codeEdit is CodeEdit:
		var texto = codeEdit.text
		if texto != "":
			return texto
	if script:
		if script.source_code != "":
			return script.source_code
		var path = script.resource_path
		if path != "" and not path.contains("::") and FileAccess.file_exists(path):
			var f := FileAccess.open(path, FileAccess.READ)
			if f:
				var contenido := f.get_as_text()
				f.close()
				return contenido
	return ""

static func _lineaEditorAApi(linea_ui: int) -> int:
	return maxi(0, linea_ui - 1)

static func _lineaApiAEditor(linea_api: int) -> int:
	return linea_api + 1

static func _parsearMensajeErrorGodot(mensaje: String) -> Dictionary:
	var resultado := {"line": -1, "column": -1, "message": mensaje}
	var reParen := RegEx.new()
	reParen.compile("\\((\\d+),\\s*(\\d+)\\)")
	var m := reParen.search(mensaje)
	if m:
		resultado["line"] = m.get_string(1).to_int()
		resultado["column"] = m.get_string(2).to_int()
		var parteMsg := mensaje.find(")")
		if parteMsg != -1 and parteMsg + 1 < mensaje.length():
			resultado["message"] = mensaje.substr(parteMsg + 1).strip_edges().trim_prefix(":").strip_edges()
		return resultado
	var reColon := RegEx.new()
	reColon.compile(":(\\d+):\\s*(.+)$")
	var m2 := reColon.search(mensaje)
	if m2:
		resultado["line"] = m2.get_string(1).to_int()
		resultado["message"] = m2.get_string(2).strip_edges()
	return resultado

static func _recopilarItemLists(nodo: Node) -> Array:
	var resultado: Array = []
	if nodo is ItemList:
		resultado.append(nodo)
	for hijo in nodo.get_children():
		resultado.append_array(_recopilarItemLists(hijo))
	return resultado

static func _leerErroresDelPanelEditor(scriptEditor: Node, lineasSource: Array) -> Array:
	var erroresEncontrados: Array = []
	var currentEditor = scriptEditor.get_current_editor()
	if not currentEditor:
		return erroresEncontrados
	var itemLists := _recopilarItemLists(currentEditor)
	var reErrorLinea := RegEx.new()
	reErrorLinea.compile("\\((\\d+),\\s*(\\d+)\\):\\s*(.+)$")
	for lista in itemLists:
		var il := lista as ItemList
		if il.item_count == 0:
			continue
		for i in range(il.item_count):
			var txt := il.get_item_text(i).strip_edges()
			if txt == "":
				continue
			var m := reErrorLinea.search(txt)
			if m:
				var lineaNum := m.get_string(1).to_int()
				var colNum := m.get_string(2).to_int()
				var msgTexto := m.get_string(3).strip_edges()
				var lineaIdx := lineaNum - 1
				var lineaTexto = lineasSource[lineaIdx].strip_edges() if lineaIdx < lineasSource.size() else ""
				erroresEncontrados.append({
					"line": lineaNum,
					"column": colNum,
					"message": msgTexto,
					"source_line": lineaTexto
				})
	return erroresEncontrados

static func obtenerErroresScript(_args: Dictionary) -> Dictionary:
	if not Engine.is_editor_hint():
		return {"success": false, "output": "Not running in editor context."}
	var codeEdit = _obtenerCodeEditActual()
	var script = _obtenerScriptActualConFallback()
	if not codeEdit and not script:
		return {"success": false, "output": "No script is currently active."}
	var sourceCode := _obtenerContenidoScript(script, codeEdit)
	if sourceCode == "":
		return {"success": false, "output": "Could not read source code from the active script."}
	var scriptPath := ""
	if script:
		scriptPath = script.resource_path
	var tempScript := GDScript.new()
	tempScript.source_code = sourceCode
	var errCode := tempScript.reload(false)
	if errCode == OK:
		var info := {"path": scriptPath, "error_count": 0, "errors": [], "status": "ok"}
		return {"success": true, "output": JSON.stringify(info)}
	var lineasSource := sourceCode.split("\n")
	var erroresEncontrados: Array = []
	var scriptEditor := EditorInterface.get_script_editor()
	if scriptEditor:
		erroresEncontrados = _leerErroresDelPanelEditor(scriptEditor, lineasSource)
	if erroresEncontrados.is_empty():
		erroresEncontrados.append({
			"line": -1,
			"column": -1,
			"message": "Script has errors (reload error code %d). The exact error with line and column is visible in the Godot Output panel and in the script editor status bar. Paste the error text here so it can be parsed precisely." % errCode,
			"source_line": "",
			"hint": "In the Godot editor, click the red error icon at the bottom of the script editor to see the full error list with line numbers."
		})
	var info := {
		"path": scriptPath,
		"error_count": erroresEncontrados.size(),
		"errors": erroresEncontrados,
		"status": "error",
		"reload_error_code": errCode
	}
	return {"success": true, "output": JSON.stringify(info)}

static func abrirScriptEnEditor(args: Dictionary) -> Dictionary:
	if not Engine.is_editor_hint():
		return {"success": false, "output": "Not running in editor context."}
	var resolucion := Rutas.proyecto(args.get("path", ""))
	if not bool(resolucion["ok"]):
		return {"success": false, "output": str(resolucion["motivo"])}
	var path: String = str(resolucion["ruta"])
	var lineaStr := args.get("line", "0")
	var linea = lineaStr.to_int() if lineaStr.is_valid_int() else 0
	var lineaApi := _lineaEditorAApi(linea) if linea > 0 else 0
	if path.contains("::"):
		var partes = path.split("::")
		var scenePath = partes[0]
		if not FileAccess.file_exists(scenePath):
			return {"success": false, "output": "Scene file not found: " + scenePath}
		var scriptEditor := EditorInterface.get_script_editor()
		if not scriptEditor:
			return {"success": false, "output": "Script editor not available."}
		var openScripts := scriptEditor.get_open_scripts()
		for s in openScripts:
			if s.resource_path == path:
				EditorInterface.edit_script(s, lineaApi, 0)
				return {"success": true, "output": "Switched to built-in script already open: %s" % path}
		var resource := load(path)
		if resource == null:
			return {"success": false, "output": "Could not load built-in script resource: " + path}
		EditorInterface.edit_script(resource, lineaApi, 0)
		return {"success": true, "output": "Opened built-in script in editor: %s" % path}
	if not FileAccess.file_exists(path):
		return {"success": false, "output": "File not found: " + path}
	var script := load(path)
	if script == null:
		return {"success": false, "output": "Could not load resource: " + path}
	EditorInterface.edit_script(script, lineaApi, 0)
	var lineaStr2 := " (line %d)" % linea if linea > 0 else ""
	return {"success": true, "output": "Opened in script editor: %s%s" % [path, lineaStr2]}

static func obtenerScriptActualEnEditor(_args: Dictionary) -> Dictionary:
	if not Engine.is_editor_hint():
		return {"success": false, "output": "Not running in editor context."}
	var scriptEditor := EditorInterface.get_script_editor()
	if not scriptEditor:
		return {"success": false, "output": "Script editor not available."}
	var codeEdit = _obtenerCodeEditActual()
	var script = _obtenerScriptActualConFallback()
	if not script and not codeEdit:
		return {"success": false, "output": "No script is currently active in the script editor."}
	var path := ""
	var esIntegrado := false
	if script:
		path = script.resource_path
		esIntegrado = _esScriptIntegrado(script)
	var contenido := _obtenerContenidoScript(script, codeEdit)
	if contenido == "" and not script:
		return {"success": false, "output": "Could not read source code from the active editor."}
	var info := {
		"path": path,
		"is_built_in": esIntegrado,
		"content": contenido
	}
	if esIntegrado:
		var partes := path.split("::")
		info["scene_path"] = partes[0]
	return {"success": true, "output": JSON.stringify(info)}

static func obtenerScriptsAbiertos(_args: Dictionary) -> Dictionary:
	if not Engine.is_editor_hint():
		return {"success": false, "output": "Not running in editor context."}
	var scriptEditor := EditorInterface.get_script_editor()
	if not scriptEditor:
		return {"success": false, "output": "Script editor not available."}
	var openScripts := scriptEditor.get_open_scripts()
	var scriptActual = _obtenerScriptActualConFallback()
	var rutaActual = scriptActual.resource_path if scriptActual else ""
	if openScripts.is_empty():
		return {"success": true, "output": "No scripts currently open."}
	var resultados: Array = []
	for s in openScripts:
		var ruta := s.resource_path
		var esIntegrado := ruta.contains("::")
		var entrada := {
			"path": ruta,
			"is_built_in": esIntegrado,
			"is_active": ruta == rutaActual
		}
		if esIntegrado:
			var partes := ruta.split("::")
			entrada["scene_path"] = partes[0]
		resultados.append(entrada)
	return {"success": true, "output": JSON.stringify(resultados)}

static func obtenerInfoScriptActual(_args: Dictionary) -> Dictionary:
	if not Engine.is_editor_hint():
		return {"success": false, "output": "Not running in editor context."}
	var scriptEditor := EditorInterface.get_script_editor()
	if not scriptEditor:
		return {"success": false, "output": "Script editor not available."}
	var script = _obtenerScriptActualConFallback()
	var codeEdit = _obtenerCodeEditActual()
	if not script and not codeEdit:
		return {"success": false, "output": "No script is currently active."}
	var path = script.resource_path if script else ""
	var esIntegrado := _esScriptIntegrado(script)
	var contenido := _obtenerContenidoScript(script, codeEdit)
	var info := {
		"path": path,
		"is_built_in": esIntegrado,
		"full_text": contenido,
		"line_count": 0
	}
	if esIntegrado and path.contains("::"):
		info["scene_path"] = path.split("::")[0]
	if codeEdit:
		info["line_count"] = codeEdit.get_line_count()
		info["cursor_line"] = _lineaApiAEditor(codeEdit.get_caret_line())
		info["cursor_column"] = codeEdit.get_caret_column()
		info["has_selection"] = codeEdit.has_selection()
		if codeEdit.has_selection():
			info["selected_text"] = codeEdit.get_selected_text()
			info["selection_from_line"] = _lineaApiAEditor(codeEdit.get_selection_from_line())
			info["selection_from_column"] = codeEdit.get_selection_from_column()
			info["selection_to_line"] = _lineaApiAEditor(codeEdit.get_selection_to_line())
			info["selection_to_column"] = codeEdit.get_selection_to_column()
	else:
		var lineas := contenido.split("\n")
		info["line_count"] = lineas.size()
	return {"success": true, "output": JSON.stringify(info)}

static func obtenerLineaScript(args: Dictionary) -> Dictionary:
	if not Engine.is_editor_hint():
		return {"success": false, "output": "Not running in editor context."}
	var lineaStr := args.get("line", "")
	if not lineaStr.is_valid_int():
		return {"success": false, "output": "Line must be a valid integer."}
	var lineaUi = lineaStr.to_int()
	var lineaApi := _lineaEditorAApi(lineaUi)
	var codeEdit = _obtenerCodeEditActual()
	if codeEdit:
		if lineaApi < 0 or lineaApi >= codeEdit.get_line_count():
			return {"success": false, "output": "Line %d out of range (script has %d lines)." % [lineaUi, codeEdit.get_line_count()]}
		return {"success": true, "output": codeEdit.get_line(lineaApi)}
	var script = _obtenerScriptActualConFallback()
	if not script:
		return {"success": false, "output": "No script is currently active."}
	var contenido := _obtenerContenidoScript(script, null)
	var lineas := contenido.split("\n")
	if lineaApi < 0 or lineaApi >= lineas.size():
		return {"success": false, "output": "Line %d out of range." % lineaUi}
	return {"success": true, "output": lineas[lineaApi]}

static func obtenerRangoLineasScript(args: Dictionary) -> Dictionary:
	if not Engine.is_editor_hint():
		return {"success": false, "output": "Not running in editor context."}
	var desdeStr := args.get("from_line", "")
	var hastaStr := args.get("to_line", "")
	if not desdeStr.is_valid_int() or not hastaStr.is_valid_int():
		return {"success": false, "output": "from_line and to_line must be valid integers."}
	var desdeUi = desdeStr.to_int()
	var hastaUi = hastaStr.to_int()
	var desdeApi := _lineaEditorAApi(desdeUi)
	var hastaApi := _lineaEditorAApi(hastaUi)
	if desdeApi > hastaApi:
		return {"success": false, "output": "from_line must be less than or equal to to_line."}
	var codeEdit = _obtenerCodeEditActual()
	var lineas: Array = []
	if codeEdit:
		var totalLineas = codeEdit.get_line_count()
		for i in range(desdeApi, mini(hastaApi + 1, totalLineas)):
			lineas.append({"line": i + 1, "text": codeEdit.get_line(i)})
	else:
		var script = _obtenerScriptActualConFallback()
		if not script:
			return {"success": false, "output": "No script is currently active."}
		var contenido := _obtenerContenidoScript(script, null)
		var todasLineas := contenido.split("\n")
		for i in range(desdeApi, mini(hastaApi + 1, todasLineas.size())):
			lineas.append({"line": i + 1, "text": todasLineas[i]})
	return {"success": true, "output": JSON.stringify(lineas)}

static func obtenerTextoSeleccionadoScript(_args: Dictionary) -> Dictionary:
	if not Engine.is_editor_hint():
		return {"success": false, "output": "Not running in editor context."}
	var codeEdit = _obtenerCodeEditActual()
	if not codeEdit:
		return {"success": false, "output": "No script editor currently active."}
	if codeEdit.has_selection():
		return {"success": true, "output": codeEdit.get_selected_text()}
	var linea = codeEdit.get_caret_line()
	var col = codeEdit.get_caret_column()
	var lineaTexto = codeEdit.get_line(linea)
	var inicio = col
	var fin = col
	while inicio > 0 and (lineaTexto[inicio - 1].is_valid_identifier() or lineaTexto[inicio - 1] == "_"):
		inicio -= 1
	while fin < lineaTexto.length() and (lineaTexto[fin].is_valid_identifier() or lineaTexto[fin] == "_"):
		fin += 1
	if inicio != fin:
		return {"success": true, "output": lineaTexto.substr(inicio, fin - inicio)}
	return {"success": false, "output": "No text selected and no word under cursor."}

static func reemplazarTextoSeleccionadoScript(args: Dictionary) -> Dictionary:
	if not Engine.is_editor_hint():
		return {"success": false, "output": "Not running in editor context."}
	var newText: String = args.get("new_text", "")
	var codeEdit = _obtenerCodeEditActual()
	if not codeEdit:
		return {"success": false, "output": "No script editor currently active."}
	codeEdit.insert_text_at_caret(newText)
	if codeEdit.has_selection():
		return {"success": true, "output": "Replaced selected text."}
	return {"success": true, "output": "Inserted text at cursor."}

static func establecerTextoScript(args: Dictionary) -> Dictionary:
	if not Engine.is_editor_hint():
		return {"success": false, "output": "Not running in editor context."}
	var content: String = args.get("content", "")
	if content == "":
		return {"success": false, "output": "Missing required argument: content."}
	var scriptEditor := EditorInterface.get_script_editor()
	if not scriptEditor:
		return {"success": false, "output": "Script editor not available."}
	var script = _obtenerScriptActualConFallback()
	var codeEdit = _obtenerCodeEditActual()
	if not script and not codeEdit:
		return {"success": false, "output": "No script is currently active."}
	if codeEdit:
		codeEdit.text = content
		codeEdit.clear_undo_history()
	if script:
		script.source_code = content
		var path = script.resource_path
		var esIntegrado := _esScriptIntegrado(script)
		if not esIntegrado:
			var err = script.reload()
			if err != OK:
				return {"success": false, "output": "Script reload failed (error %d)." % err}
			if path != "":
				CopiasSeguridad.respaldar(path, "editor script overwrite")
				var f := FileAccess.open(path, FileAccess.WRITE)
				if f:
					f.store_string(content)
					f.close()
					_escanerFs()
			return {"success": true, "output": "External script updated and saved: %s (%d bytes)" % [path, content.length()]}
		else:
			return {"success": true, "output": "Built-in script updated in editor (%d bytes). Save the scene to persist changes." % content.length()}
	return {"success": true, "output": "Script content updated in editor (%d bytes)." % content.length()}

static func insertarTextoEnCursorScript(args: Dictionary) -> Dictionary:
	if not Engine.is_editor_hint():
		return {"success": false, "output": "Not running in editor context."}
	var text: String = args.get("text", "")
	if text == "":
		return {"success": false, "output": "Missing required argument: text."}
	var codeEdit = _obtenerCodeEditActual()
	if not codeEdit:
		return {"success": false, "output": "No script editor currently active."}
	codeEdit.insert_text_at_caret(text)
	return {"success": true, "output": "Inserted %d characters at cursor." % text.length()}

static func insertarLineaEn(args: Dictionary) -> Dictionary:
	if not Engine.is_editor_hint():
		return {"success": false, "output": "Not running in editor context."}
	var lineaStr := args.get("line", "")
	var text: String = args.get("text", "")
	if not lineaStr.is_valid_int():
		return {"success": false, "output": "Line must be a valid integer."}
	var lineaUi = lineaStr.to_int()
	var lineaApi := _lineaEditorAApi(lineaUi)
	var codeEdit = _obtenerCodeEditActual()
	if not codeEdit:
		return {"success": false, "output": "No script editor currently active."}
	var totalLineas = codeEdit.get_line_count()
	lineaApi = clampi(lineaApi, 0, totalLineas)
	codeEdit.set_caret_line(lineaApi)
	codeEdit.set_caret_column(0)
	codeEdit.insert_text_at_caret(text + "\n")
	return {"success": true, "output": "Inserted line at line %d." % lineaUi}

static func reemplazarLinea(args: Dictionary) -> Dictionary:
	if not Engine.is_editor_hint():
		return {"success": false, "output": "Not running in editor context."}
	var lineaStr := args.get("line", "")
	var newText: String = args.get("new_text", "")
	if not lineaStr.is_valid_int():
		return {"success": false, "output": "Line must be a valid integer."}
	var lineaUi = lineaStr.to_int()
	var lineaApi := _lineaEditorAApi(lineaUi)
	var codeEdit = _obtenerCodeEditActual()
	if not codeEdit:
		return {"success": false, "output": "No script editor currently active."}
	if lineaApi < 0 or lineaApi >= codeEdit.get_line_count():
		return {"success": false, "output": "Line %d out of range." % lineaUi}
	codeEdit.select(lineaApi, 0, lineaApi, codeEdit.get_line(lineaApi).length())
	codeEdit.insert_text_at_caret(newText)
	return {"success": true, "output": "Replaced line %d." % lineaUi}

static func reemplazarTextoEnScript(args: Dictionary) -> Dictionary:
	if not Engine.is_editor_hint():
		return {"success": false, "output": "Not running in editor context."}
	var search: String = args.get("search", "")
	var replacement: String = args.get("replacement", "")
	var replaceAll := ChatParseador.booleanoDe(args, "replace_all", false)
	var matchCase := ChatParseador.booleanoDe(args, "match_case", false)
	if search == "":
		return {"success": false, "output": "Missing required argument: search."}
	var codeEdit = _obtenerCodeEditActual()
	if not codeEdit:
		return {"success": false, "output": "No script editor currently active."}
	var contenido = codeEdit.text
	var contenidoBusqueda = contenido if matchCase else contenido.to_lower()
	var patronBusqueda := search if matchCase else search.to_lower()
	var count := 0
	if replaceAll:
		var nuevo = contenido.replace(search, replacement) if matchCase else _reemplazarTodoSinCase(contenido, search, replacement)
		count = contenidoBusqueda.count(patronBusqueda)
		if count == 0:
			return {"success": false, "output": "Pattern not found: '%s'" % search}
		codeEdit.text = nuevo
		codeEdit.clear_undo_history()
		return {"success": true, "output": "Replaced %d occurrence(s) of '%s'." % [count, search]}
	var idx = contenidoBusqueda.find(patronBusqueda)
	if idx == -1:
		return {"success": false, "output": "Pattern not found: '%s'" % search}
	var nuevo = contenido.substr(0, idx) + replacement + contenido.substr(idx + search.length())
	codeEdit.text = nuevo
	codeEdit.clear_undo_history()
	var lineaResultado = contenido.substr(0, idx).count("\n")
	return {"success": true, "output": "Replaced first occurrence at line %d." % _lineaApiAEditor(lineaResultado)}

static func _reemplazarTodoSinCase(texto: String, busqueda: String, reemplazo: String) -> String:
	var resultado := ""
	var restante := texto
	var busquedaLower := busqueda.to_lower()
	while true:
		var idx := restante.to_lower().find(busquedaLower)
		if idx == -1:
			resultado += restante
			break
		resultado += restante.substr(0, idx) + reemplazo
		restante = restante.substr(idx + busqueda.length())
	return resultado

static func guardarScriptActual(_args: Dictionary) -> Dictionary:
	_guardarEscenaActual({})
	if not Engine.is_editor_hint():
		return {"success": false, "output": "Not running in editor context."}
	var scriptEditor := EditorInterface.get_script_editor()
	if not scriptEditor:
		return {"success": false, "output": "Script editor not available."}
	var script = _obtenerScriptActualConFallback()
	var codeEdit = _obtenerCodeEditActual()
	if not script and not codeEdit:
		return {"success": false, "output": "No script is currently active."}
	if codeEdit and script:
		script.source_code = codeEdit.text
	var esIntegrado := _esScriptIntegrado(script)
	if esIntegrado:
		return {"success": true, "output": "Built-in script source synced. Use the \"Save current scene\" tool to save the scene file."}
	if script:
		var sourceParaGuardar = codeEdit.text if codeEdit else script.source_code
		var path = script.resource_path
		if path == "":
			return {"success": false, "output": "Script has no file path."}
		CopiasSeguridad.respaldar(path, "script save")
		var f := FileAccess.open(path, FileAccess.WRITE)
		if not f:
			return {"success": false, "output": "Could not write to file: %s" % path}
		f.store_string(sourceParaGuardar)
		f.close()
		script.source_code = sourceParaGuardar
		var reloadErr = script.reload(true)
		_escanerFs()
		if reloadErr != OK:
			return {"success": true, "output": "Script file saved: %s — but reload reported errors (code %d). Check Output panel for details." % [path, reloadErr]}
		return {"success": true, "output": "Script saved and reloaded successfully: %s" % path}
	return {"success": false, "output": "Could not determine script to save."}

## Guarda la escena que se esta editando. Es interno: la herramienta publica con
## ese nombre es la de SceneTools ("Save current scene"). Aqui se usa antes de
## guardar un script porque un script integrado vive dentro de la escena y sin
## guardar la escena el cambio se pierde.
static func _guardarEscenaActual(_args: Dictionary) -> Dictionary:
	if not Engine.is_editor_hint():
		return {"success": false, "output": "Not running in editor context."}
	CopiasSeguridad.respaldarEscenaAbierta()
	var err := EditorInterface.save_scene()
	if err == OK:
		return {"success": true, "output": "Scene saved."}
	return {"success": false, "output": "Failed to save scene (error %d)." % err}

static func irALineaScript(args: Dictionary) -> Dictionary:
	if not Engine.is_editor_hint():
		return {"success": false, "output": "Not running in editor context."}
	var lineaStr := args.get("line", "")
	if not lineaStr.is_valid_int():
		return {"success": false, "output": "Line must be a valid integer."}
	var lineaUi = lineaStr.to_int()
	var lineaApi := _lineaEditorAApi(lineaUi)
	var codeEdit = _obtenerCodeEditActual()
	if codeEdit:
		lineaApi = clampi(lineaApi, 0, codeEdit.get_line_count() - 1)
		codeEdit.set_caret_line(lineaApi)
		codeEdit.center_viewport_to_caret()
		return {"success": true, "output": "Moved to line %d." % lineaUi}
	var script = _obtenerScriptActualConFallback()
	if not script:
		return {"success": false, "output": "No script is currently active."}
	EditorInterface.edit_script(script, lineaApi, 0)
	return {"success": true, "output": "Navigated to line %d in script: %s" % [lineaUi, script.resource_path]}

static func obtenerPosicionCursor(_args: Dictionary) -> Dictionary:
	if not Engine.is_editor_hint():
		return {"success": false, "output": "Not running in editor context."}
	var codeEdit = _obtenerCodeEditActual()
	if not codeEdit:
		return {"success": false, "output": "No script editor currently active."}
	var info := {
		"line": _lineaApiAEditor(codeEdit.get_caret_line()),
		"column": codeEdit.get_caret_column()
	}
	return {"success": true, "output": JSON.stringify(info)}

static func establecerPosicionCursor(args: Dictionary) -> Dictionary:
	if not Engine.is_editor_hint():
		return {"success": false, "output": "Not running in editor context."}
	var lineaStr := args.get("line", "")
	var colStr := args.get("column", "0")
	if not lineaStr.is_valid_int():
		return {"success": false, "output": "Line must be a valid integer."}
	var lineaUi = lineaStr.to_int()
	var lineaApi := _lineaEditorAApi(lineaUi)
	var col = colStr.to_int() if colStr.is_valid_int() else 0
	var codeEdit = _obtenerCodeEditActual()
	if not codeEdit:
		return {"success": false, "output": "No script editor currently active."}
	lineaApi = clampi(lineaApi, 0, codeEdit.get_line_count() - 1)
	var maxCol = codeEdit.get_line(lineaApi).length()
	col = clampi(col, 0, maxCol)
	codeEdit.set_caret_line(lineaApi)
	codeEdit.set_caret_column(col)
	codeEdit.center_viewport_to_caret()
	return {"success": true, "output": "Cursor set to line %d, column %d." % [lineaUi, col]}

static func seleccionarRangoTexto(args: Dictionary) -> Dictionary:
	if not Engine.is_editor_hint():
		return {"success": false, "output": "Not running in editor context."}
	var desdeLineaStr := args.get("from_line", "")
	var desdeColStr := args.get("from_column", "0")
	var hastaLineaStr := args.get("to_line", "")
	var hastaColStr := args.get("to_column", "0")
	if not desdeLineaStr.is_valid_int() or not hastaLineaStr.is_valid_int():
		return {"success": false, "output": "from_line and to_line must be valid integers."}
	var desdeLineaApi := _lineaEditorAApi(desdeLineaStr.to_int())
	var hastaLineaApi := _lineaEditorAApi(hastaLineaStr.to_int())
	var desdeCol = desdeColStr.to_int() if desdeColStr.is_valid_int() else 0
	var hastaCol = hastaColStr.to_int() if hastaColStr.is_valid_int() else 0
	var codeEdit = _obtenerCodeEditActual()
	if not codeEdit:
		return {"success": false, "output": "No script editor currently active."}
	codeEdit.select(desdeLineaApi, desdeCol, hastaLineaApi, hastaCol)
	var seleccionado = codeEdit.get_selected_text()
	return {"success": true, "output": "Selected %d characters: %s" % [seleccionado.length(), seleccionado.substr(0, 100)]}

static func buscarEnScript(args: Dictionary) -> Dictionary:
	if not Engine.is_editor_hint():
		return {"success": false, "output": "Not running in editor context."}
	var patron: String = args.get("pattern", "")
	var findAll := ChatParseador.booleanoDe(args, "find_all", false)
	var matchCase := ChatParseador.booleanoDe(args, "match_case", false)
	if patron == "":
		return {"success": false, "output": "Missing required argument: pattern."}
	var codeEdit = _obtenerCodeEditActual()
	var contenido := ""
	if codeEdit:
		contenido = codeEdit.text
	else:
		var script = _obtenerScriptActualConFallback()
		if not script:
			return {"success": false, "output": "No script is currently active."}
		contenido = _obtenerContenidoScript(script, null)
	var contenidoBusqueda := contenido if matchCase else contenido.to_lower()
	var patronBusqueda := patron if matchCase else patron.to_lower()
	var resultados: Array = []
	var pos := 0
	while true:
		var idx := contenidoBusqueda.find(patronBusqueda, pos)
		if idx == -1:
			break
		var lineaApi := contenido.substr(0, idx).count("\n")
		var inicioLinea := contenido.rfind("\n", idx - 1) + 1
		var col := idx - inicioLinea
		resultados.append({"line": _lineaApiAEditor(lineaApi), "column": col})
		if not findAll:
			break
		pos = idx + patronBusqueda.length()
	if resultados.is_empty():
		return {"success": false, "output": "Pattern not found: '%s'" % patron}
	return {"success": true, "output": JSON.stringify(resultados)}

static func obtenerSimbolosScript(_args: Dictionary) -> Dictionary:
	if not Engine.is_editor_hint():
		return {"success": false, "output": "Not running in editor context."}
	var codeEdit = _obtenerCodeEditActual()
	var contenido := ""
	if codeEdit:
		contenido = codeEdit.text
	else:
		var script = _obtenerScriptActualConFallback()
		if not script:
			return {"success": false, "output": "No script is currently active."}
		contenido = _obtenerContenidoScript(script, null)
	var lineas := contenido.split("\n")
	var simbolos: Array = []
	for i in range(lineas.size()):
		var linea := lineas[i].strip_edges()
		if linea.begins_with("func ") or linea.begins_with("static func "):
			var nombreFunc := linea
			var parenIdx := linea.find("(")
			if parenIdx != -1:
				nombreFunc = linea.substr(0, parenIdx).strip_edges()
			simbolos.append({"type": "function", "name": nombreFunc, "line": i + 1})
		elif linea.begins_with("var ") or linea.begins_with("@export var ") or linea.begins_with("@onready var "):
			var nombreVar := linea
			var assignIdx := linea.find(":")
			var eqIdx := linea.find("=")
			var endIdx := linea.length()
			if assignIdx != -1:
				endIdx = mini(endIdx, assignIdx)
			if eqIdx != -1:
				endIdx = mini(endIdx, eqIdx)
			nombreVar = linea.substr(0, endIdx).strip_edges()
			simbolos.append({"type": "variable", "name": nombreVar, "line": i + 1})
		elif linea.begins_with("class "):
			var nombreClase := linea.replace("class ", "").replace(":", "").strip_edges()
			simbolos.append({"type": "class", "name": nombreClase, "line": i + 1})
		elif linea.begins_with("signal "):
			var nombreSignal := linea.replace("signal ", "").strip_edges()
			var parenIdx := nombreSignal.find("(")
			if parenIdx != -1:
				nombreSignal = nombreSignal.substr(0, parenIdx).strip_edges()
			simbolos.append({"type": "signal", "name": nombreSignal, "line": i + 1})
		elif linea.begins_with("enum "):
			var nombreEnum := linea.replace("enum ", "").strip_edges()
			var braceIdx := nombreEnum.find("{")
			if braceIdx != -1:
				nombreEnum = nombreEnum.substr(0, braceIdx).strip_edges()
			simbolos.append({"type": "enum", "name": nombreEnum, "line": i + 1})
		elif linea.begins_with("const "):
			var nombreConst := linea.replace("const ", "").strip_edges()
			var eqIdx := nombreConst.find("=")
			var colonIdx := nombreConst.find(":")
			var endIdx := nombreConst.length()
			if eqIdx != -1:
				endIdx = mini(endIdx, eqIdx)
			if colonIdx != -1:
				endIdx = mini(endIdx, colonIdx)
			nombreConst = nombreConst.substr(0, endIdx).strip_edges()
			simbolos.append({"type": "const", "name": nombreConst, "line": i + 1})
	return {"success": true, "output": JSON.stringify(simbolos)}

static func abrirScriptIntegradoDesdNodo(args: Dictionary) -> Dictionary:
	if not Engine.is_editor_hint():
		return {"success": false, "output": "Not running in editor context."}
	var nodePath: String = args.get("node_path", "")
	if nodePath == "":
		return {"success": false, "output": "Missing required argument: node_path."}
	var sceneRoot := EditorInterface.get_edited_scene_root()
	if not sceneRoot:
		return {"success": false, "output": "No scene is currently open in the editor."}
	var nodo: Node = null
	if nodePath == "." or nodePath == sceneRoot.name:
		nodo = sceneRoot
	else:
		nodo = sceneRoot.get_node_or_null(nodePath)
	if not nodo:
		nodo = sceneRoot.find_child(nodePath, true, false)
	if not nodo:
		return {"success": false, "output": "Node not found: '%s'. Check the path relative to the scene root '%s'." % [nodePath, sceneRoot.name]}
	var script := nodo.get_script()
	if not script:
		return {"success": false, "output": "Node '%s' has no script attached." % nodePath}
	var path = script.resource_path
	EditorInterface.edit_script(script, 0, 0)
	var esIntegrado := _esScriptIntegrado(script)
	if esIntegrado:
		return {"success": true, "output": "Opened built-in script for node '%s' (path: %s)." % [nodePath, path]}
	return {"success": true, "output": "Opened script for node '%s': %s" % [nodePath, path]}
