class_name HerramientasArchivos

static func registrar(chat: Node) -> void:
	chat.registrarHerramienta(
		"Create or update file",
		"Creates or overwrites a non-script file (configs, JSON, text, resources). Do NOT use for .gd scripts — use \"Create script\" or \"Update script\" instead, which validate syntax and report exact errors.",
		{
			"path":    {"type": "string", "description": "File path relative to res://, e.g. res://scripts/Player.gd"},
			"content": {"type": "string", "description": "Full text content to write into the file"}
		},
		["path", "content"],
		crearOActualizarArchivo
	)
	chat.registrarHerramienta(
		"Read file",
		"Reads and returns the full text content of any file in the project (scripts, scenes, configs, etc.).",
		{
			"path": {"type": "string", "description": "File path to read, e.g. res://scripts/Player.gd"}
		},
		["path"],
		leerArchivo
	)
	chat.registrarHerramienta(
		"Search replace in file",
		"Finds and replaces text inside a non-script file. By default the search text must be unique, so the edit lands exactly where you meant it; set replace_all to change every occurrence. Do NOT use for .gd scripts — use \"Replace in script\" instead, which validates syntax and reports exact parse errors.",
		{
			"path":        {"type": "string", "description": "Path to the file to modify"},
			"search":      {"type": "string", "description": "The exact text to find"},
			"replace":     {"type": "string", "description": "The text to put in its place"},
			"replace_all": {"type": "boolean", "description": "If true, replaces every occurrence. If false (default), the search text must appear exactly once."}
		},
		["path", "search", "replace"],
		buscarYReemplazarEnArchivo
	)
	chat.registrarHerramienta(
		"List files",
		"Lists all files and subdirectories inside a given directory (one level deep).",
		{
			"directory": {"type": "string", "description": "Directory path, e.g. res:// or res://scenes/"}
		},
		["directory"],
		listarArchivos
	)
	chat.registrarHerramienta(
		"List files recursive",
		"Lists all files recursively inside a directory and all its subdirectories.",
		{
			"directory":        {"type": "string", "description": "Root directory to search, e.g. res://"},
			"extension_filter": {"type": "string", "description": "Optional extension filter e.g. .gd or .tscn. Leave empty for all files."}
		},
		["directory"],
		listarArchivosRecursivo
	)
	chat.registrarHerramienta(
		"Search in files",
		"Searches for text (or a regular expression) across every text file in the project and returns the matching lines as path:line: text. Use this instead of reading whole files when you are looking for where something is defined or used.",
		{
			"query":          {"type": "string", "description": "Text or regular expression to look for"},
			"path":           {"type": "string", "description": "Optional directory or file to search under, e.g. res://scripts. Defaults to the whole project."},
			"include":        {"type": "string", "description": "Optional filter: comma-separated extensions or paths, e.g. \".gd,.tscn\" or \"res://scripts/\"."},
			"regex":          {"type": "boolean", "description": "If true, query is a regular expression. Default false."},
			"case_sensitive": {"type": "boolean", "description": "If true, the match is case sensitive. Default false."},
			"max_results":    {"type": "integer", "description": "Maximum matching lines to return. Default 60."}
		},
		["query"],
		buscarEnArchivos
	)
	chat.registrarHerramienta(
		"Find files",
		"Finds files by name pattern, e.g. \"*.gd\", \"**/*.tscn\" or \"player*\". Returns res:// paths. Use it to locate files before reading them.",
		{
			"pattern":     {"type": "string", "description": "Glob pattern: * matches inside one path segment, ** spans folders. e.g. **/ui/*.gd"},
			"path":        {"type": "string", "description": "Optional directory to search under. Defaults to the whole project."},
			"max_results": {"type": "integer", "description": "Maximum paths to return. Default 200."}
		},
		["pattern"],
		buscarArchivos
	)
	chat.registrarHerramienta(
		"Create folder",
		"Creates a new directory (and any missing parent directories) at the specified res:// path.",
		{
			"path": {"type": "string", "description": "Directory path to create, e.g. res://assets/textures"}
		},
		["path"],
		crearCarpeta
	)
	chat.registrarHerramienta(
		"Delete file",
		"Permanently deletes a file from the project. For directories use \"Delete folder\". Cannot be undone.",
		{
			"path": {"type": "string", "description": "Path to the file to delete, e.g. res://scripts/OldScript.gd"}
		},
		["path"],
		eliminarArchivo
	)
	chat.registrarHerramienta(
		"Delete folder",
		"Recursively deletes a directory and all its contents. Cannot be undone.",
		{
			"path": {"type": "string", "description": "Path to the directory to delete, e.g. res://old_assets"}
		},
		["path"],
		eliminarCarpeta
	)
	chat.registrarHerramienta(
		"Move file",
		"Moves or renames a file within the project filesystem. Works across directories.",
		{
			"from": {"type": "string", "description": "Current file path, e.g. res://old/Script.gd"},
			"to":   {"type": "string", "description": "New file path, e.g. res://new/Script.gd"}
		},
		["from", "to"],
		moverArchivo
	)
	chat.registrarHerramienta(
		"File exists",
		"Checks whether a file or directory exists at the given path.",
		{
			"path": {"type": "string", "description": "Path to check, e.g. res://scripts/Player.gd"}
		},
		["path"],
		existeArchivo
	)
	chat.registrarHerramienta(
		"Create script",
		"Creates a new .gd script file. Validates GDScript syntax IN MEMORY before writing — never opens the editor, never leaves temp files. If validation fails returns the exact error message and the script is NOT written. Always use this instead of \"Create or update file\" for .gd files.",
		{
			"path":    {"type": "string", "description": "Path for the new script, e.g. res://scripts/Player.gd"},
			"content": {"type": "string", "description": "Full GDScript source code to write"}
		},
		["path", "content"],
		crearScript
	)
	chat.registrarHerramienta(
		"Update script",
		"Overwrites an existing .gd script file. Validates GDScript syntax IN MEMORY before writing — never opens the editor, never leaves temp files. If the script is currently open in the editor it will be live-refreshed so the user sees the new content immediately. If validation fails returns the exact error and the file is NOT modified.",
		{
			"path":    {"type": "string", "description": "Path to the existing script, e.g. res://scripts/Player.gd"},
			"content": {"type": "string", "description": "New full GDScript source code"}
		},
		["path", "content"],
		actualizarScript
	)
	chat.registrarHerramienta(
		"Check script errors",
		"Parses and compiles a .gd script file and returns the exact error message if invalid. Returns status ok if no errors. Does NOT open the editor.",
		{
			"path": {"type": "string", "description": "Path to the .gd script file to check"}
		},
		["path"],
		verificarErroresScript
	)
	chat.registrarHerramienta(
		"Replace in script",
		"Finds and replaces text inside a .gd script. Validates syntax after the replacement and only writes if valid. Live-refreshes the editor if the script is open. Use this for surgical edits without rewriting the whole file.",
		{
			"path":    {"type": "string", "description": "Path to the .gd script"},
			"search":  {"type": "string", "description": "The exact text to find (must appear at least once)"},
			"replace": {"type": "string", "description": "The text to put in its place"},
			"replace_all": {"type": "boolean", "description": "If true replaces every occurrence. If false (default) requires the search to be unique and replaces only that one."}
		},
		["path", "search", "replace"],
		reemplazarEnScript
	)
	chat.registrarHerramienta(
		"Insert in script",
		"Inserts new lines into a .gd script at a specific line number (1-indexed). Validates syntax after the insertion and only writes if valid. Live-refreshes the editor if the script is open.",
		{
			"path":    {"type": "string", "description": "Path to the .gd script"},
			"line":    {"type": "integer", "description": "1-indexed line where to insert. The new content is placed BEFORE this line. Use 0 to prepend at the very top, or a number greater than the script length to append at the end."},
			"content": {"type": "string", "description": "Text to insert. Can contain multiple lines separated by \\n."}
		},
		["path", "line", "content"],
		insertarEnScript
	)
	chat.registrarHerramienta(
		"Replace lines in script",
		"Replaces a contiguous range of lines (1-indexed, inclusive) in a .gd script with new content. Validates syntax after the change and only writes if valid. Live-refreshes the editor if the script is open. Ideal for rewriting a single function or block without touching the rest.",
		{
			"path":       {"type": "string", "description": "Path to the .gd script"},
			"start_line": {"type": "integer", "description": "First line to replace (1-indexed, inclusive)"},
			"end_line":   {"type": "integer", "description": "Last line to replace (1-indexed, inclusive). Use the same value as start_line to replace a single line."},
			"content":    {"type": "string", "description": "New text that replaces the selected lines. Can be empty to delete the range."}
		},
		["path", "start_line", "end_line", "content"],
		reemplazarLineasEnScript
	)
	chat.registrarHerramienta(
		"Append to script",
		"Appends new content at the end of a .gd script. Validates syntax after the append and only writes if valid. Live-refreshes the editor if the script is open.",
		{
			"path":    {"type": "string", "description": "Path to the .gd script"},
			"content": {"type": "string", "description": "Text to append at the end of the script"}
		},
		["path", "content"],
		anadirAlScript
	)

# ============================================================
# Helpers internos
# ============================================================

static func _escanerFs() -> void:
	if Engine.is_editor_hint():
		var fs := EditorInterface.get_resource_filesystem()
		if fs:
			fs.scan()

static func _listarRecursivo(path: String, filtro: String, resultado: Array) -> void:
	var dir := DirAccess.open(path)
	if dir == null:
		return
	dir.list_dir_begin()
	var nombre := dir.get_next()
	while nombre != "":
		if nombre != "." and nombre != "..":
			var full := path.path_join(nombre)
			if dir.current_is_dir():
				_listarRecursivo(full, filtro, resultado)
			else:
				if filtro == "" or full.ends_with(filtro):
					resultado.append(full)
		nombre = dir.get_next()
	dir.list_dir_end()

static func _eliminarDirectorioRecursivo(dirPath: String) -> Error:
	var dir := DirAccess.open(dirPath)
	if dir == null:
		return ERR_CANT_OPEN
	dir.list_dir_begin()
	var nombre := dir.get_next()
	while nombre != "":
		if nombre != "." and nombre != "..":
			var full := dirPath.path_join(nombre)
			if dir.current_is_dir():
				var err := _eliminarDirectorioRecursivo(full)
				if err != OK:
					return err
			else:
				var err := DirAccess.remove_absolute(full)
				if err != OK:
					return err
		nombre = dir.get_next()
	dir.list_dir_end()
	return DirAccess.remove_absolute(dirPath)

# ============================================================
# Herramientas de archivos genéricos
# ============================================================

static func crearOActualizarArchivo(args: Dictionary) -> Dictionary:
	var resolucion := Rutas.proyecto(args.get("path", ""))
	if not bool(resolucion["ok"]):
		return {"success": false, "output": str(resolucion["motivo"])}
	var path: String = str(resolucion["ruta"])
	var content := args.get("content", "")
	if path == "":
		return {"success": false, "output": "Missing required argument: path."}
	if path.ends_with(".gd"):
		return {"success": false, "output": "Use \"Create script\" or \"Update script\" for .gd files — they validate syntax and return exact error details."}
	var copia: String = CopiasSeguridad.respaldar(path, "file overwrite")
	var archivo := FileAccess.open(path, FileAccess.WRITE)
	if archivo == null:
		return {"success": false, "output": "Could not write to: %s (error %d)" % [path, FileAccess.get_open_error()]}
	archivo.store_string(content)
	archivo.close()
	_escanerFs()
	return {"success": true, "output": "File written: %s (%d bytes)%s" % [path, content.length(), CopiasSeguridad.sufijoAviso(copia)]}

static func leerArchivo(args: Dictionary) -> Dictionary:
	var resolucion := Rutas.proyecto(args.get("path", ""))
	if not bool(resolucion["ok"]):
		return {"success": false, "output": str(resolucion["motivo"])}
	var path: String = str(resolucion["ruta"])
	if path == "":
		return {"success": false, "output": "Missing required argument: path."}
	if not FileAccess.file_exists(path):
		return {"success": false, "output": "File not found: " + path}
	var archivo := FileAccess.open(path, FileAccess.READ)
	if archivo == null:
		return {"success": false, "output": "Could not read file: " + path}
	var contenido := archivo.get_as_text()
	archivo.close()
	return {"success": true, "output": contenido}

static func buscarYReemplazarEnArchivo(args: Dictionary) -> Dictionary:
	var resolucion := Rutas.proyecto(args.get("path", ""))
	if not bool(resolucion["ok"]):
		return {"success": false, "output": str(resolucion["motivo"])}
	var path: String = str(resolucion["ruta"])
	var buscar := args.get("search", "")
	var reemplazar := args.get("replace", "")
	var replace_all: bool = bool(args.get("replace_all", false))
	if path == "" or buscar == "":
		return {"success": false, "output": "Missing required arguments: path or search."}
	if path.ends_with(".gd"):
		return {"success": false, "output": "Use \"Replace in script\" for .gd files — it validates syntax and returns exact error details."}
	if not FileAccess.file_exists(path):
		return {"success": false, "output": "File not found: " + path}
	var fIn := FileAccess.open(path, FileAccess.READ)
	if fIn == null:
		return {"success": false, "output": "Could not read file: " + path}
	var contenido := fIn.get_as_text()
	fIn.close()
	if not contenido.contains(buscar):
		return {"success": false, "output": "Search string not found in: " + path}
	var count := contenido.count(buscar)
	# Igual que en los scripts: si el texto no es unico, el modelo casi siempre se
	# equivoco de sitio. Se para y se le dice como arreglarlo.
	if not replace_all and count > 1:
		return {"success": false, "output": "Search string is not unique (found %d occurrences). Set replace_all=true or provide a more specific search string." % count}
	var nuevo: String
	if replace_all:
		nuevo = contenido.replace(buscar, reemplazar)
	else:
		var idx := contenido.find(buscar)
		nuevo = contenido.substr(0, idx) + reemplazar + contenido.substr(idx + buscar.length())
	var copia: String = CopiasSeguridad.respaldar(path, "search and replace")
	var fOut := FileAccess.open(path, FileAccess.WRITE)
	if fOut == null:
		return {"success": false, "output": "Could not write to file: " + path}
	fOut.store_string(nuevo)
	fOut.close()
	_escanerFs()
	return {"success": true, "output": "Replaced %d occurrence(s) in: %s%s" % [(count if replace_all else 1), path, CopiasSeguridad.sufijoAviso(copia)]}

static func listarArchivos(args: Dictionary) -> Dictionary:
	var resolucion := Rutas.proyecto(args.get("directory", "res://"), "directory")
	if not bool(resolucion["ok"]):
		return {"success": false, "output": str(resolucion["motivo"])}
	var directorio: String = str(resolucion["ruta"])
	var dir := DirAccess.open(directorio)
	if dir == null:
		return {"success": false, "output": "Could not open directory: " + directorio}
	var entradas: Array = []
	dir.list_dir_begin()
	var nombre := dir.get_next()
	while nombre != "":
		if nombre != "." and nombre != "..":
			var tipo := "[DIR] " if dir.current_is_dir() else "[FILE]"
			entradas.append("%s %s" % [tipo, directorio.path_join(nombre)])
		nombre = dir.get_next()
	dir.list_dir_end()
	if entradas.is_empty():
		return {"success": true, "output": "Empty directory: " + directorio}
	return {"success": true, "output": "\n".join(entradas)}

static func listarArchivosRecursivo(args: Dictionary) -> Dictionary:
	var resolucion := Rutas.proyecto(args.get("directory", "res://"), "directory")
	if not bool(resolucion["ok"]):
		return {"success": false, "output": str(resolucion["motivo"])}
	var directorio: String = str(resolucion["ruta"])
	var filtro := args.get("extension_filter", "")
	var resultado: Array = []
	_listarRecursivo(directorio, filtro, resultado)
	if resultado.is_empty():
		return {"success": true, "output": "No files found in: " + directorio}
	return {"success": true, "output": "\n".join(resultado)}

static func crearCarpeta(args: Dictionary) -> Dictionary:
	var resolucion := Rutas.proyecto(args.get("path", ""))
	if not bool(resolucion["ok"]):
		return {"success": false, "output": str(resolucion["motivo"])}
	var path: String = str(resolucion["ruta"])
	if path == "":
		return {"success": false, "output": "Missing required argument: path."}
	var global := ProjectSettings.globalize_path(path)
	var err := DirAccess.make_dir_recursive_absolute(global)
	if err != OK:
		return {"success": false, "output": "Could not create directory: %s (error %d)" % [path, err]}
	_escanerFs()
	return {"success": true, "output": "Directory created: " + path}

static func eliminarArchivo(args: Dictionary) -> Dictionary:
	var resolucion := Rutas.proyecto(args.get("path", ""))
	if not bool(resolucion["ok"]):
		return {"success": false, "output": str(resolucion["motivo"])}
	var path: String = str(resolucion["ruta"])
	if path == "":
		return {"success": false, "output": "Missing required argument: path."}
	var global := ProjectSettings.globalize_path(path)
	if not FileAccess.file_exists(path):
		return {"success": false, "output": "Path not found or is a directory: " + path}
	var copia: String = CopiasSeguridad.respaldar(path, "delete")
	var err := DirAccess.remove_absolute(global)
	if err != OK:
		return {"success": false, "output": "Could not delete: %s (error %d)" % [path, err]}
	_escanerFs()
	return {"success": true, "output": "Deleted: %s%s" % [path, CopiasSeguridad.sufijoAviso(copia)]}

static func eliminarCarpeta(args: Dictionary) -> Dictionary:
	var resolucion := Rutas.proyecto(args.get("path", ""))
	if not bool(resolucion["ok"]):
		return {"success": false, "output": str(resolucion["motivo"])}
	var path: String = str(resolucion["ruta"])
	if path == "":
		return {"success": false, "output": "Missing required argument: path."}
	var global := ProjectSettings.globalize_path(path)
	if not DirAccess.dir_exists_absolute(global):
		return {"success": false, "output": "Directory not found: " + path}
	# Borrar una carpeta entera se lleva por delante cada archivo de dentro, asi
	# que se copia el arbol completo antes de empezar.
	var copia: Dictionary = CopiasSeguridad.respaldarArbol(path, "folder delete")
	var err := _eliminarDirectorioRecursivo(global)
	if err != OK:
		return {"success": false, "output": "Could not delete directory: %s (error %d)" % [path, err]}
	_escanerFs()
	return {"success": true, "output": "Deleted directory: %s (backed up %d file(s), skipped %d)" % [path, copia["copiados"], copia["omitidos"]]}

static func moverArchivo(args: Dictionary) -> Dictionary:
	var rutaDesde := Rutas.proyecto(args.get("from", ""), "from")
	if not bool(rutaDesde["ok"]):
		return {"success": false, "output": str(rutaDesde["motivo"])}
	var rutaHasta := Rutas.proyecto(args.get("to", ""), "to")
	if not bool(rutaHasta["ok"]):
		return {"success": false, "output": str(rutaHasta["motivo"])}
	var desde: String = str(rutaDesde["ruta"])
	var hasta: String = str(rutaHasta["ruta"])
	if not FileAccess.file_exists(desde):
		return {"success": false, "output": "Source file not found: " + desde}
	var fIn := FileAccess.open(desde, FileAccess.READ)
	if fIn == null:
		return {"success": false, "output": "Could not read source: " + desde}
	var datos := fIn.get_buffer(fIn.get_length())
	fIn.close()
	# El origen desaparece y el destino puede tener contenido previo: los dos se
	# copian antes de tocar nada.
	CopiasSeguridad.respaldar(desde, "move from")
	var copiaDestino: String = CopiasSeguridad.respaldar(hasta, "move over")
	var fOut := FileAccess.open(hasta, FileAccess.WRITE)
	if fOut == null:
		return {"success": false, "output": "Could not write destination: " + hasta}
	fOut.store_buffer(datos)
	fOut.close()
	DirAccess.remove_absolute(ProjectSettings.globalize_path(desde))
	_escanerFs()
	return {"success": true, "output": "Moved: %s → %s%s" % [desde, hasta, CopiasSeguridad.sufijoAviso(copiaDestino)]}

static func existeArchivo(args: Dictionary) -> Dictionary:
	var resolucion := Rutas.proyecto(args.get("path", ""))
	if not bool(resolucion["ok"]):
		return {"success": false, "output": str(resolucion["motivo"])}
	var path: String = str(resolucion["ruta"])
	if path == "":
		return {"success": false, "output": "Missing required argument: path."}
	var global := ProjectSettings.globalize_path(path)
	if FileAccess.file_exists(path):
		return {"success": true, "output": "EXISTS (file): " + path}
	elif DirAccess.dir_exists_absolute(global):
		return {"success": true, "output": "EXISTS (directory): " + path}
	return {"success": true, "output": "NOT FOUND: " + path}

# ============================================================
# Búsqueda en el proyecto
# ============================================================

# Carpetas que no se rastrean: son cache del motor o control de versiones, y
# buscarlas devuelve ruido y cuesta tiempo.
const CARPETAS_IGNORADAS := [".godot", ".git"]
# Un archivo mas grande que esto no se lee: casi siempre es un binario con
# extension enganosa.
const BYTES_MAXIMOS_ARCHIVO := 2000000
const ARCHIVOS_MAXIMOS_RASTREADOS := 20000
const RESULTADOS_BUSQUEDA := 60
const RESULTADOS_ARCHIVOS := 200
const EXTENSIONES_BINARIAS := [
	"png", "jpg", "jpeg", "gif", "webp", "bmp", "tga", "dds", "ktx", "exr", "hdr",
	"ttf", "otf", "woff", "woff2", "fnt",
	"mp3", "ogg", "wav", "mp4", "webm", "ogv",
	"pck", "zip", "gz", "7z", "exe", "dll", "so", "dylib", "bin", "res", "scn",
	"ico", "icns", "blend", "glb", "fbx", "obj",
]

static func buscarEnArchivos(args: Dictionary) -> Dictionary:
	var consulta := str(args.get("query", ""))
	if consulta == "":
		return {"success": false, "output": "Missing required argument: query."}
	# Buscar y Find files pueden barrer el proyecto entero: sin path, la raiz.
	var raizPedida := str(args.get("path", "")).strip_edges()
	var resolucion := Rutas.proyecto(raizPedida if raizPedida != "" else "res://")
	if not bool(resolucion["ok"]):
		return {"success": false, "output": str(resolucion["motivo"])}
	var raiz: String = str(resolucion["ruta"])
	var incluir := str(args.get("include", ""))
	var sensible := bool(args.get("case_sensitive", false))
	var maxResultados := int(args.get("max_results", RESULTADOS_BUSQUEDA))
	if maxResultados <= 0:
		maxResultados = RESULTADOS_BUSQUEDA
	var re: RegEx = null
	if bool(args.get("regex", false)):
		re = RegEx.new()
		var patron := consulta if sensible else "(?i)" + consulta
		if re.compile(patron) != OK:
			return {"success": false, "output": "Invalid regular expression: " + consulta}
	var archivos := _archivosBajo(raiz)
	if archivos.is_empty():
		return {"success": false, "output": "Nothing to search in: " + raiz}
	var consultaCmp := consulta if sensible else consulta.to_lower()
	var coincidencias: Array = []
	var revisados := 0
	var conCoincidencia := 0
	var truncado := false
	for ruta in archivos:
		if revisados >= ARCHIVOS_MAXIMOS_RASTREADOS:
			break
		if not _esArchivoDeTexto(ruta, incluir):
			continue
		var texto := _leerTextoSiPesaPoco(ruta)
		if texto == "":
			continue
		revisados += 1
		var hubo := false
		var lineas := texto.split("\n")
		for i in lineas.size():
			var linea := lineas[i]
			var hay := false
			if re != null:
				hay = re.search(linea) != null
			else:
				hay = (linea if sensible else linea.to_lower()).contains(consultaCmp)
			if not hay:
				continue
			hubo = true
			if coincidencias.size() >= maxResultados:
				truncado = true
				break
			coincidencias.append("%s:%d: %s" % [ruta, i + 1, linea.strip_edges()])
		if hubo:
			conCoincidencia += 1
		if truncado:
			break
	if coincidencias.is_empty():
		return {"success": true, "output": "No matches for \"%s\" (%d file(s) searched)." % [consulta, revisados]}
	var cabecera := "%d match(es) in %d file(s) of %d searched" % [coincidencias.size(), conCoincidencia, revisados]
	if truncado:
		cabecera += " - stopped at the limit, narrow the search or use include"
	return {"success": true, "output": cabecera + "\n" + "\n".join(coincidencias)}

static func buscarArchivos(args: Dictionary) -> Dictionary:
	var patron := str(args.get("pattern", ""))
	if patron == "":
		return {"success": false, "output": "Missing required argument: pattern."}
	# Buscar y Find files pueden barrer el proyecto entero: sin path, la raiz.
	var raizPedida := str(args.get("path", "")).strip_edges()
	var resolucion := Rutas.proyecto(raizPedida if raizPedida != "" else "res://")
	if not bool(resolucion["ok"]):
		return {"success": false, "output": str(resolucion["motivo"])}
	var raiz: String = str(resolucion["ruta"])
	var maxResultados := int(args.get("max_results", RESULTADOS_ARCHIVOS))
	if maxResultados <= 0:
		maxResultados = RESULTADOS_ARCHIVOS
	var re := RegEx.new()
	if re.compile(_globARegex(patron)) != OK:
		return {"success": false, "output": "Invalid pattern: " + patron}
	var archivos := _archivosBajo(raiz)
	if archivos.is_empty():
		return {"success": false, "output": "Nothing to search in: " + raiz}
	var encontrados: Array = []
	var truncado := false
	for ruta in archivos:
		var completa := str(ruta)
		var relativa: String = completa.trim_prefix(raiz if raiz.ends_with("/") else raiz + "/")
		if re.search(completa) == null and re.search(relativa) == null and re.search(completa.get_file()) == null:
			continue
		if encontrados.size() >= maxResultados:
			truncado = true
			break
		encontrados.append(completa)
	if encontrados.is_empty():
		return {"success": true, "output": "No files match \"%s\" in %s" % [patron, raiz]}
	var cabecera := "%d file(s)" % encontrados.size()
	if truncado:
		cabecera += " (stopped at the limit)"
	return {"success": true, "output": cabecera + ":\n" + "\n".join(encontrados)}

## Todos los archivos bajo una ruta, recursivo y sin las carpetas ignoradas.
static func _archivosBajo(raiz: String) -> Array:
	var salida: Array = []
	if FileAccess.file_exists(raiz):
		salida.append(raiz)
		return salida
	var global := ProjectSettings.globalize_path(raiz)
	if not DirAccess.dir_exists_absolute(global):
		return salida
	_acumularArchivos(raiz, salida)
	return salida

static func _acumularArchivos(dir: String, salida: Array) -> void:
	if salida.size() >= ARCHIVOS_MAXIMOS_RASTREADOS:
		return
	var d := DirAccess.open(dir)
	if d == null:
		return
	d.list_dir_begin()
	var nombre := d.get_next()
	while nombre != "":
		if nombre != "." and nombre != "..":
			var hijo := dir.path_join(nombre)
			if d.current_is_dir():
				if not CARPETAS_IGNORADAS.has(nombre) and not nombre.begins_with("."):
					_acumularArchivos(hijo, salida)
			else:
				salida.append(hijo)
		nombre = d.get_next()
	d.list_dir_end()

## Texto legible: ni binario por extension ni filtrado por el argumento include.
## El filtro acepta extensiones ("gd", ".tscn") o trozos de ruta ("res://scripts/").
static func _esArchivoDeTexto(ruta: String, incluir: String) -> bool:
	var extension := ruta.get_extension().to_lower()
	if EXTENSIONES_BINARIAS.has(extension):
		return false
	var filtro := incluir.strip_edges()
	if filtro == "":
		return true
	for parte in filtro.split(","):
		var trozo := parte.strip_edges().lstrip("*").lstrip(".")
		if trozo == "":
			continue
		if trozo.contains("/"):
			if ruta.contains(trozo):
				return true
		elif ruta.get_extension().to_lower() == trozo.lstrip(".").to_lower():
			return true
	return false

static func _leerTextoSiPesaPoco(ruta: String) -> String:
	var f := FileAccess.open(ruta, FileAccess.READ)
	if f == null:
		return ""
	if f.get_length() > BYTES_MAXIMOS_ARCHIVO:
		f.close()
		return ""
	var texto := f.get_as_text()
	f.close()
	return texto

## Glob a expresion regular: ** cruza carpetas, * se queda en su tramo, ? es un
## caracter. Se ancla entera para que "*.gd" no valga como "a.gd.bak".
static func _globARegex(patron: String) -> String:
	var salida := "^"
	var i := 0
	while i < patron.length():
		var c := patron[i]
		if c == "*":
			if i + 1 < patron.length() and patron[i + 1] == "*":
				salida += ".*"
				i += 2
				continue
			salida += "[^/]*"
		elif c == "?":
			salida += "[^/]"
		elif c == "." or c == "(" or c == ")" or c == "[" or c == "]" or c == "{" or c == "}" or c == "+" or c == "^" or c == "$" or c == "|" or c == "\\":
			salida += "\\" + c
		else:
			salida += c
		i += 1
	return salida + "$"

# ============================================================
# Validación de GDScript — SIN editor, SIN archivos temporales
# ============================================================

# Captura de errores del logger del motor durante reload().
# Como GDScript no expone un logger personalizado en runtime, usamos un
# enfoque doble:
#   1. GDScript.new().reload(false) -> da el código de error global.
#   2. Si hay error y estamos en el editor, intentamos pedir al
#      ScriptLanguage interno los detalles vía duck-typing (puede no
#      estar disponible en algunas builds — entonces caemos en un
#      mensaje legible basado en el código).
static func _validarGDScript(content: String, path: String) -> Dictionary:
	var script := GDScript.new()
	script.source_code = content
	var errCode := script.reload(false)
	if errCode == OK:
		return {}

	var sourceLines: PackedStringArray = content.split("\n")
	var errores: Array = _intentarValidatePorLanguage(content, path, sourceLines)

	if errores.is_empty():
		errores.append({
			"line": -1,
			"column": -1,
			"message": _mensajeCodigoError(errCode, content),
			"source_line": ""
		})

	return {"error_count": errores.size(), "errors": errores}

# Intenta llamar al método validate() del ScriptLanguage de GDScript.
# Este método existe en C++ pero según la build puede no estar bindeado a
# GDScript. Si no está, devolvemos array vacío y se usa el fallback.
static func _intentarValidatePorLanguage(content: String, path: String, sourceLines: PackedStringArray) -> Array:
	var resultado: Array = []
	var lang_count := Engine.get_script_language_count()
	for i in lang_count:
		var lang := Engine.get_script_language(i)
		if lang == null:
			continue
		if lang.get_name() != "GDScript":
			continue
		if not lang.has_method("validate"):
			return resultado
		var res = lang.call("validate", content, path, false, true, false, false)
		if typeof(res) != TYPE_DICTIONARY:
			return resultado
		if res.get("valid", true):
			return resultado
		var errs = res.get("errors", [])
		for e in errs:
			var line: int = int(e.get("line", -1))
			var col: int = int(e.get("column", -1))
			var msg := str(e.get("message", "Unknown error"))
			var lineTxt := ""
			var lineIdx := line - 1
			if lineIdx >= 0 and lineIdx < sourceLines.size():
				lineTxt = sourceLines[lineIdx].strip_edges()
			resultado.append({
				"line": line,
				"column": col,
				"message": msg,
				"source_line": lineTxt
			})
		return resultado
	return resultado

# Convierte un código de error de GDScript.reload() en un mensaje legible
# y, cuando es posible, añade pistas sobre la línea problemática.
static func _mensajeCodigoError(errCode: int, content: String) -> String:
	var base: String
	match errCode:
		ERR_PARSE_ERROR:
			base = "Parse error: invalid GDScript syntax."
		ERR_COMPILATION_FAILED:
			base = "Compilation failed: the script has semantic errors (e.g. references to non-existent identifiers, wrong types, invalid inheritance, missing class members)."
		ERR_INVALID_DATA:
			base = "Invalid script data."
		ERR_INVALID_DECLARATION:
			base = "Invalid declaration in script."
		ERR_FILE_CORRUPT:
			base = "Script file is corrupt."
		_:
			base = "Script error (code %d): the script could not be parsed or compiled." % errCode
	var pistas := _detectarPistasSintacticas(content)
	if pistas != "":
		base += " Hints: " + pistas
	return base

# Heurística simple: detecta errores comunes y devuelve la primera pista
# encontrada con número de línea.
static func _detectarPistasSintacticas(content: String) -> String:
	var lineas: PackedStringArray = content.split("\n")
	var pistas: Array = []

	# Brackets desbalanceados (globales)
	var balancePar := 0
	var balanceCor := 0
	var balanceLla := 0
	var enString := false
	var charString := ""
	for i in content.length():
		var c := content[i]
		if enString:
			if c == charString and (i == 0 or content[i - 1] != "\\"):
				enString = false
			continue
		if c == "\"" or c == "'":
			enString = true
			charString = c
			continue
		match c:
			"(": balancePar += 1
			")": balancePar -= 1
			"[": balanceCor += 1
			"]": balanceCor -= 1
			"{": balanceLla += 1
			"}": balanceLla -= 1
	if balancePar != 0:
		pistas.append("unbalanced parentheses (%+d)" % balancePar)
	if balanceCor != 0:
		pistas.append("unbalanced brackets (%+d)" % balanceCor)
	if balanceLla != 0:
		pistas.append("unbalanced braces (%+d)" % balanceLla)

	# Mezcla de tabs y espacios para indentar
	var conTab := false
	var conEsp := false
	for l in lineas:
		if l.length() == 0:
			continue
		var c0 := l[0]
		if c0 == "\t":
			conTab = true
		elif c0 == " ":
			conEsp = true
	if conTab and conEsp:
		pistas.append("mixed tabs and spaces in indentation")

	# Falta de ':' al final de definiciones de bloque
	var rePalabras := RegEx.new()
	rePalabras.compile("^\\s*(func|if|elif|else|for|while|class|match|enum)\\b.*$")
	for idx in lineas.size():
		var ln := lineas[idx]
		var stripped := ln.strip_edges()
		if stripped == "" or stripped.begins_with("#"):
			continue
		if rePalabras.search(ln) != null:
			# Eliminamos comentarios al final
			var sinComentario := ln
			var hashIdx := ln.find("#")
			if hashIdx >= 0:
				sinComentario = ln.substr(0, hashIdx)
			sinComentario = sinComentario.strip_edges()
			if sinComentario != "" and not sinComentario.ends_with(":") and not sinComentario.ends_with("\\"):
				if not (stripped.begins_with("else") and stripped.length() == 4):
					pistas.append("line %d may be missing ':' at the end" % (idx + 1))
					break

	# extend en vez de extends
	for idx in lineas.size():
		var ln2 := lineas[idx].strip_edges()
		if ln2.begins_with("extend ") and not ln2.begins_with("extends "):
			pistas.append("line %d: 'extend' should be 'extends'" % (idx + 1))
			break

	if pistas.is_empty():
		return ""
	return "; ".join(pistas)

# Si el script está abierto en el editor de scripts, refresca su
# contenido en vivo sin pedir confirmación al usuario y sin cerrar la
# pestaña.
# Publica porque tambien la llama CopiasSeguridad al restaurar una copia: el
# editor no se entera solo de que el archivo cambio por debajo, y sin esto sigue
# mostrando (y guardando) el contenido viejo.
static func refrescarScriptSiAbierto(path: String) -> void:
	if not Engine.is_editor_hint():
		return
	var fs := EditorInterface.get_resource_filesystem()
	if fs:
		fs.update_file(path)
	var script_editor := EditorInterface.get_script_editor()
	if script_editor == null:
		return
	var open_scripts: Array = script_editor.get_open_scripts()
	for s in open_scripts:
		if s == null:
			continue
		if s.resource_path == path:
			s.reload(true)
			break

# Núcleo: valida el contenido en memoria y, sólo si es válido, escribe a
# disco. No abre el editor, no crea archivos temporales.
static func _guardarScriptValidado(path: String, content: String) -> Dictionary:
	var errInfo := _validarGDScript(content, path)
	if not errInfo.is_empty():
		return {"success": false, "output": JSON.stringify({
			"path": path,
			"saved": false,
			"status": "error",
			"error_count": errInfo["error_count"],
			"errors": errInfo["errors"]
		})}
	var copia: String = CopiasSeguridad.respaldar(path, "script overwrite")
	var archivo := FileAccess.open(path, FileAccess.WRITE)
	if archivo == null:
		var openErr := FileAccess.get_open_error()
		return {"success": false, "output": JSON.stringify({
			"path": path,
			"saved": false,
			"status": "io_error",
			"error_count": 1,
			"errors": [{
				"line": -1,
				"column": -1,
				"message": "Could not write file (FileAccess error code %d). Check that the path is valid and writable." % openErr,
				"source_line": ""
			}]
		})}
	archivo.store_string(content)
	archivo.close()
	_escanerFs()
	refrescarScriptSiAbierto(path)
	return {"success": true, "output": JSON.stringify({
		"path": path,
		"saved": true,
		"status": "ok",
		"bytes": content.length(),
		"backup": copia,
	})}

# ============================================================
# Herramientas de scripts
# ============================================================

static func crearScript(args: Dictionary) -> Dictionary:
	var resolucion := Rutas.proyecto(args.get("path", ""))
	if not bool(resolucion["ok"]):
		return {"success": false, "output": str(resolucion["motivo"])}
	var path: String = str(resolucion["ruta"])
	var content := args.get("content", "")
	if path == "":
		return {"success": false, "output": "Missing required argument: path."}
	if not path.ends_with(".gd"):
		return {"success": false, "output": "\"Create script\" only works with .gd files."}
	if FileAccess.file_exists(path):
		return {"success": false, "output": "Script already exists: " + path + ". Use \"Update script\" to overwrite it."}
	return _guardarScriptValidado(path, content)

static func actualizarScript(args: Dictionary) -> Dictionary:
	var resolucion := Rutas.proyecto(args.get("path", ""))
	if not bool(resolucion["ok"]):
		return {"success": false, "output": str(resolucion["motivo"])}
	var path: String = str(resolucion["ruta"])
	var content := args.get("content", "")
	if path == "":
		return {"success": false, "output": "Missing required argument: path."}
	if not path.ends_with(".gd"):
		return {"success": false, "output": "\"Update script\" only works with .gd files."}
	if not FileAccess.file_exists(path):
		return {"success": false, "output": "Script not found: " + path + ". Use \"Create script\" to create it first."}
	return _guardarScriptValidado(path, content)

static func verificarErroresScript(args: Dictionary) -> Dictionary:
	var resolucion := Rutas.proyecto(args.get("path", ""))
	if not bool(resolucion["ok"]):
		return {"success": false, "output": str(resolucion["motivo"])}
	var path: String = str(resolucion["ruta"])
	if path == "":
		return {"success": false, "output": "Missing required argument: path."}
	if not FileAccess.file_exists(path):
		return {"success": false, "output": "File not found: " + path}
	var f := FileAccess.open(path, FileAccess.READ)
	if f == null:
		return {"success": false, "output": "Could not read file: " + path}
	var contenido := f.get_as_text()
	f.close()
	var errInfo := _validarGDScript(contenido, path)
	if errInfo.is_empty():
		return {"success": true, "output": JSON.stringify({
			"path": path,
			"status": "ok",
			"error_count": 0,
			"errors": []
		})}
	return {"success": false, "output": JSON.stringify({
		"path": path,
		"status": "error",
		"error_count": errInfo["error_count"],
		"errors": errInfo["errors"]
	})}

static func reemplazarEnScript(args: Dictionary) -> Dictionary:
	var resolucion := Rutas.proyecto(args.get("path", ""))
	if not bool(resolucion["ok"]):
		return {"success": false, "output": str(resolucion["motivo"])}
	var path: String = str(resolucion["ruta"])
	var buscar := args.get("search", "")
	var reemplazar := args.get("replace", "")
	var replace_all: bool = bool(args.get("replace_all", false))
	if path == "" or buscar == "":
		return {"success": false, "output": "Missing required arguments: path or search."}
	if not path.ends_with(".gd"):
		return {"success": false, "output": "\"Replace in script\" only works with .gd files. Use \"Search replace in file\" for other types."}
	if not FileAccess.file_exists(path):
		return {"success": false, "output": "Script not found: " + path}
	var fIn := FileAccess.open(path, FileAccess.READ)
	if fIn == null:
		return {"success": false, "output": "Could not read script: " + path}
	var contenido := fIn.get_as_text()
	fIn.close()
	if not contenido.contains(buscar):
		return {"success": false, "output": "Search string not found in script: " + path}
	var count := contenido.count(buscar)
	if not replace_all and count > 1:
		return {"success": false, "output": "Search string is not unique (found %d occurrences). Set replace_all=true or provide a more specific search string." % count}
	var nuevo: String
	if replace_all:
		nuevo = contenido.replace(buscar, reemplazar)
	else:
		var idx := contenido.find(buscar)
		nuevo = contenido.substr(0, idx) + reemplazar + contenido.substr(idx + buscar.length())
	var resultado := _guardarScriptValidado(path, nuevo)
	if resultado.get("success", false):
		var data: Dictionary = JSON.parse_string(resultado["output"])
		data["replacements"] = (count if replace_all else 1)
		resultado["output"] = JSON.stringify(data)
	return resultado

static func insertarEnScript(args: Dictionary) -> Dictionary:
	var resolucion := Rutas.proyecto(args.get("path", ""))
	if not bool(resolucion["ok"]):
		return {"success": false, "output": str(resolucion["motivo"])}
	var path: String = str(resolucion["ruta"])
	var line: int = int(args.get("line", -1))
	var content := args.get("content", "")
	if path == "":
		return {"success": false, "output": "Missing required argument: path."}
	if not path.ends_with(".gd"):
		return {"success": false, "output": "\"Insert in script\" only works with .gd files."}
	if not FileAccess.file_exists(path):
		return {"success": false, "output": "Script not found: " + path}
	var fIn := FileAccess.open(path, FileAccess.READ)
	if fIn == null:
		return {"success": false, "output": "Could not read script: " + path}
	var contenido := fIn.get_as_text()
	fIn.close()
	var lineas: Array = Array(contenido.split("\n"))
	var nuevasLineas: Array = Array(content.split("\n"))
	if line <= 0:
		for i in range(nuevasLineas.size() - 1, -1, -1):
			lineas.insert(0, nuevasLineas[i])
	elif line > lineas.size():
		for nl in nuevasLineas:
			lineas.append(nl)
	else:
		var idx := line - 1
		for i in range(nuevasLineas.size() - 1, -1, -1):
			lineas.insert(idx, nuevasLineas[i])
	var nuevo := "\n".join(lineas)
	return _guardarScriptValidado(path, nuevo)

static func reemplazarLineasEnScript(args: Dictionary) -> Dictionary:
	var resolucion := Rutas.proyecto(args.get("path", ""))
	if not bool(resolucion["ok"]):
		return {"success": false, "output": str(resolucion["motivo"])}
	var path: String = str(resolucion["ruta"])
	var startLine: int = int(args.get("start_line", 0))
	var endLine: int = int(args.get("end_line", 0))
	var content := args.get("content", "")
	if path == "":
		return {"success": false, "output": "Missing required argument: path."}
	if not path.ends_with(".gd"):
		return {"success": false, "output": "\"Replace lines in script\" only works with .gd files."}
	if startLine <= 0 or endLine < startLine:
		return {"success": false, "output": "Invalid range: start_line must be >= 1 and end_line >= start_line."}
	if not FileAccess.file_exists(path):
		return {"success": false, "output": "Script not found: " + path}
	var fIn := FileAccess.open(path, FileAccess.READ)
	if fIn == null:
		return {"success": false, "output": "Could not read script: " + path}
	var contenido := fIn.get_as_text()
	fIn.close()
	var lineas: Array = Array(contenido.split("\n"))
	var startIdx := startLine - 1
	var endIdx := endLine - 1
	if startIdx >= lineas.size():
		return {"success": false, "output": "start_line %d is out of range (script has %d lines)." % [startLine, lineas.size()]}
	if endIdx >= lineas.size():
		endIdx = lineas.size() - 1
	var nuevasLineas: Array = []
	if content != "":
		nuevasLineas = Array(content.split("\n"))
	var resultado: Array = []
	for i in startIdx:
		resultado.append(lineas[i])
	for nl in nuevasLineas:
		resultado.append(nl)
	for i in range(endIdx + 1, lineas.size()):
		resultado.append(lineas[i])
	return _guardarScriptValidado(path, "\n".join(resultado))

static func anadirAlScript(args: Dictionary) -> Dictionary:
	var resolucion := Rutas.proyecto(args.get("path", ""))
	if not bool(resolucion["ok"]):
		return {"success": false, "output": str(resolucion["motivo"])}
	var path: String = str(resolucion["ruta"])
	var content := args.get("content", "")
	if path == "":
		return {"success": false, "output": "Missing required argument: path."}
	if not path.ends_with(".gd"):
		return {"success": false, "output": "\"Append to script\" only works with .gd files."}
	if not FileAccess.file_exists(path):
		return {"success": false, "output": "Script not found: " + path}
	var fIn := FileAccess.open(path, FileAccess.READ)
	if fIn == null:
		return {"success": false, "output": "Could not read script: " + path}
	var contenido := fIn.get_as_text()
	fIn.close()
	var sep := "" if contenido.ends_with("\n") else "\n"
	var nuevo = contenido + sep + content
	return _guardarScriptValidado(path, nuevo)
