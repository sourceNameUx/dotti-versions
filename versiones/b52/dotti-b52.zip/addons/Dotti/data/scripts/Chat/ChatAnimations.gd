@tool
class_name ChatAnimaciones
extends RefCounted

static func animarEntradaBurbuja(duenio: Node, control: Control, duracionEscala: float, duracionFade: float, retardo: float = 0.0) -> void:
	if not is_instance_valid(control):
		return
	control.modulate = Color(1, 1, 1, 0)
	control.scale = Vector2(0.8, 0.8)
	control.pivot_offset = control.size / 2
	var tween := duenio.create_tween()
	tween.set_parallel(true)
	tween.set_ease(Tween.EASE_OUT)
	tween.set_trans(Tween.TRANS_BACK)
	tween.tween_property(control, "scale", Vector2.ONE, duracionEscala).set_delay(retardo)
	tween.tween_property(control, "modulate", Color(1, 1, 1, 1), duracionFade).set_delay(retardo).set_trans(Tween.TRANS_QUAD)

static func animarEntradaTarjeta(duenio: Node, control: Control, duracionTarjeta: float, duracionFade: float) -> void:
	if not is_instance_valid(control):
		return
	control.modulate = Color(1, 1, 1, 0)
	control.scale = Vector2(0.95, 0.5)
	control.pivot_offset = Vector2(control.size.x / 2, 0)
	var tween := duenio.create_tween()
	tween.set_parallel(true)
	tween.set_ease(Tween.EASE_OUT)
	tween.set_trans(Tween.TRANS_ELASTIC)
	tween.tween_property(control, "scale", Vector2.ONE, duracionTarjeta)
	tween.tween_property(control, "modulate", Color(1, 1, 1, 1), duracionFade).set_trans(Tween.TRANS_QUAD)

static func animarExito(duenio: Node, control: Control) -> void:
	if not is_instance_valid(control):
		return
	var tween := duenio.create_tween()
	tween.set_ease(Tween.EASE_OUT)
	tween.set_trans(Tween.TRANS_ELASTIC)
	tween.tween_property(control, "scale", Vector2(1.02, 1.02), 0.15)
	tween.tween_property(control, "scale", Vector2.ONE, 0.2)

static func animarError(duenio: Node, control: Control) -> void:
	if not is_instance_valid(control):
		return
	var posOriginal := control.position
	var tween := duenio.create_tween()
	tween.tween_property(control, "position:x", posOriginal.x - 5, 0.05)
	tween.tween_property(control, "position:x", posOriginal.x + 5, 0.05)
	tween.tween_property(control, "position:x", posOriginal.x - 3, 0.05)
	tween.tween_property(control, "position:x", posOriginal.x + 3, 0.05)
	tween.tween_property(control, "position:x", posOriginal.x, 0.05)

static func animarExpandirAccordion(duenio: Node, control: Control, duracionAccordion: float) -> void:
	if not is_instance_valid(control):
		return
	control.modulate = Color(1, 1, 1, 0)
	var tween := duenio.create_tween()
	tween.set_ease(Tween.EASE_OUT)
	tween.set_trans(Tween.TRANS_CUBIC)
	tween.tween_property(control, "modulate", Color(1, 1, 1, 1), duracionAccordion * 0.8)
