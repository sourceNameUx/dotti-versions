@tool
class_name Agentes
extends RefCounted

## Agentes del usuario (P9). Un agente es un archivo markdown con frontmatter:
## el nombre es el del archivo, y el cuerpo es su prompt. Se invocan escribiendo
## @nombre en el chat y desde ese momento el agente pone su prompt, su lista de
## herramientas y su modelo en la peticion.
##
## Los agentes propios viven en user://dotti_agentes/ (los escribe Ajustes). En
## res://.dotti/agentes/ pueden vivir agentes del proyecto, que se leen pero no
## se editan: son para compartir con el equipo. Y dentro del propio addon, en
## res://addons/Dotti/data/agentes/, vienen los de fabrica (general y explore):
## se leen como los del proyecto, y al guardarlos desde Ajustes nace
## una copia del usuario, que es la que manda a partir de ahi.
##
## La precedencia va de lo mas cerca del usuario a lo mas lejos: el suyo tapa al
## del proyecto, y el del proyecto tapa al de fabrica.
##
## Formato del archivo (el mismo que usa opencode):
##
##   ---
##   description: Looks for bugs, never touches a file
##   model: deepseek-v4-flash
##   tools: read-only
##   ---
##
##   You are a code reviewer. ...

const RUTA_AGENTES := "user://dotti_agentes/"
## Los del proyecto se comparten con el equipo y no se editan desde aqui.
const RUTA_PROYECTO := "res://.dotti/agentes/"
## Los de fabrica viajan dentro del addon: son los que Dotti trae puestos.
const RUTA_INCLUIDOS := "res://addons/Dotti/data/agentes/"
const EXTENSION := ".md"

## Valores del campo "tools" del frontmatter.
const TODAS := "all"
const NINGUNA := "none"
const SOLO_LECTURA := "read-only"

const LARGO_MAXIMO_NOMBRE := 64
const LARGO_MAXIMO_DESCRIPCION := 1024

## Herramientas que no cambian nada del proyecto. Un agente con "tools:
## read-only" solo ve estas: mira todo lo que quiera y no puede romper nada, que
## es justo lo que se le pide a un agente de exploracion. La lista se comprueba
## contra las herramientas registradas en el banco de pruebas, para que un
## nombre mal escrito aqui no pase en silencio.
const HERRAMIENTAS_SOLO_LECTURA := [
	"Ask user",
	"Update todo list",
	"Load skill",
	"Read file",
	"File exists",
	"List files",
	"List files recursive",
	"Search in files",
	"Find files",
	"Check script errors",
	"Get script errors",
	"View image",
	"Get scene tree",
	"Get node info",
	"Get node properties",
	"Get selected nodes",
	"Validate node path",
	"Get script exported properties",
	"Get available node types",
	"Get class property schema",
	"Get project info",
	"Get project setting",
	"Get current scene",
	"Get open scenes",
	"Get current script info",
	"Get script line",
	"Get script line range",
	"Get script symbols",
	"Get cursor position",
	"Get selected text in script",
	"Get open scripts",
	"Get current editor script",
	"Search in script",
	"Get editor log",
]

## Por que el nombre no sirve, o "" si sirve. El mensaje va tal cual a la
## interfaz, asi que va en ingles como el resto de la documentacion.
static func problemaDeNombre(nombre: String) -> String:
	var limpio := nombre.strip_edges()
	if limpio == "":
		return "The name cannot be empty."
	if limpio.length() > LARGO_MAXIMO_NOMBRE:
		return "The name cannot be longer than %d characters." % LARGO_MAXIMO_NOMBRE
	if limpio != limpio.to_lower():
		return "Use lowercase letters only."
	var regex := RegEx.new()
	regex.compile("^[a-z0-9]+(-[a-z0-9]+)*$")
	if regex.search(limpio) == null:
		return "Use letters, digits and single hyphens, like reviewer or docs-writer."
	return ""

## Todos los agentes que hay, los del usuario, los del proyecto y los de fabrica,
## ordenados por nombre. Si un nombre esta en varios sitios manda el que este mas
## cerca del usuario: se recorren las carpetas en ese orden y el primero que llega
## se queda con el nombre.
static func listar() -> Array:
	var porNombre: Dictionary = {}
	for indice in [0, 1, 2]:
		for ruta in _rutas(indice):
			var agente := cargarArchivo(ruta)
			if not agente.is_empty() and not porNombre.has(str(agente["nombre"])):
				porNombre[str(agente["nombre"])] = agente
	var nombres: Array = porNombre.keys()
	nombres.sort()
	var lista: Array = []
	for nombre in nombres:
		lista.append(porNombre[nombre])
	return lista

## El agente que se llama asi, o {} si no existe. Del mismo nombre puede haber uno
## en cada carpeta y gana el de mas cerca del usuario.
static func cargar(nombre: String) -> Dictionary:
	var limpio := nombre.strip_edges()
	if limpio == "":
		return {}
	for carpeta in [RUTA_AGENTES, RUTA_PROYECTO, RUTA_INCLUIDOS]:
		var agente := cargarArchivo(carpeta + limpio + EXTENSION)
		if not agente.is_empty():
			return agente
	return {}

## Un archivo suelto, ya con las claves normalizadas. Devuelve {} si no se puede
## leer o si el nombre del archivo no es un nombre de agente valido.
static func cargarArchivo(ruta: String) -> Dictionary:
	if not FileAccess.file_exists(ruta):
		return {}
	var archivo := FileAccess.open(ruta, FileAccess.READ)
	if archivo == null:
		return {}
	var texto := archivo.get_as_text()
	archivo.close()
	var nombre := ruta.get_file().get_basename()
	if problemaDeNombre(nombre) != "":
		return {}
	var partes := partirFrontmatter(texto)
	var metadatos: Dictionary = partes["metadatos"]
	var descripcion := str(metadatos.get("description", "")).strip_edges()
	if descripcion.length() > LARGO_MAXIMO_DESCRIPCION:
		descripcion = descripcion.substr(0, LARGO_MAXIMO_DESCRIPCION)
	return {
		"nombre": nombre,
		"descripcion": descripcion,
		"modelo": str(metadatos.get("model", "")).strip_edges(),
		"herramientas": _normalizarHerramientas(str(metadatos.get("tools", TODAS))),
		"prompt": str(partes["cuerpo"]),
		"ruta": ruta,
		"origen": _origenDe(ruta),
	}

## Si el agente no se puede cambiar en su sitio: los del proyecto porque viven en
## el repo del equipo, y los de fabrica porque viven dentro del addon. De los de
## fabrica si se saca copia: Ajustes los guarda como agente del usuario.
static func esDeSoloLectura(agente: Dictionary) -> bool:
	var origen := str(agente.get("origen", ""))
	return origen == "proyecto" or origen == "incluido"

## Como se llama su origen en la interfaz, o "" si es un agente del usuario: lo
## que se senala es lo que viene de fuera, no lo de casa.
static func etiquetaOrigen(agente: Dictionary) -> String:
	match str(agente.get("origen", "")):
		"proyecto":
			return "Project"
		"incluido":
			return "Built-in"
	return ""

## Escribe (o reescribe) un agente propio. Retorna "" si salio bien, o el
## problema que lo impide. Antes de pisar uno que ya existia deja copia: un
## agente es texto que escribio el usuario, y reescribirlo sin red es perderlo.
static func guardar(nombre: String, descripcion: String, modelo: String,
		herramientas: String, prompt: String) -> String:
	var problema := problemaDeNombre(nombre)
	if problema != "":
		return problema
	var limpio := nombre.strip_edges()
	DirAccess.make_dir_recursive_absolute(RUTA_AGENTES)
	var ruta := RUTA_AGENTES + limpio + EXTENSION
	CopiasSeguridad.respaldar(ruta, "agent file")
	var archivo := FileAccess.open(ruta, FileAccess.WRITE)
	if archivo == null:
		return "The agent file could not be written."
	var lineas: Array = ["---"]
	if descripcion.strip_edges() != "":
		lineas.append("description: " + _enUnaLinea(descripcion))
	if modelo.strip_edges() != "":
		lineas.append("model: " + _enUnaLinea(modelo))
	var regla := _normalizarHerramientas(herramientas)
	if regla != TODAS:
		lineas.append("tools: " + _enUnaLinea(regla))
	lineas.append("---")
	lineas.append("")
	lineas.append(prompt.strip_edges())
	lineas.append("")
	archivo.store_string("\n".join(lineas))
	archivo.close()
	return ""

## Borra un agente propio. Los del proyecto no se tocan. La copia de antes de
## borrar es lo que hace que esto se pueda deshacer desde las herramientas de
## copias de seguridad.
static func borrar(nombre: String) -> bool:
	var limpio := nombre.strip_edges()
	if problemaDeNombre(limpio) != "":
		return false
	var ruta := RUTA_AGENTES + limpio + EXTENSION
	if not FileAccess.file_exists(ruta):
		return false
	CopiasSeguridad.respaldar(ruta, "agent file")
	return DirAccess.remove_absolute(ruta) == OK

## El agente invocado en un texto con @nombre, o {} si no hay ninguno. Gana el
## nombre mas largo que encaje, para que @revisor-js no se lea como @revisor.
static func deMencion(texto: String) -> Dictionary:
	var nombres: Array = []
	for agente in listar():
		nombres.append(str(agente["nombre"]))
	nombres.sort_custom(func(a, b): return str(a).length() > str(b).length())
	for nombre in nombres:
		var aguja := "@" + str(nombre)
		var desde := 0
		while true:
			var pos := texto.find(aguja, desde)
			if pos < 0:
				break
			var fin := pos + aguja.length()
			var antesOk := pos == 0 or not _esDeNombre(texto[pos - 1])
			var despuesOk := fin >= texto.length() or not _esDeNombre(texto[fin])
			if antesOk and despuesOk:
				return cargar(str(nombre))
			desde = pos + 1
	return {}

## Bloque que se pega al prompt de sistema cuando hay un agente activo.
static func bloquePrompt(agente: Dictionary) -> String:
	if agente.is_empty():
		return ""
	var nombre := str(agente.get("nombre", ""))
	var prompt := str(agente.get("prompt", "")).strip_edges()
	if nombre == "":
		return ""
	var bloque := "\n\n---\n**ACTIVE AGENT: %s**\n" % nombre
	var descripcion := str(agente.get("descripcion", "")).strip_edges()
	if descripcion != "":
		bloque += "You are running as the \"%s\" agent: %s\n" % [nombre, descripcion]
	else:
		bloque += "You are running as the \"%s\" agent.\n" % nombre
	if prompt != "":
		bloque += "These instructions are yours and they win over your general habits; follow them for the whole conversation.\n\n" + prompt + "\n"
	return bloque + "---\n"

## Las herramientas que le quedan a un agente, de las que hay registradas.
## "all" (o vacio) las deja todas, "none" no deja ninguna, "read-only" deja las
## que solo miran, y cualquier otra cosa es una lista separada por comas.
static func filtrarHerramientas(agente: Dictionary, herramientas: Dictionary) -> Dictionary:
	if agente.is_empty():
		return herramientas
	var regla := str(agente.get("herramientas", TODAS)).strip_edges().to_lower()
	if regla == "" or regla == TODAS:
		return herramientas
	if regla == NINGUNA:
		return {}
	var filtradas: Dictionary = {}
	for nombre in herramientas:
		if _permite(regla, str(nombre)):
			filtradas[nombre] = herramientas[nombre]
	return filtradas

## Si el agente deja usar una herramienta suelta. Lo usa el despachador: el
## modelo solo ve las que se le ofrecen, pero un historial viejo puede traer la
## llamada de una herramienta que ya no tiene.
static func permiteHerramienta(agente: Dictionary, nombre: String) -> bool:
	if agente.is_empty():
		return true
	var regla := str(agente.get("herramientas", TODAS)).strip_edges().to_lower()
	if regla == "" or regla == TODAS:
		return true
	return _permite(regla, nombre)

## Texto corto para la interfaz: que herramientas tiene el agente.
static func etiquetaHerramientas(agente: Dictionary) -> String:
	if agente.is_empty():
		return ""
	match str(agente.get("herramientas", TODAS)):
		NINGUNA:
			return "No tools"
		SOLO_LECTURA:
			return "Read-only tools"
		TODAS:
			return "All tools"
	return "Tools: " + str(agente.get("herramientas", ""))

## Bloque <available_agents> para el prompt de sistema: sin esto el modelo no
## sabe que existen ni como se piden. Va solo con los agentes propios, que son
## los que el usuario puede invocar por su nombre.
static func bloqueDisponibles() -> String:
	var lista := listar()
	if lista.is_empty():
		return ""
	var lineas: Array = ["\n\n---", "**AVAILABLE AGENTS**",
		"The user can bring one of these agents into the conversation by typing @name. When the user does, its instructions and its tools become the ones in force. You cannot switch agents on your own: if a task would clearly go better with one of them, say so and let the user type it.", ""]
	for agente in lista:
		var descripcion := str(agente.get("descripcion", "")).strip_edges()
		var linea := "- @%s" % str(agente.get("nombre", ""))
		if descripcion != "":
			linea += ": " + descripcion
		lineas.append(linea)
	lineas.append("---")
	return "\n".join(lineas) + "\n"

# ---------------------------------------------------------------------------
# Interno
# ---------------------------------------------------------------------------

## Separa el frontmatter del cuerpo. Un archivo sin frontmatter vale igual: todo
## el texto es el cuerpo y los metadatos van vacios. Es publico porque los skills
## (Habilidades) usan el mismo formato y no tiene sentido tener dos analizadores
## que se separen con el tiempo.
static func partirFrontmatter(texto: String) -> Dictionary:
	var lineas := texto.replace("\r\n", "\n").replace("\r", "\n").split("\n")
	if lineas.size() == 0 or lineas[0].strip_edges() != "---":
		return {"metadatos": {}, "cuerpo": texto.strip_edges()}
	var metadatos: Dictionary = {}
	var cierre := -1
	for i in range(1, lineas.size()):
		var linea: String = lineas[i]
		if linea.strip_edges() == "---":
			cierre = i
			break
		var corte := linea.find(":")
		if corte <= 0:
			continue
		var clave := linea.substr(0, corte).strip_edges().to_lower()
		var valor := linea.substr(corte + 1).strip_edges()
		if clave != "":
			metadatos[clave] = _sinComillas(valor)
	if cierre < 0:
		return {"metadatos": metadatos, "cuerpo": ""}
	return {"metadatos": metadatos, "cuerpo": "\n".join(lineas.slice(cierre + 1)).strip_edges()}

static func _sinComillas(valor: String) -> String:
	if valor.length() >= 2:
		var primera := valor.substr(0, 1)
		var ultima := valor.substr(valor.length() - 1, 1)
		if (primera == "\"" and ultima == "\"") or (primera == "'" and ultima == "'"):
			return valor.substr(1, valor.length() - 2).strip_edges()
	return valor

## El valor de "tools" tal como se guarda: los tres nombres conocidos en
## minusculas, y una lista como la escribio el usuario.
static func _normalizarHerramientas(valor: String) -> String:
	var limpio := valor.strip_edges()
	var minusculas := limpio.to_lower()
	if minusculas == "" or minusculas == TODAS:
		return TODAS
	if minusculas == NINGUNA:
		return NINGUNA
	if minusculas == SOLO_LECTURA or minusculas == "readonly" or minusculas == "read only":
		return SOLO_LECTURA
	return limpio

static func _permite(regla: String, nombre: String) -> bool:
	if regla == NINGUNA:
		return false
	if regla == SOLO_LECTURA:
		return HERRAMIENTAS_SOLO_LECTURA.has(nombre)
	for item in regla.split(",", false):
		if str(item).strip_edges().to_lower() == nombre.to_lower():
			return true
	return false

## Un caracter que podria ser parte de un nombre de agente. Se usa para que
## @revisor no encaje dentro de @revisor-algo ni en medio de un correo.
static func _esDeNombre(caracter: String) -> bool:
	if caracter == "":
		return false
	# Una barra o dos puntos detras de la mencion no son un agente: "@res" no
	# puede activarse por escribir "@res://cosa.gd", que es una mencion de
	# archivo del panel.
	if caracter == ":" or caracter == "/" or caracter == "\\":
		return true
	var codigo := caracter.unicode_at(0)
	var esDigito := codigo >= 48 and codigo <= 57
	var esMayuscula := codigo >= 65 and codigo <= 90
	var esMinuscula := codigo >= 97 and codigo <= 122
	return esDigito or esMayuscula or esMinuscula or caracter == "-" or caracter == "_"

static func _enUnaLinea(valor: String) -> String:
	return valor.strip_edges().replace("\n", " ").replace("\r", " ")

## De que carpeta sale un agente, por su ruta. Cualquier otra ruta cuenta como
## del usuario: asi un archivo suelto se lee como propio y no como de fuera.
static func _origenDe(ruta: String) -> String:
	if ruta.begins_with(RUTA_PROYECTO):
		return "proyecto"
	if ruta.begins_with(RUTA_INCLUIDOS):
		return "incluido"
	return "usuario"

## Archivos .md de una carpeta, en orden. indice 0 = agentes del usuario,
## indice 1 = agentes del proyecto, indice 2 = los que trae Dotti.
static func _rutas(indice: int) -> Array:
	var carpeta := RUTA_AGENTES
	if indice == 1:
		carpeta = RUTA_PROYECTO
	elif indice == 2:
		carpeta = RUTA_INCLUIDOS
	var rutas: Array = []
	var dir := DirAccess.open(carpeta)
	if dir == null:
		return rutas
	dir.list_dir_begin()
	var entrada := dir.get_next()
	while entrada != "":
		if not dir.current_is_dir() and entrada.get_extension().to_lower() == "md" and not entrada.begins_with("."):
			rutas.append(carpeta + entrada)
		entrada = dir.get_next()
	dir.list_dir_end()
	rutas.sort()
	return rutas
