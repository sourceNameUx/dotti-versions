# Chat internals

The chat panel is built and driven by `Chat.gd` (one folder up). This folder holds
the pieces it delegates to. Nothing here owns state: they are stateless helpers
called with explicit arguments, so they can be used from a tool, a test or the
settings window without pulling the whole panel in.

## Files

- `Contexto.gd` (`ChatContexto`) - the head of the system prompt. Builds the
  `<env>` block (model, editor version, project, platform, date) and reads the
  session instructions from `user://AGENTS.md`, the file the user edits in
  Settings and that never enters the project. `Chat._reconstruirSystemPrompt()`
  puts this right after the personality prompt, before any tool rules.
- `ChatPrompts.gd` (`ChatPrompts`) - the rest of the system prompt text: the
  native tool rules, the JSON tool protocol used by non-OpenAI providers, and the
  "question with choices" format that renders as buttons.
- `ChatStyles.gd` (`ChatEstilos`) - every color, margin and stylebox the panel
  uses. Change the look of the chat here, not at the call sites.
- `ChatUIFactory.gd` (`ChatUIFactory`) - small widget builders (transparent
  buttons, chips, rows) so `Chat.gd` does not repeat theme overrides.
- `ChatIconos.gd` (`ChatIconos`) - the icon set. The SVGs are stored as text in
  the file and rasterized white, then tinted at paint time; the addon does not
  depend on the project importer or on `EditorIcons`, which do not exist outside
  the editor.
- `ChatAnimations.gd` (`ChatAnimaciones`) - entry animations for bubbles, tool
  cards and errors.
- `Autocomplete.gd` (`ChatAutocompletado`) - the suggestion list of the input
  box. Typing `@` opens the agents of the catalogue plus the files and folders of
  the project; typing `/` at the start opens the chat commands (`/compact`,
  `/agent`). Arrow keys or Ctrl+P/Ctrl+N move, Enter picks, Tab steps into a
  folder, Escape closes; in `/` mode Escape takes the half-written command away
  with it, because a loose `/command` is not a message. It is a `PanelContainer`
  painted over the input box without stealing its focus, so the user keeps typing
  while the list is open. Picking a file emits `archivoMencionado`, which is what
  adds it to the message as an attachment. It is the counterpart of opencode's
  `component/prompt/autocomplete.tsx`, and the file carries the notes on what was
  kept and what was left out.
- `ChatStreamBloques.gd` (`ChatStreamBloques`) - splits a streaming answer into
  "closed" blocks and a live tail. `MarkdownLabel` rebuilds all of its nodes on
  every text assignment and costs roughly 30 ms per 1000 characters, so the
  closed part is rendered once and only the tail is refreshed per delta.
- `ChatPasser.gd` (`ChatParseador`) - parsing and coercion helpers: tool-name
  normalization, JSON arguments that arrive as strings or nulls, safe type
  conversions. Anything that takes untrusted model output through here stays
  alive.
- `ChatModelos.gd` (`ChatModelos`) - known context windows and max output per
  model. Unknown models are treated as unknown: no caps, no badges.
- `ChatPermissions.gd` (`ChatPermisos`) - permission modes (ask, automatic, all)
  and the per-tool allow list, stored in `user://permisos_herramientas.cfg`.
- `ChatCompaction.gd` (`ChatCompactacion`) - context compaction. Decides when the
  conversation no longer leaves room for the answer, where to cut it and how to
  write the old part as a summary request. The summary itself is chat state
  (`Chat._resumen` / `Chat._corteResumen`), re-injected into the system prompt by
  `ChatPrompts.bloqueResumen()` on every request, so it survives reopening the
  chat. The history is never truncated: only what is sent is shortened.
- `Agents.gd` (`Agentes`) - the agents the user can call with `@name`. Each one is
  a Markdown file: frontmatter (`description`, `model`, `tools`) plus a body that
  is the prompt; the file name is the agent name. There are three folders to
  read from, nearest-to-the-user first: `user://dotti_agentes/` (written by the
  settings window), `res://.dotti/agentes/` (a team's, read-only) and
  `res://addons/Dotti/data/agentes/`, the two agents Dotti ships with
  (`general` and `explore`; `build` and `plan` are ways of working, not personas,
  and `plan` is the second mode of the mode selector)
  (`build`, `plan`, `general`, `explore`). A name found higher up wins and the
  lower file is left alone, which is how a project `explore.md` replaces the
  built-in one without either file moving. The file also knows which tools are
  read-only, which is what `tools: read-only` means. The class name breaks the
  `Chat` prefix on purpose: an agent belongs to the user, not to the panel, and
  the same file is read from Settings, from the chat and from the tests. `Chat.gd` keeps the active one in `_agente` and rebuilds the
  prompt when it changes.
- `Skills.gd` (`Habilidades`) - the written procedures the model loads on demand.
  A skill is a folder with a `SKILL.md` inside, in `user://dotti_skills/` or in
  `res://.dotti/skills/`, and the folder name is the skill name. Of a skill only
  the name and the description reach the system prompt; the body comes through the
  `Load skill` tool when the model asks for it, which is what keeps twenty skills
  at the price of twenty lines. It shares the frontmatter parser with `Agentes`,
  and the class name breaks the `Chat` prefix for the same reason: it is the
  user's material, not the panel's.
- `Subagent.gd` (`ChatSubagente`) - the subagents, one step further than an agent:
  here the model launches the work itself with `Run agent`, the subagent runs in
  its own conversation and only its last message comes back. It is opencode's
  `task`. It runs on the same `LLMNativo` / `LLMRouter` pair the chat uses, and
  every call inside it goes through `Chat._ejecutarUnaHerramienta`, so the tool
  cards are painted and the permission modes still apply. Three rules hold it: it
  cannot launch another subagent, it cannot ask the user anything, and it cannot
  touch the session task list. Read the header of the file before changing any of
  the three. The cards of what it touches hang from the `Run agent` card as a
  thread instead of falling loose in the chat, so the main conversation stays
  readable while the work is visible. `Tools/SubagentTools.gd` only registers the
  tool.

## Rules

- Keep the prompt text in English. Spanish is for the UI and for code comments.
- Do not add state to these helpers; if something needs state, it belongs in
  `Chat.gd`.
- Anything that renders per-delta must stay bounded: see `ChatStreamBloques.gd`
  before touching the streaming path.
