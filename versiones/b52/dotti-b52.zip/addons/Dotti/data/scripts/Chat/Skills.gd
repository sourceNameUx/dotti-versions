@tool
class_name Habilidades
extends RefCounted

## Skills del proyecto (P9b). Un skill es una carpeta con un SKILL.md dentro: el
## frontmatter lleva la descripcion y el cuerpo el procedimiento; el nombre es el
## de la carpeta.
##
## De un skill viajan dos cosas distintas en dos momentos distintos. Al prompt de
## sistema solo va el nombre con su descripcion, unas lineas por skill. El cuerpo
## lo trae la herramienta "Load skill" cuando el modelo decide que le hace falta.
## Eso es lo que los hace baratos: veinte skills escritos no cuestan mas que
## veinte lineas hasta que uno se usa, y entonces solo cuesta el suyo.
##
## Igual que los agentes viven en dos sitios: user://dotti_skills/ (los del
## usuario) y res://.dotti/skills/ (los del proyecto, para compartir con el
## equipo). Un skill del usuario tapa a uno del proyecto con el mismo nombre.
##
## Formato:
##
##   user://dotti_skills/pixel-art/SKILL.md
##
##   ---
##   description: How sprites are drawn and exported here. Use it when the user asks for pixel art.
##   ---
##
##   Steps to follow...
##
## El nombre del archivo no importa mas alla de ser un .md llamado SKILL (skill.md
## y Skill.md valen igual): lo que manda es la carpeta. La carpeta puede llevar
## mas archivos -plantillas, referencias- y el cuerpo del SKILL.md puede pedirle
## al modelo que los lea con "Read file".

const RUTA_SKILLS := "user://dotti_skills/"
const RUTA_PROYECTO := "res://.dotti/skills/"

const LARGO_MAXIMO_DESCRIPCION := 1024
## Tope del cuerpo que devuelve la herramienta. Un skill es un procedimiento, no
## un libro: lo que pase de aqui se corta y se avisa, en vez de meterlo entero en
## la ventana del modelo de una vez.
const LARGO_MAXIMO_CUERPO := 20000

## Los skills que hay, los del usuario y los del proyecto, ordenados por nombre.
## Si un nombre esta en los dos sitios manda el del usuario.
static func listar() -> Array:
	var porNombre: Dictionary = {}
	for ruta in _rutas(0):
		var skill := cargarArchivo(ruta)
		if not skill.is_empty():
			porNombre[str(skill["nombre"])] = skill
	for ruta in _rutas(1):
		var skill := cargarArchivo(ruta)
		if not skill.is_empty() and not porNombre.has(str(skill["nombre"])):
			porNombre[str(skill["nombre"])] = skill
	var nombres: Array = porNombre.keys()
	nombres.sort()
	var lista: Array = []
	for nombre in nombres:
		lista.append(porNombre[nombre])
	return lista

## El skill que se llama asi, o {} si no existe. Se compara sin mirar mayusculas
## y sobre la lista ya leida del disco, no montando una ruta con lo que manda el
## modelo: asi un nombre con ".." o con barras no llega nunca al sistema de
## archivos.
static func cargar(nombre: String) -> Dictionary:
	var buscado := _normalizarNombre(nombre)
	if buscado == "":
		return {}
	for skill in listar():
		if str(skill["nombre"]).to_lower() == buscado:
			return skill
	return {}

## Un SKILL.md suelto, ya con las claves normalizadas. Devuelve {} si no se puede
## leer o si la carpeta no tiene nombre.
static func cargarArchivo(ruta: String) -> Dictionary:
	if not FileAccess.file_exists(ruta):
		return {}
	var archivo := FileAccess.open(ruta, FileAccess.READ)
	if archivo == null:
		return {}
	var texto := archivo.get_as_text()
	archivo.close()
	var nombre := ruta.get_base_dir().get_file().strip_edges()
	if nombre == "":
		return {}
	var partes := Agentes.partirFrontmatter(texto)
	var metadatos: Dictionary = partes["metadatos"]
	var cuerpo := str(partes["cuerpo"]).strip_edges()
	var descripcion := str(metadatos.get("description", "")).strip_edges()
	if descripcion == "":
		# Un skill sin descripcion no se puede anunciar, y sin anuncio nadie lo
		# carga: se tira de la primera linea del cuerpo, que en un procedimiento
		# escrito suele decir de que va.
		descripcion = _primeraLinea(cuerpo)
	if descripcion.length() > LARGO_MAXIMO_DESCRIPCION:
		descripcion = descripcion.substr(0, LARGO_MAXIMO_DESCRIPCION)
	return {
		"nombre": nombre,
		"descripcion": descripcion,
		"cuerpo": cuerpo,
		"ruta": ruta,
		"origen": "proyecto" if ruta.begins_with(RUTA_PROYECTO) else "usuario",
	}

## Lo que devuelve la herramienta "Load skill": el cuerpo con una cabecera que
## dice de donde sale, para que el modelo no confunda un procedimiento del
## proyecto con algo que le ha pedido el usuario.
static func cuerpoParaModelo(skill: Dictionary) -> String:
	if skill.is_empty():
		return ""
	var nombre := str(skill.get("nombre", ""))
	var cuerpo := str(skill.get("cuerpo", "")).strip_edges()
	var cabecera := "Skill \"%s\" loaded. Follow it for the rest of the task." % nombre
	var descripcion := str(skill.get("descripcion", "")).strip_edges()
	if descripcion != "":
		cabecera += " " + descripcion
	var aviso := ""
	if cuerpo.length() > LARGO_MAXIMO_CUERPO:
		cuerpo = cuerpo.substr(0, LARGO_MAXIMO_CUERPO)
		aviso = "\n\n[The file is longer than %d characters and was cut here. Read the rest with \"Read file\" on %s]" % [LARGO_MAXIMO_CUERPO, str(skill.get("ruta", ""))]
	if cuerpo == "":
		return cabecera + "\n\nThe skill file has no instructions in it."
	return cabecera + "\n\n" + cuerpo + aviso

## Bloque <available-skills> del prompt de sistema: nombre y descripcion de cada
## uno, sin el cuerpo. "" si no hay ninguno.
static func bloqueDisponibles() -> String:
	var lista := listar()
	if lista.is_empty():
		return ""
	var lineas: Array = ["\n\n---", "**AVAILABLE SKILLS**",
		"Written procedures of this project. If one of them covers what you are about to do, call \"Load skill\" with its name and follow it instead of improvising; the summary below is only the summary, the instructions come when you load it.", ""]
	for skill in lista:
		var descripcion := str(skill.get("descripcion", "")).strip_edges()
		var linea := "- %s" % str(skill.get("nombre", ""))
		if descripcion != "":
			linea += ": " + descripcion
		lineas.append(linea)
	lineas.append("---")
	return "\n".join(lineas) + "\n"

# ---------------------------------------------------------------------------
# Interno
# ---------------------------------------------------------------------------

## El nombre tal como se busca: sin espacios de sobra, sin la arroba que a veces
## pone el modelo delante y en minusculas.
static func _normalizarNombre(nombre: String) -> String:
	var limpio := nombre.strip_edges()
	if limpio.begins_with("@"):
		limpio = limpio.substr(1).strip_edges()
	return limpio.to_lower()

static func _primeraLinea(texto: String) -> String:
	for linea in texto.split("\n"):
		var limpia: String = str(linea).strip_edges().lstrip("#").strip_edges()
		if limpia != "":
			return limpia
	return ""

## Rutas de los SKILL.md que hay. indice 0 = skills del usuario, indice 1 =
## skills del proyecto.
static func _rutas(indice: int) -> Array:
	var raiz := RUTA_SKILLS if indice == 0 else RUTA_PROYECTO
	var rutas: Array = []
	var dir := DirAccess.open(raiz)
	if dir == null:
		return rutas
	dir.list_dir_begin()
	var entrada := dir.get_next()
	while entrada != "":
		# El punto de delante deja fuera "." y ".." (que tambien son carpetas y
		# volverian a listar la raiz) y las carpetas ocultas.
		if dir.current_is_dir() and not entrada.begins_with("."):
			var archivo := _archivoDeCarpeta(raiz + entrada + "/")
			if archivo != "":
				rutas.append(archivo)
		entrada = dir.get_next()
	dir.list_dir_end()
	rutas.sort()
	return rutas

## El SKILL.md de una carpeta, o "" si no lo tiene. Se busca sin mirar
## mayusculas: SKILL.md, skill.md y Skill.md son el mismo archivo y nadie
## escribe siempre el mismo.
static func _archivoDeCarpeta(carpeta: String) -> String:
	var dir := DirAccess.open(carpeta)
	if dir == null:
		return ""
	var encontrado := ""
	dir.list_dir_begin()
	var entrada := dir.get_next()
	while entrada != "":
		if not dir.current_is_dir() and entrada.get_basename().to_lower() == "skill" and entrada.get_extension().to_lower() == "md":
			encontrado = carpeta + entrada
			break
		entrada = dir.get_next()
	dir.list_dir_end()
	return encontrado
