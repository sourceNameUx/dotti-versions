@tool
class_name ChatStreamBloques
extends RefCounted

## Reparte el texto de un stream entre la parte ya cerrada (bloques que no van a
## cambiar mas) y la cola viva.
##
## El motivo es de rendimiento: MarkdownLabel rehace TODOS sus nodos en cada
## asignacion de texto, y el coste crece con el tamano (medido en el proyecto:
## ~30 ms por cada 1000 caracteres). Alimentarlo con el texto completo en cada
## delta congela el motor. Rindiendo una sola vez lo ya cerrado y refrescando
## solo la cola, el trabajo por delta queda acotado.

## Tamano maximo de la cola viva: es el trozo que se vuelve a renderizar en cada
## refresco.
const MAX_COLA := 700

## Indice donde empieza la cola viva. Un bloque se cierra al llegar a una linea
## vacia fuera de un bloque de codigo; si la cola pasaria de MAX_COLA se corta
## tambien en un salto de linea seguro, para que no crezca sin limite (un texto
## largo sin lineas vacias, p. ej. un unico parrafo, tambien debe quedar acotado).
##
## Version de referencia. Recorre el texto entero, asi que NO se debe llamar por
## delta en la ruta viva: para eso esta corteConEstado(), que da el mismo indice
## reanudando el analisis. Se conserva como definicion del comportamiento y para
## poder comprobar contra ella que la version incremental no se desvia.
static func corte(texto: String) -> int:
	var objetivo := texto.length() - MAX_COLA
	var cierre := 0
	var minimo := 0
	var minimo_fijado := false
	var en_cerca := false
	var marca := ""
	var i := 0
	while i < texto.length():
		var fin := texto.find("\n", i)
		var es_ultima := fin == -1
		var linea := texto.substr(i, (texto.length() - i) if es_ultima else (fin - i))
		var recortada := linea.strip_edges()
		if recortada.begins_with("```") or recortada.begins_with("~~~"):
			var nueva := "```" if recortada.begins_with("```") else "~~~"
			if en_cerca:
				if marca == nueva:
					en_cerca = false
			else:
				en_cerca = true
				marca = nueva
		elif not en_cerca:
			if recortada == "":
				cierre = i
			if not minimo_fijado and i >= objetivo:
				minimo = i
				minimo_fijado = true
		if es_ultima:
			break
		i = fin + 1
	return maxi(cierre, minimo)

## Igual que corte(), pero reanudando el analisis donde quedo la llamada anterior
## en vez de recorrer el texto entero otra vez: corte() es O(n) por delta y en una
## respuesta larga eso acaba notandose (medido: 1,4 ms de media y 2,3 ms en el peor
## delta con 60.000 caracteres, frente a 0,025 ms reanudando). El estado vive en el
## diccionario que ya guarda el llamante junto a los bloques, asi que no hay que
## anadir nada al objeto.
##
## `lineas` recuerda, para cada arranque de linea dentro de la ventana, si estaba
## fuera de una cerca de codigo; de ahi sale el corte cuando no hay linea en blanco
## cerca del final.
static func corteConEstado(texto: String, estado: Dictionary) -> int:
	var n := texto.length()
	var pos := int(estado.get("pos", 0))
	if pos > n:
		# El texto encogio (chat nuevo o edicion): se empieza de cero.
		estado.clear()
		pos = 0
	var en_cerca := bool(estado.get("en_cerca", false))
	var marca := String(estado.get("marca", ""))
	var cierre := int(estado.get("cierre", 0))
	var lineas: Array = estado.get("lineas", [])
	var objetivo := n - MAX_COLA
	while lineas.size() > 0 and int(lineas[0][0]) < objetivo:
		lineas.pop_front()
	while pos < n:
		var fin := texto.find("\n", pos)
		if fin == -1:
			# Linea todavia sin terminar: la completa el siguiente delta y solo
			# entonces se analiza (asi el estado no se calcula dos veces).
			break
		var linea := texto.substr(pos, fin - pos)
		var recortada := linea.strip_edges()
		if recortada.begins_with("```") or recortada.begins_with("~~~"):
			var nueva := "```" if recortada.begins_with("```") else "~~~"
			if en_cerca:
				if marca == nueva:
					en_cerca = false
			else:
				en_cerca = true
				marca = nueva
		elif en_cerca:
			lineas.append([pos, false])
		else:
			if recortada == "":
				cierre = pos
			lineas.append([pos, true])
		pos = fin + 1
	estado["pos"] = pos
	estado["en_cerca"] = en_cerca
	estado["marca"] = marca
	estado["cierre"] = cierre
	estado["lineas"] = lineas
	var minimo := 0
	var fijado := false
	for registro in lineas:
		if bool(registro[1]):
			minimo = int(registro[0])
			fijado = true
			break
	# La cola sin salto de linea tambien la mira corte(): si es solo espacios vale
	# como linea en blanco, y si esta fuera de una cerca tambien puede fijar el
	# minimo. Se calcula al vuelo y no entra en el estado porque el siguiente delta
	# puede cambiarla de categoria.
	var cierreFinal := cierre
	if pos < n and not en_cerca:
		var cola := texto.substr(pos, n - pos)
		var recortada := cola.strip_edges()
		if not recortada.begins_with("```") and not recortada.begins_with("~~~"):
			if recortada == "":
				cierreFinal = pos
			if not fijado and pos >= objetivo:
				minimo = pos
	return maxi(cierreFinal, minimo)

## Indice de corte para la traza de razonamiento, que se pinta como texto plano (no
## hay bloques de markdown ni cercas de codigo que respetar). Avanza hasta el
## ultimo salto de linea disponible cuando ya hay suficiente texto nuevo; si no lo
## hay, hasta el ultimo espacio, para no partir una palabra por la mitad. Devuelve
## `desde` mientras el tramo nuevo no llegue a `minimo`: en ese caso conviene
## reescribir la cola viva en vez de congelar un trozo.
static func corteRazonamiento(texto: String, desde: int, minimo: int) -> int:
	var total := texto.length()
	if desde < 0 or desde >= total or total - desde < maxi(minimo, 1):
		return maxi(desde, 0)
	var salto := texto.rfind("\n")
	if salto >= desde:
		return salto + 1
	var espacio := texto.rfind(" ")
	if espacio >= desde:
		return espacio + 1
	return total
