@tool
class_name ChatContexto
extends RefCounted

## Contexto que se inyecta en el prompt del sistema: el bloque <env> con los datos
## del entorno y las instrucciones del usuario (user://AGENTS.md).
##
## Todo va en ingles, como el resto del prompt, y va ANTES de la primera
## respuesta del usuario: cuanto mas ingles hay al principio, menos le salta al
## upstream su filtro de contenido.

## Instrucciones del usuario. Es un solo archivo y vive en user://, no en res://:
## lo escribe el usuario para el modelo, no para el repositorio, y asi no acaba
## en el arbol del proyecto ni hay quien lo traduzca. Se edita en Ajustes >
## Instrucciones.
const RUTA_AGENTS := "user://AGENTS.md"


## Bloque <env>. Le dice al modelo con que modelo esta corriendo, en que version
## de Godot, en que proyecto y en que dia, que es lo que no puede deducir solo.
static func bloqueEntorno(nombreEnEditor: String, modelo: String) -> String:
	var lineas: Array = []
	if modelo != "":
		lineas.append("You are powered by the model named %s." % modelo)
		# El nombre del editor es como lo llama el usuario en la interfaz, y no
		# siempre coincide con el id del modelo: sirve para que el modelo se
		# refiera a si mismo como lo hace el usuario.
		if nombreEnEditor != "" and nombreEnEditor != modelo:
			lineas.append("The editor lists it as \"%s\"." % nombreEnEditor)
	else:
		lineas.append("The active model is not configured yet.")
	lineas.append("Here is useful information about the environment you are running in:")
	lineas.append("<env>")
	lineas.append("  Editor: Godot %s" % Engine.get_version_info().get("string", "4.x"))
	lineas.append("  Project name: %s" % str(ProjectSettings.get_setting("application/config/name", "Unnamed")))
	lineas.append("  Project root on disk: %s" % ProjectSettings.globalize_path("res://"))
	lineas.append("  Project files are addressed as res:// paths; user data lives in user://")
	lineas.append("  Platform: %s" % OS.get_name())
	lineas.append("  Today's date: %s" % Time.get_date_string_from_system())
	var escena := str(ProjectSettings.get_setting("application/run/main_scene", ""))
	if escena != "":
		lineas.append("  Main scene: %s" % escena)
	lineas.append("  Session instructions file: %s" % ("%s (present)" % RUTA_AGENTS if FileAccess.file_exists(RUTA_AGENTS) else "none"))
	lineas.append("</env>")
	return "\n".join(lineas)


## Instrucciones del usuario, listas para pegar en el prompt. "" si todavia no
## hay user://AGENTS.md.
static func bloqueInstrucciones() -> String:
	var contenido := leerInstrucciones()
	if contenido == "":
		return ""
	return "Instructions from: %s\n%s" % [RUTA_AGENTS, contenido]


## Lee user://AGENTS.md ya recortado. "" si no existe, no se puede abrir o esta
## vacio. Es la unica puerta de lectura del archivo: el prompt (desde
## bloqueInstrucciones) y Ajustes leen por aqui.
static func leerInstrucciones() -> String:
	if not FileAccess.file_exists(RUTA_AGENTS):
		return ""
	var f := FileAccess.open(RUTA_AGENTS, FileAccess.READ)
	if f == null:
		return ""
	var contenido := f.get_as_text().strip_edges()
	f.close()
	return contenido


## Escribe user://AGENTS.md. Con el texto vacio borra el archivo, que es lo que
## significa "no tengo instrucciones": uno vacio solo gasta una lectura y un
## "(present)" que miente. Devuelve "" si fue bien, o el motivo del fallo.
static func guardarInstrucciones(texto: String) -> String:
	var limpio := texto.strip_edges()
	if limpio == "":
		if FileAccess.file_exists(RUTA_AGENTS):
			DirAccess.remove_absolute(RUTA_AGENTS)
		return ""
	var f := FileAccess.open(RUTA_AGENTS, FileAccess.WRITE)
	if f == null:
		return "Could not write %s." % RUTA_AGENTS
	f.store_string(limpio)
	f.close()
	return ""
