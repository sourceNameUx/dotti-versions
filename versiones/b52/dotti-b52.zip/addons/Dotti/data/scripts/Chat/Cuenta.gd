@tool
class_name ChatCuenta
extends RefCounted

## El protocolo de la cuenta contra la pasarela: entrar con codigo de
## dispositivo, leer el catalogo y leer el consumo del dia.
##
## Todo pasa por aqui y nada de esto guarda estado: quien guarda es `Sesion`, y
## quien pinta es la pestana de ajustes. Las funciones son `static` y reciben el
## nodo donde colgar la peticion porque HTTPRequest necesita estar en el arbol
## para poder emitir su senal.
##
## Las respuestas de la pasarela se traducen aqui a las claves que usa el plugin,
## para que el resto del addon no tenga que saber como se llaman al otro lado.

const SEGUNDOS_DE_ESPERA := 20.0

## Segundos entre sondeo y sondeo del codigo de dispositivo. La pasarela manda
## el suyo (5); este es el que se usa si no lo manda.
const SONDEO_POR_DEFECTO := 5.0

## Codigos de error de la pasarela que el usuario puede leer tal cual.
const MENSAJES := {
	"auth_required": "This request needs a Dotti account. Sign in from Settings > Account.",
	"token_revoked": "This sign-in is no longer valid. Sign in again from Settings > Account.",
	"account_suspended": "This account is suspended. Write to whoever gave you access.",
	"gateway_unavailable": "The accounts service is not reachable right now. Try again in a minute.",
	"bad_code": "That does not look like a device code. It is eight letters and numbers, like BCDF-2345.",
	"too_many_tokens": "This account already has the maximum number of plugin tokens. Revoke one in the web panel.",
	"rate_limited": "Too many attempts. Wait a moment and try again.",
	"daily_limit_reached": "The daily limit is used up. It starts again after the day turns over.",
	"out_of_credit": "The service is out of credit right now. Nothing is wrong with your project.",
}

## Arranca el flujo: pide un codigo para ensenarselo al usuario.
##
## Devuelve {ok, codigo_usuario, device_code, url_verificacion, intervalo,
## expira_en_segundos} o {ok: false, error}.
static func iniciarDispositivo(nodo: Node, direccion: String, cliente: String) -> Dictionary:
	var respuesta := await pedir(
		nodo,
		_sinBarra(direccion) + "/auth/device/start",
		HTTPClient.METHOD_POST,
		["Content-Type: application/json"],
		{"client": cliente}
	)
	if not respuesta.get("ok", false):
		return respuesta
	var datos: Dictionary = respuesta.get("datos", {})
	var codigo := str(datos.get("device_code", ""))
	if codigo == "":
		return {"ok": false, "error": "The service answered without a code. Try again."}
	return {
		"ok": true,
		"codigo_usuario": str(datos.get("user_code", "")),
		"device_code": codigo,
		"url_verificacion": str(datos.get("verification_url", "")),
		"intervalo": float(datos.get("interval", SONDEO_POR_DEFECTO)),
		"expira_en_segundos": int(datos.get("expires_in", 0)),
	}

## Pregunta si el usuario ya aprobo el codigo. `estado` es uno de:
## approved, pending, denied, expired, not_found.
static func consultarDispositivo(nodo: Node, direccion: String, device_code: String) -> Dictionary:
	var respuesta := await pedir(
		nodo,
		_sinBarra(direccion) + "/auth/device/poll",
		HTTPClient.METHOD_POST,
		["Content-Type: application/json"],
		{"device_code": device_code}
	)
	# Quien manda es el codigo, no el "ok": el 202 (todavia no) tambien es una
	# respuesta buena, y mirar solo el "ok" leeria un sondeo pendiente como una
	# entrada hecha con el token vacio.
	var datos: Dictionary = respuesta.get("datos", {})
	match int(respuesta.get("codigo", 0)):
		200:
			var usuario: Dictionary = datos.get("user", {})
			return {
				"ok": true,
				"estado": "approved",
				"token": str(datos.get("token", "")),
				"correo": str(usuario.get("email", "")),
				"rol": str(usuario.get("role", "")),
			}
		202:
			return {"ok": true, "estado": "pending"}
		403:
			# Negarse no es un fallo del que haya que recuperarse: es una respuesta.
			return {"ok": true, "estado": "denied", "mensaje": _mensaje(str(respuesta.get("error_codigo", "denied")))}
		410:
			return {"ok": true, "estado": "expired"}
		404:
			return {"ok": true, "estado": "not_found"}
	return respuesta

## El catalogo de modelos que sirve la pasarela, con el consumo del dia.
##
## Devuelve {ok, modelos, uso}. Cada modelo es {id, etiqueta, contexto,
## salida_max, tarifas}, y el uso {gastado_usd, limite_usd, restante_usd}.
static func catalogo(nodo: Node, cabeceras: Array, direccion: String) -> Dictionary:
	var respuesta := await pedir(
		nodo,
		_sinBarra(direccion) + "/v1/models",
		HTTPClient.METHOD_GET,
		cabeceras,
		{}
	)
	if not respuesta.get("ok", false):
		return respuesta
	var datos: Dictionary = respuesta.get("datos", {})
	var modelos: Array = []
	for crudo in datos.get("data", []):
		if typeof(crudo) != TYPE_DICTIONARY:
			continue
		var m: Dictionary = crudo
		var id := str(m.get("id", "")).strip_edges()
		if id == "":
			continue
		var etiqueta := str(m.get("label", "")).strip_edges()
		modelos.append({
			"id": id,
			"etiqueta": etiqueta if etiqueta != "" else id,
			"contexto": int(m.get("context_window", 0)),
			"salida_max": int(m.get("max_output", 0)),
			"tarifas": {
				"entrada": float(m.get("input_rate", 0.0)),
				"salida": float(m.get("output_rate", 0.0)),
				"cache": float(m.get("cached_rate", 0.0)),
			},
		})
	var uso: Dictionary = datos.get("usage", {})
	return {"ok": true, "modelos": modelos, "uso": _usoDe(uso)}

## El consumo del dia con su desglose: lo que se ensena en los ajustes.
static func consumo(nodo: Node, cabeceras: Array, direccion: String) -> Dictionary:
	var respuesta := await pedir(
		nodo,
		_sinBarra(direccion) + "/me/usage",
		HTTPClient.METHOD_GET,
		cabeceras,
		{}
	)
	if not respuesta.get("ok", false):
		return respuesta
	var datos: Dictionary = respuesta.get("datos", {})
	var tokens: Dictionary = datos.get("tokens", {})
	var uso := _usoDe(datos)
	uso["inicio_dia"] = str(datos.get("day_start", ""))
	uso["entrada"] = int(tokens.get("prompt", 0))
	uso["cache"] = int(tokens.get("cached", 0))
	uso["salida"] = int(tokens.get("completion", 0))
	uso["total"] = int(tokens.get("total", 0))
	uso["correo"] = str(datos.get("user", {}).get("email", ""))
	uso["rol"] = str(datos.get("user", {}).get("role", ""))
	return {"ok": true, "uso": uso}

## Una peticion suelta. Devuelve {ok, codigo, datos} o {ok: false, codigo,
## error, error_codigo}.
static func pedir(nodo: Node, url: String, metodo: int, cabeceras: Array, cuerpo: Dictionary) -> Dictionary:
	var peticion := HTTPRequest.new()
	peticion.timeout = SEGUNDOS_DE_ESPERA
	nodo.add_child(peticion)
	var texto := "" if cuerpo.is_empty() else JSON.stringify(cuerpo)
	var arranque := peticion.request(url, PackedStringArray(cabeceras), metodo, texto)
	if arranque != OK:
		peticion.queue_free()
		return {"ok": false, "codigo": 0, "error": "Could not reach %s." % url, "error_codigo": "unreachable"}

	var respuesta: Array = await peticion.request_completed
	peticion.queue_free()
	var resultado := int(respuesta[0])
	var codigo := int(respuesta[1])
	var bytes: PackedByteArray = respuesta[3]

	if resultado != HTTPRequest.RESULT_SUCCESS:
		return {
			"ok": false,
			"codigo": codigo,
			"error": "The service did not answer (%s). Check the connection and the address." % _motivoDeRed(resultado),
			"error_codigo": "network",
		}

	var datos := {}
	if bytes.size() > 0:
		var leido = JSON.parse_string(bytes.get_string_from_utf8())
		if typeof(leido) == TYPE_DICTIONARY:
			datos = leido

	if codigo >= 200 and codigo < 300:
		return {"ok": true, "codigo": codigo, "datos": datos}

	var error_codigo := ""
	var error = datos.get("error")
	if typeof(error) == TYPE_DICTIONARY:
		error_codigo = str(error.get("code", ""))
	return {
		"ok": false,
		"codigo": codigo,
		"error": _mensajeDeRespuesta(datos, codigo),
		"error_codigo": error_codigo,
	}

## El texto que se le ensena al usuario por un fallo de la pasarela: el suyo si
## lo manda, y si no una frase del codigo, y si no una generica con el numero.
static func _mensajeDeRespuesta(datos: Dictionary, codigo: int) -> String:
	var error = datos.get("error")
	if typeof(error) == TYPE_DICTIONARY:
		var mensaje := str(error.get("message", "")).strip_edges()
		if mensaje != "":
			return mensaje
		var clave := str(error.get("code", ""))
		if MENSAJES.has(clave):
			return str(MENSAJES[clave])
	if codigo >= 500:
		return str(MENSAJES["gateway_unavailable"])
	return "The service answered %d." % codigo

static func _mensaje(clave: String) -> String:
	return str(MENSAJES.get(clave, "The request was denied."))

## La foto del dia, en las claves del plugin.
static func _usoDe(uso: Dictionary) -> Dictionary:
	return {
		"gastado_usd": float(uso.get("spent_usd", 0.0)),
		"limite_usd": float(uso.get("limit_usd", 0.0)),
		"restante_usd": float(uso.get("remaining_usd", 0.0)),
	}

static func _motivoDeRed(resultado: int) -> String:
	match resultado:
		HTTPRequest.RESULT_CANT_CONNECT:
			return "cannot connect"
		HTTPRequest.RESULT_CANT_RESOLVE:
			return "cannot resolve the address"
		HTTPRequest.RESULT_CONNECTION_ERROR:
			return "connection error"
		HTTPRequest.RESULT_TIMEOUT:
			return "timed out"
		HTTPRequest.RESULT_TLS_HANDSHAKE_ERROR:
			return "TLS handshake error"
	return "result %d" % resultado

## Sin barra final: la direccion se guarda como la escriba el usuario.
static func _sinBarra(direccion: String) -> String:
	return direccion.strip_edges().rstrip("/")
