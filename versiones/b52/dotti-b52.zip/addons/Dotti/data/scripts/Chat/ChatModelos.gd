@tool
class_name ChatModelos
extends RefCounted

## Capacidades conocidas de los modelos (datos publicos 2026). Si un
## model_id no esta aqui, se trata como desconocido: sin marcas y sin
## techos aplicados.

const CAPACIDADES := {
	"deepseek-v4-flash": {
		"contexto": 1000000,
		"salida_max": 384000,
		"multimodal": true,
		"tools": true,
		"thinking": true,
		"niveles": ["none", "high", "max"],
		"busqueda": false,
		"streaming": true,
	},
	"deepseek-v4-pro": {
		"contexto": 1000000,
		"salida_max": 384000,
		"multimodal": false,
		"tools": true,
		"thinking": true,
		"niveles": ["none", "high", "max"],
		"busqueda": false,
		"streaming": true,
	},
	"deepseek-v4-flash-vision-exp": {
		"contexto": 1000000,
		"salida_max": 384000,
		"multimodal": true,
		"tools": true,
		"thinking": true,
		"niveles": ["none", "high", "max"],
		"busqueda": false,
		"streaming": true,
	},
}

## Catalogo que sirve la pasarela, tal como lo contesto la ultima vez que se
## pudo preguntar. Vacio significa "todavia no se ha preguntado nunca", no "no
## hay modelos": de eso se encarga `idsServidos`, que cae al catalogo de casa.
static var catalogoServidor: Array = []

## Donde se guarda el ultimo catalogo bueno. Es lo que permite que el plugin
## ofrezca los modelos que el administrador anadio en el panel aunque en ese
## momento no haya red: se ensena lo ultimo que se supo.
const RUTA_CATALOGO := "user://dotti_catalogo.cfg"

## Lee el catalogo guardado. Lo llama `Apis` al construirse, antes de decidir
## que proveedores oficiales existen.
static func cargarCatalogoGuardado() -> void:
	var config := ConfigFile.new()
	if config.load(RUTA_CATALOGO) != OK:
		return
	var guardado: Array = config.get_value("catalogo", "modelos", [])
	catalogoServidor = []
	for crudo in guardado:
		if typeof(crudo) == TYPE_DICTIONARY and str((crudo as Dictionary).get("id", "")) != "":
			catalogoServidor.append((crudo as Dictionary).duplicate())

## Guarda el catalogo que acaba de contestar la pasarela.
static func aplicarCatalogo(modelos: Array) -> void:
	catalogoServidor = []
	for crudo in modelos:
		if typeof(crudo) != TYPE_DICTIONARY:
			continue
		var m: Dictionary = crudo
		var id := str(m.get("id", "")).strip_edges()
		if id == "":
			continue
		var etiqueta := str(m.get("etiqueta", "")).strip_edges()
		catalogoServidor.append({
			"id": id,
			"etiqueta": etiqueta if etiqueta != "" else id,
			"contexto": int(m.get("contexto", 0)),
			"salida_max": int(m.get("salida_max", 0)),
			"tarifas": (m.get("tarifas", {}) as Dictionary).duplicate(),
		})
	var config := ConfigFile.new()
	config.load(RUTA_CATALOGO)
	config.set_value("catalogo", "modelos", catalogoServidor)
	config.set_value("catalogo", "actualizado_en", Time.get_unix_time_from_system())
	config.save(RUTA_CATALOGO)

## Los identificadores que el servidor sirve hoy. Sin catalogo del servidor
## contesta el de casa, que es lo que trae el addon: quedarse sin modelos
## porque no hay red seria peor que ofrecer el que ya se sabe que existe.
static func idsServidos() -> Array:
	if not catalogoServidor.is_empty():
		var ids: Array = []
		for m in catalogoServidor:
			ids.append(str(m.get("id", "")))
		return ids
	var locales: Array = []
	for id in Apis.MODELOS_OFICIALES:
		locales.append(str(id))
	return locales

## Si el servidor sirve ese modelo. Es la pregunta que decide si una peticion
## sale o no: mandar un modelo que no existe es una vuelta perdida que ademas
## vuelve disfrazada de error de contenido.
static func servido(model_id: String) -> bool:
	var buscado := String(model_id).strip_edges().to_lower()
	if buscado == "":
		return false
	return idsServidos().has(buscado)

## El nombre que se le ensena al usuario para ese modelo: el del panel si lo
## mando, y si no el de casa.
static func etiqueta(model_id: String) -> String:
	var buscado := String(model_id).strip_edges().to_lower()
	for m in catalogoServidor:
		if str(m.get("id", "")).to_lower() == buscado:
			return str(m.get("etiqueta", buscado))
	if Apis.MODELOS_OFICIALES.has(buscado):
		return str(Apis.MODELOS_OFICIALES[buscado])
	return String(model_id).strip_edges()

## Las tarifas del panel, en dolares por millon de tokens. Vacio si no se saben.
static func tarifas(model_id: String) -> Dictionary:
	var buscado := String(model_id).strip_edges().to_lower()
	for m in catalogoServidor:
		if str(m.get("id", "")).to_lower() == buscado:
			return (m.get("tarifas", {}) as Dictionary).duplicate()
	return {}

static func capacidades(model_id: String) -> Dictionary:
	return CAPACIDADES.get(String(model_id).strip_edges().to_lower(), {})

## El techo de salida: primero el del panel (que es el que aplica la pasarela
## de verdad), y si no lo dijo, el de la tabla de casa.
static func salida_max(model_id: String) -> int:
	var delCatalogo := _datoDelCatalogo(model_id, "salida_max")
	if delCatalogo > 0:
		return delCatalogo
	return int(capacidades(model_id).get("salida_max", 0))

## Tokens que caben en el contexto del modelo, o 0 si no se conoce.
static func contexto_max(model_id: String) -> int:
	var delCatalogo := _datoDelCatalogo(model_id, "contexto")
	if delCatalogo > 0:
		return delCatalogo
	return int(capacidades(model_id).get("contexto", 0))

## Un numero del catalogo del servidor, o 0 si ese modelo no esta o no lo trae.
static func _datoDelCatalogo(model_id: String, clave: String) -> int:
	var buscado := String(model_id).strip_edges().to_lower()
	for m in catalogoServidor:
		if str(m.get("id", "")).to_lower() == buscado:
			return int(m.get(clave, 0))
	return 0

## Deja el `usage` del proveedor en la forma que usa el chat: entrada, salida y
## total. Cada proveedor lo llama a su manera (OpenAI prompt_tokens /
## completion_tokens, Anthropic input_tokens / output_tokens) y algunos no lo
## mandan; con nada reconocible devuelve {} y el chat no ensena nada, que es
## mejor que ensenar un cero.
static func usoNormalizado(crudo: Variant) -> Dictionary:
	if typeof(crudo) != TYPE_DICTIONARY:
		return {}
	var d: Dictionary = crudo
	var entrada := _enteroDe(d, ["prompt_tokens", "input_tokens"])
	var salida := _enteroDe(d, ["completion_tokens", "output_tokens"])
	var total := _enteroDe(d, ["total_tokens"])
	if total <= 0:
		total = entrada + salida
	if total <= 0:
		return {}
	return {"entrada": entrada, "salida": salida, "total": total, "cache": cacheLeido(d, entrada)}

## Los tokens que el proveedor no tuvo que volver a leer y cobra mas baratos.
## Vienen dentro del detalle de la entrada, y el nombre cambia segun quien
## conteste: `prompt_tokens_details.cached_tokens` en OpenAI, `cache_read_input_tokens`
## en Anthropic. No se suman a la entrada: son parte de ella, y contarlos dos
## veces inflaria el gasto que se le ensena al usuario.
static func cacheLeido(d: Dictionary, entrada: int) -> int:
	var cache := _enteroDe(d, ["cache_read_input_tokens", "cached_tokens"])
	for clave in ["prompt_tokens_details", "input_tokens_details"]:
		var detalles = d.get(clave)
		if typeof(detalles) == TYPE_DICTIONARY:
			cache = maxi(cache, _enteroDe(detalles, ["cached_tokens", "cache_read"]))
	if cache > entrada:
		cache = entrada
	return maxi(cache, 0)

## Que parte del contexto lleva gastada esta peticion, en tanto por ciento
## redondeado. -1 si no se sabe: modelo desconocido o sin tokens.
static func porcentajeContexto(model_id: String, total: int) -> int:
	var ventana := contexto_max(model_id)
	if ventana <= 0 or total <= 0:
		return -1
	return int(round(100.0 * float(total) / float(ventana)))

## Contador corto que se ensena en la barra: "850", "12.4K", "1M". Vacio cuando no
## hay tokens que ensenar, que es lo que deja el contador escondido.
static func etiquetaUso(uso: Dictionary, model_id: String) -> String:
	var total := int(uso.get("total", 0))
	if total <= 0:
		return ""
	var texto := textoTokens(total)
	var pct := porcentajeContexto(model_id, total)
	if pct >= 0:
		texto += " (%d%%)" % pct
	return texto

## Detalle para el tooltip: cuanto fue entrada y cuanto salida, y de que ventana
## sale el porcentaje. Los numeros van enteros y con separadores de miles, que es
## lo que no cabe en la barra.
static func detalleUso(uso: Dictionary, model_id: String) -> String:
	var total := int(uso.get("total", 0))
	if total <= 0:
		return ""
	var lineaEntrada := "Input %s" % _conMiles(int(uso.get("entrada", 0)))
	var cache := int(uso.get("cache", 0))
	if cache > 0:
		# Lo que el proveedor ya tenia leido se cobra mas barato: decirlo es lo
		# unico que explica que una peticion de muchos tokens costara poco.
		lineaEntrada += " (%s cached)" % _conMiles(cache)
	var lineas: Array = [
		"Last request: %s tokens" % _conMiles(total),
		lineaEntrada + " / output %s" % _conMiles(int(uso.get("salida", 0))),
	]
	var ventana := contexto_max(model_id)
	if ventana > 0:
		lineas.append("Context window: %s (%d%% used)" % [_conMiles(ventana), porcentajeContexto(model_id, total)])
	else:
		lineas.append("Context window: unknown for this model")
	return "\n".join(lineas)

## Numero abreviado para la barra: "850", "12.4K", "1M".
static func textoTokens(cantidad: int) -> String:
	if cantidad < 1000:
		return str(maxi(cantidad, 0))
	if cantidad >= 1000000:
		return _numeroCorto(float(cantidad) / 1000000.0) + "M"
	return _numeroCorto(float(cantidad) / 1000.0) + "K"

## "1.0" -> "1" (y deja "1.5" como esta).
static func _numeroCorto(valor: float) -> String:
	var texto := "%.1f" % valor
	if texto.ends_with(".0"):
		texto = texto.left(texto.length() - 2)
	return texto

## "12400" -> "12,400".
static func _conMiles(cantidad: int) -> String:
	var texto := str(maxi(cantidad, 0))
	var salida := ""
	var cuenta := 0
	for i in range(texto.length() - 1, -1, -1):
		salida = texto[i] + salida
		cuenta += 1
		if cuenta % 3 == 0 and i > 0:
			salida = "," + salida
	return salida

## Primer nombre de la lista que traiga un numero entero util. Los proveedores
## mandan los contadores como enteros, pero alguno los manda como texto.
static func _enteroDe(d: Dictionary, claves: Array) -> int:
	for clave in claves:
		if not d.has(clave):
			continue
		var valor = d[clave]
		if typeof(valor) == TYPE_INT or typeof(valor) == TYPE_FLOAT:
			return int(valor)
		if typeof(valor) == TYPE_STRING and String(valor).is_valid_int():
			return int(valor)
	return 0
