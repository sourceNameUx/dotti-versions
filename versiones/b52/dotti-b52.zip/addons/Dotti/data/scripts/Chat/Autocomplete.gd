@tool
class_name ChatAutocompletado
extends PanelContainer

## Sugerencias del campo de texto. Escribir "@" abre la lista de agentes y de
## archivos del proyecto; escribir "/" al principio abre la de comandos del
## chat. Es la pieza que en opencode vive en component/prompt/autocomplete.tsx,
## portada a lo que Dotti tiene: los mismos disparadores, las mismas teclas y
## las mismas reglas al insertar.
##
##   @  Arriba/Abajo o Ctrl+P/Ctrl+N mueven, Enter elige, Tab entra en una
##      carpeta y Escape cierra.
##   /  Enter escribe el comando. Escape cierra y se lleva la linea: un
##      "/comando" suelto no es un mensaje, igual que en opencode.
##
## La lista se pinta encima de la caja de texto sin quitarle el foco, asi que se
## sigue escribiendo mientras esta abierta. Con la lista vacia el Enter pasa de
## largo y el mensaje se envia tal cual (opencode se lo come; aqui escribir una
## mencion de algo que no existe y mandarla es mas util que no poder mandarla).
##
## El raton solo elige al hacer clic. En opencode pasar por encima tambien
## cambia la fila; aqui no, porque las filas se repintan al teclear y el puntero
## quieto le quitaria la fila al teclado.

## El usuario eligio un archivo del proyecto: el chat lo adjunta al mensaje.
signal archivoMencionado(ruta: String)

const ALTO_FILA := 20
const MAX_FILAS := 10
const MAX_OPCIONES := 10
const ANCHO_MINIMO := 340
const MARGEN := 4
## Recorte por el medio del nombre que se pinta: el final es lo que se reconoce
## (el nombre del archivo). Solo afecta a la fila; lo que se inserta va entero.
const LARGO_FILA := 58

## Lo que genera el editor al lado del archivo de verdad y nadie menciona.
const EXTENSIONES_IGNORADAS := ["import", "uid"]

## Cada cuanto se vuelve a recorrer el proyecto. opencode tiene un vigilante de
## archivos; aqui el arbol se lee al abrir la lista, y este plazo evita
## recorrerlo entero en cada pulsacion.
const SEGUNDOS_INDICE := 5

## Tope de entradas del indice. En cada pulsacion se mira la lista entera, asi
## que el tope es lo que le pone un techo al tiron de escribir: con 8000 entradas
## la consulta mas cara medida en el banco de pruebas ronda los 40 ms, y un
## proyecto de este tamano ya se busca tecleando, no mirando la lista. Lo que no
## cabe es lo mas hondo del proyecto (ver indiceProyecto).
const MAX_ENTRADAS := 8000

var _chat: Control = null
var _campo: TextEdit = null
var _ancla: Control = null
## "" cerrada, "@" menciones, "/" comandos.
var _modo := ""
## Desplazamiento del disparador ("@" o "/") dentro del texto del campo.
var _indice: int = 0
var _seleccionado: int = 0
var _opciones: Array = []
var _filas: VBoxContainer = null
var _scroll: ScrollContainer = null
## Alto real de una fila, medido una vez. Ver altoFila().
var _altoFila := 0.0

static var _indiceArchivos: Array = []
static var _indiceListo := false
static var _indiceMsec: int = 0

# ---------------------------------------------------------------------------
# Lectura del texto
# ---------------------------------------------------------------------------

## Posicion del "@" que el cursor esta escribiendo, o -1 si no hay ninguno.
## Copia de mentionTriggerIndex de opencode: el "@" tiene que abrir palabra (o
## ir al principio) y no puede haber un espacio entre el y el cursor, asi que un
## correo o una arroba dentro de una palabra no abren la lista.
static func indiceMencion(texto: String, cursor: int) -> int:
	var hasta := clampi(cursor, 0, texto.length())
	var trozo := texto.substr(0, hasta)
	var pos := trozo.rfind("@")
	if pos < 0:
		return -1
	var antes := "" if pos == 0 else trozo.substr(pos - 1, 1)
	if antes != "" and not esEspacio(antes):
		return -1
	if tieneEspacio(trozo.substr(pos)):
		return -1
	return pos

static func esEspacio(caracter: String) -> bool:
	return caracter == " " or caracter == "\t" or caracter == "\n" or caracter == "\r"

static func tieneEspacio(texto: String) -> bool:
	return texto.contains(" ") or texto.contains("\t") or texto.contains("\n") or texto.contains("\r")

## El nombre recortado por el medio, como en opencode: se quedan el principio y
## el final, que es donde esta lo que se reconoce.
static func recortarMedio(texto: String, largo: int = LARGO_FILA) -> String:
	if texto.length() <= largo:
		return texto
	var puntos := 3
	var principio := int(ceil((largo - puntos) / 2.0))
	var final := int((largo - puntos) / 2.0)
	return texto.substr(0, principio) + "..." + texto.substr(texto.length() - final)

# ---------------------------------------------------------------------------
# Opciones
# ---------------------------------------------------------------------------

## Los agentes que el usuario puede invocar con "@".
static func opcionesAgentes() -> Array:
	var opciones: Array = []
	for agente in Agentes.listar():
		var nombre := str(agente.get("nombre", ""))
		if nombre == "":
			continue
		var descripcion := str(agente.get("descripcion", "")).strip_edges()
		if descripcion == "":
			descripcion = Agentes.etiquetaHerramientas(agente)
		opciones.append({
			"tipo": "agente",
			"valor": nombre,
			"mostrar": "@" + nombre,
			"descripcion": descripcion,
			"buscar": nombre.to_lower(),
		})
	return opciones

## Los comandos que entiende el chat: los mismos que atiende
## Chat._on_button_pressed antes de mandar nada al modelo.
static func opcionesComandos() -> Array:
	return [
		{
			"tipo": "comando",
			"valor": "compact",
			"mostrar": "/compact",
			"descripcion": "Summarize the context now",
			"buscar": "compact",
		},
		{
			"tipo": "comando",
			"valor": "agent",
			"mostrar": "/agent",
			"descripcion": "Show or change the active agent: /agent name, /agent off, /agent list",
			"buscar": "agent",
		},
	]

## Todos los archivos y carpetas del proyecto, ya en forma de opcion: es el
## indice en crudo, quien pregunta filtra. El arbol se recorre como mucho una
## vez cada SEGUNDOS_INDICE segundos.
static func opcionesArchivos() -> Array:
	indiceProyecto()
	return _indiceArchivos

## Recorre el proyecto por niveles: primero lo que cuelga de res://, despues lo
## de dentro de cada carpeta, y asi hacia abajo. El orden importa dos veces: al
## escribir "@" a secas se ve lo de arriba (deLaRaiz), y si el proyecto es tan
## grande que no cabe entero, lo que se queda fuera es lo mas hondo, no una parte
## del arbol elegida al azar.
static func indiceProyecto() -> Array:
	var ahora := Time.get_ticks_msec()
	if _indiceListo and ahora - _indiceMsec < SEGUNDOS_INDICE * 1000:
		return _indiceArchivos
	var lista: Array = []
	var pendientes: Array = ["res://"]
	var siguiente := 0
	while siguiente < pendientes.size() and lista.size() < MAX_ENTRADAS:
		var carpeta := str(pendientes[siguiente])
		siguiente += 1
		var dir := DirAccess.open(carpeta)
		if dir == null:
			continue
		dir.list_dir_begin()
		var nombre := dir.get_next()
		while nombre != "" and lista.size() < MAX_ENTRADAS:
			# Nada que empiece por punto: .godot, .git y compania son ruido.
			if nombre.begins_with("."):
				nombre = dir.get_next()
				continue
			var ruta := carpeta.path_join(nombre)
			if dir.current_is_dir():
				lista.append(_opcionArchivo(ruta + "/", true))
				pendientes.append(ruta + "/")
			elif not EXTENSIONES_IGNORADAS.has(ruta.get_extension().to_lower()):
				lista.append(_opcionArchivo(ruta, false))
			nombre = dir.get_next()
		dir.list_dir_end()
	_indiceArchivos = lista
	_indiceListo = true
	_indiceMsec = ahora
	return _indiceArchivos

static func _opcionArchivo(ruta: String, carpeta: bool) -> Dictionary:
	var buscable := ruta.trim_suffix("/").to_lower()
	return {
		"tipo": "archivo",
		"valor": ruta,
		"mostrar": "@" + ruta,
		"descripcion": "folder" if carpeta else "",
		"carpeta": carpeta,
		# Sin la barra final para buscar: el nombre de una carpeta es "pruebas",
		# no "pruebas/", y asi una carpeta se llama igual que el archivo de dentro.
		"buscar": buscable,
		# El nombre suelto se guarda ya hecho: sacarlo en cada busqueda, con el
		# proyecto entero por delante, se nota al teclear.
		"nombre": buscable.get_file(),
	}

## Mezcla las dos familias de opciones. Con la consulta vacia manda el orden
## natural (agentes y comandos primero, despues archivos) y por eso las listas
## llegan ya recortadas. Con consulta encajan las dos y se ordenan por puntos,
## pero las de arriba siguen ganando el sitio: es el corte a MAX_OPCIONES de
## opencode, donde los archivos van detras de todo lo demas.
static func mezclar(noArchivos: Array, archivos: Array, consulta: String, limite: int = MAX_OPCIONES) -> Array:
	if consulta.strip_edges() == "":
		var todo: Array = []
		todo.append_array(noArchivos)
		todo.append_array(archivos)
		return todo.slice(0, limite)
	var piezas := _piezas(consulta)
	var lista: Array = []
	lista.append_array(_puntuadas(noArchivos, piezas, limite))
	lista.append_array(_puntuadas(archivos, piezas, limite))
	return lista.slice(0, limite)

## Lo que no cambia de una opcion a otra: la consulta en minusculas y troceada.
## Se calcula una vez por busqueda y viaja de mano en mano; sacarlo dentro del
## bucle de MAX_ENTRADAS opciones es la diferencia entre teclear fluido y un tiron.
static func _piezas(consulta: String) -> Dictionary:
	var buscada := consulta.to_lower()
	var letras := PackedStringArray()
	for k in range(buscada.length()):
		letras.append(buscada[k])
	return {
		"texto": buscada,
		"largo": buscada.length(),
		"primera": buscada.substr(0, 1),
		"ultima": buscada.substr(buscada.length() - 1, 1),
		"letras": letras,
	}

## Una sola pasada por las opciones, y despues el paso caro solo sobre las que
## pueden necesitarlo. Con la busqueda literal se llena la lista casi siempre y
## el paso caro ni se toca; cuando no la llena, se miran salteadas solo aquellas
## que pasaron el descarte barato.
##
## El bucle esta escrito para no pagar de mas: lo que no cambia de una opcion a
## otra sale fuera, y el descarte va aqui dentro en vez de en una funcion aparte,
## porque una llamada por opcion sobre un proyecto entero es medio segundo de
## teclado congelado. Las coincidencias se apuntan en listas de numeros y las
## mejores se eligen sobre la marcha, sin guardarlas todas ni ordenarlas al
## final: una consulta que encaja con el proyecto entero no puede costar una
## reserva de memoria por archivo.
static func _puntuadas(opciones: Array, piezas: Dictionary, limite: int) -> Array:
	var consulta := str(piezas["texto"])
	var largo := int(piezas["largo"])
	var primera := str(piezas["primera"])
	var ultima := str(piezas["ultima"])
	var letras: PackedStringArray = piezas["letras"]
	var encajan := PackedInt32Array()
	var notas := PackedFloat64Array()
	var candidatas := PackedInt32Array()
	for i in range(opciones.size()):
		var opcion: Dictionary = opciones[i]
		var texto := str(opcion.get("buscar", ""))
		if texto == "":
			texto = str(opcion.get("mostrar", "")).to_lower()
		var nombre := str(opcion.get("nombre", ""))
		if nombre == "":
			nombre = texto.get_file()
		var castigo := texto.length() * 0.01
		var pos := texto.find(consulta)
		var posNombre := nombre.find(consulta)
		var puntos := -1.0
		if posNombre == 0:
			puntos = 1000.0 - castigo
		elif pos == 0:
			puntos = 900.0 - castigo
		elif posNombre > 0:
			puntos = 700.0 - posNombre - castigo
		elif pos > 0:
			puntos = 500.0 - pos - castigo
		if puntos >= 0.0:
			encajan.append(i)
			notas.append(puntos)
			continue
		# Ya hay lista de sobra: no hace falta buscar salteados.
		if encajan.size() >= limite or texto.length() < largo:
			continue
		var inicio := texto.find(primera)
		if inicio < 0 or texto.rfind(ultima) <= inicio:
			continue
		candidatas.append(i)
	if encajan.size() < limite:
		for k in range(candidatas.size()):
			var i := candidatas[k]
			var opcion: Dictionary = opciones[i]
			var texto := str(opcion.get("buscar", ""))
			if texto == "":
				texto = str(opcion.get("mostrar", "")).to_lower()
			var nombre := str(opcion.get("nombre", ""))
			if nombre == "":
				nombre = texto.get_file()
			var salteados := -1.0
			if nombre.length() >= largo and _letrasEnOrden(nombre, letras):
				salteados = 300.0
			elif texto.length() >= largo and _letrasEnOrden(texto, letras):
				salteados = 100.0
			if salteados >= 0.0:
				encajan.append(i)
				notas.append(salteados - texto.length() * 0.01)
	# Las mejores, de mayor a menor. A igualdad de nota gana la que iba antes en
	# la lista, y eso sale solo: el empate no adelanta a nadie.
	var mejores := PackedInt32Array()
	var mejoresNotas := PackedFloat64Array()
	for k in range(encajan.size()):
		var puntos := notas[k]
		var sitio := mejores.size()
		if sitio >= limite and puntos <= mejoresNotas[sitio - 1]:
			continue
		while sitio > 0 and mejoresNotas[sitio - 1] < puntos:
			sitio -= 1
		mejores.insert(sitio, encajan[k])
		mejoresNotas.insert(sitio, puntos)
		if mejores.size() > limite:
			mejores.remove_at(mejores.size() - 1)
			mejoresNotas.remove_at(mejoresNotas.size() - 1)
	var lista: Array = []
	for k in range(mejores.size()):
		lista.append(opciones[mejores[k]])
	return lista

## True si las letras de la consulta salen en el texto, en orden. Cada letra se
## busca desde donde quedo la anterior, con un find nativo: el bucle recorre la
## consulta, que es corta, y no el texto, que es lo que hace que esto se pueda
## permitir sobre un proyecto entero en cada pulsacion.
static func _letrasEnOrden(texto: String, letras: PackedStringArray) -> bool:
	var desde := 0
	for k in range(letras.size()):
		desde = texto.find(letras[k], desde)
		if desde < 0:
			return false
		desde += 1
	return true

## Lo que hay en la raiz del proyecto, que es por donde se empieza a bajar.
## En opencode la lista de archivos viene ordenada por el buscador del proyecto
## (frecuencia de uso, lo que se acaba de tocar); aqui el arbol se recorre en
## orden, asi que al escribir "@" a secas se pintan las carpetas y los archivos
## de arriba: primero lo que se elige de un vistazo, y el resto se busca
## tecleando. Dentro de cada grupo, por nombre, que el orden de recorrido de la
## carpeta no es cosa nuestra.
static func deLaRaiz(entradas: Array, limite: int) -> Array:
	var raiz: Array = []
	for entrada in entradas:
		if _profundidad(str(entrada.get("valor", ""))) == 0:
			raiz.append(entrada)
	raiz.sort_custom(_carpetaPrimero)
	return raiz.slice(0, limite)

static func _carpetaPrimero(a: Dictionary, b: Dictionary) -> bool:
	var carpetaA := bool(a.get("carpeta", false))
	var carpetaB := bool(b.get("carpeta", false))
	if carpetaA != carpetaB:
		return carpetaA
	return str(a.get("valor", "")) < str(b.get("valor", ""))

## res://cuenta/como/uno: los escalones sin contar el "res://".
static func _profundidad(ruta: String) -> int:
	return maxi(0, ruta.trim_prefix("res://").trim_suffix("/").count("/"))

# ---------------------------------------------------------------------------
# El panel
# ---------------------------------------------------------------------------

func configurar(chat: Control, campo: TextEdit, ancla: Control) -> void:
	_chat = chat
	_campo = campo
	_ancla = ancla
	name = "Autocompletado"
	z_index = 100
	visible = false
	mouse_filter = Control.MOUSE_FILTER_STOP
	add_theme_stylebox_override("panel", _estiloPanel())
	_scroll = ScrollContainer.new()
	_scroll.name = "ScrollSugerencias"
	_scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	_scroll.vertical_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	_scroll.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	add_child(_scroll)
	_filas = VBoxContainer.new()
	_filas.name = "FilasSugerencias"
	_filas.add_theme_constant_override("separation", 0)
	_filas.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_scroll.add_child(_filas)

func estaAbierto() -> bool:
	return _modo != ""

## Lo llama el chat en cada text_changed, despues de ajustar la altura del campo.
func alCambiarTexto() -> void:
	if not is_instance_valid(_campo):
		return
	var texto := _campo.text
	var cursor := desplazamientoCursor()
	# El disparador se recalcula en cada pulsacion en vez de fiarse del que abrio
	# la lista: si el texto de delante ya no es la mencion (se borro la arroba, se
	# tacho todo y se escribio otra cosa, se metio un espacio por el medio), la
	# lista se cierra. Es el hide() de opencode, y sin ello una lista de menciones
	# se quedaba abierta encima de un "/comando" recien escrito. Cerrar no corta la
	# pulsacion: debajo se mira si lo nuevo abre otra lista, que es justo el caso
	# de pasar de "@" a "/".
	if _modo != "" and not _sigueElDisparador(texto, cursor):
		ocultar()
	if _modo != "":
		_calcular()
		return
	if cursor == 0:
		return
	if texto.begins_with("/") and not tieneEspacio(texto.substr(0, cursor)):
		_mostrar("/", 0)
		return
	var pos := indiceMencion(texto, cursor)
	if pos >= 0:
		_mostrar("@", pos)

## True si lo que hay delante del cursor sigue siendo el disparador de la lista
## que esta abierta.
func _sigueElDisparador(texto: String, cursor: int) -> bool:
	if _modo == "/":
		return texto.begins_with("/") and not tieneEspacio(texto.substr(0, cursor))
	if cursor <= _indice:
		return false
	if tieneEspacio(texto.substr(_indice, cursor - _indice)):
		return false
	return indiceMencion(texto, cursor) == _indice

## Teclas del panel. Devuelve true si la tecla era suya y el campo no debe verla.
func procesarTecla(evento: InputEvent) -> bool:
	if _modo == "" or not (evento is InputEventKey) or not evento.pressed:
		return false
	var tecla := evento as InputEventKey
	var codigo := tecla.keycode
	var control := tecla.ctrl_pressed or tecla.meta_pressed
	if codigo == KEY_ESCAPE:
		ocultar()
		return true
	if codigo == KEY_UP or (control and codigo == KEY_P):
		_mover(-1)
		return true
	if codigo == KEY_DOWN or (control and codigo == KEY_N):
		_mover(1)
		return true
	# En Android el Enter es la tecla de escribir, no la de elegir (ver Chat.
	# _procesarEntradaCampoTexto): ahi se elige tocando la fila.
	if OS.get_name() == "Android":
		return false
	if codigo == KEY_TAB:
		if bool(_opcionSeleccionada().get("carpeta", false)):
			_entrarEnCarpeta()
			return true
		return _elegir()
	if codigo == KEY_ENTER or codigo == KEY_KP_ENTER or tecla.unicode == 10 or tecla.unicode == 13:
		return _elegir()
	return false

## Cierra la lista. En modo "/" la linea se va con ella cuando el comando esta a
## medias: "/compact" sin su espacio final no es un mensaje, y dejarlo ahi seria
## mandarle al modelo un texto que el usuario no escribio. Borra hasta el cursor,
## como el hide() de opencode, no la linea entera.
func ocultar() -> void:
	if _modo == "/" and is_instance_valid(_campo):
		var texto := _campo.text
		if texto.begins_with("/") and not texto.ends_with(" "):
			_campo.text = texto.substr(mini(desplazamientoCursor(), texto.length()))
			ponerCursor(0)
	_modo = ""
	_seleccionado = 0
	_opciones = []
	visible = false

## El chat cambio de tamano (o el panel de tareas aparecio y empujo la caja de
## texto): la lista se vuelve a pegar a su sitio.
func reposicionar() -> void:
	if visible:
		_pintar()

# ---------------------------------------------------------------------------
# Por dentro
# ---------------------------------------------------------------------------

func _mostrar(modo: String, indice: int) -> void:
	_modo = modo
	_indice = indice
	_calcular()

func _calcular() -> void:
	var consulta := _consulta()
	if _modo == "/":
		_opciones = mezclar(opcionesComandos(), [], consulta)
	else:
		var archivos := opcionesArchivos()
		if consulta.strip_edges() == "":
			archivos = deLaRaiz(archivos, MAX_OPCIONES)
		_opciones = mezclar(opcionesAgentes(), archivos, consulta)
	_seleccionado = 0
	_pintar()

func _consulta() -> String:
	var cursor := desplazamientoCursor()
	if cursor <= _indice:
		return ""
	return _campo.text.substr(_indice + 1, cursor - _indice - 1)

func _opcionSeleccionada() -> Dictionary:
	if _seleccionado < 0 or _seleccionado >= _opciones.size():
		return {}
	return _opciones[_seleccionado]

func _pintar() -> void:
	if not is_instance_valid(_filas) or not is_instance_valid(_ancla):
		return
	for hijo in _filas.get_children():
		_filas.remove_child(hijo)
		hijo.queue_free()
	if _opciones.is_empty():
		_filas.add_child(_crearFila("No matching items", "", -1))
	else:
		for i in range(_opciones.size()):
			var opcion: Dictionary = _opciones[i]
			_filas.add_child(_crearFila(
				recortarMedio(str(opcion.get("mostrar", ""))),
				recortarMedio(str(opcion.get("descripcion", "")), int(LARGO_FILA / 2.0)),
				i))
	size = Vector2(maxf(ANCHO_MINIMO, _ancla.size.x), _alto(altoFila()))
	position = Vector2(
		_ancla.global_position.x - _chat.global_position.x,
		maxf(0.0, _ancla.global_position.y - _chat.global_position.y - size.y - 4))
	visible = true
	_verSeleccionada()

## Alto real de una fila. ALTO_FILA es solo el suelo (`custom_minimum_size`): el
## alto de verdad lo pone la fuente del tema a traves de las etiquetas de dentro,
## que en el editor son unos 25 px. Se mide una vez con una fila de mentira y se
## guarda: con el suelo, el panel se quedaba corto al calcular cuantas filas caben
## y en una ventana bajita se salia por arriba en vez de recortar la lista.
## Se mide con la fila ya dentro de _filas, que es de donde le llega el tema.
func altoFila() -> float:
	if _altoFila > 0.0:
		return _altoFila
	if not is_instance_valid(_filas):
		return float(ALTO_FILA)
	var sonda := _crearFila("M", "", -1)
	_filas.add_child(sonda)
	_altoFila = maxf(float(ALTO_FILA), sonda.get_combined_minimum_size().y)
	_filas.remove_child(sonda)
	sonda.free()
	return _altoFila

## Alto en pixeles: manda el numero de filas, pero nunca mas de las que caben
## entre la caja de texto y el borde de arriba del panel. Es el min(10, count,
## anchor.y) de opencode.
func _alto(altoFila: float) -> int:
	var sitio := _ancla.global_position.y - _chat.global_position.y
	if sitio <= 0.0:
		sitio = MAX_FILAS * altoFila
	var filas := mini(MAX_FILAS, maxi(1, _opciones.size()))
	var caben := maxi(1, int(sitio / altoFila))
	return int(mini(filas, caben) * altoFila) + MARGEN * 2

func _crearFila(mostrar: String, descripcion: String, indice: int) -> Control:
	var fila := PanelContainer.new()
	fila.name = "Fila%d" % indice
	fila.custom_minimum_size = Vector2(0, ALTO_FILA)
	fila.mouse_filter = Control.MOUSE_FILTER_STOP
	fila.add_theme_stylebox_override("panel", _estiloFila(indice == _seleccionado and indice >= 0))
	var caja := HBoxContainer.new()
	caja.add_theme_constant_override("separation", 8)
	caja.mouse_filter = Control.MOUSE_FILTER_IGNORE
	fila.add_child(caja)
	var etiqueta := Label.new()
	etiqueta.text = mostrar
	etiqueta.clip_text = true
	etiqueta.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	etiqueta.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	etiqueta.mouse_filter = Control.MOUSE_FILTER_IGNORE
	etiqueta.add_theme_color_override("font_color",
		ChatEstilos.COLOR_TEXTO_PRIMARIO if indice >= 0 else ChatEstilos.COLOR_TEXTO_TENUE)
	caja.add_child(etiqueta)
	if descripcion != "":
		var ayuda := Label.new()
		ayuda.text = descripcion
		ayuda.clip_text = true
		ayuda.text_overrun_behavior = TextServer.OVERRUN_TRIM_ELLIPSIS
		ayuda.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		ayuda.size_flags_vertical = Control.SIZE_SHRINK_CENTER
		ayuda.mouse_filter = Control.MOUSE_FILTER_IGNORE
		ayuda.add_theme_color_override("font_color", ChatEstilos.COLOR_TEXTO_TENUE)
		caja.add_child(ayuda)
	if indice >= 0:
		fila.gui_input.connect(_alPulsarFila.bind(indice))
	return fila

func _alPulsarFila(evento: InputEvent, indice: int) -> void:
	var clic := evento as InputEventMouseButton
	if clic == null or not clic.pressed or clic.button_index != MOUSE_BUTTON_LEFT:
		return
	_seleccionado = indice
	_marcar()
	_elegir()

func _mover(direccion: int) -> void:
	if _opciones.is_empty():
		return
	var siguiente := _seleccionado + direccion
	if siguiente < 0:
		siguiente = _opciones.size() - 1
	elif siguiente >= _opciones.size():
		siguiente = 0
	_seleccionado = siguiente
	_marcar()
	_verSeleccionada()

func _marcar() -> void:
	var i := 0
	for hijo in _filas.get_children():
		hijo.add_theme_stylebox_override("panel", _estiloFila(i == _seleccionado))
		i += 1

func _verSeleccionada() -> void:
	if _seleccionado < 0 or _seleccionado >= _filas.get_child_count():
		return
	_scroll.call_deferred("ensure_control_visible", _filas.get_child(_seleccionado))

## Elige la fila marcada. Devuelve false si no habia nada que elegir: entonces
## la tecla sigue su camino y el campo la trata como siempre.
func _elegir() -> bool:
	var opcion := _opcionSeleccionada()
	if opcion.is_empty():
		ocultar()
		return false
	var tipo := str(opcion.get("tipo", ""))
	var valor := str(opcion.get("valor", ""))
	ocultar()
	if tipo == "comando":
		_insertarComando(valor)
	else:
		_insertarMencion(valor)
	if tipo == "archivo" and not bool(opcion.get("carpeta", false)):
		archivoMencionado.emit(valor)
	return true

## Tab sobre una carpeta: en vez de elegirla se entra en ella y la lista sigue
## abierta con lo que hay dentro. Es el expandDirectory de opencode.
func _entrarEnCarpeta() -> void:
	var opcion := _opcionSeleccionada()
	if opcion.is_empty():
		return
	var indice := _indice
	var ruta := str(opcion.get("valor", "")).trim_suffix("/")
	var cursor := desplazamientoCursor()
	_campo.text = _campo.text.substr(0, indice) + "@" + ruta + "/" + _campo.text.substr(cursor)
	ponerCursor(indice + ruta.length() + 2)
	_mostrar("@", indice)

## Deja "@nombre " donde estaba lo que se escribia, con un espacio detras si no
## lo habia ya: el mismo hueco que deja opencode al insertar.
func _insertarMencion(valor: String) -> void:
	var texto := _campo.text
	var cursor := mini(desplazamientoCursor(), texto.length())
	var siguiente := "" if cursor >= texto.length() else texto.substr(cursor, 1)
	var pegado := "@" + valor + (" " if siguiente != " " else "")
	_campo.text = texto.substr(0, _indice) + pegado + texto.substr(cursor)
	ponerCursor(_indice + pegado.length())

## "/comando " al principio: se lleva por delante lo que hubiera antes del
## cursor, que en el modo "/" es el comando a medio escribir.
func _insertarComando(valor: String) -> void:
	var texto := _campo.text
	var cursor := mini(desplazamientoCursor(), texto.length())
	var pegado := "/" + valor + " "
	_campo.text = pegado + texto.substr(cursor)
	ponerCursor(pegado.length())

## Desplazamiento del cursor contando el texto entero, no la linea: es lo que
## usan todas las reglas de arriba, que vienen de un campo de una sola tirada.
func desplazamientoCursor() -> int:
	if not is_instance_valid(_campo):
		return 0
	var linea := _campo.get_caret_line()
	var total := _campo.get_caret_column()
	for i in range(linea):
		total += _campo.get_line(i).length() + 1
	return total

func ponerCursor(desplazamiento: int) -> void:
	if not is_instance_valid(_campo):
		return
	var texto := _campo.text
	var d := clampi(desplazamiento, 0, texto.length())
	var linea := 0
	var inicio := 0
	while true:
		var salto := texto.find("\n", inicio)
		if salto < 0 or salto >= d:
			break
		linea += 1
		inicio = salto + 1
	_campo.set_caret_line(linea, false, true, 0)
	_campo.set_caret_column(d - inicio)

func _estiloPanel() -> StyleBoxFlat:
	var fondo := StyleBoxFlat.new()
	fondo.bg_color = Color(0.105, 0.105, 0.105, 0.99)
	fondo.border_color = Color(0.22, 0.22, 0.22, 0.95)
	fondo.set_border_width_all(1)
	fondo.set_corner_radius_all(3)
	fondo.content_margin_left = MARGEN
	fondo.content_margin_right = MARGEN
	fondo.content_margin_top = MARGEN
	fondo.content_margin_bottom = MARGEN
	return fondo

func _estiloFila(elegida: bool) -> StyleBoxFlat:
	var estilo := StyleBoxFlat.new()
	estilo.bg_color = Color(0.18, 0.18, 0.18, 0.95) if elegida else Color(0, 0, 0, 0)
	estilo.set_corner_radius_all(2)
	estilo.content_margin_left = 6
	estilo.content_margin_right = 6
	estilo.content_margin_top = 1
	estilo.content_margin_bottom = 1
	return estilo
