@tool
class_name ChatParseador
extends RefCounted

static func normalizarNombreHerramienta(nombre: String) -> String:
	return nombre.to_lower().replace("_", "").replace("-", "").replace(" ", "")

## Los argumentos llegan de JSON: un booleano es un bool (no una cadena), un numero
## es float y una clave presente con null vale null. Llamar .to_lower() o .to_int()
## sobre esos valores revienta el editor ("Nonexistent function 'to_lower' in base
## 'bool'"). Estas ayudas aceptan cualquier forma y, si el valor falta o no se
## puede interpretar, devuelven el valor por defecto en vez de fallar.
static func textoDe(args: Dictionary, clave: String, porDefecto: String = "") -> String:
	if not args.has(clave):
		return porDefecto
	var valor = args[clave]
	if valor == null:
		return porDefecto
	if valor is String:
		return valor
	if valor is bool:
		return "true" if valor else "false"
	return str(valor)

## Un valor ausente o nulo toma el valor por defecto; una cadena vacia tambien.
## Se aceptan las formas que suelen escribir los modelos: true/false, 1/0,
## yes/no, on/off (sin distinguir mayusculas).
static func booleanoDe(args: Dictionary, clave: String, porDefecto: bool = false) -> bool:
	if not args.has(clave):
		return porDefecto
	var valor = args[clave]
	if valor == null:
		return porDefecto
	if valor is bool:
		return valor
	if valor is float or valor is int:
		return float(valor) != 0.0
	var texto := str(valor).strip_edges().to_lower()
	if texto == "":
		return porDefecto
	return not (texto == "false" or texto == "0" or texto == "no" or texto == "off")

static func enteroDe(args: Dictionary, clave: String, porDefecto: int = 0) -> int:
	if not args.has(clave):
		return porDefecto
	var valor = args[clave]
	if valor == null:
		return porDefecto
	if valor is bool:
		return 1 if valor else 0
	if valor is float or valor is int:
		return int(valor)
	var texto := str(valor).strip_edges()
	if texto.is_valid_int():
		return texto.to_int()
	if texto.is_valid_float():
		return int(texto.to_float())
	return porDefecto

static func resolverNombreHerramienta(nombre: String, herramientas: Dictionary) -> String:
	if herramientas.has(nombre):
		return nombre
	var normalizado := normalizarNombreHerramienta(nombre)
	for clave in herramientas:
		if normalizarNombreHerramienta(clave) == normalizado:
			return clave
	return ""

## El modelo a veces emite tokens literales "null" o "<null>" al inicio de la
## respuesta (fuga de JSON; el RichTextLabel ademas se come los corchetes y
## muestra "null"). Se elimina esa corrida lider. Las palabras reales en
## minusculas ("nullable", "nullify") no se tocan: "null" solo se consume si
## le sigue fin, espacio, otro "null"/"<null>" o mayuscula/puntuacion.
## "<null>" es autodeterminado y siempre se consume.
static func limpiarNulosLideres(texto: String) -> String:
	var i := 0
	var n := texto.length()
	while i < n:
		while i < n and texto.substr(i, 1) in " \t\r\n":
			i += 1
		if i + 6 <= n and texto.substr(i, 6) == "<null>":
			i += 6
			continue
		if i + 4 <= n and texto.substr(i, 4) == "null":
			var fin := i + 4
			if fin == n:
				i = fin
				continue
			var sig := texto.substr(fin, 1)
			if sig in " \t\r\n" or texto.substr(fin, 4) == "null" or texto.substr(fin, 6) == "<null>" or sig == sig.to_upper():
				i = fin
				continue
		break
	return texto.substr(i)

static func extraerCandidatosJson(contenido: String) -> Array[String]:
	var candidatos: Array[String] = []
	var posAbre := contenido.find("{")
	var posCierre := contenido.rfind("}")
	if posAbre != -1 and posCierre > posAbre:
		candidatos.append(contenido.substr(posAbre, posCierre - posAbre + 1))
	var pos := 0
	while true:
		var ini := contenido.find("```", pos)
		if ini == -1:
			break
		var finLinea := contenido.find("\n", ini + 3)
		if finLinea == -1:
			break
		var fin := contenido.find("```", finLinea + 1)
		if fin == -1:
			break
		var dentro := contenido.substr(finLinea + 1, fin - finLinea - 1).strip_edges()
		var da := dentro.find("{")
		var dc := dentro.rfind("}")
		if da != -1 and dc > da:
			candidatos.append(dentro.substr(da, dc - da + 1))
		pos = fin + 3
	return candidatos

static func detectarToolCall(contenido: String, herramientas: Dictionary) -> String:
	for candidato in extraerCandidatosJson(contenido):
		var j := JSON.new()
		if j.parse(candidato) != OK:
			continue
		var d = j.get_data()
		if typeof(d) != TYPE_DICTIONARY:
			continue
		var nombre: String = d.get("tool", "")
		if nombre == "":
			continue
		if typeof(d.get("args", null)) != TYPE_DICTIONARY:
			continue
		if resolverNombreHerramienta(nombre, herramientas) != "":
			return candidato
	return ""

static func esContenidoToolCall(contenido: String, herramientas: Dictionary) -> bool:
	if not extraerPreguntaJson(contenido).is_empty():
		return false
	if detectarToolCall(contenido, herramientas) != "":
		return true
	for candidato in extraerCandidatosJson(contenido):
		var j := JSON.new()
		if j.parse(candidato) != OK:
			continue
		var d = j.get_data()
		if typeof(d) != TYPE_DICTIONARY:
			continue
		if d.get("tool", "") != "" and typeof(d.get("args", null)) == TYPE_DICTIONARY:
			return true
	return false

static func detectarIntentoToolInvalido(contenido: String, herramientas: Dictionary) -> String:
	for candidato in extraerCandidatosJson(contenido):
		var j := JSON.new()
		if j.parse(candidato) != OK:
			continue
		var d = j.get_data()
		if typeof(d) != TYPE_DICTIONARY:
			continue
		var nombre: String = d.get("tool", "")
		if nombre == "":
			continue
		if typeof(d.get("args", null)) != TYPE_DICTIONARY:
			continue
		if resolverNombreHerramienta(nombre, herramientas) == "":
			return nombre
	return ""

## Reconoce la pregunta que algunos modelos mandan como TEXTO en vez de llamar a la
## herramienta "Ask user": la forma {"type":"question","question":...,"options":[...]}
## y la que usa los nombres de la tool ("pregunta"/"opciones"). Devuelve
## {pregunta, opciones} o {} si el texto no es una pregunta.
static func extraerPreguntaJson(contenido: String) -> Dictionary:
	var vacio := {}
	var texto := contenido.strip_edges()
	if texto == "":
		return vacio
	if texto.begins_with("```"):
		var sin_inicio := texto
		var salto := sin_inicio.find("\n")
		if salto >= 0:
			sin_inicio = sin_inicio.substr(salto + 1)
		var cierre := sin_inicio.rfind("```")
		if cierre >= 0:
			sin_inicio = sin_inicio.substr(0, cierre)
		texto = sin_inicio.strip_edges()
	var inicio := texto.find("{")
	var fin := texto.rfind("}")
	if inicio < 0 or fin <= inicio:
		return vacio
	var bruto := texto.substr(inicio, fin - inicio + 1)
	var j := JSON.new()
	if j.parse(bruto) != OK:
		return vacio
	var d = j.get_data()
	if typeof(d) != TYPE_DICTIONARY:
		return vacio
	var tipo := String(d.get("type", "")).to_lower()
	if tipo != "" and tipo != "question":
		return vacio
	# Sin "type" solo vale si el JSON es TODO el contenido: asi no se convierte en
	# tarjeta un ejemplo de codigo que el modelo este ensenando.
	if tipo == "" and (inicio != 0 or fin != texto.length() - 1):
		return vacio
	var pregunta := String(d.get("question", d.get("pregunta", ""))).strip_edges()
	var crudas = d.get("options", d.get("opciones", []))
	if pregunta == "" or typeof(crudas) != TYPE_ARRAY or (crudas as Array).is_empty():
		return vacio
	var opciones: Array = []
	for o in crudas:
		var s := String(o).strip_edges()
		if s != "":
			opciones.append(s)
	if opciones.is_empty():
		return vacio
	return {"pregunta": pregunta, "opciones": opciones}

## Aviso temprano para el stream: con el texto a medias todavia no se puede parsear
## el JSON, pero si se ve que va a acabar siendo una pregunta no conviene pintar el
## crudo en el chat (al completarse lo sustituye la tarjeta de opciones).
static func parecePreguntaJson(texto: String) -> bool:
	var cabeza := texto.strip_edges()
	if cabeza.begins_with("```"):
		var salto := cabeza.find("\n")
		if salto < 0:
			return true # Cerca abierta sin contenido todavia: no hay nada que pintar.
		cabeza = cabeza.substr(salto + 1).strip_edges()
	if not cabeza.begins_with("{"):
		return false
	var trozo := cabeza.substr(0, mini(cabeza.length(), 400)).to_lower()
	if trozo.contains("\"question\"") or trozo.contains("\"pregunta\"") or trozo.contains("\"options\"") or trozo.contains("\"opciones\""):
		return true
	# JSON corto y sin cerrar: puede ser la pregunta. Se espera a saberlo.
	return cabeza.length() < 40 and not trozo.contains("}")

static func extraerOpcionesRapidas(contenido: String) -> Array:
	var datos := extraerPreguntaJson(contenido)
	if datos.is_empty():
		return []
	return datos.get("opciones", [])

static func quitarMarcadorOpciones(contenido: String) -> String:
	return contenido.strip_edges()

static func buscarCorteSeguro(texto: String, ini: int, fin: int, total: int) -> int:
	if fin >= total:
		return total
	var ventanaMax: int = mini(fin + 200, total)
	var cortes := ["\n\n", "\n", ". ", " "]
	for sep in cortes:
		var pos := texto.find(sep, fin)
		if pos != -1 and pos < ventanaMax:
			return pos + sep.length()
	return fin
