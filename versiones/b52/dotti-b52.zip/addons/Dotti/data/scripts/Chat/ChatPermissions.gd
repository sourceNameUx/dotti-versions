@tool
class_name ChatPermisos
extends RefCounted

const PERMISOS_PREGUNTAR := 0
const PERMISOS_AUTOMATICOS := 1
const PERMISOS_TODOS := 2
const CONFIG_PATH := "user://permisos_herramientas.cfg"

static func cargarConfig() -> ConfigFile:
	var cfg := ConfigFile.new()
	cfg.load(CONFIG_PATH)
	return cfg

static func obtenerModo() -> int:
	var cfg := cargarConfig()
	return int(cfg.get_value("permisos", "modo", PERMISOS_AUTOMATICOS))

static func guardarModo(modo: int) -> void:
	var cfg := cargarConfig()
	cfg.set_value("permisos", "modo", modo)
	cfg.save(CONFIG_PATH)

static func obtenerHerramientasPermitidas() -> Array:
	var cfg := cargarConfig()
	var lista = cfg.get_value("permisos", "herramientas_permitidas", [])
	if typeof(lista) != TYPE_ARRAY:
		return []
	var salida: Array = []
	for item in lista:
		salida.append(str(item))
	return salida
