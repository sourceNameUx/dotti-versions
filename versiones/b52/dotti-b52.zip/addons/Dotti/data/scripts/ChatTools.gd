class_name HerramientasChat

static func registrarTodas(chat: Node) -> void:
	HerramientasArchivos.registrar(chat)
	HerramientasEscenas.registrar(chat)
	HerramientasEditorScripts.registrar(chat)
	HerramientasNodos.registrar(chat)
	HerramientasControlEditor.registrar(chat)
	HerramientasProyecto.registrar(chat)
	HerramientasRecursos.registrar(chat)
	HerramientasPregunta.registrar(chat)
	HerramientasCopias.registrar(chat)
	HerramientasImagenes.registrar(chat)
	HerramientasTareas.registrar(chat)
	HerramientasSkills.registrar(chat)
	HerramientasSubagentes.registrar(chat)
