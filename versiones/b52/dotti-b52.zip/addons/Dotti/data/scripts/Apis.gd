class_name Apis
extends RefCounted

const RUTA_ARCHIVO := "user://meteor_ia_config.cfg"

# Todo lo que Dotti ofrece lo sirve dotti-proxy (ver proxy/README.md): la
# pasarela inyecta la identidad de cliente que exige el upstream, salta las keys
# que se quedan sin saldo, aplica el limite diario de la cuenta y anota el gasto.
# Dotti solo tiene que apuntar a ella como un proveedor tipo "openai".
#
# La direccion del producto esta aqui, en una linea: el dia que la pasarela tenga
# su direccion de verdad, se cambia esto y todos los plugins la adoptan. Hoy
# apunta a la pasarela local, que es la misma pieza corriendo en este equipo. El
# usuario puede apuntar a otra desde los ajustes, y esa eleccion se guarda en
# `user://dotti_sesion.cfg`, no aqui.
const URL_OFICIAL := "http://127.0.0.1:8080"

# Nombres anteriores de la misma base: los llevan escritos las configuraciones
# que ya existen, y se siguen leyendo.
const PROXY_PRUEBA_NOMBRE := "Dotti Proxy Local"
const PROXY_PRUEBA_URL := URL_OFICIAL
const PROXY_PRUEBA_API_KEY := "proxy"
const MODELO_PRUEBA_ID := "deepseek-v4-flash"
const MODELO_PRUEBA_NOMBRE := "DeepSeek V4 Flash"
const MODELO_PRUEBA_NOMBRE_LEGADO := "DeepSeek V4 Flash (prueba)"
const MODELO_MAX_TOKENS := 65536
const NIVEL_RAZONAMIENTO_POR_DEFECTO := "high"

## Catalogo de casa: los modelos que Dotti conoce aunque no haya podido
## preguntar. El que manda es el del servidor -lo llena el administrador desde el
## panel y lo trae `ChatModelos.idsServidos`-, y esto solo es el respaldo para
## cuando no hay red; por eso sigue escrito aqui.
##
## Dotti ya no es open source y el usuario no puede traer modelos de terceros:
## todo proveedor o base que no salga de este catalogo se purga al cargar la
## configuracion (ver cargar_proveedores).
const MODELOS_OFICIALES := {
	MODELO_PRUEBA_ID: MODELO_PRUEBA_NOMBRE,
}

var proveedores: Array = []
var proveedores_base: Array = []
var proveedor_actual_id: String = ""

func _init() -> void:
	# El catalogo del servidor se lee antes de decidir que modelos oficiales
	# existen: si el administrador anadio uno en el panel, el plugin tiene que
	# ofrecerlo ya, sin esperar a que conteste nadie.
	ChatModelos.cargarCatalogoGuardado()
	cargar_proveedores()
	_asegurar_modelos_oficiales()
	cargar_proveedores()

# Garantiza que la base del proxy y cada modelo del catalogo oficial existan,
# incluso en configuraciones ya creadas. Solo agrega lo que falta, nunca borra
# ni cambia el proveedor actual.
func _asegurar_modelos_oficiales() -> void:
	var base_id := ""
	for b in proveedores_base:
		if _es_base_oficial(b):
			base_id = str(b.get("id", ""))
			break
	var direccion := Sesion.unica().direccionActual()
	if base_id == "":
		base_id = agregar_proveedor_base({
			"nombre": PROXY_PRUEBA_NOMBRE,
			"tipo": "openai",
			"base_url": direccion,
			"api_key": PROXY_PRUEBA_API_KEY,
			"oficial": true
		})
	else:
		# La base oficial sigue a la direccion de la cuenta. La bandera es lo que
		# la hace reconocible cuando la direccion deja de ser la de casa.
		var base := obtener_proveedor_base(base_id)
		if str(base.get("base_url", "")).rstrip("/") != direccion.rstrip("/") or not bool(base.get("oficial", false)):
			base["base_url"] = direccion
			base["oficial"] = true
			actualizar_proveedor_base(base_id, base)
	for model_id in ChatModelos.idsServidos():
		_asegurar_proveedor_oficial(str(model_id), base_id)
	if proveedor_actual_id == "" and not proveedores.is_empty():
		proveedor_actual_id = str(proveedores[0].get("id", ""))
		guardar_proveedores()

## Vuelve a leer la direccion de la cuenta y la lleva a la base oficial. Lo
## llama la pestana de la cuenta al guardar una direccion nueva.
func refrescarDireccionOficial() -> void:
	_asegurar_modelos_oficiales()
	cargar_proveedores()

## Adopta el catalogo que acaba de contestar la pasarela: se guarda para la
## proxima vez y se crea un proveedor por cada modelo que no estuviera, sin tocar
## el que el usuario tiene elegido. Lo llama la pestana de la cuenta al entrar y
## al refrescar.
func adoptarCatalogo(modelos: Array) -> void:
	ChatModelos.aplicarCatalogo(modelos)
	_asegurar_modelos_oficiales()
	cargar_proveedores()

func _asegurar_proveedor_oficial(model_id: String, base_id: String) -> void:
	for p in proveedores:
		if str(p.get("model_id", "")) == model_id and str(p.get("base_id", "")) == base_id:
			# Migraciones del proveedor automatico: nombre sin "(prueba)" y
			# tope de salida serio (solo si conserva los valores originales).
			var migrado := (p as Dictionary).duplicate()
			var toca := false
			if str(migrado.get("nombre", "")) == MODELO_PRUEBA_NOMBRE_LEGADO:
				migrado["nombre"] = ChatModelos.etiqueta(model_id)
				toca = true
			if int(migrado.get("max_tokens", 0)) == 8192:
				migrado["max_tokens"] = MODELO_MAX_TOKENS
				toca = true
			if toca:
				actualizar_proveedor(str(p.get("id", "")), migrado)
			return
	agregar_proveedor({
		"nombre": ChatModelos.etiqueta(model_id),
		"base_id": base_id,
		"model_id": model_id,
		"api_key": "",
		"max_tokens": MODELO_MAX_TOKENS
	})

# Una base es oficial si lleva la bandera. Las configuraciones anteriores a la
# bandera no la llevan, asi que se reconocen por su direccion, que era la unica
# del producto.
func _es_base_oficial(b: Dictionary) -> bool:
	if bool(b.get("oficial", false)):
		return true
	return str(b.get("base_url", "")).rstrip("/") == URL_OFICIAL and str(b.get("tipo", "")) == "openai"

# Un proveedor es oficial si su modelo esta en el catalogo y cuelga de una base
# oficial. Cualquier otra combinacion (modelos de terceros, bases propias) se
# considera traida por el usuario y se descarta.
func _es_proveedor_oficial(p: Dictionary, bases: Array) -> bool:
	# La lista de modelos servidos la manda el servidor cuando se le ha podido
	# preguntar; sin catalogo contesta la de casa.
	if not ChatModelos.idsServidos().has(str(p.get("model_id", "")).strip_edges().to_lower()):
		return false
	var base_id := str(p.get("base_id", ""))
	if base_id == "":
		return false
	for b in bases:
		if str(b.get("id", "")) == base_id:
			return true
	return false

func _existe_id(lista: Array, id: String) -> bool:
	if id == "":
		return false
	for item in lista:
		if str(item.get("id", "")) == id:
			return true
	return false

func cargar_proveedores() -> void:
	var config := ConfigFile.new()
	if config.load(RUTA_ARCHIVO) != OK:
		proveedores = []
		proveedores_base = []
		proveedor_actual_id = ""
		return
	var crudo_prov: Array = config.get_value("providers", "list", [])
	var crudo_base: Array = config.get_value("providers_base", "list", [])
	var actual: String = str(config.get_value("providers", "current", ""))
	# La config es un archivo de texto que cualquiera puede editar a mano, asi
	# que el filtro de catalogo se aplica en cada carga, no solo al inicializar.
	proveedores_base = []
	for b in crudo_base:
		if _es_base_oficial(b):
			proveedores_base.append(b)
	proveedores = []
	for p in crudo_prov:
		if _es_proveedor_oficial(p, proveedores_base):
			proveedores.append(p)
	proveedor_actual_id = actual
	var purgado: bool = proveedores.size() != crudo_prov.size() or proveedores_base.size() != crudo_base.size()
	if not _existe_id(proveedores, proveedor_actual_id):
		proveedor_actual_id = str(proveedores[0].get("id", "")) if not proveedores.is_empty() else ""
		purgado = true
	if purgado:
		guardar_proveedores()

func guardar_proveedores() -> void:
	var config := ConfigFile.new()
	config.load(RUTA_ARCHIVO)
	config.set_value("providers", "list", proveedores)
	config.set_value("providers", "current", proveedor_actual_id)
	config.set_value("providers_base", "list", proveedores_base)
	config.save(RUTA_ARCHIVO)

func agregar_proveedor(datos: Dictionary) -> String:
	var id = str(Time.get_unix_time_from_system()) + "_" + str(randi())
	var nuevo = datos.duplicate()
	nuevo["id"] = id
	proveedores.append(nuevo)
	if proveedor_actual_id == "":
		proveedor_actual_id = id
	guardar_proveedores()
	return id

func actualizar_proveedor(id: String, datos: Dictionary) -> bool:
	for i in range(proveedores.size()):
		if proveedores[i]["id"] == id:
			var actualizado = datos.duplicate()
			actualizado["id"] = id
			proveedores[i] = actualizado
			guardar_proveedores()
			return true
	return false

func eliminar_proveedor(id: String) -> void:
	for i in range(proveedores.size()):
		if proveedores[i]["id"] == id:
			proveedores.remove_at(i)
			if proveedor_actual_id == id:
				proveedor_actual_id = proveedores[0]["id"] if proveedores.size() > 0 else ""
			guardar_proveedores()
			break

func obtener_proveedor(id: String) -> Dictionary:
	for p in proveedores:
		if p["id"] == id:
			return _resolver_proveedor(p)
	return {}

func obtener_proveedor_raw(id: String) -> Dictionary:
	for p in proveedores:
		if p["id"] == id:
			return p
	return {}

func _resolver_proveedor(p: Dictionary) -> Dictionary:
	var resuelto := p.duplicate()
	var base_id: String = str(p.get("base_id", ""))
	if base_id != "":
		var base := obtener_proveedor_base(base_id)
		if not base.is_empty():
			resuelto["tipo"] = base.get("tipo", resuelto.get("tipo", ""))
			resuelto["base_url"] = base.get("base_url", resuelto.get("base_url", ""))
			resuelto["base_nombre"] = base.get("nombre", "")
			resuelto["oficial"] = _es_base_oficial(base)
			if resuelto.get("api_key", "") == "":
				resuelto["api_key"] = base.get("api_key", "")
	# El token de la cuenta es la credencial de la base oficial, y se lee aqui, en
	# cada peticion, en vez de guardarse en la configuracion: asi vive solo en
	# `user://dotti_sesion.cfg`, que es su sitio, y al salir de la cuenta deja de
	# valer en el acto. Sin cuenta se deja lo que hubiera: la pasarela local del
	# banco de pruebas no pide credencial, y la de produccion contesta
	# `auth_required`, que ya se traduce a "entra desde los ajustes".
	if bool(resuelto.get("oficial", false)):
		var sesion := Sesion.unica()
		if sesion.estaDentro():
			resuelto["api_key"] = sesion.token
	return resuelto

func obtener_proveedor_actual() -> Dictionary:
	return obtener_proveedor(proveedor_actual_id)

func establecer_proveedor_actual(id: String) -> void:
	if id == "":
		return
	for p in proveedores:
		if p["id"] == id:
			proveedor_actual_id = id
			guardar_proveedores()
			return

func obtener_api_key(id: String) -> String:
	for p in proveedores:
		if p["id"] == id:
			return p.get("api_key", "")
	return ""

func obtener_proveedor_base(id: String) -> Dictionary:
	for b in proveedores_base:
		if b.get("id", "") == id:
			return b
	return {}

func agregar_proveedor_base(datos: Dictionary) -> String:
	var id = "base_" + str(Time.get_unix_time_from_system()) + "_" + str(randi())
	var nuevo = datos.duplicate()
	nuevo["id"] = id
	proveedores_base.append(nuevo)
	guardar_proveedores()
	return id

func actualizar_proveedor_base(id: String, datos: Dictionary) -> bool:
	for i in range(proveedores_base.size()):
		if proveedores_base[i].get("id", "") == id:
			var actualizado = datos.duplicate()
			actualizado["id"] = id
			proveedores_base[i] = actualizado
			guardar_proveedores()
			return true
	return false

func eliminar_proveedor_base(id: String) -> bool:
	for p in proveedores:
		if str(p.get("base_id", "")) == id:
			return false
	for i in range(proveedores_base.size()):
		if proveedores_base[i].get("id", "") == id:
			proveedores_base.remove_at(i)
			guardar_proveedores()
			return true
	return false

func obtener_configuracion_chat() -> Dictionary:
	var config := ConfigFile.new()
	if config.load(RUTA_ARCHIVO) != OK:
		return _configuracion_por_defecto()
	return {
		"proveedor_id": config.get_value("chat", "proveedor_id", proveedor_actual_id),
		"modelo": config.get_value("chat", "modelo", ""),
		"modoSistema": config.get_value("chat", "modoSistema", 0),
		"maxTokens": config.get_value("chat", "maxTokens", 8192),
		"nivel_razonamiento": config.get_value("chat", "nivel_razonamiento", NIVEL_RAZONAMIENTO_POR_DEFECTO),
	}

func guardar_configuracion_chat(datos: Dictionary) -> void:
	var config := ConfigFile.new()
	config.load(RUTA_ARCHIVO)
	for clave in datos:
		config.set_value("chat", clave, datos[clave])
	config.save(RUTA_ARCHIVO)

func _configuracion_por_defecto() -> Dictionary:
	return {
		"proveedor_id": proveedor_actual_id,
		"modelo": "",
		"modoSistema": 0,
		"maxTokens": 8192,
		"nivel_razonamiento": NIVEL_RAZONAMIENTO_POR_DEFECTO,
	}
