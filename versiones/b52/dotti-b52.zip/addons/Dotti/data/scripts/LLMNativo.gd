class_name LLMNativo
extends Node

## Cliente OpenAI-compatible con herramientas NATIVAS (function calling) y
## STREAMING (SSE) para Dotti.
##
## - Envia `tools: [{type: "function", function: {...}}]` y `stream: true`.
## - Acumula deltas `content` / `reasoning_content` y los emite en caliente.
## - Reconstruye `tool_calls` por indice y los entrega parseados al finalizar.
## - Usa HTTPClient con polling en _process (HTTPRequest no hace streaming).
## - Los proveedores anthropic/gemini siguen usando LLMRouter (legacy).

signal texto_parcial(delta: String)
signal razonamiento_parcial(delta: String)
signal respuesta_completada(contenido: String, tool_calls: Array, razonamiento: String)
signal error_recibido(mensaje: String)
## Tokens que costo esta peticion, tal y como los cuenta el proveedor. Se pide con
## `stream_options.include_usage` y llega en un evento suelto al final del stream,
## cuando ya no hay `choices`. Es lo que deja al chat decir cuanto contexto lleva
## gastado.
signal uso_recibido(uso: Dictionary)

const TIMEOUT_CONEXION_MSEC := 20000
const TIMEOUT_STALL_MSEC := 45000

## Valor que dejaron los chats guardados cuando aun se rellenaba la traza de
## razonamiento ausente. Ya NO se envia: el upstream rechaza cualquier texto que
## no sea la traza real (HTTP 400 "The `reasoning_content` in the thinking mode
## must be passed back to the API"). Se sigue reconociendo al leer el historial
## para tratar ese turno como "sin traza".
const RAZONAMIENTO_AUSENTE := "(no reasoning trace was returned for this step)"

## Texto con el que se cierra una llamada que nunca llego a devolver resultado:
## el usuario corto la respuesta con Escape, se cayo la conexion o se cerro el
## editor a mitad. El upstream rechaza la peticion ENTERA si una llamada se queda
## sin su resultado ("messages.N: `tool_use` ids were found without `tool_result`
## blocks immediately after: call_xxx"), asi que el hueco se rellena aqui.
const TOOL_SIN_RESULTADO := "[cancelled] The tool call was stopped before it returned a result."

var _http: HTTPClient
var _activo := false
var _cancelado := false
var _fase := 0 # 0=conectando, 1=leyendo
var _inicio_msec := 0
var _ultima_actividad_msec := 0
var _codigo_respuesta := 0

var _resto := ""
var _contenido := ""
var _razonamiento := ""
var _finish_reason := ""
# indice(int) -> {id, nombre, argumentos(String acumulado)}
var _llamadas: Dictionary = {}
var _error_cuerpo := ""
# Tokens de la ultima peticion, ya normalizados (ver ChatModelos.usoNormalizado).
var _uso: Dictionary = {}

func _ready() -> void:
	set_process(false)

func cancelar() -> void:
	_cancelado = true
	_activo = false
	set_process(false)
	if is_instance_valid(_http):
		_http.close()

func solicitar(url: String, cabeceras: Array, cuerpo: Dictionary) -> void:
	cancelar()
	_cancelado = false
	_resto = ""
	_contenido = ""
	_razonamiento = ""
	_finish_reason = ""
	_llamadas = {}
	_error_cuerpo = ""
	_uso = {}
	_codigo_respuesta = 0

	var partes := _parsear_url(url)
	if partes.is_empty():
		error_recibido.emit("Invalid URL: " + url)
		return

	_http = HTTPClient.new()
	var tls_opts: TLSOptions = null
	if bool(partes["tls"]):
		tls_opts = TLSOptions.client()
	var err := _http.connect_to_host(str(partes["host"]), int(partes["puerto"]), tls_opts)
	if err != OK:
		error_recibido.emit("Failed to connect (code %d)." % err)
		return

	_fase = 0
	_url_pendiente = partes["ruta"]
	_cabeceras_pendientes = PackedStringArray(cabeceras)
	_cuerpo_pendiente = JSON.stringify(cuerpo)
	_inicio_msec = Time.get_ticks_msec()
	_ultima_actividad_msec = _inicio_msec
	_activo = true
	set_process(true)

var _url_pendiente := ""
var _cabeceras_pendientes := PackedStringArray()
var _cuerpo_pendiente := ""

func _process(_delta: float) -> void:
	if not _activo or _cancelado:
		return
	var ahora := Time.get_ticks_msec()
	if _fase == 0 and ahora - _inicio_msec > TIMEOUT_CONEXION_MSEC:
		_fallar("Connection timed out.")
		return
	if ahora - _ultima_actividad_msec > TIMEOUT_STALL_MSEC:
		# Recuperando: si el cuerpo traia un error real (o contenido parcial),
		# ese mensaje es mas util que el aviso de estancamiento.
		_fallar_recuperando("Request stalled (no data).")
		return

	_http.poll()
	var estado := _http.get_status()
	match estado:
		HTTPClient.STATUS_CONNECTED:
			if _fase == 0:
				_fase = 1
				_ultima_actividad_msec = ahora
				var err := _http.request(HTTPClient.METHOD_POST, _url_pendiente, _cabeceras_pendientes, _cuerpo_pendiente)
				if err != OK:
					_fallar("Failed to send request (code %d)." % err)
			else:
				# Con keep-alive el cliente vuelve a CONNECTED cuando el cuerpo
				# termina, en vez de pasar por DISCONNECTED. Sin esta rama el
				# cuerpo (p. ej. un 400 con el motivo real) se quedaba sin
				# procesar y el chat solo veia "Request stalled" 45s despues.
				_finalizar()
		HTTPClient.STATUS_BODY:
			_codigo_respuesta = _http.get_response_code()
			_ultima_actividad_msec = ahora
			while _http.get_status() == HTTPClient.STATUS_BODY and _http.has_response():
				var chunk := _http.read_response_body_chunk()
				if chunk.size() == 0:
					break
				_ultima_actividad_msec = Time.get_ticks_msec()
				_procesar_chunk(chunk)
		HTTPClient.STATUS_DISCONNECTED, HTTPClient.STATUS_CANT_CONNECT, HTTPClient.STATUS_CONNECTION_ERROR, HTTPClient.STATUS_TLS_HANDSHAKE_ERROR:
			if _fase == 1 and estado != HTTPClient.STATUS_DISCONNECTED:
				_fallar_recuperando(_texto_error_estado(estado))
			else:
				_finalizar()

func _texto_error_estado(estado: int) -> String:
	match estado:
		HTTPClient.STATUS_CANT_CONNECT:
			return "Cannot connect to the server."
		HTTPClient.STATUS_CONNECTION_ERROR:
			return "Connection error."
		HTTPClient.STATUS_TLS_HANDSHAKE_ERROR:
			return "TLS handshake error."
	return "Network error."

func _fallar(mensaje: String) -> void:
	if not _activo or _cancelado:
		return
	_activo = false
	set_process(false)
	if is_instance_valid(_http):
		_http.close()
	error_recibido.emit(mensaje)

## Error de transporte habiendo fase de lectura: intenta rescatar informacion
## util antes del mensaje generico (error JSON no-SSE en _resto, o contenido
## parcial ya recibido por stream).
func _fallar_recuperando(mensaje_generico: String) -> void:
	if not _activo or _cancelado:
		return
	if _contenido != "" or not _llamadas.is_empty():
		_finalizar()
		return
	if _error_cuerpo != "":
		_fallar("API Error: " + _error_cuerpo)
		return
	var api_err := _extraer_error_no_stream(_resto)
	if api_err != "":
		_fallar("API Error: " + api_err)
	else:
		_fallar(mensaje_generico)

func _procesar_chunk(chunk: PackedByteArray) -> void:
	_resto += chunk.get_string_from_utf8()
	# Cuerpo no-SSE (tipicamente un error de la API): se reconoce aqui, porque
	# el troceado de eventos de mas abajo descarta todo lo que no sea SSE. El
	# limite evita re-parsear un cuerpo grande en cada trozo.
	if _error_cuerpo == "" and _contenido == "" and _resto.length() < 65536 and _resto.strip_edges().begins_with("{"):
		var error_crudo := _extraer_error_no_stream(_resto)
		if error_crudo != "":
			_error_cuerpo = error_crudo
	while true:
		var sep := _resto.find("\n\n")
		if sep == -1:
			break
		var evento := _resto.substr(0, sep)
		_resto = _resto.substr(sep + 2)
		_procesar_evento(evento)

func _procesar_evento(evento: String) -> void:
	var datos := ""
	for linea in evento.split("\n"):
		var l := linea.strip_edges()
		if l.begins_with("data:"):
			datos += l.substr(5).strip_edges()
	if datos == "":
		return
	if datos == "[DONE]":
		_finalizar()
		return
	var j := JSON.new()
	if j.parse(datos) != OK:
		return
	var d = j.get_data()
	if typeof(d) != TYPE_DICTIONARY:
		return
	if d.has("error"):
		var msg = d["error"]
		if typeof(msg) == TYPE_DICTIONARY:
			_error_cuerpo = str(msg.get("message", "Unknown error"))
		else:
			_error_cuerpo = str(msg)
		return
	# El evento de tokens viene SUELTO y con la lista de choices vacia, asi que se
	# mira antes del corte de abajo (que es justo el que lo tiraba).
	if d.has("usage"):
		var uso := ChatModelos.usoNormalizado(d["usage"])
		if not uso.is_empty():
			_uso = uso
	var choices = d.get("choices", [])
	if typeof(choices) != TYPE_ARRAY or choices.is_empty():
		return
	var ch = choices[0]
	if typeof(ch) != TYPE_DICTIONARY:
		return
	var fr = ch.get("finish_reason", "")
	if typeof(fr) == TYPE_STRING and fr != "":
		_finish_reason = fr
	var delta = ch.get("delta", {})
	if typeof(delta) != TYPE_DICTIONARY:
		return
	# Ojo con str(): en GDScript str(null) NO es "null" sino "<null>", asi que un
	# campo JSON null (el upstream manda content:null en el primer trozo de cada
	# turno) se colaba como texto literal en el contenido, en la traza de
	# razonamiento y hasta en los argumentos de las herramientas. Hay que mirar
	# el tipo, no comparar cadenas.
	var txt = delta.get("content", "")
	if typeof(txt) == TYPE_STRING and txt != "":
		_contenido += txt
		texto_parcial.emit(txt)
	var raz = delta.get("reasoning_content", "")
	if typeof(raz) == TYPE_STRING and raz != "":
		_razonamiento += raz
		razonamiento_parcial.emit(raz)
	var tcs = delta.get("tool_calls", [])
	if typeof(tcs) == TYPE_ARRAY:
		for tc in tcs:
			_acumular_tool_call(tc)

func _acumular_tool_call(tc: Variant) -> void:
	if typeof(tc) != TYPE_DICTIONARY:
		return
	var idx := int(tc.get("index", 0))
	var slot: Dictionary = _llamadas.get(idx, {"id": "", "nombre": "", "argumentos": ""})
	# Mismo cuidado con str(null) que en _procesar_evento: de aqui salen el id,
	# el nombre y los argumentos con los que se ejecuta la herramienta.
	var idCrudo = tc.get("id", "")
	if typeof(idCrudo) == TYPE_STRING and idCrudo != "":
		slot["id"] = idCrudo
	var fn = tc.get("function", {})
	if typeof(fn) == TYPE_DICTIONARY:
		var nombreCrudo = fn.get("name", "")
		if typeof(nombreCrudo) == TYPE_STRING and nombreCrudo != "":
			slot["nombre"] = nombreCrudo
		var argsCrudo = fn.get("arguments", "")
		if typeof(argsCrudo) == TYPE_STRING and argsCrudo != "":
			slot["argumentos"] = str(slot["argumentos"]) + argsCrudo
	_llamadas[idx] = slot

func _finalizar() -> void:
	if not _activo or _cancelado:
		return
	_activo = false
	set_process(false)
	if is_instance_valid(_http):
		_http.close()
	if _fase == 0:
		# Nunca se llego a enviar la peticion: fallo de conexion.
		error_recibido.emit("Cannot connect to the server.")
		return
	if _resto.strip_edges() != "" and _contenido == "" and _llamadas.is_empty() and _error_cuerpo == "":
		_error_cuerpo = _extraer_error_no_stream(_resto)
	if _error_cuerpo != "" and _contenido == "" and _llamadas.is_empty():
		if _codigo_respuesta >= 400 or _codigo_respuesta == 0:
			error_recibido.emit("API Error: " + _error_cuerpo)
		else:
			error_recibido.emit(_error_cuerpo)
		return
	var llamadas: Array = []
	var indices := _llamadas.keys()
	indices.sort()
	for idx in indices:
		var slot: Dictionary = _llamadas[idx]
		var args := {}
		var args_raw := str(slot.get("argumentos", ""))
		if args_raw.strip_edges() != "":
			var j := JSON.new()
			if j.parse(args_raw) == OK and typeof(j.get_data()) == TYPE_DICTIONARY:
				args = j.get_data()
			else:
				args = {"_raw": args_raw}
		llamadas.append({
			"id": str(slot.get("id", "")),
			"nombre": str(slot.get("nombre", "")),
			"args": args,
		})
	if not _uso.is_empty():
		uso_recibido.emit(_uso)
	respuesta_completada.emit(_contenido, llamadas, _razonamiento)

func _extraer_error_no_stream(texto: String) -> String:
	var j := JSON.new()
	if j.parse(texto.strip_edges()) != OK:
		return ""
	var d = j.get_data()
	if typeof(d) != TYPE_DICTIONARY or not d.has("error"):
		return ""
	var msg = d["error"]
	if typeof(msg) == TYPE_DICTIONARY:
		return str(msg.get("message", "Unknown error"))
	return str(msg)

func _parsear_url(url: String) -> Dictionary:
	var resto := url.strip_edges()
	var tls := false
	if resto.begins_with("https://"):
		tls = true
		resto = resto.substr(8)
	elif resto.begins_with("http://"):
		resto = resto.substr(7)
	else:
		return {}
	var pos_barra := resto.find("/")
	var hostpuerto := resto
	var ruta := "/"
	if pos_barra != -1:
		hostpuerto = resto.substr(0, pos_barra)
		ruta = resto.substr(pos_barra)
	var host := hostpuerto
	var puerto := 443 if tls else 80
	var pos_dos := hostpuerto.rfind(":")
	if pos_dos != -1:
		host = hostpuerto.substr(0, pos_dos)
		puerto = int(hostpuerto.substr(pos_dos + 1))
	if host == "":
		return {}
	return {"host": host, "puerto": puerto, "tls": tls, "ruta": ruta}

## Instruccion del campo "titulo" que acompana a TODA herramienta. El usuario ve
## ese texto en la tarjeta del chat mientras la herramienta corre y despues, asi
## que tiene que ser corto, en gerundio y decir QUE se esta tocando.
const TITULO_HERRAMIENTA_DESC := "Short label (2-5 words, same language as the user) naming THIS call, in gerund: what you are about to do and on what, e.g. 'Reading Chat.gd' or 'Arreglando el salto de linea'. The user sees it in the chat while the function runs. Never a generic name like 'Tool call'."

## Convierte el registro de herramientas de Dotti al schema OpenAI
## `tools: [{type: "function", function: {name, description, parameters}}]`.
## Los nombres de Dotti ("Read file") NO son validos para la API (exige
## ^[a-zA-Z0-9_-]+$): se envia el nombre sanitizado y a la vuelta se resuelve
## al nombre real con ChatParseador.resolverNombreHerramienta (insensible a
## mayusculas, espacios, _ y -). Usa los tipos declarados tal cual.
static func esquema_herramientas(herramientas: Dictionary) -> Array:
	var out: Array = []
	var usados := {}
	for nombre in herramientas:
		var api := nombre_api(str(nombre))
		var base := api
		var suf := 2
		while usados.has(api):
			api = "%s_%d" % [base, suf]
			suf += 1
		usados[api] = true
		var h = herramientas[nombre]
		var props := {}
		# Titulo de la ejecucion: el modelo nombra lo que va a hacer y la tarjeta
		# del chat ensena ESE nombre en vez del JSON de parametros. Va en todas las
		# herramientas porque no depende de ninguna, y no se exige (required) para
		# no romper a los modelos que no lo manden: sin titulo la tarjeta cae al
		# nombre de la herramienta.
		props["titulo"] = {
			"type": "string",
			"description": TITULO_HERRAMIENTA_DESC,
		}
		var params = h.get("parametros", {})
		if typeof(params) == TYPE_DICTIONARY:
			for pname in params:
				var info = params[pname]
				var ptype := "string"
				var pdesc := ""
				var pitems := {}
				if typeof(info) == TYPE_DICTIONARY:
					ptype = str(info.get("type", "string"))
					pdesc = str(info.get("description", ""))
					if typeof(info.get("items", null)) == TYPE_DICTIONARY:
						pitems = info["items"]
				var esquema_prop := {"type": ptype, "description": pdesc}
				if not pitems.is_empty():
					esquema_prop["items"] = pitems
				props[pname] = esquema_prop
		var req: Array = []
		var requeridos = h.get("requeridos", [])
		if typeof(requeridos) == TYPE_ARRAY:
			for r in requeridos:
				req.append(str(r))
		out.append({
			"type": "function",
			"function": {
				"name": api,
				"description": str(h.get("descripcion", "")),
				"parameters": {"type": "object", "properties": props, "required": req},
			},
		})
	return out

## Nombre valido para la API a partir del nombre real de Dotti.
static func nombre_api(nombre: String) -> String:
	var limpio := ""
	for i in range(nombre.length()):
		var c := nombre.substr(i, 1)
		if (c >= "a" and c <= "z") or (c >= "A" and c <= "Z") or (c >= "0" and c <= "9") or c == "_" or c == "-":
			limpio += c
		else:
			limpio += "_"
	while limpio.contains("__"):
		limpio = limpio.replace("__", "_")
	limpio = limpio.lstrip("_").rstrip("_")
	if limpio == "":
		limpio = "funcion"
	if limpio.length() > 64:
		limpio = limpio.left(64)
	return limpio

## Normaliza el historial de Dotti al formato OpenAI, preservando los
## mensajes de tools nativas (assistant con tool_calls, role tool). El prompt
## del sistema va marcado con "system": true en casa, pero sale como primer
## mensaje de usuario: el upstream bloquea las conversaciones que abren con un
## system cargado de instrucciones.
##
## Regla del upstream en modo thinking: TODO turno assistant con tool_calls
## debe devolver su reasoning_content tal cual se recibio. No sirve inventarlo:
## un marcador, un texto vacio o el campo ausente dan HTTP 400 ("The
## `reasoning_content` in the thinking mode must be passed back to the API"), y
## como la validacion es de toda la conversacion, UN solo turno asi rompe el
## chat para siempre. Cuando el modelo emitio un tool call sin traza (o el chat
## se guardo antes de esta regla) se degrada ese grupo a texto plano: el turno
## assistant pasa a llevar "[tool call: NOMBRE]" y cada resultado pasa a ser un
## mensaje de usuario, con lo que la conversacion sigue siendo valida y el
## contexto no se pierde.
static func normalizar_historial(historial: Array) -> Array:
	var mensajes: Array = []
	# ids de los tool_calls degradados a texto -> nombre de la herramienta
	var degradados := {}
	# nombres del ultimo grupo degradado, para resultados sin tool_call_id
	var pendientes: Array = []
	for msg in historial:
		if typeof(msg) != TYPE_DICTIONARY:
			continue
		var rol := str(msg.get("role", "user"))
		var contenido = msg.get("content", "")
		if contenido == null:
			contenido = ""
		# El prompt del sistema sale como primer mensaje de usuario, no como
		# "system": es lo que pide el usuario y lo que pasa el filtro del upstream.
		# Un chat guardado antes de esto trae "role": "system" de verdad, y se
		# degrada igual: por el otro camino volveria a saltar el filtro.
		if bool(msg.get("system", false)) or rol == "system":
			mensajes.append({"role": "user", "content": str(contenido)})
			continue
		if rol == "assistant" and msg.has("tool_calls"):
			var tcs = msg["tool_calls"]
			if typeof(tcs) == TYPE_ARRAY and not (tcs as Array).is_empty():
				var crudo = msg.get("reasoning_content", "")
				var razonamiento := str(crudo) if typeof(crudo) == TYPE_STRING else ""
				razonamiento = razonamiento.strip_edges()
				if razonamiento == "" or razonamiento == "<null>" or razonamiento == RAZONAMIENTO_AUSENTE:
					# Sin traza util: el grupo entero se degrada a texto.
					var texto := str(contenido).strip_edges()
					pendientes = []
					for tc in tcs:
						var nombre := nombreDeToolCall(tc)
						var tid := idDeToolCall(tc)
						if tid != "":
							degradados[tid] = nombre
						pendientes.append(nombre)
						var etiqueta := "[tool call]"
						if nombre != "":
							etiqueta = "[tool call: %s]" % nombre
						if texto == "":
							texto = etiqueta
						else:
							texto = texto + "\n" + etiqueta
					if texto != "":
						mensajes.append({"role": "assistant", "content": texto})
					continue
				mensajes.append({
					"role": "assistant",
					"content": contenido,
					"tool_calls": tcs,
					"reasoning_content": razonamiento,
				})
				continue
		if rol == "tool":
			var tid := str(msg.get("tool_call_id", ""))
			var degradado := false
			var nombre := ""
			if tid != "" and degradados.has(tid):
				degradado = true
				nombre = str(degradados[tid])
			elif tid == "" and not pendientes.is_empty():
				degradado = true
				nombre = str(pendientes[0])
			if degradado:
				pendientes.erase(nombre)
				var cabecera := "[tool result]"
				if nombre != "":
					cabecera = "[tool result of %s]" % nombre
				var cuerpo := str(contenido)
				if cuerpo == "":
					mensajes.append({"role": "user", "content": cabecera})
				else:
					mensajes.append({"role": "user", "content": cabecera + " " + cuerpo})
				continue
			var entrada := {"role": "tool", "content": str(contenido)}
			if tid != "":
				entrada["tool_call_id"] = tid
			mensajes.append(entrada)
			continue
		match rol:
			"system", "user", "assistant":
				mensajes.append(Adjuntos.mensajeOpenai(rol, str(contenido), msg.get("imagenes", [])))
			_:
				mensajes.append({"role": "user", "content": str(contenido)})
	return _cerrarLlamadas(mensajes)

## Deja el historial como lo exige la API: cada tool_call con su tool result
## detras y en su orden, sin resultados sueltos y sin llamadas sin cerrar. Es la
## ultima red antes de mandar la peticion, porque un solo hueco la tira entera.
static func _cerrarLlamadas(mensajes: Array) -> Array:
	var salida: Array = []
	var i := 0
	while i < mensajes.size():
		var msg = mensajes[i]
		i += 1
		if typeof(msg) != TYPE_DICTIONARY:
			salida.append(msg)
			continue
		if str(msg.get("role", "")) == "tool":
			# Resultado sin ninguna llamada delante: cuando se guardo, su llamada
			# ya se habia degradado a texto. Se degrada tambien.
			salida.append({"role": "user", "content": "[tool result] " + str(msg.get("content", ""))})
			continue
		salida.append(msg)
		var tcs = msg.get("tool_calls", null)
		if typeof(tcs) != TYPE_ARRAY:
			continue
		var faltan := {}
		for tc in tcs:
			var idLlamada := idDeToolCall(tc)
			if idLlamada != "":
				faltan[idLlamada] = true
		# Los resultados que si llegaron van pegados detras de la llamada: se
		# dan por buenos y se consumen.
		while i < mensajes.size():
			var sig = mensajes[i]
			if typeof(sig) != TYPE_DICTIONARY or str(sig.get("role", "")) != "tool":
				break
			i += 1
			var idResultado := str(sig.get("tool_call_id", ""))
			if idResultado == "":
				salida.append({"role": "user", "content": "[tool result] " + str(sig.get("content", ""))})
				continue
			if not faltan.has(idResultado):
				continue # repetido o de una llamada que no esta aqui
			faltan.erase(idResultado)
			salida.append(sig)
		for idPendiente in faltan:
			salida.append({
				"role": "tool",
				"tool_call_id": str(idPendiente),
				"content": TOOL_SIN_RESULTADO,
			})
	return salida

## Nombre de la herramienta en un tool_call, aceptando las dos formas que
## circulan por el proyecto: {function: {name}} (API) y {name} (interno). Lo usan
## tambien la normalizacion del historial y el repintado de un chat guardado.
static func nombreDeToolCall(tc: Variant) -> String:
	if typeof(tc) != TYPE_DICTIONARY:
		return ""
	var fn = tc.get("function", null)
	if typeof(fn) == TYPE_DICTIONARY:
		var n := str(fn.get("name", "")).strip_edges()
		if n != "" and n != "<null>":
			return n
	var directo := str(tc.get("name", "")).strip_edges()
	if directo != "" and directo != "<null>":
		return directo
	return ""

static func idDeToolCall(tc: Variant) -> String:
	if typeof(tc) != TYPE_DICTIONARY:
		return ""
	var id := str(tc.get("id", "")).strip_edges()
	if id == "<null>":
		return ""
	return id

## Argumentos de un tool_call del historial: llegan como JSON en texto dentro de
## function.arguments (forma de la API) o ya como diccionario (forma interna).
static func argsDeToolCall(tc: Variant) -> Dictionary:
	if typeof(tc) != TYPE_DICTIONARY:
		return {}
	var fn = tc.get("function", null)
	if typeof(fn) == TYPE_DICTIONARY:
		var crudos := str(fn.get("arguments", "")).strip_edges()
		if crudos != "" and crudos != "<null>":
			var j := JSON.new()
			if j.parse(crudos) == OK and typeof(j.get_data()) == TYPE_DICTIONARY:
				return j.get_data()
		var directos = fn.get("args", null)
		if typeof(directos) == TYPE_DICTIONARY:
			return directos
	for clave in ["args", "argumentos"]:
		var v = tc.get(clave, null)
		if typeof(v) == TYPE_DICTIONARY:
			return v
	return {}
