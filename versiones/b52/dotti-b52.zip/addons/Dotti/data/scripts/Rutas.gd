class_name Rutas

# Politica de rutas del proyecto. Todo lo que el modelo manda como ruta de
# archivo pasa por aqui antes de tocar el disco, y de aqui solo sale res://.
#
# Hace falta porque Godot resuelve una ruta absoluta tal cual y una relativa
# contra el directorio de trabajo: sin esta puerta, "C:/Users/..." o
# "../../fuera.txt" sacan a la herramienta del proyecto y el modelo puede leer
# y escribir donde no debe. Una ruta suelta ("scripts/Player.gd") se entiende
# como del proyecto, que es lo que el modelo escribe la mitad de las veces.


## Resuelve una ruta del modelo. Devuelve {"ok": bool, "ruta": String,
## "motivo": String}: si ok, "ruta" es una res:// normalizada; si no, "motivo"
## es la frase que se le contesta.
static func proyecto(valor: Variant, que: String = "path") -> Dictionary:
	var crudo := str(valor).strip_edges().replace("\\", "/")
	if crudo == "":
		return _fallo("Missing required argument: %s." % que)
	if crudo.begins_with("res://"):
		pass
	elif crudo.contains("://") or crudo.begins_with("/") or crudo.is_absolute_path():
		return _fallo("\"%s\" is outside the project: only res:// paths are allowed." % str(valor))
	else:
		crudo = "res://" + crudo
	var ruta := crudo.simplify_path()
	# simplify_path no borra los ".." que suben por encima de la raiz: se quedan
	# escritos como "res://..", que es la senal de que la ruta se sale.
	if not ruta.begins_with("res://") or ruta == "res://.." or ruta.begins_with("res://../"):
		return _fallo("\"%s\" points outside the project." % str(valor))
	if not dentroDelProyecto(ruta):
		return _fallo("\"%s\" points outside the project." % str(valor))
	return {"ok": true, "ruta": ruta, "motivo": ""}


## Si una ruta res:// ya normalizada cae de verdad dentro de la carpeta del
## proyecto. Es la comprobacion de fondo, sobre las rutas del sistema de archivos,
## que es donde Godot resuelve res://: si manana cambia como lo resuelve, sigue
## valiendo.
static func dentroDelProyecto(ruta: String) -> bool:
	var raiz := ProjectSettings.globalize_path("res://").simplify_path()
	var real := ProjectSettings.globalize_path(ruta).simplify_path()
	if not real.begins_with(raiz):
		return false
	# La raiz a secas vale; lo de dentro tiene que traer la barra, o un proyecto
	# vecino llamado "juego-viejo" pasaria por estar dentro de "juego".
	return real == raiz or real.begins_with(raiz + "/")


## Resuelve la ruta de una imagen que el modelo quiere ver. Vale una del
## proyecto y vale una de user://, que es la carpeta de trabajo de Dotti: los
## adjuntos pegados y las capturas viven ahi, y son rutas que el propio modelo
## recibe de vuelta. Lo que no vale es una ruta absoluta del disco, que era lo
## que dejaba abrir cualquier imagen del equipo.
static func imagen(valor: Variant) -> Dictionary:
	var crudo := str(valor).strip_edges().replace("\\", "/")
	if not crudo.begins_with("user://"):
		return proyecto(valor)
	var ruta := crudo.simplify_path()
	# Igual que con res://: los ".." que suben por encima de la raiz se quedan
	# escritos como "user://..", que es la senal de que la ruta se sale.
	if ruta == "user://.." or ruta.begins_with("user://../"):
		return _fallo("\"%s\" points outside the user folder." % str(valor))
	if not dentroDeUser(ruta):
		return _fallo("\"%s\" points outside the user folder." % str(valor))
	return {"ok": true, "ruta": ruta, "motivo": ""}


## Si una ruta user:// ya normalizada cae de verdad dentro de la carpeta de
## usuario de este proyecto. La comprobacion de fondo, como la del proyecto.
static func dentroDeUser(ruta: String) -> bool:
	var raiz := ProjectSettings.globalize_path("user://").simplify_path().trim_suffix("/")
	var real := ProjectSettings.globalize_path(ruta).simplify_path()
	return real == raiz or real.begins_with(raiz + "/")


## Resuelve la ruta de una COPIA DE SEGURIDAD: la herramienta de deshacer recibe
## la copia, no el archivo del proyecto (el listado devuelve rutas de
## user://dotti_backups, y esas son las que el modelo copia y devuelve). Se exige
## que cuelgue de la carpeta de copias, sobre el texto y sobre la ruta real, como
## en dentroDelProyecto: restaurar escribe, y ahi no se deja entrar nada de fuera.
static func copia(valor: Variant, que: String = "path") -> Dictionary:
	var crudo := str(valor).strip_edges().replace("\\", "/")
	if crudo == "":
		return _fallo("Missing required argument: %s." % que)
	var ruta := crudo.simplify_path()
	if not ruta.begins_with(CopiasSeguridad.RAIZ):
		return _fallo("\"%s\" is not a backup file: backups live in %s." % [str(valor), CopiasSeguridad.RAIZ.trim_suffix("/")])
	# Lo que queda por debajo de la carpeta de copias no puede volver a subir.
	var dentro := ruta.substr(CopiasSeguridad.RAIZ.length())
	if dentro == "" or dentro.contains(".."):
		return _fallo("\"%s\" points outside the backup folder." % str(valor))
	# Sin la barra final: RAIZ la trae, y con las dos se comparaba contra
	# ".../dotti_backups//" y no pasaba ninguna copia.
	var raizReal := ProjectSettings.globalize_path(CopiasSeguridad.RAIZ).simplify_path().trim_suffix("/")
	var real := ProjectSettings.globalize_path(ruta).simplify_path()
	if not real.begins_with(raizReal + "/"):
		return _fallo("\"%s\" points outside the backup folder." % str(valor))
	return {"ok": true, "ruta": ruta, "motivo": ""}


static func _fallo(motivo: String) -> Dictionary:
	return {"ok": false, "ruta": "", "motivo": motivo}
