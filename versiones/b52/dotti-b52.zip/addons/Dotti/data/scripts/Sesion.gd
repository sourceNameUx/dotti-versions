class_name Sesion
extends RefCounted

## La cuenta del usuario: su token de plugin y lo que lleva gastado hoy.
##
## Es estado, no conversacion: vive en `user://dotti_sesion.cfg`, fuera del
## proyecto y fuera del repositorio, y no se manda a ningun sitio. El token es
## lo unico que identifica al usuario ante la pasarela; el resto (correo, rol y
## el gasto del dia) es para ensenararlo en los ajustes sin preguntar de nuevo.
##
## Todo lo que habla por HTTP esta en ChatCuenta. Aqui solo se guarda y se lee.

const RUTA_ARCHIVO := "user://dotti_sesion.cfg"

var token: String = ""
var correo: String = ""
var rol: String = ""
var direccion: String = ""
var obtenido_en: int = 0

# Foto del dia que contesto la pasarela la ultima vez. Se guarda para que la
# barra del chat pueda ensenar el gasto sin pedirlo en cada peticion.
var gastado_usd: float = 0.0
var limite_usd: float = 0.0
var inicio_dia: String = ""

## La sesion del proceso. Es una sola porque el estado vive en un fichero y dos
## copias se pisarian: la ventana de ajustes entra, y el chat y los proveedores
## leen lo mismo sin tener que avisarse.
static var _unica: Sesion = null

static func unica() -> Sesion:
	if _unica == null:
		_unica = Sesion.new()
		_unica.cargar()
	return _unica

func cargar() -> void:
	var config := ConfigFile.new()
	if config.load(RUTA_ARCHIVO) != OK:
		return
	token = str(config.get_value("cuenta", "token", ""))
	correo = str(config.get_value("cuenta", "correo", ""))
	rol = str(config.get_value("cuenta", "rol", ""))
	direccion = str(config.get_value("cuenta", "direccion", ""))
	obtenido_en = int(config.get_value("cuenta", "obtenido_en", 0))
	gastado_usd = float(config.get_value("dia", "gastado_usd", 0.0))
	limite_usd = float(config.get_value("dia", "limite_usd", 0.0))
	inicio_dia = str(config.get_value("dia", "inicio_dia", ""))

func guardar() -> void:
	var config := ConfigFile.new()
	config.load(RUTA_ARCHIVO)
	config.set_value("cuenta", "token", token)
	config.set_value("cuenta", "correo", correo)
	config.set_value("cuenta", "rol", rol)
	config.set_value("cuenta", "direccion", direccion)
	config.set_value("cuenta", "obtenido_en", obtenido_en)
	config.set_value("dia", "gastado_usd", gastado_usd)
	config.set_value("dia", "limite_usd", limite_usd)
	config.set_value("dia", "inicio_dia", inicio_dia)
	config.save(RUTA_ARCHIVO)

## Con token se esta dentro. Sin el, el plugin no puede hablar con la pasarela.
func estaDentro() -> bool:
	return token.strip_edges() != ""

## A donde se le habla a la pasarela. La direccion se guarda al entrar para que
## el banco de pruebas pueda apuntar a la pasarela local; sin nada guardado vale
## la del producto.
func direccionActual() -> String:
	var propia := direccion.strip_edges()
	if propia != "":
		return propia
	return Apis.URL_OFICIAL

## Cabeceras de una peticion autenticada.
func cabeceras() -> Array:
	return ["Authorization: Bearer " + token, "Content-Type: application/json"]

## Entra con lo que contesto la pasarela al aprobarse el codigo.
func entrar(datos: Dictionary) -> void:
	token = str(datos.get("token", ""))
	correo = str(datos.get("correo", ""))
	rol = str(datos.get("rol", ""))
	direccion = str(datos.get("direccion", direccionActual()))
	obtenido_en = int(Time.get_unix_time_from_system())
	guardar()

## Sale: se olvida el token. La foto del dia se va con el, que era de esa cuenta.
func cerrar() -> void:
	token = ""
	correo = ""
	rol = ""
	obtenido_en = 0
	gastado_usd = 0.0
	limite_usd = 0.0
	inicio_dia = ""
	guardar()

## Deja la foto del dia tal como la manda la pasarela.
func anotarDia(uso: Dictionary) -> void:
	gastado_usd = float(uso.get("gastado_usd", 0.0))
	limite_usd = float(uso.get("limite_usd", 0.0))
	inicio_dia = str(uso.get("inicio_dia", ""))
	guardar()

## Cuanto queda del limite de hoy, en dolares. -1 si no se sabe.
func restante() -> float:
	if limite_usd <= 0.0:
		return -1.0
	return maxf(limite_usd - gastado_usd, 0.0)
