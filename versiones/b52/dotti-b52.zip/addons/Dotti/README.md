# Dotti

An AI coding agent that lives inside the Godot 4 editor. It reads and edits the
project through tools, renders the answer as Markdown in a dockable chat panel,
and talks to the model through a proxy you control.

## Install

1. Copy the `Dotti` folder into your project's `addons/` folder.
2. Enable it in Project > Project Settings > Plugins.
3. Open the Dotti panel and configure the provider and the model in Settings.
   Keys are stored in `user://`, never in the project.
4. Optionally write your own `AGENTS.md`, in Settings > Instructions: whatever
   is in it opens every conversation. It lives in `user://`, outside the project,
   so it is yours and not the repository's.

## What it does

- **Agent mode** - the model has tools: read and write files, search, edit the
  open script, build and edit scenes and nodes, create resources, change project
  settings, run the game, read the editor log. **Plan mode** - the tools only
  read, so the answer is a plan: what would change, in which file, in what order.
  Nothing in Plan mode can touch the project.
- **Backups** - every file the model touches is copied to `user://dotti_backups/`
  before the change, and it can list and restore them. Nothing is lost, and the
  project stays clean.
- **Attachments** - paste with Ctrl+V to attach an image (a screenshot, a
  reference) or a file path. Images go to the model as images, not as text.
- **Permissions** - ask every time, ask only for things that write, or let it run.
- **Agents** - save a persona (a prompt, a tool list, an optional model) in
  Settings > Agents and bring it into the chat by typing `@name`. A read-only
  agent can look at everything and change nothing. Dotti ships two of its own -
  `@general` and `@explore` - and opening one keeps them as they are: saving
  writes a copy of your own, which then wins over the built-in one. Agents can also live in the project, in `res://.dotti/agentes/`, to be
  shared with the team.
- **Subagents** - the model can hand one task to an agent with `Run agent` when
  the work would fill the conversation with noise: the subagent runs in its own
  conversation, with the tools of the agent it runs as, and only its report comes
  back. It cannot ask the user anything or launch another subagent, and the cards
  of what it touches hang from the `Run agent` card instead of filling the chat.
- **Suggestions in the input box** - typing `@` lists the agents and the files
  and folders of the project, typing `/` lists the chat commands; arrow keys move,
  Enter picks, Tab steps into a folder, Escape closes. Picking a file attaches it
  to the message.
- **Skills** - a written procedure (how sprites are drawn here, how a release is
  cut) that the model loads only when it needs it. The prompt carries one line
  per skill; the instructions arrive when the model asks for them. Drop a folder
  with a `SKILL.md` inside in `user://dotti_skills/`, or in
  `res://.dotti/skills/` to share it with the team.
- **Context compaction** - when the conversation gets close to the model window,
  the old part is summarized into a checkpoint and stops being sent; the model
  keeps the thread, the panel keeps showing the whole conversation. It happens on
  its own, or on demand with `/compact` or a click on the token counter.
- **Chats** - saved in `user://`, with history, titles and reload.

## Layout

```
addons/Dotti/
  plugin.cfg, plugin.gd        plugin entry point
  data/scripts/                the code
    Chat.gd                    the chat panel and the agent loop
    Apis.gd                    providers, keys, chat configuration
    LLMNativo.gd               OpenAI-compatible client, native tools, streaming
    LLMRouter.gd               request builder for the other provider shapes
    Adjuntos.gd                attachments and clipboard images
    CopiasSeguridad.gd         backups in user://
    ChatTools.gd               tool registry
    Configuration.gd           settings window
    History.gd                 saved chats
    Chat/                      chat internals (prompts, styles, icons, parsing,
                               agents, skills, suggestions, subagents)
    Tools/                     the tools the model can call
  data/agentes/                the two agents Dotti ships (general, explore),
                               one Markdown file each
  data/MarkdownLabel/          the Markdown renderer used by the chat
  data/scenes/001.tscn         the chat panel scene, instanced by plugin.gd
```

`Chat/README.md` and `Tools/README.md` explain those two folders.

## Development notes

- Prompts and documentation are English. Code comments are Spanish and ASCII.
- Bump `DOTTI_BUILD` in `Chat.gd` on every change.
- Never put a key in the project. The proxy URL is the only endpoint the addon
  talks to.
