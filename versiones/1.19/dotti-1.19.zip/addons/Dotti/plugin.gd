@tool
extends EditorPlugin

## Dotti vive en la columna derecha del editor, en el grupo del Inspector, y de
## primero.
##
## Antes estaba en el panel de abajo, la fila de Salida y Depuracion, y ahi no se
## encontraba: ese panel nace plegado y el chat quedaba detras de una pestana que
## nadie abre. Varios usuarios dieron por hecho que el plugin no les funcionaba.
## Puesto arriba, entre el Inspector y sus vecinos, se ve desde el primer
## arranque; despues cada uno lo arrastra donde le acomode.
##
## Antes este plugin metia ademas dos botones ("Chat" e "Interpret") dentro del
## editor de codigo, encima del arbol de scripts, y cada uno abria su propia copia
## del chat ahi mismo. Se quito entero: el chat del editor de codigo no se veia
## (el prompt le pedia al modelo responder solo con herramientas), duplicaba el
## estado de la conversacion y no aportaba nada que no hiciera ya el panel.
##
## El ancho minimo del panel no se pone aqui: es `custom_minimum_size` del chat,
## que lo saca de la pantalla en `Chat._anchoMinimoChat()`. Ponerlo tambien aqui
## no servia de nada, porque `Chat._construirInterfaz()` lo pisa al construirse.

var escenaChat: Control

## Nombre con el que el editor guarda donde quedo el panel. El envoltorio que
## crea `add_control_to_dock` nace sin clave, y sin clave el editor no puede
## apuntarlo en `.godot/editor/editor_layout.cfg`: el panel volveria a caer de
## ultimo en cada arranque y perderia el sitio que le haya dado el usuario.
const CLAVE_LAYOUT := "Dotti"
## Cuadros que se espera a que el editor arme la columna derecha.
const CUADROS_ESPERANDO_GRUPO := 120
## Cuadros seguidos con el panel de primero que se toman por orden ya asentado.
const CUADROS_ASENTADO := 30
## Donde se apunta que el panel ya se puso en su sitio y se abrio una vez.
const RUTA_ESTADO := "user://dotti_panel.cfg"


func _enter_tree() -> void:
	escenaChat = preload("res://addons/Dotti/data/scenes/001.tscn").instantiate()
	add_control_to_dock(EditorPlugin.DOCK_SLOT_RIGHT_UL, escenaChat, null)
	# El envoltorio no existe hasta que el editor lo arma, y eso es en el cuadro
	# siguiente. Hasta entonces `get_parent()` devuelve null.
	_acomodar.call_deferred()


func _exit_tree() -> void:
	if escenaChat:
		remove_control_from_docks(escenaChat)
		escenaChat.queue_free()
		escenaChat = null


## Pone el panel de primero dentro del grupo del Inspector y lo abre la primera
## vez, que es cuando nadie sabe todavia que esta ahi.
##
## Espera a proposito, y no una vez sino hasta que el orden se queda quieto.
## Cuando entra un plugin el editor todavia no ha armado la columna derecha: la
## construye unos cuadros despues y entonces reparte sus pestanas por lo que
## tenga apuntado el layout, y ese reparto es el que manda al final. Una sola
## ordenacion al principio se pierde ahi: el panel vuelve a caer de ultimo y
## queda detras de una pestana que nadie abre. Por eso se reafirma el primer
## puesto mientras el grupo se esta armando, y se para cuando lleva treinta
## cuadros seguidos de primero.
##
## Solo la primera vez. Despues el sitio es el que el editor tenga guardado, que
## es donde el usuario lo haya dejado: si lo arrastro, arrastrado se queda.
func _acomodar() -> void:
	var primera := _primeraVez()
	var asentado := 0
	var envoltorio: Node = null
	for _i in CUADROS_ESPERANDO_GRUPO:
		await get_tree().process_frame
		if not is_instance_valid(escenaChat):
			return
		envoltorio = escenaChat.get_parent()
		if envoltorio == null:
			continue
		# El envoltorio que crea `add_control_to_dock` nace sin clave de layout, y
		# sin clave el editor no apunta donde quedo el panel: cada arranque
		# volveria a caer de ultimo y perderia el sitio que le haya dado el
		# usuario. Se pone en cuanto hay envoltorio, mueva o no.
		if envoltorio.has_method("set_layout_key"):
			envoltorio.call("set_layout_key", CLAVE_LAYOUT)
		if envoltorio.has_method("set_title"):
			envoltorio.call("set_title", "Dotti")
		if not primera:
			return
		var contenedor := envoltorio.get_parent()
		if contenedor == null or contenedor.get_node_or_null("Inspector") == null:
			continue
		if envoltorio.get_index() != 0:
			contenedor.move_child(envoltorio, 0)
			asentado = 0
			continue
		asentado += 1
		if asentado >= CUADROS_ASENTADO:
			break
	if primera and envoltorio != null:
		# Se abre al final y no nada mas entrar: el reparto de pestanas de la
		# restauracion dejaria la eleccion en nada. Se senala la pestana del
		# contenedor -que es lo que hace un clic en ella- y no `open()`, que en el
		# envoltorio que crea `add_control_to_dock` no hace nada: ese envoltorio es
		# un EditorDock pelado, y los que hacen algo al abrirse son los que trae
		# el editor.
		var contenedor := envoltorio.get_parent()
		if contenedor is TabContainer:
			contenedor.current_tab = envoltorio.get_index()
		_marcarAbierto()


## El saludo de bienvenida del panel, una sola vez en la vida del usuario: abrir
## el chat en cada arranque le robaria la pestana al Inspector, que es la que casi
## todo el mundo quiere al abrir el editor.
func _primeraVez() -> bool:
	var cfg := ConfigFile.new()
	if cfg.load(RUTA_ESTADO) != OK:
		return true
	return not bool(cfg.get_value("panel", "abierto", false))


func _marcarAbierto() -> void:
	var cfg := ConfigFile.new()
	cfg.load(RUTA_ESTADO)
	cfg.set_value("panel", "abierto", true)
	cfg.save(RUTA_ESTADO)
