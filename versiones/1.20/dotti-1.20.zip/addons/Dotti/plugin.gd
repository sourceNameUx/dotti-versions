@tool
extends EditorPlugin

## Dotti vive en la fila de arriba, junto a 2D, 3D, Script y Game: el editor llama
## a eso una "pantalla principal", y es el sitio donde el panel se ve sin buscarlo.
##
## Antes estaba en el panel de abajo (la fila de Salida y Depuracion, que nace
## plegada y dejaba el chat detras de una pestana que nadie abre) y despues en la
## columna derecha, junto al Inspector, donde estorbaba a quien estaba trabajando.
##
## La pestana no se pinta a mano: se la pide al editor con los tres metodos de
## abajo -que es la via que el propio editor ofrece- y el la coloca en
## `EditorMainScreenButtons` detras de Game, con el icono y el nombre que se le
## den. El control se cuelga de `EditorInterface.get_editor_main_screen()`, que es
## el contenedor que apila las pantallas, y el editor lo ensena o lo esconde
## llamando a `_make_visible` cuando el usuario cambia de pestana.
##
## El ancho minimo del chat no se pone aqui: es `custom_minimum_size` del propio
## chat, que lo saca de la pantalla en `Chat._anchoMinimoChat()`.

var escenaChat: Control


## La via que el editor tiene para pantallas propias: `_has_main_screen` dice que
## si, `_get_plugin_name` es el texto de la pestana, `_get_plugin_icon` su icono y
## `_make_visible` avisa cuando entra o sale.
func _has_main_screen() -> bool:
	return true


func _get_plugin_name() -> String:
	return "Dotti"


## Un icono de los que trae el editor, para no depender de ningun archivo nuestro.
func _get_plugin_icon() -> Texture2D:
	var tema = _interfaz().call("get_editor_theme")
	if tema == null:
		return null
	return tema.call("get_icon", "Godot", "EditorIcons")


func _make_visible(visible: bool) -> void:
	if escenaChat != null:
		escenaChat.visible = visible


func _enter_tree() -> void:
	escenaChat = preload("res://addons/Dotti/data/scenes/001.tscn").instantiate()
	# El contenedor apila las pantallas en vertical: sin esto el chat se queda con
	# la altura de su tamano minimo en vez de llenar el hueco.
	escenaChat.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	escenaChat.size_flags_vertical = Control.SIZE_EXPAND_FILL
	var pantalla: Node = _interfaz().call("get_editor_main_screen")
	pantalla.add_child(escenaChat)
	# El editor no llama a `_make_visible(false)` por su cuenta al entrar: una
	# pantalla que no es la elegida empieza escondida, y esto es lo que lo dice.
	_make_visible(false)


func _exit_tree() -> void:
	if escenaChat != null:
		escenaChat.queue_free()
		escenaChat = null


func _interfaz() -> Object:
	return Engine.get_singleton("EditorInterface")
