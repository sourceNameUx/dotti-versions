@tool
class_name OperacionesNativas
extends RefCounted

## Puente entre la senal `terminado` del nucleo nativo y `await`.
##
## Hace falta porque una operacion puede terminar antes de que se llegue a
## esperar: el token que aun vale, el refresco que no hacia falta, un argumento
## invalido... salen de forma sincrona. Conectar la caja ANTES de arrancar la
## operacion es lo unico que no pierde ese final. Es pegamento de await, no
## logica: el protocolo, el estado y la traduccion viven en el nucleo.

## Una operacion contra la pasarela. `metodo` es el nombre en DottiCuenta.
static func cuenta(nodo: Node, metodo: StringName, args: Array = []) -> Dictionary:
	return await _correr(DottiCuenta.new(), nodo, metodo, args)

## Una herramienta que espera (capturas y demas): la op ya viene creada, aqui
## solo se conecta su terminado, se arranca y se espera.
static func herramienta(nodo: Node, op: Object, metodo: StringName, args: Array = []) -> Dictionary:
	return await _correr(op, nodo, metodo, args)

static func _correr(op: Object, nodo: Node, metodo: StringName, args: Array) -> Dictionary:
	var caja := {}
	op.terminado.connect(func(r: Dictionary) -> void: caja["r"] = r, CONNECT_ONE_SHOT)
	var completos: Array = [nodo]
	completos.append_array(args)
	op.callv(metodo, completos)
	while not caja.has("r"):
		if not is_instance_valid(nodo) or not nodo.is_inside_tree():
			return {"ok": false, "error": "The settings window was closed."}
		await nodo.get_tree().process_frame
	return caja["r"]