class_name HerramientasChat

static func registrarTodas(chat: Node) -> void:
	DottiHerramientasArchivos.registrar(chat)
	DottiHerramientasEscenas.registrar(chat)
	DottiHerramientasScripts.registrar(chat)
	DottiHerramientasNodos.registrar(chat)
	DottiHerramientasControl.registrar(chat)
	DottiHerramientasProyecto.registrar(chat)
	DottiHerramientasRecursos.registrar(chat)
	HerramientasPregunta.registrar(chat)
	DottiHerramientasCopias.registrar(chat)
	HerramientasImagenes.registrar(chat)
	DottiHerramientasTareas.registrar(chat)
	DottiHerramientasSkills.registrar(chat)
	HerramientasSubagentes.registrar(chat)
