@tool
class_name HerramientasImagenes

## Herramientas de imagen: ver una y capturar vistas.
##
## "View image" es sincrona y vive entera en el nucleo. "Capture view" espera
## fotogramas (traer pantallas al frente, correr el juego), asi que es una
## operacion nativa con senal y aqui solo queda el registro con su puente de
## espera: cuando el despachador sea nativo este archivo desaparece.

static func registrar(chat: Node) -> void:
	DottiHerramientasImagenes.registrar_ver(chat)
	chat.registrarHerramienta(
		"Capture view",
		"Take a screenshot and look at it. view=\"editor\" captures the whole editor window, \"2d\" the 2D editor view, \"3d\" the 3D editor view and \"game\" runs the project scene and captures the running game itself. For view=game the scene has to be started by this tool, so a scene that is already running is restarted and whatever was happening in it is lost. The image is attached to the conversation.",
		{
			"view": {"type": "string", "description": "What to capture: editor, 2d, 3d or game. Defaults to editor."},
			"scene": {"type": "string", "description": "Only for view=game: scene to run, e.g. res://levels/level_1.tscn. Defaults to the project main scene."},
			"seconds": {"type": "number", "description": "Only for view=game: seconds to let the scene run before the shot, so it has time to load and settle. Defaults to 1.5."},
		},
		["view"],
		_capturarVista.bind(chat)
	)

static func _capturarVista(args: Dictionary, chat: Node) -> Dictionary:
	return await OperacionesNativas.herramienta(chat, DottiCaptura.new(), &"capturar", [args])
