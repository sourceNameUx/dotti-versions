@tool
class_name BloqueoEditor
extends Node

## Bloqueo de las pestanas del editor mientras el agente toca codigo.
##
## El problema: el usuario y el agente sobre el mismo archivo. El agente escribe
## un .gd en disco, el usuario lo tenia abierto con la version vieja en el buffer,
## le da a Guardar y borra lo que el agente acaba de escribir. No hay API para
## saber quien va a guardar ni para negar que se abra una pestana, asi que el
## bloqueo va por el otro lado: guardar lo que el usuario tiene (su buffer gana el
## disco), cerrar las pestanas que habia y vigilar que no vuelvan hasta que el
## turno termine. Al soltar, las del usuario vuelven leidas DEL DISCO, que es la
## version del agente.
##
## Se arma solo cuando la herramienta que va a correr no es de solo lectura y
## alguno de sus argumentos nombra un .gd, .tscn o .tres: una pregunta suelta, un
## "Read file" o un "Check project" no cierran nada, y en Plan mode no hay
## herramienta que arme. Se suelta cuando el turno del agente termina: el aviso
## son los tres indicadores de Chat en bajo un segundo seguido, porque por ahi
## pasan TODOS los finales del turno - la respuesta, el error, el reintento y la
## cancelacion. Vigilar por tiempo es ademas la razon de no engancharse a
## _detenerSpinnerBoton: esa se llama tambien al EMPEZAR cada peticion, y soltaria
## el bloqueo justo al armarlo.
##
## Las escenas del agente son suyas: sus herramientas (Open scene, las de nodos,
## Save scene) abren escenas y las necesitan abiertas, asi que mientras corre una
## herramienta no se cierra nada, y lo que aparece con ella se adopta en una
## ventana de unos ticks (abrir una escena esta diferido y una escena grande tarda
## en aparecer: mirar en el mismo cuadro no vale). Pasada la ventana, lo que
## aparezca ya es del usuario y el tick lo cierra. Las pestanas de guion no se
## adoptan nunca: Dotti edita los archivos en disco y no necesita una pestana
## abierta, y por eso se cierran tambien mientras corre la herramienta. Lo que si
## se respeta siempre es una escena sin guardar: cerrarla perderia el trabajo o
## sacaria el dialogo de confirmacion en mitad del turno.
##
## Lo que no vuelve: un guion integrado (el que vive dentro de una escena, con
## ruta "res://escena.tscn::GDScript_x") no es un archivo y no se puede reabrir.
## Y una escena nueva sin guardar, la que todavia no tiene ruta, no se toca.

## Extensiones que arman el bloqueo. Un .gd abierto se puede guardar encima; una
## escena abierta se edita y se guarda desde el dock de Escena.
const EXTENSIONES := ["gd", "tscn", "tres"]

## Cada cuanto se mira si hay pestanas que cerrar. Un cuarto de segundo es lo que
## tarda el usuario en ver que la pestana que acaba de abrir se vuelve a cerrar.
const INTERVALO := 0.25

## Ticks seguidos sin turno antes de soltar. Cuatro son un segundo: suficiente
## para no soltar entre dos herramientas de la misma ronda, corto para que las
## pestanas no se queden cerradas mas de la cuenta.
const TICKS_SIN_TURNO := 4

## Ticks que dura la ventana de adopcion despues de cada herramienta. Cuatro son
## un segundo, y no es un numero al azar: abrir una escena esta diferido en el
## editor y una escena grande tarda lo suyo en aparecer abierta, asi que la
## vigilancia no puede mirar en el mismo cuadro en que la herramienta volvio. Lo
## que aparezca dentro de la ventana es del agente; lo que aparezca despues ya es
## cosa del usuario y se cierra.
const TICKS_ADOPCION := 4

## Tope de vueltas al cerrar pestanas. Doce cubren un pestaneo normal, y un
## cierre que se niegue no enciende un bucle.
const INTENTOS_CIERRE := 12

var _chat: Node = null
var _temporizador: Timer = null
var _activo := false
## Cuantas herramientas estan corriendo ahora mismo. Es un contador y no un
## booleano porque un subagente llama a las suyas por dentro de la suya.
var _pausa := 0
## Ticks que le quedan a la ventana de adopcion. Mientras dure, la vigilancia no
## cierra escenas: esta esperando a ver cuales abrio la herramienta.
var _gracia := 0
var _sinTurno := 0
var _avisado := false
var _guionesUsuario := PackedStringArray()
var _escenasUsuario := PackedStringArray()
var _escenaActualUsuario := ""
var _escenasDotti := PackedStringArray()

## Engancha el bloqueo al chat. Se llama una vez, al construir el panel.
func configurar(chat: Node) -> void:
	_chat = chat
	_temporizador = Timer.new()
	_temporizador.name = "BloqueoEditorTimer"
	_temporizador.wait_time = INTERVALO
	_temporizador.one_shot = false
	_temporizador.autostart = false
	_temporizador.timeout.connect(_al_tick)
	add_child(_temporizador)

## Antes de una herramienta: si escribe codigo, se arma; y se pausa, que una
## herramienta de escena abre escenas propias que no hay que tocar hasta que
## vuelva. Fuera del editor no hay nada que bloquear.
func antes_de_herramienta(nombre: String, args: Dictionary) -> void:
	if _interfaz() == null:
		return
	_pausa += 1
	if not DottiAgentes.herramientas_solo_lectura().has(nombre) and _nombraCodigo(args):
		_armar()

## Al volver de una herramienta: lo que quede abierto es del agente y se adopta,
## que es lo que lo saca de la mira de la vigilancia. Lo del usuario no se adopta:
## si abrio una escena mientras corria la herramienta, se cierra al acabarse la
## ventana de adopcion.
##
## Aqui se adopta ya lo que este abierto, pero la ventana sigue abierta unos ticks
## mas porque abrir una escena esta diferido: en el cuadro en que la herramienta
## vuelve la escena todavia no esta, y sin esos ticks el primer cierre se la
## llevaba por delante. Los adopta el tick, que es el que mira de verdad.
func despues_de_herramienta() -> void:
	_pausa = maxi(0, _pausa - 1)
	if not _activo:
		return
	_gracia = TICKS_ADOPCION
	_adoptar()

## Suelta el bloqueo: guarda lo que el agente dejara a medias, cierra sus escenas
## y devuelve al usuario las pestanas que tenia, leidas del disco.
func soltar() -> void:
	if not _activo:
		return
	_activo = false
	_pausa = 0
	_gracia = 0
	_sinTurno = 0
	if _temporizador != null:
		_temporizador.stop()
	var interfaz := _interfaz()
	var editor := _editorGuiones()
	# Las escenas del agente: respaldo antes de guardarlas, que su trabajo de
	# escena vive en memoria y es lo unico que puede estar sin guardar. save_all_*
	# guarda solo lo que este sin guardar, asi que una escena que solo se miro no
	# se reescribe.
	if interfaz != null:
		for ruta in _escenasDotti:
			if FileAccess.file_exists(ruta):
				DottiCopias.respaldar(ruta, "scene the agent opened")
		interfaz.call("save_all_scenes")
	if editor != null:
		editor.call("save_all_scripts")
	# Vaciar la lista antes de cerrar: es la que protege a las del agente, y aqui
	# lo que se quiere es que se vayan. Lo del usuario se copia aparte, que es lo
	# que hay que devolver.
	_escenasDotti.clear()
	_cerrarEscenas()
	_cerrarGuiones()
	var guiones := _guionesUsuario
	var escenas := _escenasUsuario
	var actual := _escenaActualUsuario
	_escenasUsuario = PackedStringArray()
	_guionesUsuario = PackedStringArray()
	_escenaActualUsuario = ""
	_avisado = false
	if interfaz == null:
		return
	# Y vuelven las del usuario, leyendo: lo que ve es la version del agente. Las
	# escenas van con la suya la ultima, para que sea tambien la que quede delante.
	for ruta in guiones:
		if FileAccess.file_exists(ruta):
			var guion: Resource = load(ruta)
			if guion != null:
				interfaz.call("edit_script", guion, -1, 0, false)
	for ruta in escenas:
		if ruta != actual and FileAccess.file_exists(ruta):
			interfaz.call("open_scene_from_path", ruta)
	if actual != "" and FileAccess.file_exists(actual):
		interfaz.call("open_scene_from_path", actual)

## El tic del vigilante. Mientras el turno corre cierra lo que aparezca; cuando el
## turno lleva un segundo terminado suelta. Ese es tambien el paracaidas: un fallo
## en el bucle no puede dejar el editor bloqueado para siempre.
func _al_tick() -> void:
	if not _activo:
		return
	if not _turnoEnCurso():
		_pausa = 0
		_gracia = 0
		_sinTurno += 1
		if _sinTurno >= TICKS_SIN_TURNO:
			soltar()
			return
	else:
		_sinTurno = 0
	_cerrarGuiones()
	# En la ventana de adopcion solo se mira (y se adopta): lo que aparezca ahora
	# es de la herramienta que acaba de volver. Despues, y fuera de una llamada,
	# ya se puede cerrar: lo que haya es del usuario y no se le deja.
	if _gracia > 0:
		_gracia -= 1
		_adoptar()
		return
	if _pausa == 0:
		_cerrarEscenas()

## Lo que este abierto pasa a ser del agente: son las escenas que abrieron sus
## herramientas, y la vigilancia no las toca hasta soltar.
##
## Se adopta todo lo que haya, sin mirar la lista del usuario, y a proposito: la
## escena que el agente abre suele ser justo la que el usuario tenia abierta, y
## saltarsela la dejaba sin proteger - la herramienta siguiente se encontraba sin
## escena en el editor. Lo que separa al agente del usuario no es la ruta sino el
## momento: esto solo se llama con una herramienta recien vuelta o dentro de su
## ventana, y una escena que aparezca fuera de ese momento ya es del usuario y el
## tick la cierra.
func _adoptar() -> void:
	for ruta in _escenasAbiertas():
		if ruta != "" and not _escenasDotti.has(ruta):
			_escenasDotti.append(ruta)

## Arma el bloqueo: apunta lo que hay abierto, lo guarda, lo respalda y lo cierra.
func _armar() -> void:
	if _activo:
		return
	_activo = true
	_avisado = false
	_guionesUsuario = PackedStringArray()
	_escenasUsuario = PackedStringArray()
	_escenasDotti = PackedStringArray()
	_escenaActualUsuario = ""
	var interfaz := _interfaz()
	var editor := _editorGuiones()
	if editor != null:
		for guion in editor.call("get_open_scripts"):
			var ruta := _rutaDeGuion(guion)
			if ruta != "" and not _guionesUsuario.has(ruta):
				_guionesUsuario.append(ruta)
	if interfaz != null:
		_escenasUsuario = _escenasAbiertas()
		var raiz = interfaz.call("get_edited_scene_root")
		if raiz != null:
			_escenaActualUsuario = str(raiz.get("scene_file_path"))
	# Guardar es la mitad del arreglo: el buffer del usuario gana el disco antes
	# de que el agente escriba, asi que no hay version vieja que guardar encima.
	# Y de paso no queda nada sin guardar que preguntar al cerrar.
	if editor != null:
		editor.call("save_all_scripts")
	if interfaz != null:
		interfaz.call("save_all_scenes")
	# El respaldo va DESPUES de guardar a proposito: lo que hay que poder
	# recuperar es lo que el usuario acaba de escribir, no lo que ya habia.
	for ruta in _guionesUsuario:
		DottiCopias.respaldar(ruta, "script open in the editor")
	for ruta in _escenasUsuario:
		DottiCopias.respaldar(ruta, "scene open in the editor")
	_cerrarGuiones()
	_cerrarEscenas()
	_avisar()
	_gracia = 0
	_sinTurno = 0
	if _temporizador != null and _temporizador.is_inside_tree():
		_temporizador.start()

## Cierra toda pestana de guion abierta. Los guiones no se adoptan nunca: Dotti
## escribe en disco y no necesita pestana, asi que aqui no hay nada que respetar.
func _cerrarGuiones() -> void:
	var editor := _editorGuiones()
	if editor == null:
		return
	var intentos := 0
	while intentos < INTENTOS_CIERRE:
		var abiertos: Array = editor.call("get_open_scripts")
		var cerroAlguno := false
		for guion in abiertos:
			var ruta := _rutaDeGuion(guion)
			if ruta != "" and editor.call("close_file", ruta) == OK:
				cerroAlguno = true
		if not cerroAlguno:
			return
		intentos += 1

## Cierra las escenas que no sean del agente. Una escena sin guardar no se toca:
## cerrarla perderia el trabajo o sacaria el dialogo de confirmacion en mitad del
## turno. close_scene() cierra la escena ACTUAL y ninguna mas, de ahi traer al
## frente la que toca antes de cerrarla (y de ahi el parpadeo del dock al armar).
func _cerrarEscenas() -> void:
	var interfaz := _interfaz()
	if interfaz == null:
		return
	var sinGuardar: PackedStringArray = interfaz.call("get_unsaved_scenes")
	var intentos := 0
	while intentos < INTENTOS_CIERRE:
		var objetivo := ""
		for ruta in _escenasAbiertas():
			if ruta != "" and not _escenasDotti.has(ruta) and not sinGuardar.has(ruta):
				objetivo = ruta
				break
		if objetivo == "":
			return
		interfaz.call("open_scene_from_path", objetivo)
		if interfaz.call("get_edited_scene_root") == null:
			return
		if interfaz.call("close_scene") != OK:
			return
		intentos += 1

func _avisar() -> void:
	if _avisado or _chat == null or not is_instance_valid(_chat):
		return
	_avisado = true
	_chat.call("_avisoEnChat", "Editor tabs are locked while Dotti works on your scripts. They come back when the turn ends.")

## Hay turno del agente en marcha. Los tres indicadores juntos son los que sabe
## bajar cada final del turno; con uno en alto, el turno sigue vivo.
func _turnoEnCurso() -> bool:
	if _chat == null or not is_instance_valid(_chat):
		return false
	return bool(_chat.get("_bucleAgenteActivo")) or bool(_chat.get("_esperandoRespuesta")) or bool(_chat.get("_reintentando"))

## Alguna cadena de los argumentos nombra un archivo de codigo. Se mira dentro de
## listas y diccionarios: los pasos de "Test game" y los argumentos anidados de
## otras herramientas viven ahi.
func _nombraCodigo(args: Dictionary) -> bool:
	for valor in args.values():
		if _mencionaCodigo(valor):
			return true
	return false

func _mencionaCodigo(valor: Variant) -> bool:
	match typeof(valor):
		TYPE_STRING, TYPE_STRING_NAME:
			return _esCodigo(str(valor))
		TYPE_ARRAY:
			for dentro in valor:
				if _mencionaCodigo(dentro):
					return true
		TYPE_DICTIONARY:
			for dentro in (valor as Dictionary).values():
				if _mencionaCodigo(dentro):
					return true
	return false

func _esCodigo(texto: String) -> bool:
	var limpio := texto.strip_edges()
	# Una ruta no lleva saltos de linea; un texto que los lleve es una prosa que
	# habla de un archivo, no el archivo.
	if limpio == "" or limpio.contains("\n"):
		return false
	var corte := limpio.find("::")
	if corte >= 0:
		limpio = limpio.substr(0, corte)
	return EXTENSIONES.has(limpio.get_extension().to_lower())

## La ruta con la que el editor conoce la pestana de un guion, o "" si el guion
## todavia no tiene nombre (uno nuevo sin guardar).
func _rutaDeGuion(guion: Variant) -> String:
	if guion == null or not (guion is Resource):
		return ""
	return str((guion as Resource).resource_path).strip_edges()

func _escenasAbiertas() -> PackedStringArray:
	var interfaz := _interfaz()
	if interfaz == null:
		return PackedStringArray()
	return interfaz.call("get_open_scenes")

## El editor, por el singleton y no por el nombre: nombrar EditorInterface en el
## guion dejaria de compilar en un juego exportado, donde no existe. Es la misma
## puerta que usa el nucleo (DottiCopias::respaldarEscenaAbierta).
func _interfaz() -> Object:
	if not Engine.is_editor_hint():
		return null
	if not Engine.has_singleton("EditorInterface"):
		return null
	return Engine.get_singleton("EditorInterface")

func _editorGuiones() -> Object:
	var interfaz := _interfaz()
	if interfaz == null or not interfaz.has_method("get_script_editor"):
		return null
	return interfaz.call("get_script_editor")
