@tool
class_name HerramientasJuego

## Herramientas para jugar el juego: probarlo de verdad.
##
## "Test game" arranca la escena en un proceso aparte y le hace los pasos que
## el modelo pida (esperar, pulsar un boton, llamar a un metodo, leer un valor,
## mandar una accion, sacar una foto). Vive en el nucleo como operacion con
## senal -el juego tarda y se espera con ticks-, asi que aqui queda el registro
## y el puente de espera.

static func registrar(chat: Node) -> void:
	chat.registrarHerramienta(
		"Test game",
		"Runs the project in a separate process and drives it: waits, presses buttons, calls methods, reads node properties, sends input actions and takes screenshots, then reports what happened, what the game printed and every runtime error, with file and line. Nothing appears in the editor while it runs. Use it to check that the game really works after your changes, not only that the scripts compile.",
		{
			"scene": {"type": "string", "description": "Scene to run, e.g. res://levels/level_1.tscn. Defaults to the project main scene."},
			"steps": {"type": "array", "description": "Steps to run in order, each an object with a \"do\": {\"do\":\"wait\",\"seconds\":1}, {\"do\":\"press\",\"node\":\"HUD/Boton\",\"signal\":\"pressed\"}, {\"do\":\"call\",\"node\":\"Main\",\"method\":\"reset\",\"args\":[]}, {\"do\":\"read\",\"node\":\"HUD/Marcador\",\"property\":\"text\"}, {\"do\":\"input\",\"action\":\"ui_accept\",\"pressed\":true}, {\"do\":\"screenshot\",\"name\":\"final\"}. Node paths are relative to the scene root. Without steps it only starts the scene and reports what happened."},
			"seconds": {"type": "number", "description": "How long the run may take in total before it is stopped. Defaults to 30, at most 120."},
			"visible": {"type": "boolean", "description": "If true the game opens in a real window, so the user can watch it and screenshots work. Defaults to false: it runs without a window, which is faster."},
		},
		[],
		_probarJuego.bind(chat)
	)

static func _probarJuego(args: Dictionary, chat: Node) -> Dictionary:
	return await OperacionesNativas.herramienta(chat, DottiJuego.new(), &"jugar", [args])
