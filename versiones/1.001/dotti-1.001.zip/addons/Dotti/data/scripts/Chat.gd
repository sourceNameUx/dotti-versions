@tool
extends Control

## Marca de build visible (barra superior + debugger). Subir en cada cambio
## para saber que codigo corre en el editor.
const DOTTI_BUILD := "1.001"

## Lado del icono de herramienta de las tarjetas. El spinner de la misma fila mide
## lo mismo, asi que el titulo no se mueve al terminar la ejecucion.
const TAMANO_ICONO_HERRAMIENTA := 14

signal respuesta_pregunta_nativa(texto: String)

@export_range(1, 10, 0.5) var tiempoHerramienta : float = 0
@export_range(1, 10, 0.5) var tiempoEsperaEnviarMensaje: float = 0
@export var duracionAnimacionBurbuja: float = 0.35
@export var duracionAnimacionEscala: float = 0.25
@export var duracionAnimacionFade: float = 0.2
@export var duracionAnimacionTarjeta: float = 0.4
@export var retardoEntreElementos: float = 0.05
@export var duracionAnimacionAccordion: float = 0.3
@export var duracionAnimacionReintento: float = 0.15
@export var duracionAnimacionBotonSpinner: float = 0.08

var entradaVBox : VBoxContainer
var contenedorMensajes: VBoxContainer
var campoTexto: TextEdit
var _completado: ChatAutocompletado = null
var botonEnviar: Button
var _labelSpinnerBoton: Label = null
var _timerSpinnerBoton: Timer = null
var _frameSpinnerBoton: int = 0

var _router: LLMRouter
var _apis: Apis

# Cliente nativo (OpenAI tools + SSE). Solo para proveedores tipo "openai".
var _streamer: LLMNativo = null
var _burbujaStream: MarkdownLabel = null
var _textoStreamAcumulado := ""
var _creandoBurbujaRazon := false
var _razonamientoPendienteNativo := ""
var _prefijoStreamLimpio := false
var _creandoBurbujaStream := false
var _stallsConsecutivos := 0
# Verdadero mientras el modelo escribe y el usuario sigue pegado al final. Si
# el usuario sube a leer, se apaga y se respeta su posicion.
var _seguirStreamAlFinal := false
# Verdadero mientras el chat mueve el scroll por su cuenta, para no confundir
# ese movimiento con uno del usuario.
var _fijandoScroll := false
# Ultimo render de markdown durante el stream (ver _puedeRenderizarStream).
var _ultimoRenderStreamMsec := 0

var historialConversacion: Array = []
var _esperandoRespuesta: bool = false
var _bucleAgenteActivo: bool = false
var _contadorReintentos: int = 0
var _reintentando: bool = false
var _peticionCancelada: bool = false
var _idEscritura: int = 0
var _idSesion: int = 0
# Tokens que costo la ultima peticion, ya normalizados (ver ChatModelos.usoNormalizado).
# Lo escriben los dos caminos de peticion cuando el proveedor los manda, y se vacia al
# abrir otro chat: el contador ensena el gasto de la conversacion que se esta viendo.
var _usoActual: Dictionary = {}

var _textoBoton: String = ""
var _idChatActual: String = ""
var _tituloChatActual: String = ""
var _timestampChatActual: int = 0

var _herramientas: Dictionary = {}
var _mensajeHerramientaActual: Control = null
## VBox donde van las tarjetas de lo que hace un subagente mientras corre (el
## hilo que cuelga de la tarjeta del "Run agent"). null cuando no hay ninguno
## en marcha: lo abren y lo cierran _ejecutarUnaHerramienta y
## _crearTarjetaHerramienta es el unico sitio que lo mira.
var _hiloSubagente: VBoxContainer = null
var _burbujaEsperando: Control = null
var _burbujaRazonamiento: Control = null
var _textoRazonamientoAcumulado: String = ""
var _inicioRazonamientoMsec: int = 0
var _tarjetaReintentos: Control = null
var _timerTarjetaReintentos: Timer = null
var _listaErrores: Array = []

# Titulo del chat generado por la IA (una sola peticion corta por chat).
var _tituloGeneradoPorIA: bool = false
var _tituloIAEnCurso: bool = false
var _tituloIACliente: LLMNativo = null
var _tituloIAIdChat: String = ""

var _principalVBox: VBoxContainer = null
var _margenRaiz: MarginContainer = null
var _marcoBarraSuperior: PanelContainer = null
var _barraSuperior: HBoxContainer = null
var _tituloBarra: Label = null
var _separador1: HSeparator = null
var _separador2: HSeparator = null
var _scrollContenedor: ScrollContainer = null
var _marcoEntrada: PanelContainer = null
var _estiloMarcoEntradaNormal: StyleBoxFlat = null
var _estiloMarcoEntradaVacio: StyleBoxEmpty = null
var _estiloBarraSuperior: StyleBoxFlat = null
var _labelBuild: Label = null
var _labelTokens: Label = null
var _selectorModo: Button = null
var _selectorModelo: Button = null
var _selectorPermisos: Button = null
var _selectorRazonamiento: Button = null
var _popupModo: PopupMenu = null
var _popupModelo: PopupMenu = null
var _popupPermisos: PopupMenu = null
var _popupRazonamiento: PopupMenu = null
const NIVELES_RAZONAMIENTO := ["none", "high", "max"]
var _tokenRenderizado: int = 0
var _renderizandoChat: bool = false
var _panelCargaChat: Control = null
# El aviso de "falta entrar en la cuenta", si esta pintado. Vive aqui para no
# repetirlo en cada envio: con uno delante, el usuario ya sabe lo que pasa.
var _avisoCuenta: Control = null
# Lista de tareas de la sesion (la escribe "Update todo list"). Vive aqui y no en
# el historial para poder volver a inyectarla en el prompt cuando la conversacion
# se recorta, y para que el panel siga ahi al reabrir el chat (se guarda con el).
var _tareas: Array = []
# Compactacion del contexto (P8). `_resumen` es el checkpoint de lo que ya no
# viaja al modelo y `_corteResumen` el primer mensaje del historial que sigue
# enviandose (todo lo anterior esta resumido). Los dos son estado del chat y se
# guardan con el: al reabrir, el contexto sigue recortado.
var _resumen: String = ""
var _corteResumen: int = 0
# Cuando se hizo el corte (unix). Se guarda con el chat porque la fila de la
# compactacion dice la hora: recalculada al reabrir diria la de ahora, que no
# es la del corte.
var _fechaResumen: int = 0
var _compactando: bool = false
# Agente activo del chat (P9), {} si no hay ninguno. Se invoca escribiendo
# @nombre, o desde el selector de la fila de controles. Trae prompt, lista de
# herramientas y modelo, y es estado del chat: se guarda con el y vuelve al
# reabrirlo.
var _agente: Dictionary = {}
var _panelTareas: PanelContainer = null
var _cabeceraTareas: HBoxContainer = null
var _etiquetaTareas: Button = null
var _previewTareas: Label = null
var _listaTareas: VBoxContainer = null
var _scrollTareas: ScrollContainer = null
var _popupSugerenciasArchivos: PopupMenu = null
var _sugerenciaArchivoActiva: bool = false
var _ultimoPathArchivos: String = ""
var _editorActual: Control = null

# La tarjeta de "hay version nueva": su cuerpo (para poder repintarlo cuando el
# usuario instala o dice que no), el manifiesto que se esta ofreciendo y lo que
# ha pasado por el camino. `_actualizacion_instalada` es la version que acaba de
# quedar en el disco: el codigo cargado sigue siendo el viejo hasta que se
# reinicie el editor, y eso hay que decirlo.
var _tarjeta_actualizacion: VBoxContainer = null
var _info_actualizacion: Dictionary = {}
var _instalando_actualizacion: bool = false
var _actualizacion_instalada: String = ""
var _respaldo_actualizacion: String = ""
var _error_actualizacion: String = ""

const PERMISOS_PREGUNTAR := ChatPermisos.PERMISOS_PREGUNTAR
const PERMISOS_AUTOMATICOS := ChatPermisos.PERMISOS_AUTOMATICOS
const PERMISOS_TODOS := ChatPermisos.PERMISOS_TODOS
## Margen (px) para considerar que la vista esta "pegada al final". Es corto a
## proposito: en cuanto el usuario sube un poco se deja de seguirle el texto.
const UMBRAL_AUTOSCROLL := 24.0
## Rehacer el markdown completo en cada delta congela el motor: medido, unos
## 30 ms por cada 1000 caracteres de texto. Por debajo de este tamano el render
## es barato y se hace en cada delta; por encima se limita el ritmo.
const UMBRAL_STREAM_CORTO := 1500
const INTERVALO_RENDER_STREAM_MSEC := 120
## Razonamiento: a partir de este tamano lo ya recibido se congela en etiquetas
## propias y solo se reescribe la cola viva. Sin markdown de por medio el coste ya
## es bajo, pero esto acota el trabajo por delta aunque la traza sea enorme.
const RAZONAMIENTO_TROZO_MIN := 1200

var _pantallaBienvenida: Control = null
var _filaContexto: HBoxContainer = null
var _contenedorChipsContexto: HBoxContainer = null
var _botonAgregarContexto: Button = null
var _dialogoArchivos: FileDialog = null
var _archivosContexto: Array = []
var _contenedorOpcionesRapidas: VBoxContainer = null
var _filaControles: HBoxContainer = null
var _tarjetaPreguntaActiva: Control = null

const MAX_REINTENTOS := 5
const ESPERA_REINTENTO := 5.0
## Fallos que la pasarela ya decidio y que otro intento no arregla: sin cuenta,
## con el token revocado, con la cuenta suspendida, sin cupo del dia o sin saldo.
## Se reconocen por su texto porque el codigo estable de la pasarela
## (`auth_required`, `daily_limit_reached`...) se pierde cuando el router convierte
## el cuerpo en el mensaje que lee el usuario. Las frases son las de
## `proxy/production.mjs`; si cambian alli, esto deja de reconocerlas y esos fallos
## vuelven a reintentarse como los demas, que es lo que hacia antes.
const FALLOS_SIN_REINTENTO := [
	"Settings > Account",
	"account is suspended",
	"reached today's limit",
	"account is out of credit",
]
## Tope de la peticion aparte que resume la conversacion (P8). Es un resumen, no
## una tarea larga: si el modelo no ha terminado en este rato, no compensa seguir
## esperando con el chat parado y se envia sin compactar.
const SEGUNDOS_TIMEOUT_RESUMEN := 90.0
const ALTURA_MAXIMA_CAMPO := 150.0
const ALTURA_MINIMA_CAMPO := 44.0
const MENSAJES_POR_FRAME := 3
const UMBRAL_TEXTO_CHUNK := 3000
const TAMANO_CHUNK_TEXTO := 1500
const UMBRAL_ADVERTENCIA_LARGO := 40
const ANCHO_MINIMO_CHAT := 280.0
const ALTO_MINIMO_CHAT := 300.0

const SPINNER_FRAMES := ["⠋", "⠙", "⠹", "⠸", "⠼", "⠴", "⠦", "⠧", "⠇", "⠏"]

const COLOR_ACENTO := ChatEstilos.COLOR_ACENTO
const COLOR_ACENTO_SUAVE := ChatEstilos.COLOR_ACENTO_SUAVE
const COLOR_USUARIO_BG := ChatEstilos.COLOR_USUARIO_BG
const COLOR_USUARIO_BORDE := ChatEstilos.COLOR_USUARIO_BORDE
const COLOR_ASISTENTE_BG := ChatEstilos.COLOR_ASISTENTE_BG
const COLOR_ASISTENTE_BORDE := ChatEstilos.COLOR_ASISTENTE_BORDE
const COLOR_TEXTO_PRIMARIO := ChatEstilos.COLOR_TEXTO_PRIMARIO
const COLOR_TEXTO_SECUNDARIO := ChatEstilos.COLOR_TEXTO_SECUNDARIO
const COLOR_TEXTO_TENUE := ChatEstilos.COLOR_TEXTO_TENUE
const COLOR_PANEL_FONDO := ChatEstilos.COLOR_PANEL_FONDO
const COLOR_PANEL_BORDE := ChatEstilos.COLOR_PANEL_BORDE
const COLOR_SPINNER := ChatEstilos.COLOR_SPINNER
const COLOR_ESTADO_OK := ChatEstilos.COLOR_ESTADO_OK
const COLOR_ESTADO_WARN := ChatEstilos.COLOR_ESTADO_WARN
const COLOR_ESTADO_ERR := ChatEstilos.COLOR_ESTADO_ERR
## Traza de razonamiento: color apagado y atenuado, como el texto del bloque de
## razonamiento del TUI de opencode, pero dentro de una tarjeta "Thinking"
## minimizada por defecto (se abre al pulsarla).
const COLOR_RAZONAMIENTO := Color(0.55, 0.55, 0.62, 0.82)
## Fila de herramienta: el titulo que le puso el modelo, y el detalle del estado
## solo cuando hay algo que contar.
const COLOR_HERRAMIENTA_NOMBRE := Color(0.70, 0.70, 0.74, 1.0)
const COLOR_HERRAMIENTA_DETALLE := Color(0.47, 0.47, 0.51, 1.0)
## Filete del divisor de la compactacion: la linea tenue que flanquea la
## cabecera, como el divisor de "Session compacted" de opencode. Translucido
## porque es mobiliario, no texto.
const COLOR_LINEA_DIVISOR := Color(0.43, 0.43, 0.43, 0.6)
const GLIFO_ERR := "✗"
const GLIFO_DENEGADA := "✕"
const GLIFO_OK := "✓"
## Flechas del acordeon. ASCII a proposito: la fuente del editor no trae los
## triangulos (U+25B8/U+25BE) y se pintarian como cuadros vacios.
const GLIFO_ACORDEON_CERRADO := ">"
const GLIFO_ACORDEON_ABIERTO := "v"
## Cabeceras de las tarjetas plegables.
const TEXTO_RAZONANDO := "Thinking"
const TEXTO_RAZONAMIENTO_CORTO := "Thought"
## Resultado de herramienta: tope de caracteres que se guardan en la tarjeta. El
## historial completo sigue en el historial del chat; la tarjeta es solo la vista.
const MAX_RESULTADO_TARJETA := 4000
## Miniaturas de imagen en el chat (lo que devuelve una herramienta que ve o
## captura, y lo que adjunta el usuario). Se pintan dentro de una caja de
## MINIATURA_ANCHO x MINIATURA_ALTO conservando la proporcion, y solo las
## primeras MAX_MINIATURAS: la lista completa sigue en el historial.
const MINIATURA_ANCHO := 320
const MINIATURA_ALTO := 180
const MAX_MINIATURAS := 4
## Marca del mensaje que lleva pegadas las imagenes que devolvio una herramienta.
## Es lo que hace que el modelo las vea: la parte de texto solo las presenta, el
## valor va en la lista "imagenes" de la entrada. Empieza por corchetes para poder
## reconocerla al repintar un chat guardado y no ensenarla como mensaje del usuario.
const MARCA_IMAGENES_ADJUNTAS := "[ATTACHED_IMAGES] The images after this line are the result of the tool calls above. Look at them before you answer."
## Alto del cuerpo desplegado de la lista de tareas. La lista se queda con lo que
## sobra en el chat (ALTO_RESERVADO_LISTA: barra, separadores, cabecera del panel,
## caja de texto, controles y un resto para que los mensajes no desaparezcan),
## entre un minimo de un par de filas y un tope para que una lista larga no empuje
## la caja de texto fuera del panel del editor: lo que no cabe se desplaza.
const ALTO_MIN_LISTA := 70
const ALTO_MAX_LISTA := 230
const ALTO_RESERVADO_LISTA := 361
## Traza de razonamiento guardada: tamano de cada trozo al repintar un chat. La
## traza no se analiza como markdown, se reparte en etiquetas simples.
const TROZO_RAZONAMIENTO_GUARDADO := 4000
## Ritmo del spinner de fila, en segundos: 80 ms por cuadro, el mismo del TUI de
## opencode. Va por temporizador y no por frame: animar en cada frame es lo que
## hacia que la tarjeta de espera anterior se quitara.
const INTERVALO_SPINNER_FILA := 0.08

func _ready() -> void:
	for hijo in get_children():
		hijo.queue_free()
	_construirInterfaz()
	_apis = Apis.new()
	_router = LLMRouter.new()
	_router.inicializar(self, _apis)
	_router.respuesta_recibida.connect(_alRecibirContenido)
	_router.error_recibido.connect(_manejarError)
	if _router.has_signal("razonamiento_recibido"):
		_router.razonamiento_recibido.connect(_alRecibirRazonamiento)
	if _router.has_signal("razonamiento_finalizado"):
		_router.razonamiento_finalizado.connect(_alFinalizarRazonamiento)
	if _router.has_signal("uso_recibido"):
		_router.uso_recibido.connect(_alRecibirUso)
	_textoBoton = botonEnviar.text
	HerramientasChat.registrarTodas(self)
	Adjuntos.limpiarViejos()
	_iniciarNuevoChat()
	_actualizarTextoSelectores()
	# Al final y sin await: ninguna de las tres puede retrasar la apertura del
	# chat, y las de los avisos solo pintan cuando falta algo.
	_avisarSiFaltaElNucleo()
	_avisarSiFaltaLaCuenta()
	_comprobarActualizacionesAlArrancar()

func _process(_delta: float) -> void:
	# Mientras el modelo escribe se sigue el final cada frame (el layout del
	# texto nuevo tarda un frame mas que el delta), pero solo si el usuario
	# sigue abajo: si sube a leer, _alMoverScroll apaga el seguimiento.
	if _seguirStreamAlFinal and _esperandoRespuesta:
		_irAlFinal()

func registrarHerramienta(nombre: String, descripcion: String, parametros: Dictionary, requeridos: Array, funcion: Callable) -> void:
	_herramientas[nombre] = {
		"descripcion": descripcion,
		"parametros": parametros,
		"requeridos": requeridos,
		"funcion": funcion
	}

func _construirInterfaz() -> void:
	custom_minimum_size = Vector2(ANCHO_MINIMO_CHAT, ALTO_MINIMO_CHAT)

	var panelFondo := Panel.new()
	panelFondo.name = "PanelFondo"
	panelFondo.anchor_right = 1.0
	panelFondo.anchor_bottom = 1.0
	panelFondo.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	panelFondo.size_flags_vertical = Control.SIZE_EXPAND_FILL
	add_child(panelFondo)

	_margenRaiz = MarginContainer.new()
	_margenRaiz.name = "Margen"
	_margenRaiz.anchor_right = 1.0
	_margenRaiz.anchor_bottom = 1.0
	_margenRaiz.add_theme_constant_override("margin_left", 10)
	_margenRaiz.add_theme_constant_override("margin_top", 10)
	_margenRaiz.add_theme_constant_override("margin_right", 10)
	_margenRaiz.add_theme_constant_override("margin_bottom", 10)
	panelFondo.add_child(_margenRaiz)

	_principalVBox = VBoxContainer.new()
	_principalVBox.name = "Principal"
	_principalVBox.add_theme_constant_override("separation", 8)
	_principalVBox.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_principalVBox.size_flags_vertical = Control.SIZE_EXPAND_FILL
	_margenRaiz.add_child(_principalVBox)
	var principal := _principalVBox

	_marcoBarraSuperior = PanelContainer.new()
	_marcoBarraSuperior.name = "MarcoBarraSuperior"
	_marcoBarraSuperior.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_estiloBarraSuperior = ChatEstilos.crearEstiloBarraSuperior()
	_marcoBarraSuperior.add_theme_stylebox_override("panel", _estiloBarraSuperior)
	principal.add_child(_marcoBarraSuperior)

	_barraSuperior = HBoxContainer.new()
	_barraSuperior.name = "BarraSuperior"
	_barraSuperior.alignment = BoxContainer.ALIGNMENT_CENTER
	_barraSuperior.add_theme_constant_override("separation", 6)
	_barraSuperior.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_marcoBarraSuperior.add_child(_barraSuperior)

	var puntoEstado := Label.new()
	puntoEstado.name = "PuntoEstado"
	puntoEstado.text = ""
	puntoEstado.add_theme_color_override("font_color", COLOR_ACENTO_SUAVE)
	puntoEstado.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	_barraSuperior.add_child(puntoEstado)

	var spacerBarra := Control.new()
	spacerBarra.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_barraSuperior.add_child(spacerBarra)

	_popupModo = PopupMenu.new()
	_popupModo.add_item("Agent", 0)
	_popupModo.add_item("Plan", 1)
	_popupModo.id_pressed.connect(_alSeleccionarModo)
	ChatUIFactory.estilizarPopupMenu(_popupModo)
	add_child(_popupModo)

	_popupModelo = PopupMenu.new()
	_popupModelo.id_pressed.connect(_alSeleccionarModelo)
	ChatUIFactory.estilizarPopupMenu(_popupModelo)
	add_child(_popupModelo)

	_popupPermisos = PopupMenu.new()
	_popupPermisos.add_item("Ask permissions", PERMISOS_PREGUNTAR)
	_popupPermisos.add_item("Auto permissions", PERMISOS_AUTOMATICOS)
	_popupPermisos.add_item("Allow all permissions", PERMISOS_TODOS)
	_popupPermisos.id_pressed.connect(_alSeleccionarPermisos)
	ChatUIFactory.estilizarPopupMenu(_popupPermisos)
	add_child(_popupPermisos)

	var btnHistorial := ChatUIFactory.crearBotonIcono("history", "Chat history", "☰")
	btnHistorial.pressed.connect(abrirHistorial)
	_barraSuperior.add_child(btnHistorial)

	var btnNuevoChat := ChatUIFactory.crearBotonIcono("plus", "New chat", "✚")
	btnNuevoChat.pressed.connect(_iniciarNuevoChat)
	_barraSuperior.add_child(btnNuevoChat)

	var btnAjustes := ChatUIFactory.crearBotonIcono("settings", "Settings", "⚙")
	btnAjustes.pressed.connect(abrirConfiguracion)
	_barraSuperior.add_child(btnAjustes)

	_separador1 = HSeparator.new()
	_separador1.name = "Separador1"
	_separador1.modulate = Color(1, 1, 1, 0.08)
	principal.add_child(_separador1)

	_scrollContenedor = ScrollContainer.new()
	_scrollContenedor.name = "ScrollMensajes"
	_scrollContenedor.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	_scrollContenedor.vertical_scroll_mode = ScrollContainer.SCROLL_MODE_AUTO
	_scrollContenedor.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_scrollContenedor.size_flags_vertical = Control.SIZE_EXPAND_FILL
	principal.add_child(_scrollContenedor)

	contenedorMensajes = VBoxContainer.new()
	contenedorMensajes.name = "ContenedorMensajes"
	contenedorMensajes.add_theme_constant_override("separation", 10)
	contenedorMensajes.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	contenedorMensajes.size_flags_vertical = Control.SIZE_EXPAND_FILL
	_scrollContenedor.add_child(contenedorMensajes)
	# La barra avisa de cualquier movimiento (rueda, arrastre, teclado) para
	# distinguir al usuario del scroll automatico del stream.
	var barraScroll := _scrollContenedor.get_v_scroll_bar()
	if is_instance_valid(barraScroll):
		barraScroll.value_changed.connect(_alMoverScroll)

	_pantallaBienvenida = _construirPantallaBienvenida()
	contenedorMensajes.add_child(_pantallaBienvenida)

	_separador2 = HSeparator.new()
	_separador2.name = "Separador2"
	_separador2.modulate = Color(1, 1, 1, 0.08)
	principal.add_child(_separador2)

	# Panel de tareas: va pegado encima de la caja de texto, como el dock de
	# opencode. Nace oculto y solo sale cuando hay lista.
	_panelTareas = _construirPanelTareas()
	principal.add_child(_panelTareas)

	_marcoEntrada = PanelContainer.new()
	_marcoEntrada.name = "MarcoEntrada"
	_marcoEntrada.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_estiloMarcoEntradaVacio = StyleBoxEmpty.new()
	_estiloMarcoEntradaNormal = ChatEstilos.crearEstiloMarcoNormal()
	_marcoEntrada.add_theme_stylebox_override("panel", _estiloMarcoEntradaNormal)
	principal.add_child(_marcoEntrada)

	entradaVBox = VBoxContainer.new()
	entradaVBox.name = "EntradaVBox"
	entradaVBox.add_theme_constant_override("separation", 6)
	entradaVBox.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_marcoEntrada.add_child(entradaVBox)

	_filaContexto = HBoxContainer.new()
	_filaContexto.name = "FilaContexto"
	_filaContexto.add_theme_constant_override("separation", 6)
	_filaContexto.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_filaContexto.visible = false
	entradaVBox.add_child(_filaContexto)

	_contenedorChipsContexto = HBoxContainer.new()
	_contenedorChipsContexto.name = "ChipsContexto"
	_contenedorChipsContexto.add_theme_constant_override("separation", 6)
	_contenedorChipsContexto.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_filaContexto.add_child(_contenedorChipsContexto)

	campoTexto = TextEdit.new()
	campoTexto.name = "CampoTexto"
	campoTexto.placeholder_text = "Write a message..."
	campoTexto.wrap_mode = TextEdit.LINE_WRAPPING_BOUNDARY
	campoTexto.custom_minimum_size = Vector2(0, ALTURA_MINIMA_CAMPO)
	campoTexto.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	campoTexto.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	campoTexto.scroll_fit_content_height = true
	campoTexto.scroll_past_end_of_file = false
	var estiloCampoVacio := StyleBoxEmpty.new()
	campoTexto.add_theme_stylebox_override("normal", estiloCampoVacio)
	campoTexto.add_theme_stylebox_override("focus", estiloCampoVacio)
	campoTexto.text_changed.connect(_alCambiarTextoCampo)
	campoTexto.gui_input.connect(_procesarEntradaCampoTexto)
	entradaVBox.add_child(campoTexto)

	# Sugerencias del campo: "@" lista agentes y archivos del proyecto, "/" los
	# comandos. Va colgado del chat y no de la caja de texto para poder pintarse
	# por encima de ella; se coloca a mano justo arriba del marco de entrada.
	_completado = ChatAutocompletado.new()
	add_child(_completado)
	_completado.configurar(self, campoTexto, _marcoEntrada)
	_completado.archivoMencionado.connect(_alMencionarArchivo)
	_marcoEntrada.resized.connect(_alRedimensionarEntrada)

	var scrollControles := ScrollContainer.new()
	scrollControles.name = "ScrollControles"
	scrollControles.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_AUTO
	scrollControles.vertical_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	scrollControles.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	scrollControles.custom_minimum_size = Vector2(0, 32)
	entradaVBox.add_child(scrollControles)

	_filaControles = HBoxContainer.new()
	_filaControles.name = "FilaControles"
	_filaControles.add_theme_constant_override("separation", 4)
	_filaControles.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_filaControles.alignment = BoxContainer.ALIGNMENT_BEGIN
	scrollControles.add_child(_filaControles)

	_botonAgregarContexto = ChatUIFactory.crearBotonTransparente("+", "Attach files as context")
	_botonAgregarContexto.custom_minimum_size = Vector2(26, 26)
	_botonAgregarContexto.pressed.connect(_alPulsarAgregarContexto)
	_filaControles.add_child(_botonAgregarContexto)

	# El modo va el primero: es lo que decide si el chat puede tocar el proyecto.
	# El agente no tiene selector propio: se pone escribiendo @nombre (o con
	# /agent), y el que esta activo se ve en el marcador de la caja de texto y en
	# el aviso que se pinta al activarlo.
	_selectorModo = ChatUIFactory.crearBotonSelectorPlano("Agent", "Switch between Agent and Plan mode")
	_selectorModo.pressed.connect(_alPulsarSelectorModo)
	_filaControles.add_child(_selectorModo)

	_selectorModelo = ChatUIFactory.crearBotonSelectorPlano("Model", "Select active model provider")
	_selectorModelo.pressed.connect(_alPulsarSelectorModelo)
	_filaControles.add_child(_selectorModelo)

	_selectorPermisos = ChatUIFactory.crearBotonSelectorPlano("Permissions", "Select tool permissions mode")
	_selectorPermisos.pressed.connect(_alPulsarSelectorPermisos)
	_filaControles.add_child(_selectorPermisos)

	_popupRazonamiento = PopupMenu.new()
	_popupRazonamiento.add_item("Non-think", 0)
	_popupRazonamiento.add_item("High", 1)
	_popupRazonamiento.add_item("Max", 2)
	_popupRazonamiento.id_pressed.connect(_alSeleccionarRazonamiento)
	ChatUIFactory.estilizarPopupMenu(_popupRazonamiento)
	add_child(_popupRazonamiento)

	_selectorRazonamiento = ChatUIFactory.crearBotonSelectorPlano("Thinking", "Select model reasoning level")
	_selectorRazonamiento.pressed.connect(_alPulsarSelectorRazonamiento)
	_filaControles.add_child(_selectorRazonamiento)

	var spacerControles := Control.new()
	spacerControles.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_filaControles.add_child(spacerControles)

	# Contador de tokens, pegado a la marca de build: cuanto lleva gastado la
	# conversacion y que parte de la ventana del modelo es. Nace escondido y solo
	# aparece cuando el proveedor manda sus contadores.
	_labelTokens = Label.new()
	_labelTokens.name = "Tokens"
	_labelTokens.visible = false
	_labelTokens.add_theme_color_override("font_color", Color(0.45, 0.45, 0.5, 0.8))
	_labelTokens.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	# El contador tambien es el boton de compactar: un clic resume el contexto. Hay
	# que pedir el raton a mano, que una etiqueta lo ignora por defecto.
	_labelTokens.mouse_filter = Control.MOUSE_FILTER_STOP
	_labelTokens.mouse_default_cursor_shape = Control.CURSOR_POINTING_HAND
	_labelTokens.gui_input.connect(_alPulsarContador)
	_filaControles.add_child(_labelTokens)

	_labelBuild = Label.new()
	_labelBuild.text = DOTTI_BUILD
	_labelBuild.tooltip_text = "Dotti build"
	_labelBuild.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_labelBuild.add_theme_color_override("font_color", Color(0.45, 0.45, 0.5, 0.8))
	_labelBuild.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	_filaControles.add_child(_labelBuild)

	botonEnviar = ChatUIFactory.crearBotonTransparente("➤", "Send message")
	botonEnviar.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	botonEnviar.custom_minimum_size = Vector2(32, 26)
	botonEnviar.add_theme_color_override("font_color", COLOR_ACENTO)
	botonEnviar.pressed.connect(_on_button_pressed)
	_filaControles.add_child(botonEnviar)

	_labelSpinnerBoton = Label.new()
	_labelSpinnerBoton.name = "SpinnerBoton"
	_labelSpinnerBoton.visible = false
	_labelSpinnerBoton.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_labelSpinnerBoton.anchor_left = 0.0
	_labelSpinnerBoton.anchor_top = 0.0
	_labelSpinnerBoton.anchor_right = 1.0
	_labelSpinnerBoton.anchor_bottom = 1.0
	_labelSpinnerBoton.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_labelSpinnerBoton.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	_labelSpinnerBoton.text = SPINNER_FRAMES[0]
	_labelSpinnerBoton.add_theme_color_override("font_color", COLOR_SPINNER)
	botonEnviar.add_child(_labelSpinnerBoton)

func _contenedorActivoMensajes() -> VBoxContainer:
	return contenedorMensajes

func _alPulsarSelectorModo() -> void:
	if not is_instance_valid(_popupModo) or not is_instance_valid(_selectorModo):
		return
	var config := _apis.obtener_configuracion_chat() if _apis else {}
	var idxModo: int = config.get("modoSistema", 0)
	for i in range(_popupModo.item_count):
		_popupModo.set_item_checked(i, _popupModo.get_item_id(i) == idxModo)
	var alturaEstimada := int(_popupModo.item_count) * 26 + 8
	var pos: Vector2 = _selectorModo.get_screen_position() + Vector2(0, -alturaEstimada - 4)
	var ancho: int = int(max(140.0, _selectorModo.size.x))
	_popupModo.popup(Rect2i(Vector2i(pos), Vector2i(ancho, 0)))

func _alSeleccionarModo(id: int) -> void:
	if not _apis:
		return
	var config := _apis.obtener_configuracion_chat()
	config["modoSistema"] = id
	_apis.guardar_configuracion_chat(config)
	_reconstruirSystemPrompt()
	_actualizarTextoSelectores()
	_actualizarPantallaBienvenida()

func _alPulsarSelectorModelo() -> void:
	if not is_instance_valid(_popupModelo) or not is_instance_valid(_selectorModelo) or not _apis:
		return
	_popupModelo.clear()
	if _apis.proveedores.is_empty():
		_popupModelo.add_item("No providers — open Settings", -1)
		_popupModelo.set_item_disabled(0, true)
	else:
		for i in range(_apis.proveedores.size()):
			var p = _apis.proveedores[i]
			# Solo el nombre: los datos del modelo (contexto, tope de salida,
			# tools, thinking) se consultan en Settings > Model.
			_popupModelo.add_item(str(p.get("nombre", "Unnamed")), i)
			_popupModelo.set_item_checked(i, p.get("id", "") == _apis.proveedor_actual_id)
	var alturaEstimada := int(max(1, _popupModelo.item_count)) * 26 + 8
	var pos: Vector2 = _selectorModelo.get_screen_position() + Vector2(0, -alturaEstimada - 4)
	var ancho: int = int(max(380.0, _selectorModelo.size.x))
	_popupModelo.popup(Rect2i(Vector2i(pos), Vector2i(ancho, 0)))

# ---------------------------------------------------------------------------
# Agentes (P9). Un agente es un archivo markdown que el usuario escribe en
# Ajustes o deja en el proyecto (res://.dotti/agentes/). Se invoca con @nombre
# en un mensaje, y desde ahi pone su prompt, su lista de herramientas y su
# modelo. No tiene selector propio: el que esta activo se ve en el marcador de
# la caja de texto, en el aviso que se pinta al activarlo y en /agent list.
# ---------------------------------------------------------------------------


## Pone un agente en el chat. Se vuelve a leer del disco para que un cambio en su
## archivo valga ya, sin reabrir nada, y se rehace el prompt de sistema: su bloque
## y su lista de herramientas cambian con el.
##
## `avisar` en false es para cuando el usuario acaba de escribir @nombre: ya lo
## sabe, y una fila de mas solo le empuja su propio mensaje hacia abajo.
func _activarAgente(agente: Dictionary, avisar: bool = true) -> void:
	var nombre := str(agente.get("nombre", ""))
	if nombre == "" or nombre == str(_agente.get("nombre", "")):
		return
	_agente = Agentes.cargar(nombre)
	if _agente.is_empty():
		_agente = agente
	_reconstruirSystemPrompt()
	_actualizarTextoSelectores()
	# Las herramientas del agente son otras y el modelo puede ser otro: el
	# contador de contexto habla de otra ventana.
	_actualizarTextoUso()
	_guardarChatActual()
	if not avisar:
		return
	var descripcion := str(_agente.get("descripcion", "")).strip_edges()
	var texto := "Agent **@%s** is on: %s" % [nombre, Agentes.etiquetaHerramientas(_agente)]
	if str(_agente.get("modelo", "")) != "":
		texto += " · " + str(_agente.get("modelo", ""))
	if descripcion != "":
		texto += " — " + descripcion
	_avisoEnChat(texto)

func _salirDeAgente() -> void:
	if _agente.is_empty():
		return
	var nombre := str(_agente.get("nombre", ""))
	_agente = {}
	_reconstruirSystemPrompt()
	_actualizarTextoSelectores()
	_actualizarTextoUso()
	_avisoEnChat("Agent @%s is off. The chat goes back to the default instructions." % nombre)
	_guardarChatActual()

## Fila suelta en el chat para contar algo del propio panel (un agente que entra
## o sale, la lista de agentes). No es una respuesta del modelo y no entra en el
## historial, asi que no viaja al proveedor ni cuenta como turno.
func _avisoEnChat(texto: String) -> void:
	var burbuja := await _crearBurbujaMarkdown(false)
	# Entre la creacion y el texto puede caer un cambio de chat (o un "chat
	# nuevo"), que borra los mensajes que hubiera: la burbuja se queda sin padre y
	# escribirle el texto revienta. Si ya no esta, no hay nada que contar.
	if is_instance_valid(burbuja):
		burbuja.text = texto

## El comando /agent: /agent nombre lo pone, /agent off lo quita, y /agent a
## secas (o con "list") ensena los que hay con el que este puesto marcado.
func _comandoAgente(texto: String) -> void:
	var partes := texto.split(" ", false)
	var argumento := "" if partes.size() < 2 else str(partes[1]).strip_edges()
	# A secas y con "list" es lo mismo: la lista, con el que este puesto marcado. A
	# secas contestaba solo con el nombre del activo (o con un "no hay ninguno" suelto)
	# y dejaba al usuario sin ver los que tiene, que es lo que se espera de un comando
	# que se escribe sin argumentos.
	if argumento == "" or argumento == "list":
		_listarAgentes()
		return
	if argumento == "off" or argumento == "none":
		# Sin agente puesto no hay nada que apagar y callar parecia que el comando no
		# existiera.
		if _agente.is_empty():
			_avisoEnChat("No agent is active.")
		else:
			_salirDeAgente()
		return
	var agente := Agentes.cargar(argumento)
	if agente.is_empty():
		_avisoEnChat("There is no agent called `%s`. `/agent list` shows the ones you have." % argumento)
		return
	_activarAgente(agente)

## La lista de agentes con el que esta puesto marcado y los de fuera senalados (el
## del proyecto y el que trae Dotti), que esos se leen pero no se editan en su
## sitio. La ensenan `/agent` a secas y `/agent list`.
func _listarAgentes() -> void:
	var agentes := Agentes.listar()
	if agentes.is_empty():
		_avisoEnChat("No agents yet. Create one in Settings > Agents.")
		return
	var activo := str(_agente.get("nombre", ""))
	var lineas: Array = ["**Agents**", ""]
	for agente in agentes:
		var nombre := str(agente.get("nombre", ""))
		var marcas: Array[String] = []
		if nombre == activo:
			marcas.append("active")
		var origen := Agentes.etiquetaOrigen(agente)
		if origen != "":
			marcas.append(origen.to_lower())
		var linea := "- `@%s` — %s" % [nombre, Agentes.etiquetaHerramientas(agente)]
		if not marcas.is_empty():
			linea += "  (" + " · ".join(marcas) + ")"
		var descripcion := str(agente.get("descripcion", "")).strip_edges()
		if descripcion != "":
			linea += ": " + descripcion
		lineas.append(linea)
	if activo == "":
		lineas.append("")
		lineas.append("None is active. Write `/agent <name>` to put one on, or mention it with @ in a message.")
	_avisoEnChat("\n".join(lineas))


func _alSeleccionarModelo(id: int) -> void:
	if not _apis:
		return
	if id < 0 or id >= _apis.proveedores.size():
		return
	var prov = _apis.proveedores[id]
	_apis.establecer_proveedor_actual(prov.get("id", ""))
	var config := _apis.obtener_configuracion_chat()
	config["proveedor_id"] = prov.get("id", "")
	config["modelo"] = prov.get("model_id", "")
	_apis.guardar_configuracion_chat(config)
	_actualizarTextoSelectores()
	# Otro modelo es otra ventana de contexto: el mismo gasto es otro porcentaje.
	_actualizarTextoUso()

func _cargarConfigPermisos() -> ConfigFile:
	return ChatPermisos.cargarConfig()

func _obtenerModoPermisos() -> int:
	return ChatPermisos.obtenerModo()

func _guardarModoPermisos(modo: int) -> void:
	ChatPermisos.guardarModo(modo)

func _obtenerHerramientasPermitidasCfg() -> Array:
	return ChatPermisos.obtenerHerramientasPermitidas()

func _alPulsarSelectorPermisos() -> void:
	if not is_instance_valid(_popupPermisos) or not is_instance_valid(_selectorPermisos):
		return
	var modoActual: int = _obtenerModoPermisos()
	for i in range(_popupPermisos.item_count):
		_popupPermisos.set_item_checked(i, _popupPermisos.get_item_id(i) == modoActual)
	var alturaEstimada := int(_popupPermisos.item_count) * 26 + 8
	var pos: Vector2 = _selectorPermisos.get_screen_position() + Vector2(0, -alturaEstimada - 4)
	var ancho: int = int(max(180.0, _selectorPermisos.size.x))
	_popupPermisos.popup(Rect2i(Vector2i(pos), Vector2i(ancho, 0)))

func _alSeleccionarPermisos(id: int) -> void:
	_guardarModoPermisos(id)
	_actualizarTextoSelectores()

func _nivelRazonamiento() -> String:
	var nivel := "high"
	if _apis:
		nivel = str(_apis.obtener_configuracion_chat().get("nivel_razonamiento", "high")).to_lower()
	if nivel != "none" and nivel != "high" and nivel != "max":
		nivel = "high"
	return nivel

func _etiquetaRazonamiento(nivel: String) -> String:
	match nivel:
		"none":
			return "Think: Off"
		"max":
			return "Think: Max"
	return "Think: High"

func _alPulsarSelectorRazonamiento() -> void:
	if not is_instance_valid(_popupRazonamiento) or not is_instance_valid(_selectorRazonamiento):
		return
	var actual := _nivelRazonamiento()
	for i in range(_popupRazonamiento.item_count):
		_popupRazonamiento.set_item_checked(i, NIVELES_RAZONAMIENTO[_popupRazonamiento.get_item_id(i)] == actual)
	var alturaEstimada := int(_popupRazonamiento.item_count) * 26 + 8
	var pos: Vector2 = _selectorRazonamiento.get_screen_position() + Vector2(0, -alturaEstimada - 4)
	var ancho: int = int(max(140.0, _selectorRazonamiento.size.x))
	_popupRazonamiento.popup(Rect2i(Vector2i(pos), Vector2i(ancho, 0)))

func _alSeleccionarRazonamiento(id: int) -> void:
	if id < 0 or id >= NIVELES_RAZONAMIENTO.size():
		return
	if _apis:
		var config := _apis.obtener_configuracion_chat()
		config["nivel_razonamiento"] = NIVELES_RAZONAMIENTO[id]
		_apis.guardar_configuracion_chat(config)
	_actualizarTextoSelectores()

func _requierePermisoParaHerramienta(nombre: String) -> bool:
	# Preguntar al usuario es intrinsecamente interactivo: responder ya es
	# el permiso.
	if nombre == "Ask user":
		return false
	# La lista de tareas es contabilidad del propio chat: no toca el proyecto, no
	# cuesta nada deshacerla y el modelo la reescribe varias veces por tarea, asi
	# que parar a pedir permiso en cada paso solo rompe el ritmo de trabajo.
	if nombre == "Update todo list":
		return false
	var modo: int = _obtenerModoPermisos()
	match modo:
		PERMISOS_TODOS:
			return false
		PERMISOS_PREGUNTAR:
			return true
		PERMISOS_AUTOMATICOS:
			var permitidos := _obtenerHerramientasPermitidasCfg()
			for item in permitidos:
				if str(item) == nombre:
					return false
			return true
	return false

## Texto del selector de modo: el nombre solo no dice que cambia, y lo que
## cambia es lo que el chat puede tocar. Es el unico sitio donde el modo se
## explica sin abrir nada.
func _textoTooltipModo(idxModo: int) -> String:
	if idxModo == 1:
		return "Plan mode: the tools only read the project, so nothing this chat does can change it."
	return "Agent mode: the full toolbox, this chat can read and change the project."

func _actualizarTextoSelectores() -> void:
	if not _apis:
		return
	var config := _apis.obtener_configuracion_chat()
	if is_instance_valid(_selectorModo):
		var idxModo: int = config.get("modoSistema", 0)
		var etiquetaModo := "Agent" if idxModo == 0 else "Plan"
		_selectorModo.text = etiquetaModo + " ▾"
		_selectorModo.tooltip_text = _textoTooltipModo(idxModo)
	# Sin desplegable de agentes, el marcador de la caja de texto es donde se ve
	# cual esta puesto. Se reescribe aqui, que es lo que corre cada vez que un
	# agente entra o sale.
	if is_instance_valid(campoTexto):
		var nombreActivo := str(_agente.get("nombre", ""))
		campoTexto.placeholder_text = "Write a message..." if nombreActivo == "" else "Write a message... (@%s is on)" % nombreActivo
	if is_instance_valid(_selectorModelo):
		var nombreModelo := "No model"
		if _apis.proveedor_actual_id != "":
			var prov = _apis.obtener_proveedor(_apis.proveedor_actual_id)
			if not prov.is_empty():
				nombreModelo = prov.get("nombre", "Unnamed")
		_selectorModelo.text = nombreModelo + " ▾"
	if is_instance_valid(_selectorPermisos):
		var modoPermisos: int = _obtenerModoPermisos()
		var etiquetaPermisos := "Auto"
		match modoPermisos:
			PERMISOS_PREGUNTAR: etiquetaPermisos = "Ask"
			PERMISOS_AUTOMATICOS: etiquetaPermisos = "Auto"
			PERMISOS_TODOS: etiquetaPermisos = "All"
		_selectorPermisos.text = etiquetaPermisos + " ▾"
	if is_instance_valid(_selectorRazonamiento):
		_selectorRazonamiento.text = _etiquetaRazonamiento(_nivelRazonamiento()) + " ▾"

## Tokens que costo la ultima peticion. Llegan por los dos caminos (el nativo del
## stream y el legacy del router) y con ellos se pinta el contador de la barra.
func _alRecibirUso(uso: Dictionary) -> void:
	_usoActual = uso
	_actualizarTextoUso()

func _actualizarTextoUso() -> void:
	if not is_instance_valid(_labelTokens):
		return
	var modelo := _modeloActual()
	var texto := ChatModelos.etiquetaUso(_usoActual, modelo)
	_labelTokens.text = texto
	_labelTokens.visible = texto != ""
	var detalle := ChatModelos.detalleUso(_usoActual, modelo)
	# El gasto del dia va aqui porque es donde el usuario ya mira los tokens: la
	# barra dice lo que costo la ultima peticion y el globo dice ademas por donde
	# va hoy contra su limite. Sin cuenta, o sin limite conocido, no se dice nada.
	var sesion := Sesion.unica()
	if sesion.estaDentro() and sesion.limite_usd > 0.0:
		detalle += "\n\nToday: $%.2f of $%.2f" % [sesion.gastado_usd, sesion.limite_usd]
	if texto != "":
		detalle += "\n\nClick to compact the context now."
	_labelTokens.tooltip_text = detalle

## Clic en el contador: compactar a mano. Mientras hay una respuesta en marcha no
## se toca nada, que la compactacion reescribe el prompt de sistema que esa
## peticion esta usando; la automatica ya se encarga sola antes de cada envio.
func _alPulsarContador(evento: InputEvent) -> void:
	if not (evento is InputEventMouseButton):
		return
	var boton := evento as InputEventMouseButton
	if not boton.pressed or boton.button_index != MOUSE_BUTTON_LEFT:
		return
	if _esperandoRespuesta or _bucleAgenteActivo:
		return
	_compactarContexto(true)

## model_id del modelo que va a contestar, o "" si todavia no hay ninguno. Se mira
## donde lo mira la peticion (el agente manda, luego la configuracion del chat,
## luego el proveedor activo), para que el porcentaje sea el de la ventana que se
## usa de verdad.
func _modeloActual() -> String:
	if not _apis:
		return ""
	var id := _proveedorIdActual()
	if id == "":
		return ""
	var prov := _apis.obtener_proveedor(id)
	if prov.is_empty():
		return ""
	return str(prov.get("model_id", ""))

## El proveedor que va a contestar. Un agente puede fijar modelo: si hay uno del
## catalogo que lo sirva, ese manda.
func _proveedorIdActual() -> String:
	if not _apis:
		return ""
	var delAgente := _proveedorDelAgente()
	if delAgente != "":
		return delAgente
	var id := str(_apis.obtener_configuracion_chat().get("proveedor_id", ""))
	if id == "":
		id = _apis.proveedor_actual_id
	return id

## El proveedor del catalogo que sirve el modelo del agente activo, o "" si el
## agente no fija modelo o no hay ninguno que lo sirva: en ese caso manda la
## configuracion del chat, que es mas util que quedarse sin modelo.
func _proveedorDelAgente() -> String:
	if not _apis or _agente.is_empty():
		return ""
	var modelo := str(_agente.get("modelo", "")).strip_edges()
	if modelo == "":
		return ""
	for prov in _apis.proveedores:
		if str(prov.get("model_id", "")) == modelo:
			return str(prov.get("id", ""))
	return ""

## Chat nuevo o reabierto: el contador vuelve a cero, que los tokens de la
## conversacion anterior no dicen nada de esta.
func _limpiarUso() -> void:
	_usoActual = {}
	_actualizarTextoUso()

# ---------------------------------------------------------------------------
# Compactacion del contexto (P8).
#
# La conversacion entera sigue en `historialConversacion` (el usuario la ve y se
# guarda con el chat), pero al modelo solo le viaja la cola: lo anterior al corte
# va resumido en un checkpoint que vive en el prompt de sistema, con la lista de
# tareas (ChatPrompts.bloqueResumen). El resumen lo escribe el propio modelo en
# una peticion APARTE, como la del titulo del chat: sin herramientas, sin tocar
# el hilo y sin ensuciar el historial. Si falla, se envia sin compactar; el error
# de contexto del proveedor (el proxy ya lo traduce) lo dira mejor que un aviso
# nuestro de tres lineas.
# ---------------------------------------------------------------------------

## Lo que se envia de verdad: el prompt de sistema y la cola sin resumir. Los
## mensajes resumidos no se borran del historial, solo dejan de viajar.
func _historialParaEnvio() -> Array:
	if _resumen == "" or _corteResumen <= 1 or _corteResumen >= historialConversacion.size():
		return historialConversacion
	var enviados: Array = []
	if not historialConversacion.is_empty():
		enviados.append(historialConversacion[0])
	enviados.append_array(historialConversacion.slice(_corteResumen))
	return enviados

## Compacta si la peticion que esta por salir ya no cabe en la ventana del modelo.
## Devuelve true si se compacto. Se llama antes de cada envio, tambien dentro del
## bucle de herramientas, que es donde el contexto crece de verdad.
func _compactarSiHaceFalta() -> bool:
	if _compactando or _peticionCancelada:
		return false
	var modelo := _modeloActual()
	if modelo == "":
		return false
	var estimado := ChatCompactacion.estimarTokens(_historialParaEnvio())
	estimado += ChatCompactacion.estimarTokens(_herramientasParaEnvioNativo())
	var config := _apis.obtener_configuracion_chat() if _apis else {}
	var salida := int(config.get("maxTokens", 8192))
	if not ChatCompactacion.debeCompactar(modelo, _usoActual, estimado, salida):
		return false
	return await _compactarContexto(false)

## La compactacion en si. Manual y automatica solo cambian de donde sale el corte:
## a mano se resume hasta el ultimo turno del usuario aunque la conversacion
## todavia quepa, que es lo que uno espera al pedirlo. Devuelve true si el
## checkpoint quedo escrito.
func _compactarContexto(manual: bool) -> bool:
	if _compactando:
		return false
	# La marca de cancelada solo habla de una peticion en curso, y a mano no hay
	# ninguna: ademas, un panel recien abierto la lleva puesta sin que nadie haya
	# cortado nada (la deja ahi el propio arranque del chat), asi que mirarla
	# dejaria la compactacion a mano muerta hasta el primer mensaje. El resumen que
	# se pide mas abajo tampoco la mira cuando es a mano: ver _pedirResumen.
	if not manual and _peticionCancelada:
		return false
	var corte := ChatCompactacion.corteManual(historialConversacion) if manual else ChatCompactacion.corteDeMensajes(historialConversacion)
	# Nada nuevo que resumir: o no hay conversacion detras del corte, o ya estaba
	# resumida (el corte no puede echarse atras: lo resumido no vuelve a viajar).
	if corte <= 1 or corte <= _corteResumen:
		if manual:
			_avisarCompactacion("Nothing to compact yet", true)
		return false
	var prompt := ChatCompactacion.construirPrompt(
		ChatCompactacion.serializar(historialConversacion, 1, corte), _resumen)
	# Si ni el texto que hay que resumir cabe en la ventana, la peticion fallaria y
	# el aviso seria peor que el silencio: se deja pasar y que hable el proveedor.
	var ventana := ChatModelos.contexto_max(_modeloActual())
	if ventana > 0 and ChatCompactacion.estimarTokens(prompt) + ChatCompactacion.MAX_SALIDA_RESUMEN > ventana:
		_avisarCompactacion("Context too large to summarize", false)
		return false
	# El aviso tambien sale a mano: sin nada en pantalla, un clic que no hace nada
	# parece roto.
	var sesion := _idSesion
	var fila := _crearFilaCompactado("Compacting context...")
	_compactando = true
	var resultado := await _pedirResumen(prompt, not manual)
	_compactando = false
	# Mientras se pedia el resumen puede haber pasado cualquier cosa: un mensaje
	# nuevo, un "New chat", otra conversacion abierta. El resumen es entonces de una
	# conversacion que ya no esta, y escribir el checkpoint encima le pondria a la
	# nueva un corte y un resumen que no son suyos. La sesion es la que dice si el
	# chat es el mismo de cuando se pidio.
	if _idSesion != sesion:
		_cerrarFilaCompactado(fila, "Compaction cancelled: the chat changed while it was summarizing", false)
		return false
	var resumen := str(resultado.get("texto", ""))
	if resumen == "":
		_cerrarFilaCompactado(fila, "Could not compact the context: " + str(resultado.get("motivo", "")), false)
		return false
	_aplicarResumen(corte, resumen)
	_cerrarFilaCompactado(fila, ChatCompactacion.textoFila(corte, _fechaResumen), true, resumen)
	return true

## Escribe el checkpoint: el corte, el resumen, el prompt de sistema (que es donde
## vive el bloque) y el chat guardado. El contador de tokens se vacia porque el
## numero que habia era el de la peticion vieja, la que ya no se manda: el que
## venga despues sera el de la conversacion recortada.
func _aplicarResumen(corte: int, resumen: String) -> void:
	_corteResumen = corte
	_fechaResumen = int(Time.get_unix_time_from_system())
	_resumen = resumen
	_reconstruirSystemPrompt()
	_limpiarUso()
	_guardarChatActual()

## La peticion del resumen: mismo proveedor y misma forma que la del titulo, en su
## propio cliente, que el hilo del chat no se toca. Aqui no hay streaming: se
## espera la respuesta entera o nada.
##
## Devuelve {"texto": ..., "motivo": ...}: texto vacio con el motivo escrito es el
## fallo, y ese motivo es lo que se le ensena al usuario en la fila (un "Could not
## compact the context" a secas no dejaba ver nada de lo que habia debajo).
##
## `cancelable` dice si la marca de peticion cancelada del chat corta este resumen.
## Va en false para la compactacion a mano, y no es un detalle: un chat recien
## abierto la lleva puesta sin que nadie haya cortado nada, y mirarla mataba el
## resumen antes de salir (el sintoma era clavar "Could not compact the context" al
## primer clic, y ninguno despues del primer mensaje, que es cuando se levanta).
func _pedirResumen(prompt: String, cancelable: bool = true) -> Dictionary:
	var constructor := LLMRouter.new()
	constructor.inicializar(self, _apis)
	var peticion := constructor.construirPeticionOpenaiNativa([{"role": "user", "content": prompt}], {}, true)
	if peticion.is_empty():
		return _resumenFallido("the current provider cannot build this request (it needs an OpenAI-style provider with a model).")
	var cuerpo: Dictionary = peticion["cuerpo"]
	cuerpo["max_tokens"] = ChatCompactacion.MAX_SALIDA_RESUMEN
	# Es una tarea mecanica de redaccion: razonar aqui solo cuesta tiempo y tokens.
	cuerpo["reasoning_effort"] = "none"
	cuerpo["thinking"] = {"type": "disabled"}
	var cliente := LLMNativo.new()
	cliente.name = "LLMResumen"
	add_child(cliente)
	var listo := [false]
	var salida := [""]
	var fallo := [""]
	cliente.respuesta_completada.connect(func(contenido: String, _llamadas: Array, _razonamiento: String) -> void:
		salida[0] = contenido
		listo[0] = true)
	cliente.error_recibido.connect(func(mensaje: String) -> void:
		fallo[0] = mensaje
		listo[0] = true)
	cliente.solicitar(str(peticion["url"]), peticion["cabeceras"], peticion["cuerpo"])
	var limite := Time.get_ticks_msec() + int(SEGUNDOS_TIMEOUT_RESUMEN * 1000.0)
	var cortado := false
	while not listo[0] and Time.get_ticks_msec() < limite:
		if cancelable and _peticionCancelada:
			cortado = true
			break
		await get_tree().process_frame
	var agoto: bool = not bool(listo[0])
	if not listo[0]:
		cliente.cancelar()
	cliente.queue_free()
	if cortado:
		return _resumenFallido("the request was cancelled.")
	if fallo[0] != "":
		return _resumenFallido(fallo[0])
	if agoto:
		return _resumenFallido("the provider did not answer in %d seconds." % int(SEGUNDOS_TIMEOUT_RESUMEN))
	var resumen := ChatCompactacion.limpiarResumen(salida[0])
	if resumen == "":
		return _resumenFallido("the model answered with no summary.")
	return {"texto": resumen, "motivo": ""}

## El fallo del resumen, con su motivo. El motivo se recorta porque acaba en una
## fila del chat y un error crudo del proveedor puede traer media respuesta.
func _resumenFallido(motivo: String) -> Dictionary:
	var limpio := motivo.strip_edges()
	if limpio.length() > 160:
		limpio = limpio.substr(0, 160) + "..."
	return {"texto": "", "motivo": limpio}

## Aviso suelto de compactacion: una fila ya cerrada, sin resumen que ensenar.
func _avisarCompactacion(texto: String, exito: bool) -> void:
	_cerrarFilaCompactado(_crearFilaCompactado(texto), texto, exito)

## Si el chat esta en Plan mode (modo 1). Sus herramientas son las de solo
## lectura: ver Agentes.HERRAMIENTAS_SOLO_LECTURA y _herramientasActivas().
func _esModoPlan() -> bool:
	if not _apis:
		return false
	var config := _apis.obtener_configuracion_chat()
	return int(config.get("modoSistema", 0)) == 1

## Herramientas NATIVAS (function calling + stream) solo para proveedores tipo
## "openai" (p. ej. Dotti Proxy). Anthropic/gemini y el modo editor de codigo
## siguen el camino legacy (JSON en texto + HTTPRequest).
func _usaHerramientasNativas() -> bool:
	if not _apis:
		return false
	_apis.cargar_proveedores()
	var prov := _apis.obtener_proveedor(_proveedorIdActual())
	if prov.is_empty():
		return false
	return str(prov.get("tipo", "openai")) == "openai"

func _ajustarAlturaCampoTexto() -> void:
	var lineas := campoTexto.get_line_count()
	var alturaLinea := campoTexto.get_line_height()
	var alturaDeseada := clamp(lineas * alturaLinea + 12, ALTURA_MINIMA_CAMPO, ALTURA_MAXIMA_CAMPO)
	campoTexto.custom_minimum_size.y = alturaDeseada
	campoTexto.scroll_fit_content_height = alturaDeseada < ALTURA_MAXIMA_CAMPO

## Cada tecla que cambia el texto pasa por aqui: la caja crece con las lineas y
## las sugerencias miran si hay que abrirse, filtrarse o cerrarse.
func _alCambiarTextoCampo() -> void:
	_ajustarAlturaCampoTexto()
	if is_instance_valid(_completado):
		_completado.alCambiarTexto()

func _alRedimensionarEntrada() -> void:
	if is_instance_valid(_completado):
		_completado.reposicionar()

## El usuario eligio un archivo en la lista de sugerencias: se adjunta al
## mensaje, igual que si lo hubiera elegido con el boton "+". El texto de la
## mencion se queda en el mensaje para que el modelo sepa de que se le habla.
func _alMencionarArchivo(ruta: String) -> void:
	_adjuntarRuta(ruta)

func _procesarEntradaCampoTexto(evento: InputEvent) -> void:
	if not (evento is InputEventKey) or not evento.pressed:
		return
	var tecla := evento as InputEventKey
	# Las sugerencias van primero: con la lista abierta, arriba/abajo, Enter, Tab
	# y Escape son suyos y el campo no llega a verlos.
	if is_instance_valid(_completado) and _completado.procesarTecla(tecla):
		campoTexto.accept_event()
		return
	# Escape detiene la respuesta en curso: es la pausa del chat. Lo ya escrito
	# se queda en pantalla y el campo sigue disponible para seguir escribiendo.
	if tecla.keycode == KEY_ESCAPE:
		if _esperandoRespuesta or _bucleAgenteActivo:
			_cancelarPeticion()
			campoTexto.accept_event()
		return
	# Pegar: si el portapapeles trae una imagen, o la ruta de un archivo, se
	# adjunta en vez de pegar texto. Ctrl+Shift+V pega el texto crudo, que es la
	# salida para pegar una ruta como texto y no como adjunto.
	if tecla.keycode == KEY_V and tecla.is_command_or_control_pressed() and not tecla.shift_pressed:
		if _adjuntarDesdePortapapeles():
			campoTexto.accept_event()
		return
	var esEnter := tecla.keycode == KEY_ENTER or tecla.keycode == KEY_KP_ENTER or tecla.unicode == 10 or tecla.unicode == 13
	if not esEnter:
		return
	# En Android el Enter del teclado tactil es la tecla de escribir, no la de
	# enviar: el usuario quiere seguir escribiendo. Enviar es el boton (y
	# Shift+Enter sigue metiendo un salto de linea).
	if OS.get_name() == "Android":
		campoTexto.insert_text_at_caret("\n" if tecla.shift_pressed else " ")
		campoTexto.accept_event()
		return
	if tecla.shift_pressed:
		campoTexto.insert_text_at_caret("\n")
	else:
		_on_button_pressed()
	campoTexto.accept_event()

func _iniciarSpinnerBoton() -> void:
	_detenerSpinnerBoton()
	if not is_instance_valid(botonEnviar):
		return
	botonEnviar.text = ""
	if _labelSpinnerBoton:
		_labelSpinnerBoton.visible = true
		_labelSpinnerBoton.text = SPINNER_FRAMES[0]
		_labelSpinnerBoton.tooltip_text = "Click to stop"
	botonEnviar.tooltip_text = "Click to stop"
	_timerSpinnerBoton = Timer.new()
	_timerSpinnerBoton.wait_time = duracionAnimacionBotonSpinner
	_timerSpinnerBoton.one_shot = false
	# Arranque por bandera y no con start(): si esto corre antes de que el panel
	# este montado, start() suelta un "not inside the scene tree" y el spinner se
	# queda parado. Con autostart arranca solo en cuanto entra en el arbol.
	_timerSpinnerBoton.autostart = true
	add_child(_timerSpinnerBoton)
	_frameSpinnerBoton = 0
	_timerSpinnerBoton.timeout.connect(_tickSpinnerBoton)

func _tickSpinnerBoton() -> void:
	if not is_instance_valid(_labelSpinnerBoton):
		_detenerSpinnerBoton()
		return
	_frameSpinnerBoton = (_frameSpinnerBoton + 1) % SPINNER_FRAMES.size()
	_labelSpinnerBoton.text = SPINNER_FRAMES[_frameSpinnerBoton]

func _detenerSpinnerBoton() -> void:
	if _timerSpinnerBoton and is_instance_valid(_timerSpinnerBoton):
		_timerSpinnerBoton.stop()
		if _timerSpinnerBoton.timeout.is_connected(_tickSpinnerBoton):
			_timerSpinnerBoton.timeout.disconnect(_tickSpinnerBoton)
		_timerSpinnerBoton.queue_free()
	_timerSpinnerBoton = null
	if is_instance_valid(_labelSpinnerBoton):
		_labelSpinnerBoton.visible = false
	if is_instance_valid(botonEnviar):
		botonEnviar.text = _textoBoton if _textoBoton != "" else "➤"
		botonEnviar.tooltip_text = "Send message"

func _cancelar_todo() -> void:
	_idSesion += 1
	_peticionCancelada = true
	_bucleAgenteActivo = false
	_idEscritura += 1
	_esperandoRespuesta = false
	_reintentando = false
	if _router:
		_router.cancelar()
	_liberarStreamer()
	if is_instance_valid(_burbujaStream):
		# Deja el parcial ya recibido en un solo bloque: el stream se corta aqui.
		_colapsarStream(_burbujaStream, _textoStreamAcumulado)
	if is_instance_valid(_burbujaStream) and _textoStreamAcumulado.strip_edges() == "":
		_burbujaStream.queue_free()
		_burbujaStream = null
	_detenerYLiberarTimerTarjetaReintentos()
	if is_instance_valid(_burbujaEsperando):
		_burbujaEsperando.queue_free()
		_burbujaEsperando = null
	if is_instance_valid(_burbujaRazonamiento):
		_finalizarBurbujaRazonamiento(_burbujaRazonamiento, true)
	_burbujaRazonamiento = null
	_textoRazonamientoAcumulado = ""
	if is_instance_valid(_tarjetaReintentos):
		_tarjetaReintentos.queue_free()
		_tarjetaReintentos = null
	if is_instance_valid(_mensajeHerramientaActual):
		if not bool(_mensajeHerramientaActual.get_meta("terminada", false)):
			_finalizarTarjetaHerramientaCancelada(_mensajeHerramientaActual)
	_mensajeHerramientaActual = null
	_limpiarUITrabajandoHuerfana()
	# Igual que al cancelar: una pregunta pendiente se suelta, o su await se queda
	# vivo para siempre y la tarjeta sigue en pantalla.
	respuesta_pregunta_nativa.emit("")
	_removerOpcionesRapidas()
	_detenerSpinnerBoton()
	if is_instance_valid(botonEnviar):
		botonEnviar.disabled = false
	_listaErrores.clear()

func _detenerYLiberarTimerTarjetaReintentos() -> void:
	if _timerTarjetaReintentos and is_instance_valid(_timerTarjetaReintentos):
		_timerTarjetaReintentos.stop()
		_timerTarjetaReintentos.queue_free()
	_timerTarjetaReintentos = null

func _iniciarNuevoChat() -> void:
	_cancelar_todo()
	for hijo in contenedorMensajes.get_children():
		hijo.queue_free()
	_pantallaBienvenida = null
	_contenedorOpcionesRapidas = null
	historialConversacion.clear()
	_contadorReintentos = 0
	# Chat nuevo, lista nueva: la del anterior no pinta nada aqui.
	_actualizarTareas([])
	_limpiarUso()
	# Y el contexto vuelve a estar entero: la conversacion del anterior no cuenta.
	_resumen = ""
	_corteResumen = 0
	_fechaResumen = 0
	# El agente es del chat, no del panel: uno nuevo arranca sin ninguno.
	_agente = {}
	_actualizarTextoSelectores()
	_reconstruirSystemPrompt()
	_idChatActual = Historial.generarId()
	_tituloChatActual = ""
	# El titulo del chat anterior que se estaba pidiendo ya no vale para este.
	_liberarTituloIA()
	_tituloGeneradoPorIA = false
	_timestampChatActual = Time.get_unix_time_from_system()
	_limpiarArchivosContexto()
	_pantallaBienvenida = _construirPantallaBienvenida()
	contenedorMensajes.add_child(_pantallaBienvenida)
	_actualizarPantallaBienvenida()

func _reconstruirSystemPrompt() -> void:
	var config := _apis.obtener_configuracion_chat() if _apis else {}
	var idxModo := int(config.get("modoSistema", 0))
	var fullPrompt: String
	# El briefing de sesion abre el mensaje: es el documento largo en ingles que
	# enmarca la conversacion y lo que hace que el upstream no bloquee el chat.
	# Detras va la personalidad del modo (y, si hay, el agente activo).
	# El strip_edges es por el salto que GDScript se queda detras de las triples
	# comillas: sin el, el mensaje empieza en blanco.
	fullPrompt = ChatPrompts.promptSesion().strip_edges() + "\n\n" + Configuracion.promptSistema(idxModo)
	# El agente activo va pegado a la personalidad, antes que nada: sus
	# instrucciones son las del usuario y mandan sobre los habitos generales.
	fullPrompt += Agentes.bloquePrompt(_agente)
	fullPrompt += "\n\n" + _construirSystemPromptContexto(config)
	# El checkpoint de la compactacion va con el contexto, no en el historial: asi
	# sigue delante del modelo cuando los mensajes que resume dejan de enviarse.
	fullPrompt += ChatPrompts.bloqueResumen(_resumen)
	# Las reglas de herramientas van en los dos modos: Plan mode no se queda sin
	# herramientas, se queda con las que solo leen, y el modelo tiene que saber
	# como se llaman igual que en Agent mode.
	if _usaHerramientasNativas():
		fullPrompt += ChatPrompts.construirSystemPromptHerramientasNativas()
	else:
		fullPrompt += _construirSystemPromptHerramientas()
	# La lista de tareas se reconstruye aqui, desde el estado del chat y no desde
	# el historial: asi sigue delante del modelo aunque la conversacion se haya
	# recortado, y no hay que tocar los mensajes para inyectarla.
	fullPrompt += ChatPrompts.bloqueTareas(_tareas)
	# El catalogo de agentes solo se ensena cuando los hay y el chat no esta ya
	# dentro de uno: es para que el modelo sepa que existen y no los invente. En
	# Plan mode no se ensena: sin "Run agent" seria una invitacion a llamar a una
	# herramienta que no tiene.
	if not _esModoPlan() and _agente.is_empty():
		fullPrompt += Agentes.bloqueDisponibles()
	# Y los skills, solo si de verdad puede cargarlos: sin la herramienta (agente
	# con "tools: none" o con una lista que no la incluye) el bloque seria una
	# invitacion a una llamada que no existe.
	if _herramientasActivas().has("Load skill"):
		fullPrompt += Habilidades.bloqueDisponibles()
	fullPrompt += _construirSystemPromptOpcionesRapidas()
	var instruccionesUsuario: String = Configuracion.cargarInstruccionesUsuario().strip_edges()
	if instruccionesUsuario == "":
		instruccionesUsuario = String(config.get("instruccionesUsuario", "")).strip_edges()
	if instruccionesUsuario != "":
		fullPrompt += "\n\n---\n**USER CUSTOM INSTRUCTIONS (always follow these):**\n%s\n---\n" % instruccionesUsuario
	if historialConversacion.is_empty():
		historialConversacion.append({"role": "user", "content": fullPrompt, "system": true})
	else:
		historialConversacion[0] = {"role": "user", "content": fullPrompt, "system": true}

func _construirSystemPromptOpcionesRapidas() -> String:
	return ChatPrompts.construirSystemPromptOpcionesRapidas()

## Bloque <env> mas las instrucciones del usuario (user://AGENTS.md). Va pegado
## al prompt de personalidad, antes que todo lo demas: cuanto mas contexto en
## ingles haya al principio de la conversacion, menos le salta al upstream su
## filtro de contenido.
func _construirSystemPromptContexto(config: Dictionary) -> String:
	var nombreProveedor := ""
	var modelo := str(config.get("modelo", ""))
	if _apis and _apis.proveedor_actual_id != "":
		var prov = _apis.obtener_proveedor(_apis.proveedor_actual_id)
		if not prov.is_empty():
			nombreProveedor = str(prov.get("nombre", ""))
			if modelo == "":
				modelo = str(prov.get("model_id", ""))
	var bloque := ChatContexto.bloqueEntorno(nombreProveedor, modelo)
	var instrucciones := ChatContexto.bloqueInstrucciones()
	if instrucciones != "":
		bloque += "\n\n" + instrucciones
	return bloque

func _construirSystemPromptHerramientas() -> String:
	return ChatPrompts.construirSystemPromptHerramientas(_herramientasActivas())

func abrirConfiguracion(enCuenta: bool = false) -> void:
	var ventana := Configuracion.new()
	ventana.configuracionGuardada.connect(_alGuardarConfiguracion)
	add_child(ventana)
	ventana.establecerHerramientas(_herramientas)
	# La cuenta se pide desde el chat, y el aviso no puede dejar al usuario
	# buscando la pestana: se abre ya en ella.
	if enCuenta:
		ventana.abrirEnCuenta()

func abrirHistorial() -> void:
	var ventana := Historial.new()
	ventana.chatSeleccionado.connect(_alCargarChat)
	ventana.chatNuevoSolicitado.connect(_iniciarNuevoChat)
	add_child(ventana)

func _alGuardarConfiguracion() -> void:
	_apis.cargar_proveedores()
	# Un agente editado (o borrado) en Ajustes vale ya: su archivo se relee del
	# disco, y si ya no esta el chat vuelve solo a las instrucciones de siempre.
	if not _agente.is_empty():
		_agente = Agentes.cargar(str(_agente.get("nombre", "")))
		_actualizarTextoSelectores()
	_reconstruirSystemPrompt()
	_actualizarTextoSelectores()
	# En Ajustes se puede haber cambiado el modelo activo.
	_actualizarTextoUso()

func _alCargarChat(idChat: String) -> void:
	_cancelar_todo()
	_peticionCancelada = false
	_tokenRenderizado += 1
	var miToken := _tokenRenderizado
	for hijo in contenedorMensajes.get_children():
		hijo.queue_free()
	_pantallaBienvenida = null
	_contenedorOpcionesRapidas = null
	_limpiarArchivosContexto()
	_panelCargaChat = _construirPanelCargaChat("Loading chat...")
	contenedorMensajes.add_child(_panelCargaChat)
	await get_tree().process_frame
	var datos := Historial.cargarChat(idChat)
	if datos.is_empty():
		if is_instance_valid(_panelCargaChat):
			_panelCargaChat.queue_free()
			_panelCargaChat = null
		return
	_idChatActual = datos.get("id", Historial.generarId())
	_tituloChatActual = datos.get("titulo", "")
	_timestampChatActual = datos.get("timestamp", Time.get_unix_time_from_system())
	historialConversacion = datos.get("mensajes", [])
	# Un titulo en vuelo pertenecia al chat que se deja atras.
	_liberarTituloIA()
	_tituloGeneradoPorIA = bool(datos.get("titulo_ia", false))
	# La lista de tareas vuelve con el chat: el panel se repinta antes de los
	# mensajes para que no aparezca a mitad del repintado.
	var tareasGuardadas = datos.get("tareas", [])
	_actualizarTareas(tareasGuardadas if typeof(tareasGuardadas) == TYPE_ARRAY else [])
	# El checkpoint de compactacion tambien vuelve, pero solo si el corte cae dentro
	# del historial que se acaba de cargar: un chat tocado a mano no puede dejar el
	# contexto recortado por un indice que ya no existe.
	var resumenGuardado = datos.get("resumen", "")
	var corteGuardado = datos.get("corte", 0)
	var fechaGuardada = datos.get("fechaResumen", 0)
	_resumen = str(resumenGuardado) if typeof(resumenGuardado) == TYPE_STRING else ""
	_corteResumen = int(corteGuardado) if typeof(corteGuardado) in [TYPE_INT, TYPE_FLOAT] else 0
	_fechaResumen = int(fechaGuardada) if typeof(fechaGuardada) in [TYPE_INT, TYPE_FLOAT] else 0
	if _corteResumen <= 1 or _corteResumen >= historialConversacion.size():
		_resumen = ""
		_corteResumen = 0
		_fechaResumen = 0
	# El agente del chat vuelve por su nombre, y el prompt se relee del disco: si
	# el archivo se edito o se borro entre medias, manda el disco.
	var agenteGuardado = datos.get("agente", "")
	_agente = Agentes.cargar(str(agenteGuardado)) if typeof(agenteGuardado) == TYPE_STRING else {}
	# El chat guardado no trae los tokens de su ultima peticion: el contador se
	# queda a cero hasta que se hable otra vez.
	_limpiarUso()
	_reconstruirSystemPrompt()

	var elementos := _elementosDeHistorial(historialConversacion)

	_renderizandoChat = true
	await _renderizarMensajesPorLotes(elementos, miToken)
	_renderizandoChat = false

	if is_instance_valid(_panelCargaChat):
		_panelCargaChat.queue_free()
		_panelCargaChat = null
	await get_tree().process_frame
	await _scrollAlFinal()

## Convierte el historial guardado en la lista de cosas que hay que repintar, EN
## ORDEN: turnos de usuario, respuestas, tarjetas de razonamiento y tarjetas de
## herramienta con su resultado. Antes solo se pintaban los textos finales, asi que
## al volver a un chat se perdia todo el progreso (razonamiento y tools).
##
## El resultado de cada tool viaja en el mensaje siguiente con role "tool" y su
## tool_call_id: se guarda el indice de la tarjeta para pegarselo al llegar.
func _elementosDeHistorial(mensajes: Array) -> Array:
	var elementos: Array = []
	var tarjetaPorId := {}
	for i in range(mensajes.size()):
		# La marca de la compactacion cae justo donde esta el corte: por encima, el
		# usuario sigue viendo su conversacion entera, aunque al modelo solo le
		# llegue de ahi para abajo (mas el resumen del prompt de sistema).
		if _resumen != "" and i == _corteResumen:
			elementos.append({
				"tipo": "compactado",
				"texto": _resumen,
				"cabecera": ChatCompactacion.textoFila(_corteResumen, _fechaResumen),
			})
		var mensaje = mensajes[i]
		if typeof(mensaje) != TYPE_DICTIONARY:
			continue
		if bool(mensaje.get("system", false)):
			continue
		var rol := str(mensaje.get("role", ""))
		var contenido := str(mensaje.get("content", ""))
		if rol == "assistant":
			var razonamiento := str(mensaje.get("reasoning_content", "")).strip_edges()
			if razonamiento != "" and razonamiento != "<null>" and razonamiento != LLMNativo.RAZONAMIENTO_AUSENTE:
				elementos.append({"tipo": "razonamiento", "texto": razonamiento})
			if mensaje.has("tool_calls"):
				var tcs = mensaje["tool_calls"]
				if typeof(tcs) == TYPE_ARRAY:
					for tc in tcs:
						# El nombre guardado es el que exige la API (Read_file); al
						# pintar se resuelve al nombre real de Dotti. Si la
						# herramienta ya no existe se ensena el guardado: mas vale el
						# nombre crudo que una tarjeta muda.
						var crudo := LLMNativo.nombreDeToolCall(tc)
						var nombre := _resolverNombreHerramienta(crudo)
						if nombre == "":
							nombre = crudo
						tarjetaPorId[LLMNativo.idDeToolCall(tc)] = elementos.size()
						elementos.append({
							"tipo": "herramienta",
							"nombre": nombre,
							"args": LLMNativo.argsDeToolCall(tc),
							"salida": "",
						})
				continue
			if contenido.strip_edges() == "":
				continue
			if _esContenidoToolCall(contenido) or not _extraerPreguntaJson(contenido).is_empty():
				continue
			elementos.append({"tipo": "asistente", "texto": contenido})
		elif rol == "tool":
			var id := str(mensaje.get("tool_call_id", ""))
			if tarjetaPorId.has(id):
				var idx: int = tarjetaPorId[id]
				elementos[idx]["salida"] = contenido
			continue
		elif rol == "user":
			if contenido.begins_with("[HIDDEN_RESULT]"):
				# Resultado que una herramienta le dejo al modelo en modo texto: no es
				# un mensaje del usuario, es parte de la tarjeta anterior.
				if _hayImagenes(mensaje):
					_pegarImagenesAlUltimoElemento(elementos, mensaje["imagenes"])
				continue
			if contenido.begins_with("[ATTACHED_IMAGES]"):
				# Mensaje de acarreo de las imagenes que devolvieron las herramientas:
				# tampoco lo escribio el usuario, se ve en su tarjeta.
				_pegarImagenesAlUltimoElemento(elementos, mensaje.get("imagenes", []))
				continue
			var entrada: Dictionary = {"tipo": "usuario", "texto": contenido}
			if _hayImagenes(mensaje):
				entrada["imagenes"] = mensaje["imagenes"]
			elementos.append(entrada)
	return elementos


## Imagenes de una entrada del historial, si las trae. Se guardan como rutas de
## user://dotti_adjuntos; si el archivo ya no esta (retencion de adjuntos), la
## entrada se queda sin miniaturas pero el texto sigue.
func _hayImagenes(mensaje: Dictionary) -> bool:
	var rutas = mensaje.get("imagenes", [])
	if typeof(rutas) != TYPE_ARRAY:
		return false
	for ruta in rutas:
		if FileAccess.file_exists(str(ruta)):
			return true
	return false


## Cuelga las imagenes del ultimo elemento pintable, que es la tarjeta de
## herramienta a la que pertenecen. Si no hay tarjeta antes (un historial raro), se
## pierden las miniaturas: el texto del resultado ya cuenta lo que paso.
func _pegarImagenesAlUltimoElemento(elementos: Array, rutas: Variant) -> void:
	if typeof(rutas) != TYPE_ARRAY or elementos.is_empty():
		return
	var ultimo: Dictionary = elementos[elementos.size() - 1]
	if str(ultimo.get("tipo", "")) != "herramienta":
		return
	var previas = ultimo.get("imagenes", [])
	if typeof(previas) != TYPE_ARRAY:
		previas = []
	var todas: Array = previas.duplicate()
	todas.append_array(rutas as Array)
	ultimo["imagenes"] = todas

## Repinta una tarjeta de razonamiento guardada, PLEGADA (igual que en vivo: el
## chat cargado no se llena de trazas) y con la cabecera ya en pasado, porque esa
## traza es de un turno terminado. El texto se reparte en trozos para no crear una
## sola etiqueta gigante.
func _pintarRazonamientoGuardado(texto: String) -> void:
	var traza := texto.strip_edges()
	if traza == "":
		return
	var panel := _construirTarjetaRazonamiento()
	panel.set_meta("terminada", true)
	panel.set_meta("razonamiento_texto", traza)
	_contenedorActivoMensajes().add_child(panel)
	var contenido := panel.find_child("ContenidoRazonamiento", true, false) as VBoxContainer
	if is_instance_valid(contenido):
		var inicio := 0
		while inicio < traza.length():
			var fin: int = mini(inicio + TROZO_RAZONAMIENTO_GUARDADO, traza.length())
			var trozo := Label.new()
			trozo.add_theme_color_override("font_color", COLOR_RAZONAMIENTO)
			trozo.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
			trozo.size_flags_horizontal = Control.SIZE_EXPAND_FILL
			trozo.text = traza.substr(inicio, fin - inicio)
			contenido.add_child(trozo)
			inicio = fin
	var cabecera := panel.find_child("CabeceraRazonamiento", true, false) as Button
	if is_instance_valid(cabecera):
		cabecera.text = _textoCabeceraRazonamiento(panel)

## Repinta una tarjeta de herramienta guardada: cabecera con el titulo que le dio
## el modelo, detalle plegado y, si fallo, el rojo. Sin spinner ni animaciones
## (aqui no hay nada corriendo), y sin chulo de exito: una ejecucion que salio bien
## se ve como una linea limpia. El historial no guarda un "exito", asi que solo se
## pinta en rojo lo que el propio resultado marca como error.
func _pintarHerramientaGuardada(datos: Dictionary) -> void:
	var nombre := str(datos.get("nombre", ""))
	if nombre == "":
		nombre = "tool"
	var args = datos.get("args", {})
	if typeof(args) != TYPE_DICTIONARY:
		args = {}
	var tarjeta := _construirTarjetaHerramienta(nombre, args)
	_contenedorActivoMensajes().add_child(tarjeta)
	# Imagenes que devolvio la herramienta: van en la tarjeta, visibles sin abrir.
	_agregarMiniaturas(tarjeta.find_child("MiniaturasContainer", true, false), datos.get("imagenes", []))
	var salida := str(datos.get("salida", ""))
	if salida.strip_edges() == "":
		# Turno que se corto antes de recibir el resultado: se pinta como cancelada
		# en vez de fingir un exito que no ocurrio.
		_finalizarTarjetaHerramientaCancelada(tarjeta)
		return
	var exito := not _resultadoPareceError(salida)
	tarjeta.set_meta("terminada", true)
	if exito:
		_apagarSpinnerTarjeta(tarjeta)
	else:
		_cerrarSpinnerFila(tarjeta, GLIFO_ERR, COLOR_ESTADO_ERR)
		_fijarEstadoHerramienta(tarjeta, "failed", COLOR_ESTADO_ERR)
	_fijarDetalleHerramienta(tarjeta, salida)

## Solo los resultados marcados como error por la propia herramienta se pintan en
## rojo al reconstruir un chat: el historial no trae marca de exito, y dar por
## fallado cualquier salida "rara" llenaria el chat de tarjetas rojas falsas.
func _resultadoPareceError(salida: String) -> bool:
	var texto := salida.strip_edges()
	return texto.begins_with("ERROR") or texto.begins_with("Error: ") or texto.begins_with("[ERROR]")

func _renderizarMensajesPorLotes(mensajes: Array, token: int) -> void:
	var total := mensajes.size()
	var i := 0
	while i < total:
		if token != _tokenRenderizado or _peticionCancelada:
			return
		var fin: int = mini(i + MENSAJES_POR_FRAME, total)
		for j in range(i, fin):
			var mensaje = mensajes[j]
			var tipo: String = str(mensaje.get("tipo", ""))
			match tipo:
				"usuario":
					var burbuja := _crearBurbujaMarkdownSinAnimacion(true)
					burbuja.text = str(mensaje.get("texto", ""))
					_agregarMiniaturas(_miniaturasDeBurbuja(burbuja), mensaje.get("imagenes", []))
				"asistente":
					var burbujaA := _crearBurbujaMarkdownSinAnimacion(false)
					# El historial puede contener respuestas viejas con la corrida
					# de "null"/"<null>" del modelo: se sanea al pintar.
					burbujaA.text = ChatParseador.limpiarNulosLideres(str(mensaje.get("texto", "")).replace("<null>", ""))
				"razonamiento":
					_pintarRazonamientoGuardado(str(mensaje.get("texto", "")))
				"herramienta":
					_pintarHerramientaGuardada(mensaje)
				"compactado":
					_pintarCompactadoGuardado(mensaje)
		i = fin
		if is_instance_valid(_panelCargaChat) and _labelCargaChatEstadoValido():
			var porc := int((float(i) / float(max(1, total))) * 100.0)
			_setEstadoCargaChat("Loading chat... %d%% (%d/%d)" % [porc, i, total])
		if i < total:
			await get_tree().process_frame

func _construirPanelCargaChat(textoInicial: String) -> Control:
	var panel := PanelContainer.new()
	panel.name = "PanelCargaChat"
	panel.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	var estilo := StyleBoxFlat.new()
	estilo.bg_color = Color(0.10, 0.10, 0.10, 0.96)
	estilo.border_color = COLOR_PANEL_BORDE
	estilo.border_width_left = 2
	estilo.corner_radius_top_left = 2
	estilo.corner_radius_top_right = 2
	estilo.corner_radius_bottom_left = 2
	estilo.corner_radius_bottom_right = 2
	estilo.content_margin_left = 18
	estilo.content_margin_right = 18
	estilo.content_margin_top = 20
	estilo.content_margin_bottom = 20
	panel.add_theme_stylebox_override("panel", estilo)

	var vbox := VBoxContainer.new()
	vbox.alignment = BoxContainer.ALIGNMENT_CENTER
	vbox.add_theme_constant_override("separation", 10)
	panel.add_child(vbox)

	var fila := HBoxContainer.new()
	fila.alignment = BoxContainer.ALIGNMENT_CENTER
	fila.add_theme_constant_override("separation", 10)
	vbox.add_child(fila)

	var spinner := Label.new()
	spinner.name = "SpinnerCargaChat"
	spinner.text = SPINNER_FRAMES[0]
	spinner.add_theme_color_override("font_color", COLOR_ACENTO)

	fila.add_child(spinner)

	var labelEstado := Label.new()
	labelEstado.name = "EstadoCargaChat"
	labelEstado.text = textoInicial
	labelEstado.add_theme_color_override("font_color", COLOR_TEXTO_PRIMARIO)
	fila.add_child(labelEstado)

	var timer := Timer.new()
	timer.wait_time = 0.08
	timer.one_shot = false
	timer.autostart = true
	panel.add_child(timer)
	var frame := [0]
	timer.timeout.connect(func():
		if not is_instance_valid(spinner):
			if is_instance_valid(timer):
				timer.stop()
				timer.queue_free()
			return
		frame[0] = (frame[0] + 1) % SPINNER_FRAMES.size()
		spinner.text = SPINNER_FRAMES[frame[0]]
	)
	return panel

func _labelCargaChatEstadoValido() -> bool:
	if not is_instance_valid(_panelCargaChat):
		return false
	var l := _panelCargaChat.find_child("EstadoCargaChat", true, false) as Label
	return is_instance_valid(l)

func _setEstadoCargaChat(texto: String) -> void:
	if not is_instance_valid(_panelCargaChat):
		return
	var l := _panelCargaChat.find_child("EstadoCargaChat", true, false) as Label
	if is_instance_valid(l):
		l.text = texto

func _guardarChatActual() -> void:
	if _idChatActual.is_empty():
		return
	Historial.guardarChat(_idChatActual, _tituloChatActual, historialConversacion, _timestampChatActual, _tituloGeneradoPorIA, _tareas, _resumen, _corteResumen, str(_agente.get("nombre", "")), _fechaResumen)
	# Aqui es donde el chat ya tiene material para titularse: el titulo de la IA se
	# pide al guardar, nunca antes (y solo una vez por chat).
	_programarTituloIA()

# ---------------------------------------------------------------------------
# Titulo del chat generado por la IA (una sola vez por chat).
#
# Hasta ahora el titulo era el arranque del primer mensaje del usuario, que en
# la lista del historial se veia a medias y sin decir de que iba la conversacion.
# opencode pide a un modelo pequeno un resumen corto del primer intercambio; aqui
# se hace lo mismo con una peticion APARTE y sin herramientas: no toca el hilo
# del chat, no se guarda en el historial y si falla no se nota (se queda el
# titulo provisional). El resultado se guarda con el chat para no repetirlo al
# reabrirlo.
# ---------------------------------------------------------------------------

## Lanza la peticion de titulo si el chat ya tiene material para resumir y nadie
## lo ha intentado antes. Se llama al cerrar un turno con respuesta del asistente.
func _programarTituloIA() -> void:
	if _tituloGeneradoPorIA or _tituloIAEnCurso or _idChatActual.is_empty():
		return
	if _apis == null:
		return
	var primerUsuario := _primerTextoDeRol("user")
	if primerUsuario.strip_edges() == "":
		return
	var primeraRespuesta := _primerTextoDeRol("assistant")
	if primeraRespuesta.strip_edges() == "":
		# Todavia no hay respuesta que resumir: se intentara en el proximo turno.
		return
	var constructor := LLMRouter.new()
	constructor.inicializar(self, _apis)
	# Sin herramientas y con stream: LLMNativo solo sabe leer SSE.
	var peticion := constructor.construirPeticionOpenaiNativa(_mensajesParaTitulo(primerUsuario, primeraRespuesta), {}, true)
	if peticion.is_empty():
		return
	var cuerpo: Dictionary = peticion["cuerpo"]
	# Titulo corto y sin gastar razonamiento: es una tarea de una linea.
	cuerpo["max_tokens"] = 64
	cuerpo["reasoning_effort"] = "none"
	cuerpo["thinking"] = {"type": "disabled"}
	_tituloIAEnCurso = true
	_tituloIAIdChat = _idChatActual
	_tituloIACliente = LLMNativo.new()
	_tituloIACliente.name = "LLMTitulo"
	add_child(_tituloIACliente)
	_tituloIACliente.respuesta_completada.connect(_alTituloIA)
	# Un fallo aqui no puede ensuciar el chat: el titulo provisional se queda.
	_tituloIACliente.error_recibido.connect(_alErrorTituloIA)
	_tituloIACliente.solicitar(str(peticion["url"]), peticion["cabeceras"], peticion["cuerpo"])

## Mensajes de la peticion de titulo: instruccion + primer intercambio recortado.
## Nada de esto entra en historialConversacion.
func _mensajesParaTitulo(primerUsuario: String, primeraRespuesta: String) -> Array:
	return [
		{"role": "system", "content": "You title conversations. Reply with ONLY a short title of 3 to 6 words that says what the conversation is about, in the same language the user wrote in. No quotes, no markdown, no trailing period, no explanations."},
		{"role": "user", "content": "USER: %s\n\nASSISTANT: %s" % [_recorte(primerUsuario, 1200), _recorte(primeraRespuesta, 1200)]},
	]

func _recorte(texto: String, limite: int) -> String:
	if texto.length() <= limite:
		return texto
	return texto.substr(0, limite)

## Primer texto util del historial para un rol: ignora los turnos de herramientas
## (contenido vacio o JSON) y los avisos internos.
func _primerTextoDeRol(rol: String) -> String:
	for mensaje in historialConversacion:
		if typeof(mensaje) != TYPE_DICTIONARY:
			continue
		if str(mensaje.get("role", "")) != rol:
			continue
		if bool(mensaje.get("system", false)):
			continue
		var contenido := str(mensaje.get("content", "")).strip_edges()
		if contenido == "" or contenido.begins_with("[HIDDEN_RESULT]"):
			continue
		if rol == "assistant":
			if mensaje.has("tool_calls") or _esContenidoToolCall(contenido):
				continue
			if not _extraerPreguntaJson(contenido).is_empty():
				continue
			# Un JSON suelto (tool call mal formado) no es una respuesta que resumir:
			# el titulo saldria con llaves y nombres de campos por dentro.
			if contenido.begins_with("{") and _esJsonObjeto(contenido):
				continue
		return contenido
	return ""

func _esJsonObjeto(texto: String) -> bool:
	var j := JSON.new()
	if j.parse(texto) != OK:
		return false
	return typeof(j.get_data()) == TYPE_DICTIONARY

func _alTituloIA(contenido: String, _tool_calls: Array, _razonamiento: String) -> void:
	var idDelTitulo := _tituloIAIdChat
	_liberarTituloIA()
	# Si mientras tanto se abrio otro chat, el titulo ya no es de este: se tira.
	if idDelTitulo != _idChatActual:
		return
	var titulo := _limpiarTituloIA(contenido)
	if titulo == "":
		return
	_tituloChatActual = titulo
	_tituloGeneradoPorIA = true
	_guardarChatActual()

func _alErrorTituloIA(_mensaje: String) -> void:
	_liberarTituloIA()

func _liberarTituloIA() -> void:
	_tituloIAEnCurso = false
	_tituloIAIdChat = ""
	if is_instance_valid(_tituloIACliente):
		_tituloIACliente.queue_free()
	_tituloIACliente = null

## Deja el texto del modelo en un titulo presentable: una linea, sin comillas ni
## vinetas, sin el "Title:" que a veces antepone, y con tope de largo.
func _limpiarTituloIA(texto: String) -> String:
	var titulo := ""
	for linea in texto.replace("<null>", "").split("\n"):
		var limpia := linea.strip_edges()
		if limpia != "":
			titulo = limpia
			break
	titulo = titulo.lstrip("#*-•> \t").strip_edges()
	if titulo.to_lower().begins_with("title:"):
		titulo = titulo.substr(6).strip_edges()
	titulo = titulo.trim_prefix("\"").trim_suffix("\"").trim_prefix("'").trim_suffix("'")
	titulo = titulo.trim_suffix(".")
	titulo = _unaLinea(titulo)
	if titulo.length() > 60:
		titulo = titulo.substr(0, 60).strip_edges()
	return titulo

## Salto al final tras agregar una burbuja o tarjeta. Solo si el usuario ya
## estaba abajo: si subio a leer algo, no se le mueve la vista.
func _scrollAlFinal() -> void:
	await get_tree().process_frame
	if _estaAlFinal():
		_irAlFinal()

## El usuario movio el scroll (rueda, arrastre, teclado): se sigue el stream
## solo si volvio al final. El parametro es el valor que emite la barra.
func _alMoverScroll(_valor: float = 0.0) -> void:
	if _fijandoScroll:
		return
	_seguirStreamAlFinal = _estaAlFinal()

func _estaAlFinal() -> bool:
	if not is_instance_valid(_scrollContenedor):
		return true
	var sb := _scrollContenedor.get_v_scroll_bar()
	if not is_instance_valid(sb):
		return true
	var distancia: float = float(sb.max_value) - float(_scrollContenedor.scroll_vertical) - float(_scrollContenedor.size.y)
	return distancia <= UMBRAL_AUTOSCROLL

## Pega la vista al final sin condiciones. Lo usan el seguimiento del stream y
## el envio del propio usuario; nunca debe moverle la vista a quien lee arriba.
func _irAlFinal() -> void:
	if not is_instance_valid(_scrollContenedor):
		return
	var sb := _scrollContenedor.get_v_scroll_bar()
	if not is_instance_valid(sb):
		return
	_fijandoScroll = true
	_scrollContenedor.scroll_vertical = int(sb.max_value)
	_fijandoScroll = false

## Refresco de la cola viva de un stream, como mucho cada
## INTERVALO_RENDER_STREAM_MSEC: rehacer markdown a la velocidad de los deltas
## bloquea el hilo principal.
func _puedeRenderizarStream() -> bool:
	var ahora := Time.get_ticks_msec()
	if ahora - _ultimoRenderStreamMsec < INTERVALO_RENDER_STREAM_MSEC:
		return false
	_ultimoRenderStreamMsec = ahora
	return true

## Vuelca el texto acumulado de un stream en su burbuja sin rehacer el markdown
## entero cada vez: lo que ya cerro bloque (linea vacia o tope de cola) se rinde
## UNA sola vez en su propio MarkdownLabel y solo la cola viva se refresca. El
## coste por delta queda acotado aunque la respuesta sea larguisima.
func _volcarStream(etiqueta: MarkdownLabel, texto: String) -> void:
	if not is_instance_valid(etiqueta):
		return
	etiqueta.set_meta("stream_texto", texto)
	var estado: Dictionary = etiqueta.get_meta("stream_bloques", {"corte": 0, "bloques": [], "escaneo": {}})
	# El escaneo reanuda donde quedo la llamada anterior en vez de recorrer todo el
	# texto en cada delta: corte() es O(n) por delta y con 60.000 caracteres ya se
	# notaba (1,4 ms de media y 2,3 ms en el peor delta). Va dentro del mismo
	# diccionario, asi que no hay que anadir nada al objeto.
	var escaneo: Dictionary = estado.get("escaneo", {})
	var corte := ChatStreamBloques.corteConEstado(texto, escaneo)
	estado["escaneo"] = escaneo
	var anterior := int(estado.get("corte", 0))
	if corte > anterior:
		_anexarBloqueStream(etiqueta, estado, texto.substr(anterior, corte - anterior))
		estado["corte"] = corte
		etiqueta.set_meta("stream_bloques", estado)
	if not _puedeRenderizarStream():
		return
	etiqueta.text = texto.substr(corte)

## Rinde como bloque propio (una sola vez) el tramo que acaba de cerrarse.
func _anexarBloqueStream(etiqueta: MarkdownLabel, estado: Dictionary, tramo: String) -> void:
	var limpio := tramo.strip_edges()
	if limpio == "":
		return
	var contenedor := _contenedorBloquesStream(etiqueta)
	if not is_instance_valid(contenedor):
		return
	var bloque := MarkdownLabel.new()
	bloque.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	bloque.colorTexto = etiqueta.colorTexto
	contenedor.add_child(bloque)
	contenedor.move_child(bloque, etiqueta.get_index())
	bloque.text = limpio
	var bloques: Array = estado.get("bloques", [])
	bloques.append(bloque)
	estado["bloques"] = bloques

## Contenedor que aloja los bloques cerrados junto a la cola viva. Se crea la
## primera vez que hace falta, envolviendo la etiqueta que ya estaba puesta: la
## burbuja (asistente o razonamiento) no cambia su estructura.
func _contenedorBloquesStream(etiqueta: MarkdownLabel) -> VBoxContainer:
	var padre := etiqueta.get_parent()
	if not is_instance_valid(padre):
		return null
	if padre is VBoxContainer and bool(padre.get_meta("contenedor_stream", false)):
		return padre
	var vbox := VBoxContainer.new()
	vbox.add_theme_constant_override("separation", 10)
	vbox.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	vbox.set_meta("contenedor_stream", true)
	var indice := etiqueta.get_index()
	padre.add_child(vbox)
	padre.move_child(vbox, indice)
	padre.remove_child(etiqueta)
	vbox.add_child(etiqueta)
	return vbox

## Cierre del stream: los bloques ya rendidos se retiran y el texto completo
## queda en un unico MarkdownLabel, igual que un mensaje cargado del historial.
func _colapsarStream(etiqueta: MarkdownLabel, texto: String) -> void:
	if not is_instance_valid(etiqueta):
		return
	if etiqueta.has_meta("stream_bloques"):
		var estado: Dictionary = etiqueta.get_meta("stream_bloques")
		for bloque in estado.get("bloques", []):
			if is_instance_valid(bloque):
				bloque.visible = false
				bloque.queue_free()
		etiqueta.remove_meta("stream_bloques")
	if etiqueta.has_meta("stream_texto"):
		etiqueta.remove_meta("stream_texto")
	etiqueta.text = texto

## Deja el aviso de espera al final del chat: lo que llega despues (tarjetas,
## respuesta) se inserta por encima y el aviso no se queda en medio.
func _moverEsperaAlFinal() -> void:
	if is_instance_valid(_burbujaEsperando):
		var cont := _contenedorActivoMensajes()
		if _burbujaEsperando.get_parent() == cont:
			cont.move_child(_burbujaEsperando, cont.get_child_count() - 1)

func _raizBurbuja(etiqueta: Control) -> Control:
	if not is_instance_valid(etiqueta):
		return null
	if etiqueta.has_meta("raiz"):
		var r: Variant = etiqueta.get_meta("raiz")
		if r is Control and is_instance_valid(r):
			return r
	var cont := _contenedorActivoMensajes()
	var n: Node = etiqueta
	while n and n.get_parent() != null and n.get_parent() != cont:
		n = n.get_parent()
	return n as Control

func _animarEntradaBurbuja(control: Control, retardo: float = 0.0) -> void:
	ChatAnimaciones.animarEntradaBurbuja(self, control, duracionAnimacionEscala, duracionAnimacionFade, retardo)

func _animarEntradaTarjeta(control: Control) -> void:
	ChatAnimaciones.animarEntradaTarjeta(self, control, duracionAnimacionTarjeta, duracionAnimacionFade)

func _animarExito(control: Control) -> void:
	ChatAnimaciones.animarExito(self, control)

func _animarError(control: Control) -> void:
	ChatAnimaciones.animarError(self, control)

func _animarExpandirAccordion(control: Control) -> void:
	ChatAnimaciones.animarExpandirAccordion(self, control, duracionAnimacionAccordion)

## Aparicion suave, solo opacidad: para las filas de texto que no son burbujas ni
## tarjetas (razonamiento, filas de herramienta), que no deben entrar escalando.
func _animarAparecer(control: Control) -> void:
	if not is_instance_valid(control):
		return
	control.modulate = Color(1, 1, 1, 0)
	var tween := create_tween()
	tween.set_ease(Tween.EASE_OUT)
	tween.set_trans(Tween.TRANS_QUAD)
	tween.tween_property(control, "modulate:a", 1.0, duracionAnimacionFade)

func _crearBurbujaUsuarioInterna() -> MarkdownLabel:
	var wrapper := HBoxContainer.new()
	wrapper.name = "BurbujaUsuarioWrapper"
	wrapper.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	wrapper.add_theme_constant_override("separation", 0)

	var spacer := Control.new()
	spacer.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	spacer.size_flags_stretch_ratio = 0.18
	spacer.custom_minimum_size = Vector2(24, 0)
	wrapper.add_child(spacer)

	var panel := PanelContainer.new()
	panel.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	panel.size_flags_stretch_ratio = 0.82
	var estilo := StyleBoxFlat.new()
	estilo.bg_color = COLOR_USUARIO_BG
	estilo.border_color = COLOR_USUARIO_BORDE
	estilo.border_width_right = 3
	estilo.content_margin_left = 14
	estilo.content_margin_right = 14
	estilo.content_margin_top = 10
	estilo.content_margin_bottom = 10
	estilo.corner_radius_top_left = 2
	estilo.corner_radius_top_right = 2
	estilo.corner_radius_bottom_left = 2
	estilo.corner_radius_bottom_right = 2
	estilo.shadow_color = Color(0, 0, 0, 0.2)
	estilo.shadow_size = 0
	estilo.shadow_offset = Vector2(0, 1)
	panel.add_theme_stylebox_override("panel", estilo)

	var etiqueta := MarkdownLabel.new()
	etiqueta.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	etiqueta.colorTexto = COLOR_TEXTO_PRIMARIO
	etiqueta.mouse_filter = Control.MOUSE_FILTER_IGNORE
	# El texto y las miniaturas van juntos dentro del mismo panel: la foto adjunta
	# es parte del mensaje, y con el texto largo tiene que quedar debajo, no al lado.
	var columna := VBoxContainer.new()
	columna.name = "ColumnaUsuario"
	columna.add_theme_constant_override("separation", 6)
	columna.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	columna.mouse_filter = Control.MOUSE_FILTER_IGNORE
	columna.add_child(etiqueta)
	var miniaturas := VBoxContainer.new()
	miniaturas.name = "MiniaturasContainer"
	miniaturas.add_theme_constant_override("separation", 4)
	miniaturas.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	miniaturas.mouse_filter = Control.MOUSE_FILTER_IGNORE
	columna.add_child(miniaturas)
	panel.add_child(columna)
	wrapper.add_child(panel)

	_contenedorActivoMensajes().add_child(wrapper)
	_moverEsperaAlFinal()
	etiqueta.set_meta("raiz", wrapper)
	etiqueta.set_meta("miniaturas", miniaturas)
	return etiqueta

func _crearBurbujaAsistenteInterna() -> MarkdownLabel:
	var wrapper := HBoxContainer.new()
	wrapper.name = "BurbujaAsistenteWrapper"
	wrapper.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	wrapper.add_theme_constant_override("separation", 10)

	var colMarcador := VBoxContainer.new()
	colMarcador.custom_minimum_size = Vector2(18, 0)
	colMarcador.size_flags_vertical = Control.SIZE_SHRINK_BEGIN
	var marcador := Label.new()
	marcador.text = ""
	marcador.add_theme_color_override("font_color", COLOR_ACENTO_SUAVE)
	marcador.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	colMarcador.add_child(marcador)
	wrapper.add_child(colMarcador)

	var panel := PanelContainer.new()
	panel.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	var estilo := StyleBoxFlat.new()
	estilo.bg_color = COLOR_ASISTENTE_BG
	estilo.border_color = COLOR_ASISTENTE_BORDE
	estilo.border_width_left = 2
	estilo.content_margin_left = 14
	estilo.content_margin_right = 14
	estilo.content_margin_top = 10
	estilo.content_margin_bottom = 10
	estilo.corner_radius_top_left = 2
	estilo.corner_radius_top_right = 2
	estilo.corner_radius_bottom_left = 2
	estilo.corner_radius_bottom_right = 2
	panel.add_theme_stylebox_override("panel", estilo)

	var etiqueta := MarkdownLabel.new()
	etiqueta.size_flags_horizontal = Control.SIZE_EXPAND_FILL

	etiqueta.colorTexto = COLOR_TEXTO_PRIMARIO
	panel.add_child(etiqueta)
	wrapper.add_child(panel)

	var spacerDer := Control.new()
	spacerDer.custom_minimum_size = Vector2(24, 0)
	wrapper.add_child(spacerDer)

	_contenedorActivoMensajes().add_child(wrapper)
	_moverEsperaAlFinal()
	etiqueta.set_meta("raiz", wrapper)
	return etiqueta

func _crearBurbujaMarkdownSinAnimacion(esUsuario: bool) -> MarkdownLabel:
	if esUsuario:
		return _crearBurbujaUsuarioInterna()
	return _crearBurbujaAsistenteInterna()

func _crearBurbujaMarkdown(esUsuario: bool) -> MarkdownLabel:
	var etiqueta := _crearBurbujaMarkdownSinAnimacion(esUsuario)
	var raiz := _raizBurbuja(etiqueta)
	await get_tree().process_frame
	# La espera de un cuadro cae justo donde se aplican los queue_free(): si
	# mientras tanto se limpio el chat (chat nuevo, otro chat abierto), la burbuja
	# ya no esta y animarla revienta.
	if is_instance_valid(raiz):
		_animarEntradaBurbuja(raiz)
	if is_instance_valid(etiqueta):
		await _scrollAlFinal()
	return etiqueta

func _crearSeparador() -> void:
	pass

## Aviso de espera: una linea de texto con spinner. Antes era una tarjeta
## "Agent is working" que animaba en cada frame y se quito por eso; sin nada, la
## espera se sentia muerta. El spinner va por temporizador a 80 ms por cuadro (el
## ritmo del TUI de opencode), asi que cuesta 12 actualizaciones por segundo de una
## sola etiqueta, no un repintado por frame.
func _crearBurbujaEspera() -> Control:
	var fila := HBoxContainer.new()
	fila.name = "BurbujaEspera"
	fila.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	fila.add_theme_constant_override("separation", 8)
	var spinner := Label.new()
	spinner.name = "SpinnerFila"
	spinner.text = SPINNER_FRAMES[0]
	spinner.add_theme_color_override("font_color", COLOR_SPINNER)
	# Ancho fijo: los cuadros del spinner no deben mover el texto de al lado.
	spinner.custom_minimum_size = Vector2(14, 0)
	fila.add_child(spinner)
	var etiqueta := Label.new()
	etiqueta.text = "Processing"
	etiqueta.add_theme_color_override("font_color", Color(0.62, 0.64, 0.70, 0.95))
	etiqueta.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	fila.add_child(etiqueta)
	_contenedorActivoMensajes().add_child(fila)
	_moverEsperaAlFinal()
	_iniciarSpinnerFila(spinner)
	await get_tree().process_frame
	await _scrollAlFinal()
	return fila

## Fila de la compactacion, con la forma del divisor de opencode ("Session
## compacted"): el texto entre dos filetes, centrado y apagado. Debajo, plegado,
## el resumen que se guardo: es lo unico que deja ver que se le escribio al
## modelo en nombre del usuario.
##
## Todo el ancho es elastico (los filetes se estiran y el texto se recorta con
## puntos suspensivos cuando no cabe), asi que la fila se lee igual en el panel
## ancho del editor que en uno estrecho.
func _crearFilaCompactado(texto: String, animar: bool = true) -> Control:
	var panel := PanelContainer.new()
	panel.name = "FilaCompactado"
	panel.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	panel.add_theme_stylebox_override("panel", _estiloFilaCompacta())
	panel.set_meta("terminada", false)
	panel.set_meta("abierta", false)
	# Sin resumen dentro no hay nada que plegar: el clic no tendria a donde ir y
	# la flecha seria un adorno que no hace nada.
	panel.set_meta("plegable", false)
	var vbox := VBoxContainer.new()
	vbox.add_theme_constant_override("separation", 4)
	vbox.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	vbox.mouse_filter = Control.MOUSE_FILTER_IGNORE
	panel.add_child(vbox)
	var cabecera := HBoxContainer.new()
	cabecera.name = "CabeceraCompactado"
	cabecera.add_theme_constant_override("separation", 8)
	cabecera.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	cabecera.mouse_filter = Control.MOUSE_FILTER_IGNORE
	vbox.add_child(cabecera)
	var spinner := Label.new()
	spinner.name = "SpinnerFila"
	spinner.text = SPINNER_FRAMES[0]
	spinner.add_theme_color_override("font_color", COLOR_SPINNER)
	# Mismo hueco que el spinner de las filas de herramienta: asi el texto arranca
	# a la misma altura que el de cualquier otra fila.
	spinner.custom_minimum_size = Vector2(TAMANO_ICONO_HERRAMIENTA, 0)
	cabecera.add_child(spinner)
	cabecera.add_child(_fileteDivisor("FileteIzq"))
	var etiqueta := Label.new()
	etiqueta.name = "TextoCompactado"
	etiqueta.text = texto
	# Gris de mobiliario: la fila es el corte de la conversacion, no una
	# herramienta. Un texto apagado en medio de dos filetes se lee como divisor.
	etiqueta.add_theme_color_override("font_color", COLOR_TEXTO_SECUNDARIO)
	etiqueta.text_overrun_behavior = TextServer.OVERRUN_TRIM_ELLIPSIS
	etiqueta.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	# El texto se queda con casi todo el ancho y los filetes con lo que sobra: al
	# reves, una cabecera corta se comeria el ancho en filetes.
	etiqueta.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	etiqueta.size_flags_stretch_ratio = 8.0
	etiqueta.mouse_filter = Control.MOUSE_FILTER_IGNORE
	cabecera.add_child(etiqueta)
	cabecera.add_child(_fileteDivisor("FileteDer"))
	var flecha := Button.new()
	flecha.name = "AccordionBtn"
	flecha.flat = true
	flecha.focus_mode = Control.FOCUS_NONE
	flecha.text = GLIFO_ACORDEON_CERRADO
	flecha.add_theme_color_override("font_color", COLOR_TEXTO_TENUE)
	# Nace escondida: solo aparece cuando el resumen llego y hay algo que leer.
	flecha.visible = false
	flecha.pressed.connect(_alternarPlegable.bind(panel, "ResumenCompactado"))
	cabecera.add_child(flecha)
	var detalles := MarginContainer.new()
	detalles.name = "ResumenCompactado"
	detalles.visible = false
	detalles.add_theme_constant_override("margin_left", 22)
	detalles.add_theme_constant_override("margin_top", 2)
	detalles.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	detalles.mouse_filter = Control.MOUSE_FILTER_IGNORE
	vbox.add_child(detalles)
	var cuerpo := MarkdownLabel.new()
	cuerpo.name = "ResumenTexto"
	cuerpo.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	cuerpo.colorTexto = COLOR_TEXTO_SECUNDARIO
	detalles.add_child(cuerpo)
	panel.gui_input.connect(_alPulsarFilaCompactado.bind(panel))
	_contenedorActivoMensajes().add_child(panel)
	_moverEsperaAlFinal()
	# En vivo gira mientras el modelo escribe el resumen; al reabrir un chat la fila
	# nace cerrada, sin nada que esperar.
	if animar:
		_iniciarSpinnerFila(spinner)
		_animarAparecer(panel)
	return panel

## Filete del divisor: una linea de un pixel que se estira con el ancho. Va en
## ColorRect y no en HSeparator porque lo que se quiere es la linea suelta, sin el
## hueco vertical que trae el separador (que ademas la dejaria mas corta que el
## texto de al lado).
func _fileteDivisor(nombre: String) -> ColorRect:
	var filete := ColorRect.new()
	filete.name = nombre
	filete.color = COLOR_LINEA_DIVISOR
	filete.custom_minimum_size = Vector2(12, 1)
	filete.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	filete.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	filete.mouse_filter = Control.MOUSE_FILTER_IGNORE
	return filete

## El clic de la fila de compactacion: solo pliega cuando hay resumen que leer. Una
## fila que se abre y se cierra sin nada dentro parece rota.
func _alPulsarFilaCompactado(evento: InputEvent, panel: Control) -> void:
	if not is_instance_valid(panel) or not bool(panel.get_meta("plegable", false)):
		return
	_alPulsarTarjetaPlegable(evento, panel, "ResumenCompactado")

## Cierra la fila: el spinner se apaga con su glifo, la cabecera se queda con el
## recuento y su hora (o con el motivo del fallo, en rojo) y, si el resumen
## llego, el cuerpo plegable se llena y sale la flecha que avisa de que ahi
## debajo esta lo que se le escribio al modelo en nombre del usuario.
##
## El resumen entra por aqui y no con una llamada aparte porque la fila viva y la
## fila repintada tienen que quedar identicas: la viva nace esperando y la
## repintada nace cerrada, y las dos acaban en esta funcion.
func _cerrarFilaCompactado(fila: Control, texto: String, exito: bool, resumen: String = "") -> void:
	if not is_instance_valid(fila):
		return
	fila.set_meta("terminada", true)
	var etiqueta := fila.find_child("TextoCompactado", true, false) as Label
	if is_instance_valid(etiqueta):
		etiqueta.text = texto
		etiqueta.add_theme_color_override("font_color", COLOR_ESTADO_ERR if not exito else COLOR_TEXTO_SECUNDARIO)
	var cuerpo := fila.find_child("ResumenTexto", true, false) as MarkdownLabel
	if is_instance_valid(cuerpo) and resumen.strip_edges() != "":
		cuerpo.text = resumen
		fila.set_meta("plegable", true)
		var flecha := fila.find_child("AccordionBtn", true, false) as Button
		if is_instance_valid(flecha):
			flecha.visible = true
	_cerrarSpinnerFila(fila, GLIFO_OK if exito else GLIFO_ERR, COLOR_ESTADO_OK if exito else COLOR_ESTADO_ERR)
	_scrollAlFinal()

## La fila de compactacion al reabrir un chat: cerrada desde el principio (aqui no
## hay nada corriendo) y con el resumen que se guardo en su cuerpo plegable. La
## cabecera llega ya escrita desde el historial, que es donde vive la hora del
## corte: recalculada aqui diria la de ahora.
func _pintarCompactadoGuardado(datos: Dictionary) -> void:
	var cabecera := str(datos.get("cabecera", ""))
	var fila := _crearFilaCompactado(cabecera, false)
	_cerrarFilaCompactado(fila, cabecera, true, str(datos.get("texto", "")))

## Spinner de fila con temporizador. El temporizador cuelga de la propia etiqueta,
## asi que muere con ella y no deja conexiones vivas; el is_instance_valid cubre el
## hueco entre queue_free y el borrado real.
func _iniciarSpinnerFila(etiqueta: Label) -> Timer:
	if not is_instance_valid(etiqueta):
		return null
	etiqueta.set_meta("frame_spinner", 0)
	var timer := Timer.new()
	timer.name = "TimerSpinnerFila"
	timer.wait_time = INTERVALO_SPINNER_FILA
	timer.one_shot = false
	# Por bandera, igual que el del boton: una fila construida antes de colgarse
	# del arbol no puede reventar al arrancar su spinner.
	timer.autostart = true
	etiqueta.add_child(timer)
	timer.timeout.connect(_tickSpinnerFila.bind(etiqueta))
	return timer

func _tickSpinnerFila(etiqueta: Label) -> void:
	if not is_instance_valid(etiqueta):
		return
	var frame := (int(etiqueta.get_meta("frame_spinner", 0)) + 1) % SPINNER_FRAMES.size()
	etiqueta.set_meta("frame_spinner", frame)
	etiqueta.text = SPINNER_FRAMES[frame]

## Cierra el spinner de una fila con su glifo final (check, cruz, denegada) y lo
## apaga: una fila terminada no puede seguir girando.
func _cerrarSpinnerFila(fila: Control, glifo: String, color: Color = COLOR_ESTADO_OK) -> void:
	if not is_instance_valid(fila):
		return
	var spinner := fila.find_child("SpinnerFila", true, false) as Label
	if not is_instance_valid(spinner):
		return
	var timer := spinner.get_node_or_null("TimerSpinnerFila") as Timer
	if is_instance_valid(timer):
		timer.stop()
		timer.queue_free()
	spinner.text = glifo
	spinner.add_theme_color_override("font_color", color)

## Tarjeta de razonamiento: cabecera plegable ("Thinking") y cuerpo con la traza,
## OCULTO por defecto. Se abre y se cierra pulsando la tarjeta o su cabecera, como
## el bloque de razonamiento del TUI de opencode, pero sin ensuciar el chat: la
## traza completa sigue ahi cuando se quiere leer.
##
## El texto NO se analiza como markdown: un modelo que piensa mucho escupe trazas
## enormes y MarkdownLabel rehace todos sus nodos en cada asignacion de texto
## (~30 ms por 1000 caracteres, medido en el proyecto): analizar eso en cada delta
## congelaba el editor. Aqui el texto se reparte en etiquetas simples y solo se
## reescribe la cola viva, este abierta o cerrada.
func _construirTarjetaRazonamiento() -> Control:
	var panel := PanelContainer.new()
	panel.name = "BurbujaRazonamiento"
	panel.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	panel.add_theme_stylebox_override("panel", ChatEstilos.crearEstiloRazonamiento())
	panel.set_meta("terminada", false)
	panel.set_meta("abierta", false)
	panel.set_meta("corte_razonamiento", 0)
	panel.set_meta("razonamiento_texto", "")
	panel.set_meta("frame_spinner", 0)
	var vbox := VBoxContainer.new()
	vbox.add_theme_constant_override("separation", 4)
	vbox.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	# Deja pasar el raton: el que decide (abrir/cerrar) es la tarjeta entera.
	vbox.mouse_filter = Control.MOUSE_FILTER_IGNORE
	panel.add_child(vbox)
	var cabecera := Button.new()
	cabecera.name = "CabeceraRazonamiento"
	cabecera.flat = true
	cabecera.focus_mode = Control.FOCUS_NONE
	cabecera.alignment = HORIZONTAL_ALIGNMENT_LEFT
	cabecera.text = _textoCabeceraRazonamiento(panel)
	cabecera.add_theme_color_override("font_color", COLOR_RAZONAMIENTO)
	cabecera.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	vbox.add_child(cabecera)
	var contenido := VBoxContainer.new()
	contenido.name = "ContenidoRazonamiento"
	contenido.visible = false
	# Sin separacion: los trozos se cortan en saltos de linea, asi que la traza se
	# lee como un bloque continuo.
	contenido.add_theme_constant_override("separation", 0)
	contenido.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	# Los clics sobre la traza no se quedan aqui: suben a la tarjeta, que es la que
	# abre y cierra. Asi se pliega pulsando el texto, no solo la cabecera.
	contenido.mouse_filter = Control.MOUSE_FILTER_IGNORE
	vbox.add_child(contenido)
	cabecera.pressed.connect(_alternarRazonamiento.bind(panel))
	panel.gui_input.connect(_alPulsarTarjetaPlegable.bind(panel, "ContenidoRazonamiento"))
	# El spinner de la cabecera: 80 ms por cuadro, el mismo ritmo del TUI de
	# opencode. El temporizador cuelga de la tarjeta, asi que muere con ella y no
	# deja conexiones vivas; el coste es cambiar el texto de una sola etiqueta.
	var timer := Timer.new()
	timer.name = "TimerSpinnerCabecera"
	timer.wait_time = 0.08
	timer.one_shot = false
	timer.autostart = true
	panel.add_child(timer)
	timer.timeout.connect(_avanzarSpinnerCabecera.bind(panel))
	return panel

func _crearBurbujaRazonamiento() -> Control:
	if is_instance_valid(_burbujaRazonamiento):
		return _burbujaRazonamiento
	var panel := _construirTarjetaRazonamiento()
	var cont := _contenedorActivoMensajes()
	cont.add_child(panel)
	# El razonamiento pertenece antes de la respuesta en streaming. La
	# respuesta vacia se crea primero para recibir deltas posteriores.
	if is_instance_valid(_burbujaStream):
		var raizStream := _raizBurbuja(_burbujaStream)
		if is_instance_valid(raizStream) and raizStream.get_parent() == cont:
			cont.move_child(panel, raizStream.get_index())
	_burbujaRazonamiento = panel
	_inicioRazonamientoMsec = Time.get_ticks_msec()
	# La tarjeta pasa a ser el indicador de actividad (su cabecera gira): el
	# "Processing" sobra y dos cargas a la vez ensucian. Si el modelo no manda
	# razonamiento, la fila se queda como estaba y sigue siendo ella la que avisa.
	if is_instance_valid(_burbujaEsperando):
		_burbujaEsperando.queue_free()
		_burbujaEsperando = null
	await get_tree().process_frame
	_animarAparecer(panel)
	await _scrollAlFinal()
	_textoRazonamientoAcumulado = ""
	return panel

## Cabecera de la tarjeta: estado, y nada mas. Mientras piensa lleva delante un
## cuadro del spinner (lo mueve _avanzarSpinnerCabecera) para que se vea que el
## modelo sigue trabajando; al terminar, "Thought for Ns", el mismo resumen que
## ensena el TUI de opencode. Sin flechas: el usuario las quito por feas, y la
## tarjeta entera abre y cierra igual.
func _textoCabeceraRazonamiento(panel: Control) -> String:
	if not bool(panel.get_meta("terminada", false)):
		var frame := int(panel.get_meta("frame_spinner", 0)) % SPINNER_FRAMES.size()
		return "%s %s" % [SPINNER_FRAMES[frame], TEXTO_RAZONANDO]
	var segundos := int(panel.get_meta("segundos_razonamiento", 0))
	if segundos <= 0:
		return TEXTO_RAZONAMIENTO_CORTO
	return "%s for %ds" % [TEXTO_RAZONAMIENTO_CORTO, segundos]

## Un cuadro mas del spinner de la cabecera. Lo llama el temporizador que cuelga
## de la propia tarjeta; en cuanto la traza termina el temporizador deja de tocar
## nada (la cabecera ya es definitiva).
func _avanzarSpinnerCabecera(panel: Control) -> void:
	if not is_instance_valid(panel):
		return
	if bool(panel.get_meta("terminada", false)):
		# La cabecera ya es definitiva. Las tarjetas del historial nacen terminadas,
		# asi que su primer cuadro apaga el temporizador y no queda nada girando en
		# un chat repintado.
		var timer := panel.get_node_or_null("TimerSpinnerCabecera") as Timer
		if is_instance_valid(timer):
			timer.stop()
			timer.queue_free()
		return
	panel.set_meta("frame_spinner", int(panel.get_meta("frame_spinner", 0)) + 1)
	var cabecera := panel.find_child("CabeceraRazonamiento", true, false) as Button
	if is_instance_valid(cabecera):
		cabecera.text = _textoCabeceraRazonamiento(panel)

## Abre o cierra el cuerpo de una tarjeta plegable (razonamiento y herramientas).
func _alternarPlegable(panel: Control, nombreContenido: String) -> void:
	if not is_instance_valid(panel):
		return
	var contenido := panel.find_child(nombreContenido, true, false) as Control
	if not is_instance_valid(contenido):
		return
	var abierta := not contenido.visible
	contenido.visible = abierta
	panel.set_meta("abierta", abierta)
	var cabecera := panel.find_child("CabeceraRazonamiento", true, false) as Button
	if is_instance_valid(cabecera):
		cabecera.text = _textoCabeceraRazonamiento(panel)
	var flecha := panel.find_child("AccordionBtn", true, false) as Button
	if is_instance_valid(flecha):
		flecha.text = GLIFO_ACORDEON_ABIERTO if abierta else GLIFO_ACORDEON_CERRADO
	if abierta:
		_animarExpandirAccordion(contenido)

func _alternarRazonamiento(panel: Control) -> void:
	_alternarPlegable(panel, "ContenidoRazonamiento")

## Un clic en cualquier punto libre de la tarjeta (no solo en la cabecera) abre y
## cierra el cuerpo: el usuario pidio que se pueda pulsar la tarjeta entera.
func _alPulsarTarjetaPlegable(evento: InputEvent, panel: Control, nombreContenido: String) -> void:
	if evento is InputEventMouseButton and evento.pressed and evento.button_index == MOUSE_BUTTON_LEFT:
		# Se consume aqui: una tarjeta de dentro del hilo de un subagente no tiene que
		# plegar tambien la tarjeta del "Run agent" que la contiene.
		panel.accept_event()
		_alternarPlegable(panel, nombreContenido)

func _alRecibirRazonamiento(texto: String) -> void:
	if _peticionCancelada:
		return
	if texto == null or String(texto) == "":
		return
	texto = String(texto).replace("<null>", "")
	if texto == "":
		return
	if not is_instance_valid(_burbujaRazonamiento):
		await _crearBurbujaRazonamiento()
	if not is_instance_valid(_burbujaRazonamiento):
		return
	_textoRazonamientoAcumulado += String(texto)
	_volcarRazonamiento(_burbujaRazonamiento, _textoRazonamientoAcumulado)
	_seguirStreamAlFinal = true
	await _scrollAlFinal()

## Vuelca la traza en el cuerpo de la tarjeta sin analizar markdown. Lo que ya pasa
## del tamano de trozo se congela en su propia etiqueta (una sola vez) y solo se
## reescribe la cola viva: el coste por delta queda acotado aunque la traza sea
## larguisima. Funciona igual con la tarjeta abierta o cerrada.
func _volcarRazonamiento(panel: Control, texto: String) -> void:
	var contenedor := panel.find_child("ContenidoRazonamiento", true, false) as VBoxContainer
	if not is_instance_valid(contenedor):
		return
	panel.set_meta("razonamiento_texto", texto)
	var corte := int(panel.get_meta("corte_razonamiento", 0))
	var nuevo := ChatStreamBloques.corteRazonamiento(texto, corte, RAZONAMIENTO_TROZO_MIN)
	var cola := contenedor.get_node_or_null("ColaRazonamiento") as Label
	if nuevo > corte:
		var trozo := Label.new()
		trozo.add_theme_color_override("font_color", COLOR_RAZONAMIENTO)
		trozo.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		trozo.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		trozo.text = texto.substr(corte, nuevo - corte)
		contenedor.add_child(trozo)
		if is_instance_valid(cola):
			contenedor.move_child(cola, contenedor.get_child_count() - 1)
		panel.set_meta("corte_razonamiento", nuevo)
		corte = nuevo
	elif not _puedeRenderizarStream():
		return
	if not is_instance_valid(cola):
		cola = Label.new()
		cola.name = "ColaRazonamiento"
		cola.add_theme_color_override("font_color", COLOR_RAZONAMIENTO)
		cola.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		cola.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		contenedor.add_child(cola)
	cola.text = texto.substr(corte)

func _alFinalizarRazonamiento() -> void:
	if is_instance_valid(_burbujaRazonamiento):
		_finalizarBurbujaRazonamiento(_burbujaRazonamiento, false)
		_burbujaRazonamiento = null
		_textoRazonamientoAcumulado = ""

func _finalizarBurbujaRazonamiento(panel: Control, cancelado: bool = false) -> void:
	if not is_instance_valid(panel):
		return
	panel.set_meta("terminada", true)
	# Una tarjeta de razonamiento vacia no aporta nada: se elimina en vez de
	# acumular tarjetas "Thinking" vacias en el chat.
	if str(panel.get_meta("razonamiento_texto", "")).strip_edges() == "":
		panel.queue_free()
		return
	# Cuanto duro: la cabecera pasa de "Thinking" a "Thought for Ns".
	if _inicioRazonamientoMsec > 0:
		panel.set_meta("segundos_razonamiento", int(round((Time.get_ticks_msec() - _inicioRazonamientoMsec) / 1000.0)))
	_inicioRazonamientoMsec = 0
	var cabecera := panel.find_child("CabeceraRazonamiento", true, false) as Button
	if is_instance_valid(cabecera):
		cabecera.text = _textoCabeceraRazonamiento(panel)
	# La interrupcion se anota dentro del cuerpo, con el mismo tono apagado de la traza.
	if cancelado:
		var contenedor := panel.find_child("ContenidoRazonamiento", true, false) as VBoxContainer
		if is_instance_valid(contenedor) and contenedor.get_node_or_null("NotaInterrupcion") == null:
			var nota := Label.new()
			nota.name = "NotaInterrupcion"
			nota.text = "(reasoning interrupted)"
			nota.add_theme_color_override("font_color", COLOR_HERRAMIENTA_DETALLE)
			nota.size_flags_horizontal = Control.SIZE_EXPAND_FILL
			contenedor.add_child(nota)

func _finalizarTarjetaHerramientaCancelada(tarjeta: Control) -> void:
	if not is_instance_valid(tarjeta):
		return
	tarjeta.set_meta("terminada", true)
	_cerrarSpinnerFila(tarjeta, GLIFO_DENEGADA, COLOR_ESTADO_WARN)
	_fijarEstadoHerramienta(tarjeta, "cancelled", Color(0.72, 0.68, 0.60, 1.0))
	_fijarDetalleHerramienta(tarjeta, "The turn was cancelled before the tool finished.")

func _limpiarUITrabajandoHuerfana() -> void:
	if not is_instance_valid(contenedorMensajes):
		return
	for hijo in contenedorMensajes.get_children():
		if not is_instance_valid(hijo):
			continue
		var nombre := str(hijo.name)
		if nombre == "BurbujaEspera":
			hijo.queue_free()
		elif nombre == "BurbujaRazonamiento":
			if not bool(hijo.get_meta("terminada", false)):
				_finalizarBurbujaRazonamiento(hijo, true)
		elif nombre == "TarjetaHerramienta":
			if not bool(hijo.get_meta("terminada", false)):
				_finalizarTarjetaHerramientaCancelada(hijo)
		elif nombre == "TarjetaReintentos":
			hijo.queue_free()

## Quita el aviso de espera cuando el turno termina sin una respuesta que lo
## sustituya. Antes esta tarea la hacia la tarjeta "Agent is working", que ya no
## existe; el aviso de espera es ahora la unica pieza transitoria de la UI.
func _ocultarEspera() -> void:
	if is_instance_valid(_burbujaEsperando):
		_burbujaEsperando.queue_free()
		_burbujaEsperando = null

## Las filas de suceso (herramienta, reintento) NO son tarjetas: el usuario no
## quiere contornos ni paneles de fondo, solo texto. El estilo es vacio a proposito
## (el PanelContainer sigue haciendo falta como contenedor del cuerpo plegable, pero
## no dibuja nada) y solo queda el margen justo para alinear el texto.
func _estiloFilaCompacta() -> StyleBoxEmpty:
	var estilo := StyleBoxEmpty.new()
	estilo.content_margin_left = 2
	estilo.content_margin_right = 0
	estilo.content_margin_top = 2
	estilo.content_margin_bottom = 2
	return estilo

## Panel de tareas: la lista que escribe "Update todo list", pegada encima de la
## caja de texto. Plegado ocupa una linea (el recuento y la tarea en curso, que es
## lo que se quiere ver de un vistazo mientras el modelo trabaja) y abierto ensena
## la lista, con scroll cuando no cabe entera. Es una vista del estado que vive en
## _tareas: el modelo nunca lee esto, lee el bloque del prompt.
func _construirPanelTareas() -> PanelContainer:
	var panel := PanelContainer.new()
	panel.name = "PanelTareas"
	panel.visible = false
	panel.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	# El mismo velo que el razonamiento: es un bloque de estado, no una tarjeta.
	panel.add_theme_stylebox_override("panel", ChatEstilos.crearEstiloRazonamiento())
	panel.set_meta("abierta", false)
	var caja := VBoxContainer.new()
	caja.name = "CajaTareas"
	caja.add_theme_constant_override("separation", 2)
	caja.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	caja.mouse_filter = Control.MOUSE_FILTER_IGNORE
	panel.add_child(caja)
	var cabecera := HBoxContainer.new()
	cabecera.name = "CabeceraTareas"
	cabecera.add_theme_constant_override("separation", 6)
	cabecera.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	cabecera.mouse_filter = Control.MOUSE_FILTER_IGNORE
	caja.add_child(cabecera)
	_cabeceraTareas = cabecera
	_etiquetaTareas = Button.new()
	_etiquetaTareas.name = "EtiquetaTareas"
	_etiquetaTareas.flat = true
	_etiquetaTareas.focus_mode = Control.FOCUS_NONE
	_etiquetaTareas.add_theme_color_override("font_color", COLOR_HERRAMIENTA_NOMBRE)
	_etiquetaTareas.pressed.connect(_alternarPlegable.bind(panel, "ListaTareas"))
	cabecera.add_child(_etiquetaTareas)
	_previewTareas = Label.new()
	_previewTareas.name = "PreviewTareas"
	_previewTareas.add_theme_color_override("font_color", ChatEstilos.COLOR_TEXTO_TENUE)
	_previewTareas.text_overrun_behavior = TextServer.OVERRUN_TRIM_ELLIPSIS
	_previewTareas.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_previewTareas.mouse_filter = Control.MOUSE_FILTER_IGNORE
	cabecera.add_child(_previewTareas)
	var flecha := Button.new()
	flecha.name = "AccordionBtn"
	flecha.flat = true
	flecha.focus_mode = Control.FOCUS_NONE
	flecha.text = GLIFO_ACORDEON_CERRADO
	flecha.add_theme_color_override("font_color", ChatEstilos.COLOR_TEXTO_TENUE)
	flecha.pressed.connect(_alternarPlegable.bind(panel, "ListaTareas"))
	cabecera.add_child(flecha)
	# La lista va dentro de un scroll de alto ajustado: sin el, una lista larga
	# empujaria la caja de texto fuera del panel del editor. El nodo que se pliega
	# y se despliega es el scroll, para que la cabecera no se quede con un hueco
	# vacio debajo cuando la lista esta cerrada.
	_scrollTareas = ScrollContainer.new()
	_scrollTareas.name = "ListaTareas"
	_scrollTareas.visible = false
	_scrollTareas.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	_scrollTareas.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	caja.add_child(_scrollTareas)
	_listaTareas = VBoxContainer.new()
	_listaTareas.name = "FilasTareas"
	_listaTareas.add_theme_constant_override("separation", 2)
	_listaTareas.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_listaTareas.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_scrollTareas.add_child(_listaTareas)
	# El alto que piden las filas depende del ancho que acaban teniendo (el texto
	# se reparte en varias lineas), y antes de colocarse miden de mas: se vuelve a
	# mirar cada vez que cambian de tamano.
	_listaTareas.resized.connect(_ajustarAltoLista)
	panel.gui_input.connect(_alPulsarTarjetaPlegable.bind(panel, "ListaTareas"))
	resized.connect(_ajustarAltoLista)
	return panel

## Alto que le toca al scroll de la lista: el que piden las filas, recortado a lo
## que sobra en el chat. Se llama al repintar y cada vez que cambia el tamano del
## chat, que es cuando el usuario arrastra el borde del panel del editor.
func _ajustarAltoLista() -> void:
	if not is_instance_valid(_scrollTareas) or not is_instance_valid(_listaTareas):
		return
	var tope := clampf(size.y - ALTO_RESERVADO_LISTA, ALTO_MIN_LISTA, ALTO_MAX_LISTA)
	# get_combined_minimum_size() de una etiqueta con ajuste de linea depende del
	# ancho que tenga en ese momento: por eso esto se llama en diferido, cuando las
	# filas ya se han colocado y saben cuanto ocupan de verdad.
	var alto := minf(_listaTareas.get_combined_minimum_size().y, tope)
	if absf(alto - _scrollTareas.custom_minimum_size.y) < 1.0:
		return
	_scrollTareas.custom_minimum_size.y = alto

## Vuelve a pintar el panel desde _tareas. Es lo unico que hay que llamar cuando la
## lista cambia, se carga un chat o se empieza uno nuevo.
func _refrescarPanelTareas() -> void:
	if not is_instance_valid(_panelTareas):
		return
	_panelTareas.visible = not _tareas.is_empty()
	if not is_instance_valid(_listaTareas):
		return
	for hijo in _listaTareas.get_children():
		_listaTareas.remove_child(hijo)
		hijo.queue_free()
	if _tareas.is_empty():
		# Sin lista no queda nada que desplegar: la proxima vuelve a nacer plegada.
		if is_instance_valid(_scrollTareas):
			_scrollTareas.visible = false
		_panelTareas.set_meta("abierta", false)
		var flechaVacia := _panelTareas.find_child("AccordionBtn", true, false) as Button
		if is_instance_valid(flechaVacia):
			flechaVacia.text = GLIFO_ACORDEON_CERRADO
		return
	_etiquetaTareas.text = "Todo %s" % HerramientasTareas.resumen(_tareas)
	var activa: Dictionary = HerramientasTareas.tareaActiva(_tareas)
	_previewTareas.text = str(activa.get("content", ""))
	_previewTareas.visible = _previewTareas.text != ""
	for t in _tareas:
		_listaTareas.add_child(_filaTarea(t))
	_ajustarAltoLista.call_deferred()

## Una fila de la lista: la marca del estado y el texto. La hecha y la cancelada se
## apagan (Godot no tiene tachado en un Label); la que esta en curso va con el color
## fuerte, que es la que interesa.
func _filaTarea(tarea: Dictionary) -> Control:
	var estado := str(tarea.get("status", "pending"))
	var fila := HBoxContainer.new()
	fila.name = "FilaTarea"
	fila.add_theme_constant_override("separation", 6)
	fila.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	fila.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var marca := Label.new()
	marca.name = "MarcaTarea"
	marca.text = str(HerramientasTareas.MARCAS.get(estado, "[ ]"))
	marca.custom_minimum_size = Vector2(22, 0)
	marca.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var colorMarca := ChatEstilos.COLOR_TEXTO_TENUE
	if estado == "in_progress":
		colorMarca = COLOR_HERRAMIENTA_NOMBRE
	elif estado == "pending":
		colorMarca = ChatEstilos.COLOR_TEXTO_SECUNDARIO
	marca.add_theme_color_override("font_color", colorMarca)
	fila.add_child(marca)
	var texto := Label.new()
	texto.name = "TextoTarea"
	texto.text = str(tarea.get("content", ""))
	texto.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	texto.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	texto.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var colorTexto := ChatEstilos.COLOR_TEXTO_SECUNDARIO
	if estado == "in_progress":
		colorTexto = ChatEstilos.COLOR_TEXTO_PRIMARIO
	elif estado == "completed" or estado == "cancelled":
		colorTexto = ChatEstilos.COLOR_TEXTO_TENUE
	texto.add_theme_color_override("font_color", colorTexto)
	fila.add_child(texto)
	return fila

## Punto unico de entrada de la lista: la herramienta, al reabrir un chat y al
## empezar uno nuevo pasan por aqui. Deja el panel pintado y el prompt al dia, que
## es lo que hace que la lista viaje en la siguiente peticion sin tocar el historial.
func _actualizarTareas(tareas: Array) -> void:
	_tareas = tareas.duplicate(true)
	_refrescarPanelTareas()
	_reconstruirSystemPrompt()

## Herramienta: UNA linea de texto con el nombre que el propio modelo le dio a la
## ejecucion ("Reading Chat.gd"), y nada mas. El usuario no quiere tarjetas: no hay
## fondo, ni contorno, ni JSON de parametros, ni chulo de exito. Mientras corre gira
## el spinner; al terminar bien deja en su hueco el icono de herramienta; y solo el
## fallo pinta algo ("failed" en rojo). El resultado completo sigue a un clic, en el
## cuerpo plegable.
##
## No hay RichTextLabel ni un HBox por parametro como en la version anterior: el
## detalle son Labels simples, que es lo que abarata el redibujado.
func _construirTarjetaHerramienta(nombreHerramienta: String, args: Dictionary) -> Control:
	var panel := PanelContainer.new()
	panel.name = "TarjetaHerramienta"
	panel.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	panel.add_theme_stylebox_override("panel", _estiloFilaCompacta())
	panel.set_meta("terminada", false)
	panel.set_meta("abierta", false)
	var vbox := VBoxContainer.new()
	vbox.add_theme_constant_override("separation", 4)
	vbox.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	# Deja pasar el raton: el que decide (abrir/cerrar) es la tarjeta entera.
	vbox.mouse_filter = Control.MOUSE_FILTER_IGNORE
	panel.add_child(vbox)
	var cabecera := HBoxContainer.new()
	cabecera.name = "CabeceraHerramienta"
	cabecera.add_theme_constant_override("separation", 8)
	cabecera.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	cabecera.mouse_filter = Control.MOUSE_FILTER_IGNORE
	vbox.add_child(cabecera)
	var spinner := Label.new()
	spinner.name = "SpinnerFila"
	spinner.text = SPINNER_FRAMES[0]
	spinner.add_theme_color_override("font_color", COLOR_SPINNER)
	# Ancho fijo: los cuadros del spinner no deben mover el resto de la linea.
	spinner.custom_minimum_size = Vector2(TAMANO_ICONO_HERRAMIENTA, 0)
	cabecera.add_child(spinner)
	# Icono de herramienta: ocupa el mismo hueco que el spinner (por eso los dos
	# miden TAMANO_ICONO_HERRAMIENTA) y sale cuando la ejecucion termina bien, para
	# que se vea de un vistazo que eso fue una herramienta y no un mensaje mas.
	var icono := TextureRect.new()
	icono.name = "IconoHerramienta"
	icono.texture = _iconoHerramienta()
	icono.visible = false
	icono.custom_minimum_size = Vector2(TAMANO_ICONO_HERRAMIENTA, TAMANO_ICONO_HERRAMIENTA)
	icono.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	icono.modulate = COLOR_HERRAMIENTA_DETALLE
	icono.mouse_filter = Control.MOUSE_FILTER_IGNORE
	cabecera.add_child(icono)
	var nombreLabel := Label.new()
	nombreLabel.name = "NombreHerramienta"
	# El titulo que dio el modelo manda; el nombre de la herramienta es el recado
	# de "esto lo hizo tal herramienta" y solo se ensena si no hubo titulo.
	nombreLabel.text = _textoTarjetaHerramienta(nombreHerramienta, args)
	nombreLabel.add_theme_color_override("font_color", COLOR_HERRAMIENTA_NOMBRE)
	nombreLabel.text_overrun_behavior = TextServer.OVERRUN_TRIM_ELLIPSIS
	nombreLabel.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	cabecera.add_child(nombreLabel)
	# Estado: oculto mientras todo va bien (el spinner ya lo dice). Solo aparece
	# cuando hay algo que contar: failed, denied, cancelled.
	var estadoLabel := Label.new()
	estadoLabel.name = "EstadoHerramienta"
	estadoLabel.visible = false
	estadoLabel.add_theme_color_override("font_color", COLOR_HERRAMIENTA_DETALLE)
	cabecera.add_child(estadoLabel)
	# Aviso de permiso: SIEMPRE visible, fuera del acordeon (dentro quedaria oculto
	# y el chat se quedaria esperando una respuesta que nadie ve).
	var permiso := VBoxContainer.new()
	permiso.name = "PermisoContainer"
	permiso.add_theme_constant_override("separation", 6)
	permiso.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	permiso.mouse_filter = Control.MOUSE_FILTER_IGNORE
	vbox.add_child(permiso)
	# Miniaturas: si la herramienta devolvio una imagen (ver o capturar), se ve aqui
	# sin abrir nada. Es el resultado, no un detalle.
	var miniaturas := VBoxContainer.new()
	miniaturas.name = "MiniaturasContainer"
	miniaturas.add_theme_constant_override("separation", 4)
	miniaturas.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	miniaturas.mouse_filter = Control.MOUSE_FILTER_IGNORE
	vbox.add_child(miniaturas)
	# Detalle plegado: el resultado completo. Los parametros ya no se listan (el
	# usuario no los quiere ver), pero el texto que devolvio la herramienta sigue
	# ahi: es la unica forma de leer que paso si algo salio raro.
	var details := VBoxContainer.new()
	details.name = "DetailsContainer"
	details.visible = false
	details.add_theme_constant_override("separation", 4)
	details.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	details.mouse_filter = Control.MOUSE_FILTER_IGNORE
	vbox.add_child(details)
	var detalle := Label.new()
	detalle.name = "ResultadoDetalle"
	detalle.visible = false
	detalle.add_theme_color_override("font_color", Color(0.62, 0.62, 0.66, 0.95))
	detalle.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	detalle.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	# Tope de lineas visibles: una salida enorme no puede estirar la tarjeta.
	detalle.max_lines_visible = 24
	details.add_child(detalle)
	# La tarjeta entera abre y cierra su cuerpo: no hay flecha ni cabecera
	# pulsable aparte, asi que un solo enganche basta.
	panel.gui_input.connect(_alPulsarTarjetaPlegable.bind(panel, "DetailsContainer"))
	return panel

## Texto de la cabecera: el titulo que dio el modelo para ESTA ejecucion. Si no lo
## mando (o mando algo vacio), se cae al nombre de la herramienta con el dato mas
## util de los argumentos detras, que es lo que se veia antes.
func _textoTarjetaHerramienta(nombreHerramienta: String, args: Dictionary) -> String:
	var titulo := str(args.get("titulo", "")).strip_edges()
	if titulo != "":
		var limpio := _unaLinea(titulo)
		if limpio.length() > 90:
			limpio = limpio.substr(0, 87) + "..."
		return limpio
	var objetivo := _objetivoHerramienta(args)
	if objetivo == "":
		return nombreHerramienta
	return "%s · %s" % [nombreHerramienta, objetivo]

## Fila de herramienta: se construye, se mete en el chat y arranca su spinner. El
## cuerpo plegable se abre pulsando la tarjeta.
func _crearTarjetaHerramienta(nombreHerramienta: String, args: Dictionary) -> Control:
	var panel := _construirTarjetaHerramienta(nombreHerramienta, args)
	var spinner := panel.find_child("SpinnerFila", true, false) as Label
	# Con un subagente en marcha, la tarjeta cuelga del hilo de su tarjeta y no
	# del chat: el usuario ve lo que se toca sin que el hilo principal se ensucie.
	var destino: Node = _hiloSubagente if is_instance_valid(_hiloSubagente) else _contenedorActivoMensajes()
	destino.add_child(panel)
	_moverEsperaAlFinal()
	_iniciarSpinnerFila(spinner)
	_animarAparecer(panel)
	await get_tree().process_frame
	await _scrollAlFinal()
	return panel


## Abre el hilo de un subagente sobre la tarjeta que lo lanzo y devuelve el VBox
## donde van sus pasos: lo que se pinte ahi cuelga de la tarjeta del "Run agent",
## sangrado y con una guia vertical, en vez de caer suelto en el chat.
##
## El hilo se mete en el vbox de la tarjeta JUSTO DESPUES de PermisoContainer, y
## no dentro del acordeon: el aviso de permiso de la tarjeta padre tiene que
## seguir siendo suyo (se busca por nombre con find_child, que baja a los hijos)
## y el hilo no puede plegarse con ella.
func _abrirHiloSubagente(tarjeta: Control) -> VBoxContainer:
	_cerrarHiloSubagente()
	if not is_instance_valid(tarjeta) or tarjeta.get_child_count() == 0:
		return null
	var vbox := tarjeta.get_child(0) as VBoxContainer
	if vbox == null:
		return null
	var margen := MarginContainer.new()
	margen.name = "HiloSubagente"
	margen.add_theme_constant_override("margin_left", 16)
	margen.add_theme_constant_override("margin_top", 2)
	margen.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var fila := HBoxContainer.new()
	fila.add_theme_constant_override("separation", 8)
	fila.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	fila.mouse_filter = Control.MOUSE_FILTER_IGNORE
	# La guia: la linea fina que dice "esto de aqui dentro es del subagente".
	var guia := ColorRect.new()
	guia.color = COLOR_HERRAMIENTA_DETALLE
	guia.custom_minimum_size = Vector2(2, 0)
	guia.size_flags_vertical = Control.SIZE_EXPAND_FILL
	guia.mouse_filter = Control.MOUSE_FILTER_IGNORE
	fila.add_child(guia)
	var pasos := VBoxContainer.new()
	pasos.name = "PasosSubagente"
	pasos.add_theme_constant_override("separation", 4)
	pasos.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	pasos.mouse_filter = Control.MOUSE_FILTER_IGNORE
	fila.add_child(pasos)
	margen.add_child(fila)
	var indice := vbox.get_child_count()
	for i in range(vbox.get_child_count()):
		if str(vbox.get_child(i).name) == "PermisoContainer":
			indice = i + 1
			break
	vbox.add_child(margen)
	vbox.move_child(margen, indice)
	_hiloSubagente = pasos
	return pasos


## Cierra el hilo. Con `pasos` (lo que devolvio _abrirHiloSubagente) solo lo
## cierra si sigue siendo el abierto: una llamada vieja que vuelve tarde, cuando
## ya hay otro subagente corriendo, no puede llevarse por delante el hilo nuevo.
func _cerrarHiloSubagente(pasos: VBoxContainer = null) -> void:
	if pasos != null and _hiloSubagente != pasos:
		return
	_hiloSubagente = null

func _fijarEstadoHerramienta(tarjeta: Control, texto: String, color: Color) -> void:
	var estado := tarjeta.find_child("EstadoHerramienta", true, false) as Label
	if is_instance_valid(estado):
		estado.text = texto
		# Nace oculto: el estado solo se ensena cuando hay algo que contar.
		estado.visible = texto != ""
		estado.add_theme_color_override("font_color", color)

## Texto del cuerpo plegable: el resultado completo, recortado a un tope para que
## una salida gigante no se coma el chat (el historial guarda el texto entero).
func _fijarDetalleHerramienta(tarjeta: Control, mensaje: String) -> void:
	var detalle := tarjeta.find_child("ResultadoDetalle", true, false) as Label
	if not is_instance_valid(detalle):
		return
	var texto := mensaje.strip_edges()
	if texto == "":
		detalle.visible = false
		return
	if texto.length() > MAX_RESULTADO_TARJETA:
		texto = texto.substr(0, MAX_RESULTADO_TARJETA) + "\n... (result truncated)"
	detalle.text = texto
	detalle.visible = true


## Miniaturas de imagen: lo que devolvio una herramienta que ve o captura, y lo que
## adjunto el usuario. Se pintan dentro de una caja de MINIATURA_ANCHO x
## MINIATURA_ALTO conservando la proporcion. Devuelve cuantas puso, para que quien
## llame pueda decidir si el hueco se queda vacio.
func _agregarMiniaturas(contenedor: Node, rutas: Array) -> int:
	if not is_instance_valid(contenedor):
		return 0
	var puestas := 0
	for ruta in rutas:
		if puestas >= MAX_MINIATURAS:
			break
		var textura := _texturaDeArchivo(str(ruta))
		if textura == null:
			continue
		contenedor.add_child(_marcoMiniatura(textura))
		puestas += 1
	return puestas


## Imagen de un archivo de disco como textura. Se lee con Image y no con load():
## lo que guarda el chat (user://dotti_adjuntos) son archivos sueltos, no recursos
## importados, y load() no los encuentra.
func _texturaDeArchivo(ruta: String) -> Texture2D:
	if ruta == "" or not FileAccess.file_exists(ruta):
		return null
	var img := Image.new()
	if img.load(ruta) != OK:
		return null
	return ImageTexture.create_from_image(img)


## Marco de una miniatura. El tamano se calcula aqui (y no se deja al layout)
## porque una foto de 1536 px estiraria el chat entero.
func _marcoMiniatura(textura: Texture2D) -> Control:
	var marco := PanelContainer.new()
	marco.name = "Miniatura"
	marco.size_flags_horizontal = Control.SIZE_SHRINK_BEGIN
	marco.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var estilo := StyleBoxFlat.new()
	estilo.bg_color = Color(0, 0, 0, 0.25)
	estilo.border_color = Color(1, 1, 1, 0.12)
	estilo.set_border_width_all(1)
	estilo.set_corner_radius_all(4)
	estilo.set_content_margin_all(2)
	marco.add_theme_stylebox_override("panel", estilo)
	var real := textura.get_size()
	var caja := _tamanoMiniatura(real)
	var foto := TextureRect.new()
	foto.texture = textura
	foto.custom_minimum_size = caja
	# Sin esto el minimo del TextureRect es el de la textura (1536 px) y la
	# imagen manda sobre el layout en vez de al reves.
	foto.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	foto.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	foto.mouse_filter = Control.MOUSE_FILTER_IGNORE
	if caja.x > real.x or caja.y > real.y:
		# Se esta agrandando: un sprite tiene que quedar en bloques, no borroso.
		foto.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	marco.add_child(foto)
	return marco


## Caja de la miniatura: encaja la imagen en MINIATURA_ANCHO x MINIATURA_ALTO. Una
## imagen mas pequena que la caja se agranda por un factor entero (un sprite de
## 16x16 no se ve a 16x16) con un tope, para no convertir una miniatura en mural.
func _tamanoMiniatura(real: Vector2) -> Vector2:
	if real.x < 1.0 or real.y < 1.0:
		return Vector2(MINIATURA_ANCHO, MINIATURA_ALTO)
	var escala := minf(MINIATURA_ANCHO / real.x, MINIATURA_ALTO / real.y)
	if escala >= 1.0:
		escala = clampf(floorf(escala), 1.0, 4.0)
	return Vector2(maxf(roundf(real.x * escala), 1.0), maxf(roundf(real.y * escala), 1.0))


## Hueco de miniaturas de una burbuja (la del usuario o la de una tarjeta de
## herramienta). Va dentro del VBox de la burbuja, debajo del texto.
func _miniaturasDeBurbuja(etiqueta: Node) -> Node:
	if not is_instance_valid(etiqueta):
		return null
	return etiqueta.get_meta("miniaturas", null) as Node


## Claves de las que sale el objetivo de la fila, de la mas informativa a la menos.
## Son las que usan las herramientas del addon (rutas, nodos, busquedas).
const CLAVES_OBJETIVO := [
	"path", "ruta", "archivo", "file", "node_path", "parent_path", "target_node_path",
	"directory", "scene_path", "script_path", "resource_path", "from",
	"search", "pattern", "query", "setting", "view", "mode", "name", "nombre",
]

## Objetivo de la fila: el dato mas util de los argumentos, en una sola linea y
## recortado. opencode ensena lo mismo detras del nombre de la herramienta; sin
## esto la fila no dice sobre que se esta trabajando.
func _objetivoHerramienta(args: Dictionary) -> String:
	if args.is_empty():
		return ""
	var valor := ""
	for clave in CLAVES_OBJETIVO:
		var v: Variant = args.get(clave, null)
		if v is String and String(v).strip_edges() != "":
			valor = String(v)
			break
	if valor == "":
		# La lista de tareas llega como array, no como texto: su dato util es el
		# recuento, que es lo que se lee de un vistazo en la fila.
		var todos = args.get("todos", null)
		if typeof(todos) == TYPE_ARRAY:
			return "%s tasks" % HerramientasTareas.resumen(todos)
	if valor == "":
		# Sin clave conocida: el primer texto que traiga, para no dejar la fila muda.
		for clave in args.keys():
			var v: Variant = args[clave]
			if v is String and String(v).strip_edges() != "":
				valor = String(v)
				break
	if valor == "":
		return ""
	valor = _unaLinea(valor)
	if valor.length() > 64:
		valor = valor.substr(0, 61) + "..."
	return valor

## Deja un texto en una sola linea y sin espacios de mas: ni la fila de herramienta
## ni el resumen pueden crecer en alto.
func _unaLinea(texto: String) -> String:
	var s := texto.replace("\r", " ").replace("\n", " ").replace("\t", " ")
	while s.contains("  "):
		s = s.replace("  ", " ")
	return s.strip_edges()

func _actualizarTarjetaHerramienta(tarjeta: Control, exito: bool, mensaje: String, imagenes: Array = []) -> void:
	if not is_instance_valid(tarjeta):
		return
	tarjeta.set_meta("terminada", true)
	# Exito = linea limpia: se apaga el spinner y no queda ni glifo ni "done". El
	# rojo se reserva para lo que de verdad fallo.
	if exito:
		_apagarSpinnerTarjeta(tarjeta)
	else:
		_cerrarSpinnerFila(tarjeta, GLIFO_ERR, COLOR_ESTADO_ERR)
		_fijarEstadoHerramienta(tarjeta, "failed", COLOR_ESTADO_ERR)
	_fijarDetalleHerramienta(tarjeta, mensaje)
	if not imagenes.is_empty():
		var hueco := tarjeta.find_child("MiniaturasContainer", true, false)
		_agregarMiniaturas(hueco, imagenes)
	if exito:
		_animarExito(tarjeta)
	else:
		_animarError(tarjeta)
	await _scrollAlFinal()


## Termina el spinner de una tarjeta y deja en su hueco el icono de herramienta: la
## ejecucion salio bien y esto es lo unico que se ensena de ella. Si el tema del
## editor no trae icono, el hueco se queda vacio (el titulo no se mueve porque el
## spinner y el icono miden lo mismo).
func _apagarSpinnerTarjeta(tarjeta: Control) -> void:
	if not is_instance_valid(tarjeta):
		return
	var spinner := tarjeta.find_child("SpinnerFila", true, false) as Label
	if is_instance_valid(spinner):
		var timer := spinner.get_node_or_null("TimerSpinnerFila") as Timer
		if is_instance_valid(timer):
			timer.stop()
			timer.queue_free()
		spinner.text = ""
		spinner.visible = false
	var icono := tarjeta.find_child("IconoHerramienta", true, false) as TextureRect
	if is_instance_valid(icono) and icono.texture != null:
		icono.visible = true

## Icono de herramienta de la tarjeta. Es un SVG propio (ChatIconos) y no un
## EditorIcon a proposito: los nombres de EditorIcons cambian entre versiones de
## Godot y no existen fuera del editor, asi que la tarjeta se quedaba sin icono sin
## avisar. Con el SVG el icono esta siempre y ademas pega con el resto de la interfaz.
func _iconoHerramienta() -> Texture2D:
	return ChatIconos.icono("wrench", TAMANO_ICONO_HERRAMIENTA)


## Reintento: una fila mas del chat, hermana de las de herramienta. Cabecera de una
## linea (spinner + "Retrying... (2/5)" + cuenta atras a la derecha) y, plegada, la
## lista de errores que lo provocaron. Antes era una caja roja de tres pixeles de
## borde con barra de progreso de bloques, giro ASCII y boton de acordeon: pesaba
## mas que la respuesta que intentaba recuperar y no se parecia a nada del chat.
func _crearOActualizarTarjetaReintentos(mensaje: String, intento: int) -> void:
	_listaErrores.append({"mensaje": mensaje, "intento": intento, "timestamp": Time.get_unix_time_from_system()})
	if is_instance_valid(_tarjetaReintentos):
		await _actualizarTarjetaReintentosExistente()
		return
	var panel := PanelContainer.new()
	panel.name = "TarjetaReintentos"
	panel.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	panel.add_theme_stylebox_override("panel", _estiloFilaCompacta())
	var vbox := VBoxContainer.new()
	vbox.add_theme_constant_override("separation", 4)
	vbox.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	vbox.mouse_filter = Control.MOUSE_FILTER_IGNORE
	panel.add_child(vbox)
	var cabecera := HBoxContainer.new()
	cabecera.name = "CabeceraReintento"
	cabecera.add_theme_constant_override("separation", 8)
	cabecera.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	cabecera.mouse_filter = Control.MOUSE_FILTER_IGNORE
	vbox.add_child(cabecera)
	var spinnerLabel := Label.new()
	spinnerLabel.name = "SpinnerReintento"
	spinnerLabel.text = SPINNER_FRAMES[0]
	spinnerLabel.add_theme_color_override("font_color", COLOR_SPINNER)
	# Mismo hueco que el spinner de las filas de herramienta: asi el titulo de un
	# reintento arranca a la misma altura que el de cualquier otra fila.
	spinnerLabel.custom_minimum_size = Vector2(TAMANO_ICONO_HERRAMIENTA, 0)
	cabecera.add_child(spinnerLabel)
	var tituloLabel := Label.new()
	tituloLabel.name = "TituloReintento"
	tituloLabel.text = _textoTituloReintento()
	tituloLabel.add_theme_color_override("font_color", COLOR_HERRAMIENTA_NOMBRE)
	tituloLabel.text_overrun_behavior = TextServer.OVERRUN_TRIM_ELLIPSIS
	tituloLabel.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	cabecera.add_child(tituloLabel)
	# La cuenta atras vive donde el estado de una herramienta: a la derecha y en
	# gris. Al llegar a cero se queda vacia, que es lo que hace una fila que va bien.
	var cuentaLabel := Label.new()
	cuentaLabel.name = "CuentaReintento"
	cuentaLabel.add_theme_color_override("font_color", COLOR_HERRAMIENTA_DETALLE)
	cabecera.add_child(cuentaLabel)
	# Cuerpo plegable: los errores. Nace cerrado y se abre pulsando la fila entera,
	# igual que el resultado de una herramienta.
	var details := VBoxContainer.new()
	details.name = "DetailsReintento"
	details.visible = false
	details.add_theme_constant_override("separation", 3)
	details.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	details.mouse_filter = Control.MOUSE_FILTER_IGNORE
	vbox.add_child(details)
	var erroresContainer := VBoxContainer.new()
	erroresContainer.name = "ErroresContainer"
	erroresContainer.add_theme_constant_override("separation", 3)
	erroresContainer.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	erroresContainer.mouse_filter = Control.MOUSE_FILTER_IGNORE
	details.add_child(erroresContainer)
	_actualizarListaErroresUI(erroresContainer)
	panel.gui_input.connect(_alPulsarTarjetaPlegable.bind(panel, "DetailsReintento"))
	_contenedorActivoMensajes().add_child(panel)
	_moverEsperaAlFinal()
	_tarjetaReintentos = panel
	await get_tree().process_frame
	_animarAparecer(panel)
	await _scrollAlFinal()
	_iniciarSpinnerFila(spinnerLabel)
	_iniciarAnimacionReintento(cuentaLabel)

## "Retrying... (2/5)". El numero de intento sale de la lista de errores, que es la
## que de verdad lleva la cuenta: antes la creacion usaba el parametro y la
## actualizacion el tamano de la lista, dos formas de decir lo mismo.
func _textoTituloReintento() -> String:
	return "Retrying... (%d/%d)" % [_listaErrores.size(), MAX_REINTENTOS]

func _actualizarTarjetaReintentosExistente() -> void:
	if not is_instance_valid(_tarjetaReintentos):
		return
	var tituloLabel := _tarjetaReintentos.find_child("TituloReintento", true, false) as Label
	if tituloLabel:
		tituloLabel.text = _textoTituloReintento()
	var erroresContainer := _tarjetaReintentos.find_child("ErroresContainer", true, false) as VBoxContainer
	if erroresContainer:
		_actualizarListaErroresUI(erroresContainer)
	# La espera vuelve a empezar en cada intento, asi que la cuenta atras tambien:
	# el temporizador se rearma con el reloj a cero.
	var cuenta := _tarjetaReintentos.find_child("CuentaReintento", true, false) as Label
	if cuenta:
		_iniciarAnimacionReintento(cuenta)
	# Cada error nuevo sacude la fila: es lo unico que avisa de que sigue fallando.
	_animarError(_tarjetaReintentos)
	await _scrollAlFinal()

func _actualizarListaErroresUI(container: VBoxContainer) -> void:
	for child in container.get_children():
		container.remove_child(child)
		child.queue_free()
	for i in range(_listaErrores.size()):
		var errorData = _listaErrores[i]
		var errorLine := HBoxContainer.new()
		errorLine.add_theme_constant_override("separation", 6)
		errorLine.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		errorLine.mouse_filter = Control.MOUSE_FILTER_IGNORE
		var numLabel := Label.new()
		numLabel.text = "#%d" % errorData["intento"]
		numLabel.add_theme_color_override("font_color", COLOR_HERRAMIENTA_DETALLE)
		errorLine.add_child(numLabel)
		var msgLabel := Label.new()
		# Aqui NO se recorta: el cuerpo plegable existe justo para poder leer el
		# error entero cuando el reintento no arreglo nada.
		msgLabel.text = _unaLinea(str(errorData["mensaje"]))
		msgLabel.add_theme_color_override("font_color", COLOR_HERRAMIENTA_DETALLE)
		msgLabel.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		msgLabel.max_lines_visible = 3
		msgLabel.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		errorLine.add_child(msgLabel)
		container.add_child(errorLine)

## Cuenta atras hasta el siguiente intento, con el ritmo de la animacion de
## reintento ya existente. El spinner de la fila lo mueve _iniciarSpinnerFila.
func _iniciarAnimacionReintento(cuenta: Label) -> void:
	_detenerYLiberarTimerTarjetaReintentos()
	_timerTarjetaReintentos = Timer.new()
	_timerTarjetaReintentos.name = "TimerReintento"
	_timerTarjetaReintentos.wait_time = duracionAnimacionReintento
	_timerTarjetaReintentos.one_shot = false
	_timerTarjetaReintentos.autostart = true
	add_child(_timerTarjetaReintentos)
	var tiempoInicio := Time.get_unix_time_from_system()
	# La cuenta arranca escrita: si no, la fila nace con el hueco de la derecha vacio
	# y no se rellena hasta el primer tic del temporizador.
	cuenta.text = "%.1fs" % ESPERA_REINTENTO
	_timerTarjetaReintentos.timeout.connect(func():
		if not is_instance_valid(cuenta):
			_detenerYLiberarTimerTarjetaReintentos()
			return
		var tiempoTranscurrido := Time.get_unix_time_from_system() - tiempoInicio
		var tiempoRestante := maxf(0.0, ESPERA_REINTENTO - tiempoTranscurrido)
		cuenta.text = "" if tiempoRestante <= 0.0 else "%.1fs" % tiempoRestante
	)

func _finalizarTarjetaReintentos(exito: bool) -> void:
	_detenerYLiberarTimerTarjetaReintentos()
	if not is_instance_valid(_tarjetaReintentos):
		_listaErrores.clear()
		_tarjetaReintentos = null
		return
	var spinner := _tarjetaReintentos.find_child("SpinnerReintento", true, false) as Label
	if is_instance_valid(spinner):
		var timer := spinner.get_node_or_null("TimerSpinnerFila") as Timer
		if is_instance_valid(timer):
			timer.stop()
			timer.queue_free()
		spinner.text = GLIFO_OK if exito else GLIFO_ERR
		spinner.add_theme_color_override("font_color", COLOR_ESTADO_OK if exito else COLOR_ESTADO_ERR)
	var titulo := _tarjetaReintentos.find_child("TituloReintento", true, false) as Label
	if titulo:
		titulo.text = "Recovered successfully" if exito else "Max retries reached"
		titulo.add_theme_color_override("font_color", COLOR_ESTADO_OK if exito else COLOR_ESTADO_ERR)
	var cuenta := _tarjetaReintentos.find_child("CuentaReintento", true, false) as Label
	if cuenta:
		cuenta.text = ""
	if exito:
		_animarExito(_tarjetaReintentos)
	else:
		_animarError(_tarjetaReintentos)
	_tarjetaReintentos = null
	_listaErrores.clear()

func _on_button_pressed() -> void:
	if _esperandoRespuesta or _bucleAgenteActivo:
		_cancelarPeticion()
		return
	var texto := campoTexto.text.strip_edges()
	# /compact: comando de barra, no un mensaje. Resume el contexto ya, sin
	# esperar a que la conversacion llene la ventana.
	if texto == "/compact":
		campoTexto.clear()
		campoTexto.text = ""
		_ajustarAlturaCampoTexto()
		_compactarContexto(true)
		return
	# /agent: comando de barra. /agent nombre lo pone, /agent off lo quita,
	# /agent sin nada dice cual esta activo y /agent list los enumera. @nombre en
	# un mensaje hace lo mismo, que es como se usa de verdad.
	if texto == "/agent" or texto.begins_with("/agent "):
		campoTexto.clear()
		campoTexto.text = ""
		_ajustarAlturaCampoTexto()
		_comandoAgente(texto)
		return
	# Un mensaje con solo una imagen adjunta tambien vale.
	if texto == "" and _archivosContexto.is_empty():
		return
	# @nombre: el mensaje invoca a un agente. Se activa ANTES de pintar el mensaje
	# para que su prompt y su lista de herramientas ya esten puestos en la peticion
	# que sale de este mismo turno.
	var agenteMencionado := Agentes.deMencion(texto)
	if not agenteMencionado.is_empty():
		_activarAgente(agenteMencionado, false)
	if is_instance_valid(_completado):
		_completado.ocultar()
	campoTexto.clear()
	campoTexto.text = ""
	_ajustarAlturaCampoTexto()
	_removerOpcionesRapidas()
	_mostrarPantallaBienvenida(false)
	var burbujaUsuario := await _crearBurbujaMarkdown(true)
	var imagenes := _rutasImagenesContexto()
	var textoMostrado := texto
	if not _archivosContexto.is_empty():
		var nombres: Array = []
		for a in _archivosContexto:
			nombres.append(a.get("nombre", ""))
		if textoMostrado != "":
			textoMostrado += "\n\n"
		textoMostrado += "_📎 " + ", ".join(nombres) + "_"
	burbujaUsuario.text = textoMostrado
	# La miniatura de lo que se acaba de adjuntar: si el usuario pego una captura,
	# tiene que verla en su propio mensaje, no solo el nombre del archivo.
	_agregarMiniaturas(_miniaturasDeBurbuja(burbujaUsuario), imagenes)
	# El usuario acaba de escribir: la vista vuelve al final y se sigue el
	# stream desde ahi, aunque estuviera leyendo mas arriba.
	_seguirStreamAlFinal = true
	await get_tree().process_frame
	_irAlFinal()
	var textoEnvio := texto + _construirBloqueContexto()
	_limpiarArchivosContexto()
	_bucleAgenteActivo = true
	await enviarMensaje(textoEnvio, imagenes)

func _cancelarPeticion() -> void:
	_idSesion += 1
	_peticionCancelada = true
	_bucleAgenteActivo = false
	_idEscritura += 1
	_esperandoRespuesta = false
	_reintentando = false
	_router.cancelar()
	_liberarStreamer()
	# Un subagente a medio camino se queda sin hilo: sus tarjetas ya no tienen donde
	# caer y la vuelta siguiente empieza en el chat, que es donde toca.
	_cerrarHiloSubagente()
	# Suelta cualquier pregunta pendiente: nadie emite la senal al cancelar, asi que
	# el await se quedaba colgado y la corrutina vieja seguia viva hasta la pregunta
	# siguiente. Los que esperan comprueban sesion y cancelacion al despertar.
	respuesta_pregunta_nativa.emit("")
	if is_instance_valid(_burbujaStream):
		# Deja el parcial ya recibido en un solo bloque: el stream se corta aqui.
		_colapsarStream(_burbujaStream, _textoStreamAcumulado)
	if is_instance_valid(_burbujaStream) and _textoStreamAcumulado.strip_edges() == "":
		_burbujaStream.queue_free()
		_burbujaStream = null
	_detenerYLiberarTimerTarjetaReintentos()
	if is_instance_valid(_burbujaEsperando):
		_burbujaEsperando.queue_free()
		_burbujaEsperando = null
	if is_instance_valid(_burbujaRazonamiento):
		_finalizarBurbujaRazonamiento(_burbujaRazonamiento, true)
	_burbujaRazonamiento = null
	_textoRazonamientoAcumulado = ""
	if is_instance_valid(_tarjetaReintentos):
		_tarjetaReintentos.queue_free()
		_tarjetaReintentos = null
	if is_instance_valid(_mensajeHerramientaActual):
		if not bool(_mensajeHerramientaActual.get_meta("terminada", false)):
			_finalizarTarjetaHerramientaCancelada(_mensajeHerramientaActual)
	_mensajeHerramientaActual = null
	_limpiarUITrabajandoHuerfana()
	_detenerSpinnerBoton()
	botonEnviar.disabled = false
	_listaErrores.clear()

func enviarMensaje(mensajeUsuario: String, imagenes: Array = []) -> void:
	_idSesion += 1
	var miSesion := _idSesion
	_peticionCancelada = false
	# Un hilo abierto de la vuelta anterior no puede tragarse las tarjetas de esta.
	_cerrarHiloSubagente()
	_contadorReintentos = 0
	_stallsConsecutivos = 0
	_esperandoRespuesta = true
	_seguirStreamAlFinal = true
	_iniciarSpinnerBoton()
	botonEnviar.disabled = false
	if _tituloChatActual.is_empty():
		_tituloChatActual = Historial.generarTitulo(mensajeUsuario)
	# Las imagenes viajan como rutas de user://, no como bytes: el chat guardado
	# se queda en texto y la imagen se lee al construir cada peticion.
	var entrada: Dictionary = {"role": "user", "content": mensajeUsuario}
	if not imagenes.is_empty():
		entrada["imagenes"] = imagenes
	historialConversacion.append(entrada)
	_burbujaEsperando = await _crearBurbujaEspera()
	await get_tree().create_timer(tiempoEsperaEnviarMensaje).timeout
	if _peticionCancelada or _idSesion != miSesion:
		return
	_realizarPeticion()

## El modelo que se va a pedir y que el servidor NO sirve, o "" si todo esta en
## orden. Se miran los dos: el que pide el agente (aunque la configuracion del
## chat fuera a contestar con otro, porque el usuario escribio @agente para ese) y
## el que va a contestar de verdad.
func _modeloNoServido() -> String:
	if not _apis or _apis.proveedores.is_empty():
		return ""
	if not _agente.is_empty():
		var delAgente := str(_agente.get("modelo", "")).strip_edges()
		if delAgente != "" and not ChatModelos.servido(delAgente):
			return delAgente
	var modelo := _modeloActual()
	if modelo != "" and not ChatModelos.servido(modelo):
		return modelo
	return ""

## Antes de enviar, el modelo tiene que ser uno que el servidor sirva.
##
## Mandar uno que no existe vuelve como un 400 que el upstream disfraza de filtro
## de contenido, y eso se lee como un problema del proyecto cuando lo que pasa es
## que el modelo no esta. Aqui se corta antes de gastar la vuelta: se dice cual es
## y se cae al que si esta. Devuelve true si queda algo que enviar.
func _modeloDisponible() -> bool:
	var malo := _modeloNoServido()
	if malo == "":
		return true
	var prov := _apis.obtener_proveedor(_proveedorIdActual())
	if not prov.is_empty() and ChatModelos.servido(str(prov.get("model_id", ""))):
		# El que va a contestar si esta: el que falta es el que pide el agente, y el
		# chat ya responde con el suyo.
		_avisoEnChat("The agent asks for the model '%s', which the server does not serve. Answering with '%s' instead." % [malo, str(prov.get("model_id", ""))])
		return true
	var alternativa := ""
	for p in _apis.proveedores:
		if ChatModelos.servido(str(p.get("model_id", ""))):
			alternativa = str(p.get("id", ""))
			break
	if alternativa == "":
		_cortarPeticionAntesDeEnviar()
		await _mostrarBurbujaError("There is no model to answer with: '%s' is not one the server serves, and no other one is configured. Pick one in Settings > Models, or ask whoever runs the gateway to add it." % malo)
		await _scrollAlFinal()
		return false
	var elegido := _apis.obtener_proveedor(alternativa)
	var config := _apis.obtener_configuracion_chat()
	_apis.establecer_proveedor_actual(alternativa)
	config["proveedor_id"] = alternativa
	config["modelo"] = str(elegido.get("model_id", ""))
	_apis.guardar_configuracion_chat(config)
	_actualizarTextoSelectores()
	# Otro modelo es otra ventana de contexto: el mismo gasto es otro porcentaje.
	_actualizarTextoUso()
	_avisoEnChat("The model '%s' is not one the server serves. Answering with '%s' instead; pick the one you want in Settings > Models." % [malo, str(elegido.get("model_id", ""))])
	return true

## Deja el chat como si la peticion hubiera terminado mal: sin spinner, sin
## burbuja de espera y con el boton libre. Es lo que hace _manejarError cuando se
## le acaban los reintentos, y aqui hace falta porque los cortes que pasan antes
## de enviar no pasan por el: ni un modelo que no existe ni un texto que no se
## abre se arreglan reintentando.
## Corta una peticion antes de que salga y deja el chat como si no se hubiera
## enviado nada. La llaman las tres puertas que revisan el envio antes de gastarlo
## (el nucleo nativo, la cuenta y el modelo), y a las tres se llega con la espera
## pintada y con `_esperandoRespuesta` en alto: si no se baja aqui, el boton de
## enviar se queda de cancelar y la primera pulsacion no hace nada.
func _cortarPeticionAntesDeEnviar() -> void:
	_bucleAgenteActivo = false
	_esperandoRespuesta = false
	_detenerSpinnerBoton()
	botonEnviar.disabled = false
	_finalizarTarjetaReintentos(false)
	_ocultarEspera()

## Si el nucleo nativo esta cargado y sus textos se abren. Sin el no hay
## prompts, asi que no se envia nada: una peticion sin reglas es el modelo
## contestando a ciegas, y eso no se ve en un error sino en la respuesta.
func _nucleoListo() -> bool:
	return Secretos.faltan().is_empty()

## Si hay cuenta. La pasarela de produccion contesta `auth_required` a quien no la
## tenga, asi que sin esto la peticion se gasta para que le digan al usuario lo
## que el plugin ya sabia (y con reintentos, que es peor).
func _cuentaLista() -> bool:
	if not Apis.exigeCuenta():
		return true
	return Sesion.unica().estaDentro()

## Si el fallo es de los que no se arreglan insistiendo (ver FALLOS_SIN_REINTENTO).
func _esFalloDeCuenta(mensaje: String) -> bool:
	for frase in FALLOS_SIN_REINTENTO:
		if mensaje.contains(frase):
			return true
	return false

## El aviso de la cuenta, cuando falta. Se pinta al abrir el panel para que el
## usuario se entere antes de escribir, y otra vez si intenta enviar. Lleva boton
## porque entrar es un viaje a los ajustes: sin el, el aviso manda a buscar la
## pestana a quien acaba de instalar el plugin.
func _avisarSiFaltaLaCuenta() -> void:
	if _cuentaLista():
		return
	if is_instance_valid(_avisoCuenta):
		return
	var burbuja := await _crearBurbujaMarkdown(false)
	if not is_instance_valid(burbuja):
		return
	burbuja.text = ("**Dotti needs an account.** Nothing is sent until you sign in.")
	var panel := PanelContainer.new()
	panel.name = "AvisoCuenta"
	var estilo := StyleBoxFlat.new()
	estilo.bg_color = Color(0.12, 0.13, 0.16, 0.75)
	estilo.border_color = Color(0.42, 0.45, 0.55, 0.5)
	estilo.border_width_left = 2
	estilo.corner_radius_top_left = 2
	estilo.corner_radius_top_right = 2
	estilo.corner_radius_bottom_left = 2
	estilo.corner_radius_bottom_right = 2
	estilo.content_margin_left = 10
	estilo.content_margin_right = 10
	estilo.content_margin_top = 8
	estilo.content_margin_bottom = 8
	panel.add_theme_stylebox_override("panel", estilo)
	var fila := HBoxContainer.new()
	fila.add_theme_constant_override("separation", 8)
	panel.add_child(fila)
	var texto := Label.new()
	texto.text = "Sign in from Settings > Account and approve the code."
	texto.add_theme_color_override("font_color", Color(0.72, 0.74, 0.8, 1.0))
	texto.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	texto.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	texto.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	fila.add_child(texto)
	var boton := ChatUIFactory.crearBotonTarjeta("Open Account", true)
	boton.pressed.connect(_irALaCuenta)
	fila.add_child(boton)
	contenedorMensajes.add_child(panel)
	_avisoCuenta = panel
	_animarEntradaTarjeta(panel)
	await _scrollAlFinal()

## Abre los ajustes en la pestana de la cuenta, y quita el aviso del chat: ya no
## hace falta que lo pida, esta delante.
func _irALaCuenta() -> void:
	abrirConfiguracion(true)
	if is_instance_valid(_avisoCuenta):
		_avisoCuenta.queue_free()
	_avisoCuenta = null

## El aviso del nucleo, cuando falta. Se pinta al abrir el panel para que el
## usuario se entere antes de escribir, y otra vez si intenta enviar.
func _avisarSiFaltaElNucleo() -> void:
	var aviso := Secretos.avisoDeLoQueFalta()
	if aviso == "":
		return
	await _avisoEnChat(aviso)

func _realizarPeticion() -> void:
	if _peticionCancelada:
		return
	# Sin nucleo nativo no hay textos del plugin, y sin textos no se manda nada.
	# Va antes que todo lo demas porque es lo unico que no gasta una peticion.
	if not _nucleoListo():
		_cortarPeticionAntesDeEnviar()
		await _mostrarBurbujaError(Secretos.avisoDeLoQueFalta())
		await _scrollAlFinal()
		return
	# Y sin cuenta tampoco: la pasarela de produccion contesta `auth_required`, asi
	# que esperar a mandarlo es gastar la peticion para que digan lo que ya se sabe.
	# La pasarela local del banco no pasa por aqui (ver Apis.exigeCuenta).
	if not _cuentaLista():
		_cortarPeticionAntesDeEnviar()
		_avisarSiFaltaLaCuenta()
		return
	# Antes de enviar: el modelo tiene que existir al otro lado, y si la
	# conversacion ya no cabe en su ventana, lo viejo se resume y deja de viajar.
	# Si no se puede compactar se envia igual, y el error de contexto del
	# proveedor (el proxy ya lo traduce) lo dira.
	if not await _modeloDisponible():
		return
	await _compactarSiHaceFalta()
	if _peticionCancelada:
		return
	if _usaHerramientasNativas():
		await _realizarPeticionNativa()
		return
	if _router:
		_router = LLMRouter.new()
		_router.inicializar(self, _apis)
		_router.respuesta_recibida.connect(_alRecibirContenido)
		_router.error_recibido.connect(_manejarError)
		if _router.has_signal("uso_recibido"):
			_router.uso_recibido.connect(_alRecibirUso)
	_router.realizarPeticion(_historialParaEnvio(), _proveedorIdActual())

func _alRecibirContenido(contenidoRespuesta: String) -> void:
	if _peticionCancelada:
		return
	if is_instance_valid(_burbujaEsperando):
		_burbujaEsperando.queue_free()
		_burbujaEsperando = null
	if is_instance_valid(_burbujaRazonamiento):
		_finalizarBurbujaRazonamiento(_burbujaRazonamiento, false)
		_burbujaRazonamiento = null
		_textoRazonamientoAcumulado = ""
	_esperandoRespuesta = false
	if is_instance_valid(_tarjetaReintentos) and _listaErrores.size() > 0:
		_finalizarTarjetaReintentos(true)
	_stallsConsecutivos = 0
	contenidoRespuesta = ChatParseador.limpiarNulosLideres(contenidoRespuesta.replace("<null>", ""))
	var entradaAsistente: Dictionary = {"role": "assistant", "content": contenidoRespuesta}
	historialConversacion.append(entradaAsistente)
	_guardarChatActual()
	await _procesarRespuestaCompleta(contenidoRespuesta)

# ---------------------------------------------------------------------------
# Camino NATIVO: function calling + streaming (proveedores tipo "openai").
# ---------------------------------------------------------------------------

func _herramientasParaEnvioNativo() -> Dictionary:
	return _herramientasActivas()

## Las herramientas que tiene el chat ahora mismo: las del agente activo y
## nunca mas que las del modo. Es la misma lista para las cuatro cosas que
## dependen de ella (el esquema nativo, el prompt del camino legacy, el
## despachador y lo que se le ofrece a un subagente), para que no se pueda
## ofrecer una cosa y ejecutar otra.
##
## En Plan mode se queda en Agentes.HERRAMIENTAS_SOLO_LECTURA: el modo no
## cambia el prompt, cambia lo que se puede tocar. Un agente activo recorta
## primero (el suyo es el recorte mas fino) y el modo recorta despues.
func _herramientasActivas() -> Dictionary:
	var lista := Agentes.filtrarHerramientas(_agente, _herramientas)
	if not _esModoPlan():
		return lista
	var soloLectura: Dictionary = {}
	for nombre in lista:
		if Agentes.HERRAMIENTAS_SOLO_LECTURA.has(str(nombre)):
			soloLectura[nombre] = lista[nombre]
	return soloLectura

func _liberarStreamer() -> void:
	if is_instance_valid(_streamer):
		_streamer.cancelar()
		_streamer.queue_free()
	_streamer = null

func _realizarPeticionNativa() -> void:
	var miSesion := _idSesion
	_liberarStreamer()
	var constructor := LLMRouter.new()
	constructor.inicializar(self, _apis)
	var peticion := constructor.construirPeticionOpenaiNativa(
		_historialParaEnvio(), _herramientasParaEnvioNativo(), true, _proveedorIdActual())
	if peticion.is_empty():
		_manejarError("Native tools not available for this provider.")
		return
	_textoStreamAcumulado = ""
	_prefijoStreamLimpio = false
	# La burbuja de respuesta NO se crea aqui: solo existe si llega contenido
	# real (creacion perezosa en _alTextoParcialNativo / _alRespuestaNativa).
	# Asi nunca se ven tarjetas vacias.
	_burbujaStream = null
	_creandoBurbujaStream = false
	# La burbuja de espera ("Processing") se mantiene viva durante el stream:
	# es el indicador de actividad mientras el texto va llegando. Se retira
	# al completar (_alRespuestaNativa) o fallar (_manejarError).
	_streamer = LLMNativo.new()
	_streamer.name = "LLMNativo"
	add_child(_streamer)
	_streamer.texto_parcial.connect(_alTextoParcialNativo)
	_streamer.razonamiento_parcial.connect(_alRazonamientoParcialNativo)
	_streamer.respuesta_completada.connect(_alRespuestaNativa)
	_streamer.error_recibido.connect(_alErrorNativo)
	_streamer.uso_recibido.connect(_alRecibirUso)
	_streamer.solicitar(str(peticion["url"]), peticion["cabeceras"], peticion["cuerpo"])

func _alTextoParcialNativo(delta: String) -> void:
	var miSesion := _idSesion
	if _peticionCancelada:
		return
	# El modelo fuga tokens "<null>": se matan en el delta, cuestan O(delta).
	delta = delta.replace("<null>", "")
	if delta == "":
		return
	_stallsConsecutivos = 0
	_textoStreamAcumulado += delta
	# Sanea la corrida lider de "null" que a veces emite el modelo. Solo se
	# revisa el prefijo (append-only): en cuanto el inicio queda decidido se
	# deja de revisar para no pagar O(n) por delta.
	if not _prefijoStreamLimpio:
		_textoStreamAcumulado = ChatParseador.limpiarNulosLideres(_textoStreamAcumulado)
		var cabeza := _textoStreamAcumulado.strip_edges()
		if cabeza.length() > 4:
			if not cabeza.begins_with("null"):
				_prefijoStreamLimpio = true
			elif not (cabeza.substr(4, 1) in " \t\r\n" or cabeza.substr(4, 4) == "null"):
				_prefijoStreamLimpio = true # Palabra real: nullable, nullify...
	# Si el texto va camino de ser la pregunta que el modelo manda como JSON, no se
	# pinta el crudo en el chat: al completarse se convierte en la tarjeta de
	# opciones. Lo acumulado se conserva, por si al final no era una pregunta.
	if ChatParseador.parecePreguntaJson(_textoStreamAcumulado):
		return
	# Creacion perezosa: la burbuja nace con el primer contenido real, nunca
	# antes. Si ya se esta creando, este delta ya quedo acumulado.
	if not is_instance_valid(_burbujaStream):
		if _creandoBurbujaStream:
			return
		_creandoBurbujaStream = true
		var nueva: MarkdownLabel = await _crearBurbujaMarkdown(false)
		_creandoBurbujaStream = false
		if _peticionCancelada or _idSesion != miSesion or not is_instance_valid(nueva):
			if is_instance_valid(nueva):
				var rz := _raizBurbuja(nueva)
				if is_instance_valid(rz):
					rz.queue_free()
				else:
					nueva.queue_free()
			return
		_burbujaStream = nueva
	_volcarStream(_burbujaStream, _textoStreamAcumulado)
	_seguirStreamAlFinal = true

func _alRazonamientoParcialNativo(delta: String) -> void:
	var miSesion := _idSesion
	delta = delta.replace("<null>", "")
	if _peticionCancelada or delta == "":
		return
	_stallsConsecutivos = 0
	if not is_instance_valid(_burbujaRazonamiento):
		if _creandoBurbujaRazon:
			_razonamientoPendienteNativo += delta
			return
		_creandoBurbujaRazon = true
		await _crearBurbujaRazonamiento()
		_creandoBurbujaRazon = false
		if _peticionCancelada or _idSesion != miSesion or not is_instance_valid(_streamer):
			if is_instance_valid(_burbujaRazonamiento):
				_finalizarBurbujaRazonamiento(_burbujaRazonamiento, true)
				_burbujaRazonamiento = null
			_textoRazonamientoAcumulado = ""
			_razonamientoPendienteNativo = ""
			return
		_textoRazonamientoAcumulado += _razonamientoPendienteNativo
		_razonamientoPendienteNativo = ""
	_textoRazonamientoAcumulado += delta
	# Texto plano y repartido en trozos: analizar markdown aqui congelaba el editor
	# con las trazas largas. El scroll lo sigue el flag de siempre (_process).
	_volcarRazonamiento(_burbujaRazonamiento, _textoRazonamientoAcumulado)
	_seguirStreamAlFinal = true

func _alRespuestaNativa(contenido: String, tool_calls: Array, razonamiento: String) -> void:
	var miSesion := _idSesion
	if _peticionCancelada:
		return
	_stallsConsecutivos = 0
	_liberarStreamer()
	if is_instance_valid(_burbujaEsperando):
		_burbujaEsperando.queue_free()
		_burbujaEsperando = null
	contenido = ChatParseador.limpiarNulosLideres(contenido.replace("<null>", ""))
	_textoStreamAcumulado = ChatParseador.limpiarNulosLideres(_textoStreamAcumulado.replace("<null>", ""))
	if is_instance_valid(_burbujaStream) and _textoStreamAcumulado.strip_edges() != "":
		_colapsarStream(_burbujaStream, _textoStreamAcumulado)
	if is_instance_valid(_burbujaRazonamiento):
		_finalizarBurbujaRazonamiento(_burbujaRazonamiento, false)
		_burbujaRazonamiento = null
		_textoRazonamientoAcumulado = ""
		_razonamientoPendienteNativo = ""
	_esperandoRespuesta = false
	if is_instance_valid(_tarjetaReintentos) and _listaErrores.size() > 0:
		_finalizarTarjetaReintentos(true)
	if not tool_calls.is_empty():
		if is_instance_valid(_burbujaStream) and _textoStreamAcumulado.strip_edges() == "":
			_burbujaStream.queue_free()
			_burbujaStream = null
		_textoStreamAcumulado = ""
		await _ejecutarHerramientasNativas(contenido, tool_calls, miSesion, razonamiento)
		return
	if contenido.strip_edges() == "" or _esContenidoToolCall(contenido):
		# Fallback legacy: el modelo respondio en formato JSON clasico.
		if is_instance_valid(_burbujaStream):
			_burbujaStream.queue_free()
			_burbujaStream = null
		_textoStreamAcumulado = ""
		var entradaLegacy: Dictionary = {"role": "assistant", "content": contenido}
		historialConversacion.append(entradaLegacy)
		_guardarChatActual()
		await _procesarRespuestaCompleta(contenido)
		return
	# Algunos modelos mandan la pregunta como TEXTO en vez de llamar a la
	# herramienta "Ask user". Se convierte en la tarjeta de opciones: si no, el
	# JSON crudo acababa pintado en el chat.
	var datosPregunta := _extraerPreguntaJson(contenido)
	if not datosPregunta.is_empty():
		await _resolverPreguntaEnTexto(datosPregunta, miSesion)
		return
	var entrada: Dictionary = {"role": "assistant", "content": contenido}
	historialConversacion.append(entrada)
	_guardarChatActual()
	# Si el texto llego sin deltas previos (o la creacion quedo a medias),
	# la burbuja nace aqui con contenido real. Jamas vacia.
	if not is_instance_valid(_burbujaStream) and contenido.strip_edges() != "":
		_burbujaStream = await _crearBurbujaMarkdown(false)
		if _peticionCancelada or _idSesion != miSesion:
			return
	if is_instance_valid(_burbujaStream):
		_burbujaStream.text = _textoStreamAcumulado if _textoStreamAcumulado.strip_edges() != "" else contenido
	_burbujaStream = null
	_bucleAgenteActivo = false
	_detenerSpinnerBoton()
	botonEnviar.disabled = false
	_ocultarEspera()
	await _scrollAlFinal()

## Convierte en tarjeta de opciones la pregunta que el modelo mando como texto en
## vez de llamar a la herramienta. Tira lo que se haya pintado del JSON crudo, deja
## la pregunta en el historial como turno del asistente, espera la eleccion y la
## manda como turno del usuario para que el bucle agente siga con ella.
func _resolverPreguntaEnTexto(datosPregunta: Dictionary, miSesion: int) -> void:
	var pregunta := String(datosPregunta.get("pregunta", "")).strip_edges()
	var opciones: Array = datosPregunta.get("opciones", [])
	if pregunta == "" or opciones.is_empty():
		return
	_descartarStreamCrudo()
	historialConversacion.append({"role": "assistant", "content": pregunta})
	_guardarChatActual()
	var elegida: String = await _preguntarUsuarioNativo(pregunta, opciones)
	_removerOpcionesRapidas()
	if elegida == "" or _peticionCancelada or _idSesion != miSesion:
		_bucleAgenteActivo = false
		_detenerSpinnerBoton()
		botonEnviar.disabled = false
		_ocultarEspera()
		return
	historialConversacion.append({"role": "user", "content": elegida})
	_guardarChatActual()
	# La eleccion es un turno del usuario y el chat debe ensenarla.
	var burbujaUsuario := await _crearBurbujaMarkdown(true)
	if is_instance_valid(burbujaUsuario):
		burbujaUsuario.text = elegida
	await _continuarBucleAgente()

## Tira la burbuja donde se pinto texto que no debia salir (el JSON de la
## pregunta): deja de ser stream y desaparece del chat.
func _descartarStreamCrudo() -> void:
	if is_instance_valid(_burbujaStream):
		var raiz := _raizBurbuja(_burbujaStream)
		if is_instance_valid(raiz):
			raiz.queue_free()
		else:
			_burbujaStream.queue_free()
	_burbujaStream = null
	_textoStreamAcumulado = ""
	_creandoBurbujaStream = false
	if is_instance_valid(_burbujaEsperando):
		_burbujaEsperando.queue_free()
		_burbujaEsperando = null

func _alErrorNativo(mensaje: String) -> void:
	_liberarStreamer()
	# Cierra la razonamiento al momento: si no, queda el spinner girando.
	if is_instance_valid(_burbujaRazonamiento):
		_finalizarBurbujaRazonamiento(_burbujaRazonamiento, true)
		_burbujaRazonamiento = null
		_textoRazonamientoAcumulado = ""
		_razonamientoPendienteNativo = ""
	# Conserva respuesta parcial si la hay (igual que al cancelar); el error
	# se muestra aparte con _mostrarBurbujaError.
	if is_instance_valid(_burbujaStream):
		_colapsarStream(_burbujaStream, _textoStreamAcumulado)
	if is_instance_valid(_burbujaStream) and _textoStreamAcumulado.strip_edges() == "":
		_burbujaStream.queue_free()
		_burbujaStream = null
	# El streamer ya termino. La burbuja parcial, si existe, no debe volver a
	# recibir deltas de una solicitud posterior.
	_burbujaStream = null
	_textoStreamAcumulado = ""
	_manejarError(mensaje)

func _ejecutarHerramientasNativas(contenido: String, tool_calls: Array, miSesion: int, razonamiento: String = "") -> void:
	var plan: Array = []
	var n := 0
	for tc in tool_calls:
		if typeof(tc) != TYPE_DICTIONARY:
			continue
		n += 1
		var nombreOriginal := str(tc.get("nombre", ""))
		var llamada := {
			"id": str(tc.get("id", "")),
			"nombre": _resolverNombreHerramienta(nombreOriginal),
			"args": tc.get("args", {}),
			"original": nombreOriginal,
		}
		if typeof(llamada["args"]) != TYPE_DICTIONARY:
			llamada["args"] = {}
		if llamada["id"] == "":
			llamada["id"] = "call_nativo_%d" % n
		plan.append(llamada)
	var tcs_api: Array = []
	for llamada in plan:
		tcs_api.append({
			"id": llamada["id"],
			"type": "function",
			"function": {"name": llamada["original"], "arguments": JSON.stringify(llamada["args"])},
		})
	var entradaNativa := {"role": "assistant", "content": contenido, "tool_calls": tcs_api}
	# Se guarda la traza real cuando existe. Si el modelo no devolvio ninguna, el
	# turno se guarda sin el campo y LLMNativo.normalizar_historial lo degrada a
	# texto al enviar: el upstream exige la traza en modo thinking y rechaza la
	# conversacion entera si un turno con tool_calls no la trae.
	if razonamiento.strip_edges() != "":
		entradaNativa["reasoning_content"] = razonamiento
	historialConversacion.append(entradaNativa)
	# Imagenes que devuelvan las herramientas de este grupo (ver o capturar). No
	# pueden ir dentro de la entrada "tool" (esa solo admite texto), asi que se
	# apuntan aqui y se mandan en un mensaje de usuario pegado al final del grupo:
	# el upstream exige que los resultados vayan inmediatamente detras de su llamada.
	var imagenesDelGrupo: Array = []
	for indice in range(plan.size()):
		var llamada: Dictionary = plan[indice]
		if _peticionCancelada or _idSesion != miSesion:
			_cerrarLlamadasPendientes(plan, indice)
			return
		if llamada["nombre"] == "":
			var msgDesconocida := "ERROR: Unknown tool \"%s\". Available: %s" % [llamada["original"], ", ".join(_herramientas.keys())]
			await _mostrarBurbujaError(msgDesconocida)
			historialConversacion.append({"role": "tool", "tool_call_id": llamada["id"], "content": msgDesconocida})
			continue
		var res := await _ejecutarUnaHerramienta(llamada["nombre"], llamada["args"])
		if _peticionCancelada or _idSesion != miSesion:
			_cerrarLlamadasPendientes(plan, indice)
			return
		if bool(res.get("cancelado", false)):
			_cerrarLlamadasPendientes(plan, indice)
			return
		var salida := str(res.get("output", ""))
		if bool(res.get("denegada", false)):
			salida = "ERROR: The user denied permission to execute this tool. Do not retry it. " + salida
		historialConversacion.append({"role": "tool", "tool_call_id": llamada["id"], "content": salida})
		imagenesDelGrupo.append_array(res.get("imagenes", []))
	_anexarImagenesDelGrupo(imagenesDelGrupo)
	_guardarChatActual()
	await _continuarBucleAgente()


## Cuelga del final del grupo de herramientas el mensaje que lleva las imagenes que
## devolvieron. Con el historial sin imagenes no se escribe nada: la mayoria de los
## grupos no devuelve ninguna y un mensaje vacio de mas solo gasta tokens.
func _anexarImagenesDelGrupo(imagenes: Array) -> void:
	if imagenes.is_empty():
		return
	historialConversacion.append({
		"role": "user",
		"content": MARCA_IMAGENES_ADJUNTAS,
		"imagenes": imagenes,
	})

## El grupo de llamadas ya esta escrito en el historial, asi que cada una tiene
## que tener su resultado detras: las que no llegaron a ejecutarse (el usuario
## corto con Escape, o el editor se cerro) se cierran con un resultado textual.
## Si no, al reabrir el chat la peticion entera la rechaza el upstream:
## "messages.N: `tool_use` ids were found without `tool_result` blocks".
func _cerrarLlamadasPendientes(plan: Array, desde: int) -> void:
	for i in range(desde, plan.size()):
		var llamada: Dictionary = plan[i]
		historialConversacion.append({
			"role": "tool",
			"tool_call_id": str(llamada.get("id", "")),
			"content": LLMNativo.TOOL_SIN_RESULTADO,
		})
	_guardarChatActual()

func _manejarError(mensaje: String) -> void:
	if mensaje.strip_edges() == "":
		mensaje = "Unknown error from the provider."
	var miSesion := _idSesion
	if is_instance_valid(_burbujaEsperando):
		_burbujaEsperando.queue_free()
		_burbujaEsperando = null
	_esperandoRespuesta = false
	if _peticionCancelada or _idSesion != miSesion:
		_detenerSpinnerBoton()
		botonEnviar.disabled = false
		_bucleAgenteActivo = false
		_ocultarEspera()
		if is_instance_valid(_tarjetaReintentos):
			_finalizarTarjetaReintentos(false)
		return
	# Un fallo de cuenta no merece cinco intentos: sin cuenta o con el token
	# revocado, la pasarela no va a cambiar de opinion, y cada vuelta alarga el
	# mismo aviso. Se cae directo al final, donde ademas se pide entrar.
	var falloDeCuenta := _esFalloDeCuenta(mensaje)
	if falloDeCuenta:
		_contadorReintentos = MAX_REINTENTOS
		_stallsConsecutivos = 0
	# Un stall (upstream mudo) no merece 5 reintentos de 45s: al segundo
	# consecutivo se falla con un mensaje accionable. Otro error distinto
	# demuestra que el upstream responde y rompe la racha.
	elif mensaje.begins_with("Request stalled"):
		_stallsConsecutivos += 1
		if _stallsConsecutivos >= 2:
			_contadorReintentos = MAX_REINTENTOS
			mensaje += " The provider went silent twice in a row. Try English or a shorter prompt."
	else:
		_stallsConsecutivos = 0
	if _contadorReintentos < MAX_REINTENTOS:
		_contadorReintentos += 1
		await _crearOActualizarTarjetaReintentos(mensaje, _contadorReintentos)
		_reintentando = true
		var timer := get_tree().create_timer(ESPERA_REINTENTO)
		await timer.timeout
		_reintentando = false
		if _peticionCancelada or _idSesion != miSesion:
			_detenerSpinnerBoton()
			botonEnviar.disabled = false
			_bucleAgenteActivo = false
			_ocultarEspera()
			if is_instance_valid(_tarjetaReintentos):
				_finalizarTarjetaReintentos(false)
			return
		_esperandoRespuesta = true
		_burbujaEsperando = await _crearBurbujaEspera()
		_realizarPeticion()
	else:
		_bucleAgenteActivo = false
		_detenerSpinnerBoton()
		botonEnviar.disabled = false
		_finalizarTarjetaReintentos(false)
		_ocultarEspera()
		if is_instance_valid(_burbujaRazonamiento):
			_finalizarBurbujaRazonamiento(_burbujaRazonamiento, true)
			_burbujaRazonamiento = null
			_textoRazonamientoAcumulado = ""
			_razonamientoPendienteNativo = ""
			_creandoBurbujaRazon = false
		await _mostrarBurbujaError(mensaje)
		await _scrollAlFinal()
		# El error dice lo que paso; el aviso dice donde se arregla, y lleva el
		# boton. Solo cuando el fallo fue de cuenta, que es lo unico que el usuario
		# puede resolver desde aqui.
		if falloDeCuenta:
			_avisarSiFaltaLaCuenta()

func _normalizarNombreHerramienta(nombre: String) -> String:
	return ChatParseador.normalizarNombreHerramienta(nombre)

func _resolverNombreHerramienta(nombre: String) -> String:
	return ChatParseador.resolverNombreHerramienta(nombre, _herramientas)

func _extraerCandidatosJson(contenido: String) -> Array[String]:
	return ChatParseador.extraerCandidatosJson(contenido)

func _detectarToolCall(contenido: String) -> String:
	return ChatParseador.detectarToolCall(contenido, _herramientas)

func _esContenidoToolCall(contenido: String) -> bool:
	return ChatParseador.esContenidoToolCall(contenido, _herramientas)

func _detectarIntentoToolInvalido(contenido: String) -> String:
	return ChatParseador.detectarIntentoToolInvalido(contenido, _herramientas)

func _procesarRespuestaCompleta(contenido: String) -> void:
	var jsonToolCall := _detectarToolCall(contenido)
	if jsonToolCall != "":
		var j := JSON.new()
		j.parse(jsonToolCall)
		var d = j.get_data()
		var nombreOriginal: String = d.get("tool", "")
		var nombreResuelto: String = _resolverNombreHerramienta(nombreOriginal)
		var args: Dictionary = d.get("args", {})
		# El titulo viaja AL LADO de "args" en el JSON (asi lo pide el prompt), pero
		# aqui se mete dentro para que la tarjeta y el historial lo traten igual que
		# en el camino nativo, donde llega como un parametro mas.
		var tituloLegacy := str(d.get("titulo", "")).strip_edges()
		if tituloLegacy != "" and not args.has("titulo"):
			args["titulo"] = tituloLegacy
		await _ejecutarHerramienta(nombreResuelto, args)
		return
	var nombreInvalido := _detectarIntentoToolInvalido(contenido)
	if nombreInvalido != "":
		_bucleAgenteActivo = false
		_detenerSpinnerBoton()
		botonEnviar.disabled = false
		await _mostrarBurbujaError("Unknown tool: \"%s\". Available: %s" % [nombreInvalido, ", ".join(_herramientas.keys())])
		_ocultarEspera()
		return
	_bucleAgenteActivo = false
	_detenerSpinnerBoton()
	botonEnviar.disabled = false
	await _mostrarTextoCompleto(contenido)
	_ocultarEspera()

func _mostrarTextoCompleto(contenido: String) -> void:
	var datosPregunta := _extraerPreguntaJson(contenido)
	if not datosPregunta.is_empty():
		await _mostrarTarjetaPregunta(String(datosPregunta.get("pregunta", "")), datosPregunta.get("opciones", []))
		return
	if contenido.length() > UMBRAL_TEXTO_CHUNK:
		await _mostrarTextoEnChunks(contenido)
	else:
		var burbuja := await _crearBurbujaMarkdown(false)
		burbuja.text = contenido
	await _scrollAlFinal()

func _mostrarTextoEnChunks(contenido: String) -> void:
	var burbuja := await _crearBurbujaMarkdown(false)
	var total := contenido.length()
	var cursor := 0
	var acumulado := ""
	var miToken := _idEscritura
	while cursor < total:
		if _peticionCancelada or miToken != _idEscritura:
			return
		var fin: int = mini(cursor + TAMANO_CHUNK_TEXTO, total)
		var siguiente := _buscarCorteSeguro(contenido, cursor, fin, total)
		acumulado = contenido.substr(0, siguiente)
		if is_instance_valid(burbuja):
			burbuja.text = acumulado
		cursor = siguiente
		if cursor < total:
			await get_tree().process_frame

func _buscarCorteSeguro(texto: String, ini: int, fin: int, total: int) -> int:
	return ChatParseador.buscarCorteSeguro(texto, ini, fin, total)

func _mostrarBurbujaError(mensaje: String) -> void:
	var panel := PanelContainer.new()
	panel.name = "BurbujaError"
	panel.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	var estilo := StyleBoxFlat.new()
	estilo.bg_color = Color(0.15, 0.1, 0.1, 1.0)
	estilo.border_color = Color(0.6, 0.4, 0.4, 0.6)
	estilo.border_width_left = 3
	estilo.content_margin_left = 12
	estilo.content_margin_right = 12
	estilo.content_margin_top = 10
	estilo.content_margin_bottom = 10
	estilo.corner_radius_top_left = 2
	estilo.corner_radius_top_right = 2
	estilo.corner_radius_bottom_left = 2
	estilo.corner_radius_bottom_right = 2
	panel.add_theme_stylebox_override("panel", estilo)
	var hbox := HBoxContainer.new()
	hbox.add_theme_constant_override("separation", 8)
	hbox.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	panel.add_child(hbox)
	var iconoError := Label.new()
	iconoError.text = "!"
	iconoError.add_theme_color_override("font_color", Color(0.7, 0.5, 0.5, 1.0))
	hbox.add_child(iconoError)
	var etiqueta := Label.new()
	etiqueta.text = mensaje
	etiqueta.add_theme_color_override("font_color", Color(0.7, 0.55, 0.55, 1.0))
	etiqueta.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	etiqueta.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	hbox.add_child(etiqueta)
	_contenedorActivoMensajes().add_child(panel)
	_moverEsperaAlFinal()
	await get_tree().process_frame
	_animarEntradaBurbuja(panel)
	_animarError(panel)
	await _scrollAlFinal()

# ---------------------------------------------------------------------------
# Actualizaciones (Paso 5). Una vez al dia, y solo en el editor, se mira si hay
# version nueva; si la hay y el usuario no la habia rechazado, se pinta una
# tarjeta con lo que trae y dos botones. Nada se instala sin que el usuario lo
# pulse, y lo que se instala pasa por el hash del manifiesto
# (ChatActualizaciones, en Chat/Updates.gd).
# ---------------------------------------------------------------------------


## La comprobacion del arranque. Los fallos se callan a proposito: el usuario no
## pidio nada, asi que un problema de red no tiene por que aparecer en el chat.
## Se entera cuando la pide desde Ajustes, que es donde si se le cuenta.
func _comprobarActualizacionesAlArrancar() -> void:
	if not OS.has_feature("editor") or not ChatActualizaciones.tocaComprobar():
		return
	var info := await ChatActualizaciones.comprobar(self)
	if not bool(info.get("ok", false)) or not bool(info.get("hay_nueva", false)):
		return
	if ChatActualizaciones.yaIgnorada(str(info.get("version", ""))):
		return
	_mostrarTarjetaActualizacion(info)


## La tarjeta. Se pinta al final del chat y no entra en el historial: es un aviso
## del panel, no un turno de conversacion.
func _mostrarTarjetaActualizacion(info: Dictionary) -> void:
	if not is_instance_valid(contenedorMensajes):
		return
	_info_actualizacion = info

	var panel := PanelContainer.new()
	panel.name = "TarjetaActualizacion"
	panel.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	var estilo := StyleBoxFlat.new()
	estilo.bg_color = Color(0.13, 0.13, 0.13, 1.0)
	estilo.border_color = ChatEstilos.COLOR_ACENTO_SUAVE
	estilo.border_width_left = 2
	estilo.border_width_top = 2
	estilo.border_width_right = 2
	estilo.border_width_bottom = 2
	estilo.content_margin_left = 12
	estilo.content_margin_right = 12
	estilo.content_margin_top = 10
	estilo.content_margin_bottom = 10
	estilo.corner_radius_top_left = 2
	estilo.corner_radius_top_right = 2
	estilo.corner_radius_bottom_left = 2
	estilo.corner_radius_bottom_right = 2
	panel.add_theme_stylebox_override("panel", estilo)

	_tarjeta_actualizacion = VBoxContainer.new()
	_tarjeta_actualizacion.add_theme_constant_override("separation", 8)
	panel.add_child(_tarjeta_actualizacion)

	_pintarTarjetaActualizacion()
	_contenedorActivoMensajes().add_child(panel)
	_moverEsperaAlFinal()
	await get_tree().process_frame
	_animarEntradaBurbuja(panel)
	await _scrollAlFinal()


## El cuerpo de la tarjeta, que cambia con lo que va pasando: se ofrece, se esta
## bajando, fallo, o quedo instalada y falta reiniciar. Se rehace entero en cada
## cambio porque son cuatro estados y no merece la pena ir tocando hijos.
func _pintarTarjetaActualizacion() -> void:
	if not is_instance_valid(_tarjeta_actualizacion):
		return
	for hijo in _tarjeta_actualizacion.get_children():
		_tarjeta_actualizacion.remove_child(hijo)
		hijo.queue_free()

	# Instalada: el editor sigue con el codigo viejo cargado, asi que lo que
	# queda por hacer es reiniciarlo, y eso es lo que dice la tarjeta.
	if _actualizacion_instalada != "":
		_tarjeta_actualizacion.add_child(_etiquetaActualizacion(
			"Dotti %s is installed. Restart the editor so the new code loads." % _actualizacion_instalada,
			ChatEstilos.COLOR_ESTADO_OK))
		if _respaldo_actualizacion != "":
			_tarjeta_actualizacion.add_child(_etiquetaActualizacion(
				"Your previous version is backed up in %s." % _respaldo_actualizacion,
				ChatEstilos.COLOR_TEXTO_TENUE))
		return

	if _info_actualizacion.is_empty():
		_tarjeta_actualizacion.add_child(_etiquetaActualizacion(
			"Not now. That version will not be offered again; a newer one still will.",
			ChatEstilos.COLOR_TEXTO_TENUE))
		return

	var version := str(_info_actualizacion.get("version", ""))
	var titulo := Label.new()
	titulo.text = "Dotti %s is available" % version
	titulo.add_theme_color_override("font_color", ChatEstilos.COLOR_TEXTO_PRIMARIO)
	titulo.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_tarjeta_actualizacion.add_child(titulo)

	var notas := str(_info_actualizacion.get("notas", ""))
	if notas != "":
		_tarjeta_actualizacion.add_child(_etiquetaActualizacion(notas, ChatEstilos.COLOR_TEXTO_SECUNDARIO))

	if bool(_info_actualizacion.get("obligatoria", false)):
		_tarjeta_actualizacion.add_child(_etiquetaActualizacion(
			"This one is marked as required: the version you have is no longer served.",
			ChatEstilos.COLOR_ESTADO_WARN))

	var fila := HBoxContainer.new()
	fila.add_theme_constant_override("separation", 8)
	var btn_instalar := ChatUIFactory.crearBotonTarjeta("Installing..." if _instalando_actualizacion else "Install", true)
	btn_instalar.disabled = _instalando_actualizacion
	btn_instalar.pressed.connect(_instalarActualizacionDesdeElChat)
	fila.add_child(btn_instalar)
	var btn_luego := ChatUIFactory.crearBotonTarjeta("Not now", false)
	btn_luego.disabled = _instalando_actualizacion
	btn_luego.pressed.connect(_noInstalarActualizacionDesdeElChat)
	fila.add_child(btn_luego)
	_tarjeta_actualizacion.add_child(fila)

	if _error_actualizacion != "":
		_tarjeta_actualizacion.add_child(_etiquetaActualizacion(_error_actualizacion, ChatEstilos.COLOR_ESTADO_ERR))


## Una linea de texto dentro de la tarjeta.
func _etiquetaActualizacion(texto: String, color: Color) -> Label:
	var etiqueta := Label.new()
	etiqueta.text = texto
	etiqueta.add_theme_color_override("font_color", color)
	etiqueta.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	etiqueta.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	return etiqueta


## Instalar desde el chat: se baja, se comprueba el hash y se descomprime encima
## del addon. Con el boton apagado mientras dura, que si no se puede pulsar dos
## veces y bajar el zip dos veces a la vez.
func _instalarActualizacionDesdeElChat() -> void:
	if _instalando_actualizacion or _info_actualizacion.is_empty():
		return
	_instalando_actualizacion = true
	_error_actualizacion = ""
	_pintarTarjetaActualizacion()
	await _scrollAlFinal()

	var version := str(_info_actualizacion.get("version", ""))
	var resultado := await ChatActualizaciones.instalar(self, _info_actualizacion)
	_instalando_actualizacion = false
	if not bool(resultado.get("ok", false)):
		_error_actualizacion = str(resultado.get("error", ""))
		_pintarTarjetaActualizacion()
		await _scrollAlFinal()
		return
	_actualizacion_instalada = version
	_respaldo_actualizacion = str(resultado.get("respaldo", ""))
	_info_actualizacion = {}
	_pintarTarjetaActualizacion()
	await _scrollAlFinal()


## Decir que no: se apunta la version para no volver a ofrecerla. No se apaga la
## comprobacion: una version mas nueva se seguira ofreciendo.
func _noInstalarActualizacionDesdeElChat() -> void:
	var version := str(_info_actualizacion.get("version", ""))
	if version == "":
		return
	ChatActualizaciones.ignorar(version)
	_info_actualizacion = {}
	_pintarTarjetaActualizacion()


func _ejecutarHerramienta(nombre: String, args: Dictionary) -> void:
	var miSesion := _idSesion
	var res := await _ejecutarUnaHerramienta(nombre, args)
	if _peticionCancelada or _idSesion != miSesion:
		return
	if bool(res.get("cancelado", false)):
		return
	var mensajeResultado: String
	if bool(res.get("crudo", false)):
		mensajeResultado = str(res.get("output", ""))
	elif bool(res.get("denegada", false)):
		mensajeResultado = "[TOOL_RESULT: %s]\nERROR: The user denied permission to execute this tool. Do not retry it. Inform the user that this action requires permission and continue with alternative approaches or ask what they want to do instead." % nombre
	else:
		mensajeResultado = "[TOOL_RESULT: %s]\n%s" % [nombre, str(res.get("output", ""))]
	# Las imagenes que devuelva la herramienta viajan pegadas a este mismo mensaje:
	# el camino legacy no tiene donde mas ponerlas, y Adjuntos ya sabe convertirlas
	# en partes image_url de una entrada de usuario.
	var entradaResultado: Dictionary = {"role": "user", "content": "[HIDDEN_RESULT]" + mensajeResultado}
	var imagenes := res.get("imagenes", [])
	if typeof(imagenes) == TYPE_ARRAY and not (imagenes as Array).is_empty():
		entradaResultado["imagenes"] = imagenes
	historialConversacion.append(entradaResultado)
	await get_tree().create_timer(tiempoHerramienta).timeout
	if _peticionCancelada or _idSesion != miSesion:
		return
	await _continuarBucleAgente()

## Ejecuta UNA herramienta (tarjeta UI + permiso + llamada) sin tocar el
## historial ni continuar el bucle. Retorna {success, output, denegada,
## cancelado, crudo}. Lo usan el camino legacy y el nativo.
func _ejecutarUnaHerramienta(nombre: String, args: Dictionary) -> Dictionary:
	var miSesion := _idSesion
	var tarjeta: Control = await _crearTarjetaHerramienta(nombre, args)
	_mensajeHerramientaActual = tarjeta
	# Un "Run agent" abre su hilo: lo que el subagente haga por dentro se pinta
	# ahi, colgado de esta tarjeta, y no suelto en el chat.
	var esSubagente := nombre == ChatSubagente.NOMBRE_HERRAMIENTA
	var hilo: VBoxContainer = null
	if esSubagente:
		hilo = _abrirHiloSubagente(tarjeta)
	if _requierePermisoParaHerramienta(nombre):
		var permitido: bool = await _solicitarPermisoEnTarjeta(tarjeta, nombre)
		if _peticionCancelada or _idSesion != miSesion:
			_cerrarHiloSubagente(hilo)
			return {"success": false, "output": "Cancelled", "denegada": false, "cancelado": true, "crudo": false}
		if not permitido:
			var mensajeDenegado := "Permission denied by user"
			await _actualizarTarjetaHerramientaDenegado(tarjeta, mensajeDenegado)
			_cerrarHiloSubagente(hilo)
			return {"success": false, "output": mensajeDenegado, "denegada": true, "cancelado": false, "crudo": false}
	if tiempoHerramienta < 0 : tiempoHerramienta = 1
	await get_tree().create_timer(tiempoHerramienta).timeout
	if _peticionCancelada or _idSesion != miSesion:
		_cerrarHiloSubagente(hilo)
		return {"success": false, "output": "Cancelled", "denegada": false, "cancelado": true, "crudo": false}
	# El titulo es un recado para la tarjeta, no un parametro de la herramienta:
	# se quita antes de llamarla para que no lo vea ni lo valide.
	var argsLlamada := args.duplicate()
	argsLlamada.erase("titulo")
	# Un agente con lista corta de herramientas puede recibir la llamada de una que
	# no tiene (historial viejo, o el modelo se la inventa), y en Plan mode pasa lo
	# mismo con todo lo que escriba: se contesta con el motivo sin ejecutarla.
	if not _herramientasActivas().has(nombre):
		var mensajeFuera := "Tool not available for the active agent: " + nombre
		if _esModoPlan():
			mensajeFuera = "Tool not available in Plan mode: " + nombre
		await _actualizarTarjetaHerramientaDenegado(tarjeta, mensajeFuera)
		_cerrarHiloSubagente(hilo)
		return {"success": false, "output": mensajeFuera, "denegada": true, "cancelado": false, "crudo": false}
	var herramienta = _herramientas[nombre]
	# La tarjeta del subagente ya no corre: lo que venga de aqui en adelante (su
	# informe) es de la tarjeta, no del hilo.
	var resultado: Dictionary = await herramienta["funcion"].call(argsLlamada)
	_cerrarHiloSubagente(hilo)
	if _peticionCancelada or _idSesion != miSesion:
		return {"success": false, "output": "Cancelled", "denegada": false, "cancelado": true, "crudo": false}
	var exito := resultado.get("success", false)
	var output := resultado.get("output", "")
	await _actualizarTarjetaHerramienta(tarjeta, exito, output, _imagenesDeResultado(resultado))
	return {"success": exito, "output": output, "denegada": false, "cancelado": false, "crudo": false,
		"imagenes": _imagenesDeResultado(resultado)}


## Imagenes que devolvio una herramienta (rutas de user://), listas para viajar
## como parte image_url y para pintarse como miniatura. Casi ninguna devuelve.
func _imagenesDeResultado(resultado: Dictionary) -> Array:
	var crudo: Variant = resultado.get("imagenes", [])
	if typeof(crudo) != TYPE_ARRAY:
		return []
	var limpias: Array = []
	for ruta in crudo as Array:
		var r := str(ruta)
		if r != "" and FileAccess.file_exists(r):
			limpias.append(r)
	return limpias

func _solicitarPermisoEnTarjeta(tarjeta: Control, nombre: String) -> bool:
	if not is_instance_valid(tarjeta):
		return false
	# El aviso vive en su propio contenedor, siempre visible: dentro del acordeon
	# quedaria oculto con la tarjeta plegada y nadie veria el Allow/Deny.
	var detailsVbox := tarjeta.find_child("PermisoContainer", true, false) as VBoxContainer
	if detailsVbox == null:
		detailsVbox = tarjeta.find_child("DetailsContainer", true, false) as VBoxContainer
		if detailsVbox != null:
			detailsVbox.visible = true
	if detailsVbox == null:
		return true
	var permisoPanel := PanelContainer.new()
	permisoPanel.name = "PermisoPanel"
	permisoPanel.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	var permisoEstilo := StyleBoxFlat.new()
	permisoEstilo.bg_color = Color(0.14, 0.12, 0.08, 0.75)
	permisoEstilo.border_color = Color(0.55, 0.45, 0.25, 0.5)
	permisoEstilo.border_width_left = 2
	permisoEstilo.corner_radius_top_left = 2
	permisoEstilo.corner_radius_top_right = 2
	permisoEstilo.corner_radius_bottom_left = 2
	permisoEstilo.corner_radius_bottom_right = 2
	permisoEstilo.content_margin_left = 10
	permisoEstilo.content_margin_right = 10
	permisoEstilo.content_margin_top = 8
	permisoEstilo.content_margin_bottom = 8
	permisoPanel.add_theme_stylebox_override("panel", permisoEstilo)
	detailsVbox.add_child(permisoPanel)
	var permisoVbox := VBoxContainer.new()
	permisoVbox.add_theme_constant_override("separation", 6)
	permisoPanel.add_child(permisoVbox)
	var pregunta := Label.new()
	pregunta.text = "Allow Dotti to run '%s'?" % nombre
	pregunta.add_theme_color_override("font_color", Color(0.8, 0.72, 0.55, 1.0))
	pregunta.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	pregunta.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	permisoVbox.add_child(pregunta)
	var botonera := HBoxContainer.new()
	botonera.add_theme_constant_override("separation", 6)
	botonera.alignment = BoxContainer.ALIGNMENT_END
	botonera.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	permisoVbox.add_child(botonera)
	var btnDenegar := ChatUIFactory.crearBotonPermiso("Deny", false)
	var btnPermitir := ChatUIFactory.crearBotonPermiso("Allow", true)
	botonera.add_child(btnDenegar)
	botonera.add_child(btnPermitir)
	var resultado := [null]
	btnPermitir.pressed.connect(func(): resultado[0] = true)
	btnDenegar.pressed.connect(func(): resultado[0] = false)
	_animarEntradaTarjeta(permisoPanel)
	await _scrollAlFinal()
	while resultado[0] == null:
		if _peticionCancelada:
			resultado[0] = false
			break
		await get_tree().process_frame
	if is_instance_valid(permisoPanel):
		permisoPanel.queue_free()
	return bool(resultado[0])

func _actualizarTarjetaHerramientaDenegado(tarjeta: Control, mensaje: String) -> void:
	if not is_instance_valid(tarjeta):
		return
	tarjeta.set_meta("terminada", true)
	_cerrarSpinnerFila(tarjeta, GLIFO_DENEGADA, COLOR_ESTADO_WARN)
	_fijarEstadoHerramienta(tarjeta, "denied", Color(0.78, 0.68, 0.45, 0.95))
	_fijarDetalleHerramienta(tarjeta, mensaje)
	await _scrollAlFinal()

func _continuarBucleAgente() -> void:
	if _peticionCancelada:
		_bucleAgenteActivo = false
		_detenerSpinnerBoton()
		botonEnviar.disabled = false
		_ocultarEspera()
		return
	_contadorReintentos = 0
	_esperandoRespuesta = true
	_burbujaEsperando = await _crearBurbujaEspera()
	_realizarPeticion()

func _construirPantallaBienvenida() -> Control:
	var contenedor := CenterContainer.new()
	contenedor.name = "PantallaBienvenida"
	contenedor.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	contenedor.size_flags_vertical = Control.SIZE_EXPAND_FILL

	var marco := MarginContainer.new()
	marco.add_theme_constant_override("margin_left", 20)
	marco.add_theme_constant_override("margin_right", 20)
	marco.add_theme_constant_override("margin_top", 40)
	marco.add_theme_constant_override("margin_bottom", 40)
	contenedor.add_child(marco)

	var vbox := VBoxContainer.new()
	vbox.add_theme_constant_override("separation", 14)
	vbox.alignment = BoxContainer.ALIGNMENT_CENTER
	marco.add_child(vbox)

	var separacion := Control.new()
	separacion.custom_minimum_size = Vector2(0, 6)
	vbox.add_child(separacion)

	var separacion2 := Control.new()
	separacion2.custom_minimum_size = Vector2(0,1)
	vbox.add_child(separacion2)
	return contenedor

func _actualizarPantallaBienvenida() -> void:
	if not is_instance_valid(_pantallaBienvenida):
		return
	var sub := _pantallaBienvenida.find_child("SubtituloBienvenida", true, false) as Label

func _mostrarPantallaBienvenida(visible_: bool) -> void:
	if is_instance_valid(_pantallaBienvenida):
		_pantallaBienvenida.visible = visible_

func _alPulsarAgregarContexto() -> void:
	if not is_instance_valid(_dialogoArchivos):
		_dialogoArchivos = FileDialog.new()
		_dialogoArchivos.title = "Select files for context"
		_dialogoArchivos.file_mode = FileDialog.FILE_MODE_OPEN_FILES
		_dialogoArchivos.access = FileDialog.ACCESS_FILESYSTEM
		_dialogoArchivos.use_native_dialog = true
		_dialogoArchivos.files_selected.connect(_alSeleccionarArchivosContexto)
		_dialogoArchivos.file_selected.connect(func(ruta: String):
			var arr := PackedStringArray()
			arr.append(ruta)
			_alSeleccionarArchivosContexto(arr)
		)
		add_child(_dialogoArchivos)
	_dialogoArchivos.popup_centered_ratio(0.7)

func _alSeleccionarArchivosContexto(rutas: PackedStringArray) -> void:
	for ruta in rutas:
		_adjuntarRuta(ruta)

## Adjunta un archivo al mensaje. Las imagenes se copian a user:// (Adjuntos) y
## viajan al modelo como imagen; el resto de archivos se pegan como texto al
## enviar. Devuelve false si no habia nada que adjuntar.
func _adjuntarRuta(ruta: String, nombreMostrado: String = "") -> bool:
	var preparado := Adjuntos.preparar(ruta, nombreMostrado)
	if preparado.is_empty():
		return false
	for a in _archivosContexto:
		if a.get("ruta", "") == preparado["ruta"]:
			return true
	_archivosContexto.append(preparado)
	_refrescarChipsContexto()
	return true

## Ctrl+V: primero la imagen del portapapeles, despues la ruta de un archivo
## copiado desde el explorador (que llega como texto). Devuelve true si consumio
## el pegado; false deja que el campo pegue el texto normalmente.
func _adjuntarDesdePortapapeles() -> bool:
	var pegada := Adjuntos.delPortapapeles()
	if pegada != "":
		_adjuntarRuta(pegada, "pasted image." + pegada.get_extension())
		return true
	var texto := Adjuntos.delPortapapelesTexto().strip_edges()
	if Adjuntos.esRutaDeArchivo(texto):
		return _adjuntarRuta(texto)
	return false

func _refrescarChipsContexto() -> void:
	if not is_instance_valid(_contenedorChipsContexto):
		return
	for hijo in _contenedorChipsContexto.get_children():
		hijo.queue_free()
	for i in range(_archivosContexto.size()):
		var archivo = _archivosContexto[i]
		var ayuda := "Sent to the model as text"
		if bool(archivo.get("imagen", false)):
			ayuda = "Sent to the model as an image"
		var chip := ChatUIFactory.crearChipArchivo(archivo.get("nombre", ""), i, _eliminarArchivoContexto, ayuda)
		_contenedorChipsContexto.add_child(chip)
	if is_instance_valid(_filaContexto):
		_filaContexto.visible = _archivosContexto.size() > 0

func _eliminarArchivoContexto(indice: int) -> void:
	if indice < 0 or indice >= _archivosContexto.size():
		return
	_archivosContexto.remove_at(indice)
	_refrescarChipsContexto()

func _limpiarArchivosContexto() -> void:
	_archivosContexto.clear()
	_refrescarChipsContexto()

func _construirBloqueContexto() -> String:
	var cuerpo := ""
	for archivo in _archivosContexto:
		# Las imagenes no van aqui: viajan como parte de imagen del mensaje. Pegar
		# sus bytes en el texto seria basura ilegible para el modelo.
		if bool(archivo.get("imagen", false)):
			continue
		var ruta: String = archivo.get("ruta", "")
		var nombre: String = archivo.get("nombre", "")
		var f := FileAccess.open(ruta, FileAccess.READ)
		if f == null:
			cuerpo += "\n(Could not read: %s)\n" % nombre
			continue
		var contenido := f.get_as_text()
		f.close()
		if contenido.length() > 20000:
			contenido = contenido.substr(0, 20000) + "\n...[truncated]"
		cuerpo += "\n### %s\n```\n%s\n```\n" % [nombre, contenido]
	if cuerpo == "":
		return ""
	return "\n\n---\n**Attached context files:**\n" + cuerpo + "\n---\n"

## Rutas de las imagenes adjuntas, en orden. Se consumen al enviar.
func _rutasImagenesContexto() -> Array:
	var rutas: Array = []
	for archivo in _archivosContexto:
		if bool(archivo.get("imagen", false)):
			rutas.append(archivo.get("ruta", ""))
	return rutas

func _extraerPreguntaJson(contenido: String) -> Dictionary:
	return ChatParseador.extraerPreguntaJson(contenido)

func _extraerOpcionesRapidas(contenido: String) -> Array:
	return ChatParseador.extraerOpcionesRapidas(contenido)

func _quitarMarcadorOpciones(contenido: String) -> String:
	return ChatParseador.quitarMarcadorOpciones(contenido)

func _mostrarOpcionesRapidas(opciones: Array) -> void:
	if opciones.is_empty():
		return
	await _mostrarTarjetaPregunta("", opciones)

func _mostrarTarjetaPregunta(pregunta: String, opciones: Array) -> void:
	_removerOpcionesRapidas()
	if opciones.is_empty():
		return
	var panel := PanelContainer.new()
	panel.name = "TarjetaPregunta"
	panel.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	var estilo := StyleBoxFlat.new()
	estilo.bg_color = Color(0.08, 0.08, 0.08, 0.98)
	estilo.border_color = Color(0.28, 0.28, 0.28, 1.0)
	estilo.border_width_left = 1
	estilo.border_width_top = 1
	estilo.border_width_right = 1
	estilo.border_width_bottom = 1
	estilo.corner_radius_top_left = 2
	estilo.corner_radius_top_right = 2
	estilo.corner_radius_bottom_left = 2
	estilo.corner_radius_bottom_right = 2
	estilo.content_margin_left = 14
	estilo.content_margin_right = 14
	estilo.content_margin_top = 12
	estilo.content_margin_bottom = 12
	estilo.shadow_size = 0
	panel.add_theme_stylebox_override("panel", estilo)

	var vbox := VBoxContainer.new()
	vbox.add_theme_constant_override("separation", 10)
	vbox.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	panel.add_child(vbox)

	var encabezado := HBoxContainer.new()
	encabezado.add_theme_constant_override("separation", 8)
	vbox.add_child(encabezado)

	var marcador := Label.new()
	marcador.text = "?"
	marcador.add_theme_color_override("font_color", COLOR_ACENTO)

	encabezado.add_child(marcador)

	var etiqueta := Label.new()
	etiqueta.text = "Select one"
	etiqueta.add_theme_color_override("font_color", COLOR_TEXTO_TENUE)

	etiqueta.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	encabezado.add_child(etiqueta)

	if pregunta.strip_edges() != "":
		var labelPregunta := Label.new()
		labelPregunta.text = pregunta
		labelPregunta.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		labelPregunta.add_theme_color_override("font_color", COLOR_TEXTO_PRIMARIO)
		labelPregunta.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		vbox.add_child(labelPregunta)

	var separador := HSeparator.new()
	separador.modulate = Color(1, 1, 1, 0.06)
	vbox.add_child(separador)

	var listaOpciones := VBoxContainer.new()
	listaOpciones.add_theme_constant_override("separation", 6)
	listaOpciones.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	vbox.add_child(listaOpciones)

	for opcion in opciones:
		var btn := ChatUIFactory.crearBotonOpcionRapida(String(opcion), _alPulsarOpcionRapida)
		listaOpciones.add_child(btn)

	_tarjetaPreguntaActiva = panel
	_contenedorOpcionesRapidas = listaOpciones
	_contenedorActivoMensajes().add_child(panel)
	_animarEntradaBurbuja(panel)
	await _scrollAlFinal()

func _removerOpcionesRapidas() -> void:
	if is_instance_valid(_tarjetaPreguntaActiva):
		_tarjetaPreguntaActiva.queue_free()
	_tarjetaPreguntaActiva = null
	if is_instance_valid(_contenedorOpcionesRapidas):
		_contenedorOpcionesRapidas.queue_free()
	_contenedorOpcionesRapidas = null

func _alPulsarOpcionRapida(texto: String) -> void:
	_removerOpcionesRapidas()
	if _esperandoRespuesta or _bucleAgenteActivo:
		return
	if not is_instance_valid(campoTexto):
		return
	campoTexto.text = texto
	_ajustarAlturaCampoTexto()
	await get_tree().process_frame
	_on_button_pressed()

## Flujo NATIVO de preguntas: la tool "Ask user" muestra esta tarjeta y la
## seleccion del usuario vuelve como resultado del tool (no como mensaje).
func _preguntarUsuarioNativo(pregunta: String, opciones: Array) -> String:
	var miSesion := _idSesion
	_removerOpcionesRapidas()
	var panel := PanelContainer.new()
	panel.name = "TarjetaPregunta"
	panel.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	# Sin panel ni contorno, igual que las herramientas: el usuario queria texto y
	# nada mas. El contenedor sigue porque es el que agrupa pregunta y opciones,
	# pero no dibuja nada.
	var estilo := StyleBoxEmpty.new()
	estilo.content_margin_left = 2
	estilo.content_margin_right = 0
	estilo.content_margin_top = 2
	estilo.content_margin_bottom = 2
	panel.add_theme_stylebox_override("panel", estilo)
	var vbox := VBoxContainer.new()
	vbox.add_theme_constant_override("separation", 8)
	vbox.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	vbox.mouse_filter = Control.MOUSE_FILTER_IGNORE
	panel.add_child(vbox)
	var encabezado := HBoxContainer.new()
	encabezado.add_theme_constant_override("separation", 8)
	encabezado.mouse_filter = Control.MOUSE_FILTER_IGNORE
	vbox.add_child(encabezado)
	var marcador := Label.new()
	marcador.text = "?"
	marcador.add_theme_color_override("font_color", COLOR_ACENTO)
	encabezado.add_child(marcador)
	var etiqueta := Label.new()
	etiqueta.text = "Dotti needs your choice"
	etiqueta.add_theme_color_override("font_color", COLOR_TEXTO_TENUE)
	etiqueta.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	encabezado.add_child(etiqueta)
	if pregunta.strip_edges() != "":
		var labelPregunta := Label.new()
		labelPregunta.text = pregunta
		labelPregunta.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		labelPregunta.add_theme_color_override("font_color", COLOR_TEXTO_PRIMARIO)
		labelPregunta.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		vbox.add_child(labelPregunta)
	var listaOpciones := VBoxContainer.new()
	listaOpciones.add_theme_constant_override("separation", 6)
	listaOpciones.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	vbox.add_child(listaOpciones)
	for opcion in opciones:
		var textoOpcion := String(opcion)
		# El boton llama al callback CON el texto de la opcion, asi que el callback
		# tiene que aceptar ese argumento. Antes iba un lambda sin parametros y
		# GDScript rechazaba la llamada ("Expected 0 argument(s)"): pulsar una opcion
		# no hacia absolutamente nada.
		var btn := ChatUIFactory.crearBotonOpcionRapida(textoOpcion, _resolverPreguntaNativa)
		listaOpciones.add_child(btn)
	_tarjetaPreguntaActiva = panel
	_contenedorOpcionesRapidas = listaOpciones
	_contenedorActivoMensajes().add_child(panel)
	_moverEsperaAlFinal()
	_animarEntradaBurbuja(panel)
	# El scroll es cosmetico y no se espera: asi la espera de la senal queda
	# registrada ya en este cuadro, con la tarjeta pulsable desde el primero.
	_scrollAlFinal()
	# La espera se registra ANTES de que nada mas pueda consumir el clic: si un
	# clic llegara en el mismo cuadro en que nace la tarjeta se perderia y la
	# pregunta se quedaria colgada para siempre.
	var elegida: String = await respuesta_pregunta_nativa
	_removerOpcionesRapidas()
	if _peticionCancelada or _idSesion != miSesion:
		return ""
	return elegida

func _resolverPreguntaNativa(texto: String) -> void:
	_removerOpcionesRapidas()
	respuesta_pregunta_nativa.emit(texto)
