class_name Configuracion
extends Window

signal configuracionGuardada

## Los dos prompts de sistema (0 es Agent mode, 1 es Plan mode). Sellados, como
## el resto de los textos propietarios: ver Secretos. El original se edita en
## `secrets-src/prompt_sistema_agente.txt` y `secrets-src/prompt_sistema_plan.txt`.
const NOMBRES_PROMPTS_SISTEMA := ["prompt_sistema_agente", "prompt_sistema_plan"]

static func promptSistema(indice: int) -> String:
	if indice < 0 or indice >= NOMBRES_PROMPTS_SISTEMA.size():
		indice = 0
	return Secretos.abrir(NOMBRES_PROMPTS_SISTEMA[indice])

const COLOR_FONDO := Color(0.098, 0.098, 0.098, 1.0)
const COLOR_PANEL := Color(0.125, 0.125, 0.125, 1.0)
const COLOR_PANEL_ALT := Color(0.157, 0.157, 0.157, 1.0)
const COLOR_PANEL_HOVER := Color(0.196, 0.196, 0.196, 1.0)
const COLOR_BORDE := Color(0.235, 0.235, 0.235, 0.95)
const COLOR_BORDE_SUAVE := Color(0.184, 0.184, 0.184, 0.75)
const COLOR_TEXTO := Color(0.902, 0.902, 0.902, 1.0)
const COLOR_TEXTO_SUAVE := Color(0.631, 0.631, 0.631, 1.0)
const COLOR_TEXTO_TENUE := Color(0.459, 0.459, 0.459, 1.0)
const COLOR_ACENTO := Color(0.855, 0.855, 0.855, 1.0)
const COLOR_ACENTO_SUAVE := Color(0.549, 0.549, 0.549, 0.85)
const COLOR_PELIGRO := Color(0.722, 0.42, 0.42, 1.0)

## Marcas de la ficha del modelo: lo que el modelo tiene y lo que no. Son
## las mismas del chat, para que un "no" se lea igual en toda la ventana.
const GLIFO_SI := "✓"
const GLIFO_NO := "✗"

const RUTA_INSTRUCCIONES := "user://dotti_instrucciones_usuario.txt"

## Relleno de las filas de datos (estilo de la ventana).
const MARGEN_FILA_H := 12
const MARGEN_FILA_H_DERECHA := 10
const MARGEN_FILA_V := 10

static func cargarInstruccionesUsuario() -> String:
	if not FileAccess.file_exists(RUTA_INSTRUCCIONES):
		return ""
	var f := FileAccess.open(RUTA_INSTRUCCIONES, FileAccess.READ)
	if f == null:
		return ""
	var texto := f.get_as_text()
	f.close()
	return texto

static func guardarInstruccionesUsuario(texto: String) -> void:
	var f := FileAccess.open(RUTA_INSTRUCCIONES, FileAccess.WRITE)
	if f == null:
		return
	f.store_string(texto)
	f.close()

var _apis: Apis

var _input_instrucciones: TextEdit
var _boton_guardar_instrucciones: Button
var _label_estado_instrucciones: Label

var _herramientasDisponibles: Dictionary = {}
var _input_busqueda_permisos: LineEdit
var _contenedor_lista_permisos: VBoxContainer
var _filtro_permisos: String = ""
var _label_vacio_permisos: Label
var _contenedor_datos_modelo: VBoxContainer

# Pagina "Agents" (P9): lista a la izquierda, editor a la derecha. El agente en
# edicion se lleva por nombre; vacio es uno nuevo que todavia no existe.
var _paginas: Array = []
var _contenedor_lista_agentes: VBoxContainer
var _label_vacio_agentes: Label
var _label_titulo_agente: Label
var _chip_agente: Label
var _input_nombre_agente: LineEdit
var _input_descripcion_agente: LineEdit
var _selector_modelo_agente: OptionButton
var _caja_herramientas_agente: VBoxContainer
var _marco_herramientas_agente: PanelContainer
var _boton_customizar_agente: Button
## El scroll que envuelve el formulario del agente. Al desplegar la lista de
## herramientas hay que bajar hasta ella, que nace por debajo del corte.
var _scroll_formulario_agente: ScrollContainer
var _label_resumen_herramientas_agente: Label
var _preset_todas: Button
var _preset_lectura: Button
var _preset_ninguna: Button
var _input_prompt_agente: TextEdit
var _label_estado_agente: Label
var _boton_borrar_agente: Button
var _agente_en_edicion: String = ""
## De donde viene el agente abierto en el formulario: "usuario", "proyecto" o
## "incluido" (los de fabrica). Vacio cuando no hay ninguno. Los dos ultimos no
## se cambian en su sitio; de los de fabrica Ajustes guarda copia propia.
var _agente_origen: String = ""
var _herramientas_agente_elegidas: Array = []
## Nombre con el que el agente esta en el disco. Si al guardar el formulario
## lleva otro, el guardado es un renombrado y el archivo viejo se va con el.
var _agente_original: String = ""
## El boton de borrar pide dos clics: con el primero se arma, y cualquier otra
## cosa que se toque en el formulario lo desarma.
var _borrado_armado: bool = false

# --- Cuenta ---------------------------------------------------------------
# La pagina de la cuenta: entrar por codigo de dispositivo, ver el gasto del dia
# y salir. El sondeo del codigo va en un temporizador, no en un bucle, para que
# la ventana siga viva mientras el usuario aprueba en la web.
var _sesion: Sesion
var _contenedor_cuenta: VBoxContainer
var _label_estado_cuenta: Label
var _temporizador_dispositivo: Timer
var _dispositivo_codigo: String = ""
var _dispositivo_usuario: String = ""
var _dispositivo_url: String = ""
var _intervalo_dispositivo: float = ChatCuenta.SONDEO_POR_DEFECTO
var _consultando_cuenta: bool = false
## La pagina y su boton, para poder abrir la ventana directamente en ella cuando el
## chat pide entrar (ver abrirEnCuenta).
var _pagina_cuenta: Control
var _btn_cuenta: Button

# --- Actualizaciones ------------------------------------------------------
# La pagina que mira si hay version nueva y la instala. Todo el trabajo lo hace
# `ChatActualizaciones`; aqui solo se pinta lo que contesta y se le piden las dos
# cosas que sabe hacer. `_actualizacion_instalada` es la version que acaba de
# quedar en el disco: mientras el editor siga abierto el codigo cargado es el
# viejo, asi que lo unico que queda por hacer es reiniciar, y eso hay que decirlo.
var _contenedor_actualizaciones: VBoxContainer
var _label_estado_actualizaciones: Label
var _casilla_actualizaciones: CheckBox
var _actualizacion: Dictionary = {}
var _actualizacion_instalada: String = ""
var _consultando_actualizaciones: bool = false

func establecerHerramientas(herramientas: Dictionary) -> void:
	_herramientasDisponibles = herramientas
	if is_instance_valid(_contenedor_lista_permisos):
		_refrescarListaPermisos()
	# La pagina de agentes se construye en _ready(), y el chat pasa las
	# herramientas un instante despues: con el registro vacio el formulario se
	# habia quedado sin ninguna marcada. Aqui se repinta y, si el formulario esta
	# en blanco (agente nuevo), se rellena otra vez con "todas" marcadas.
	if is_instance_valid(_caja_herramientas_agente):
		_refrescarHerramientasAgente()
		if _agente_en_edicion == "":
			_cargarAgenteEnFormulario({})

func _ready() -> void:
	var windowSize = DisplayServer.window_get_size()
	_apis = Apis.new()
	title = "Settings - Dotti"
	min_size = windowSize * 0.8
	close_requested.connect(queue_free)

	var fondo := Panel.new()
	fondo.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	fondo.add_theme_stylebox_override("panel", _estiloFondo())
	add_child(fondo)

	var main_margin := MarginContainer.new()
	main_margin.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	main_margin.add_theme_constant_override("margin_left", 18)
	main_margin.add_theme_constant_override("margin_right", 18)
	main_margin.add_theme_constant_override("margin_top", 16)
	main_margin.add_theme_constant_override("margin_bottom", 18)
	add_child(main_margin)

	var columna_principal := VBoxContainer.new()
	columna_principal.add_theme_constant_override("separation", 14)
	columna_principal.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	columna_principal.size_flags_vertical = Control.SIZE_EXPAND_FILL
	main_margin.add_child(columna_principal)

	columna_principal.add_child(_crearEncabezado("Settings", "Custom instructions, tool permissions, models and agents"))

	var cuerpo := HBoxContainer.new()
	cuerpo.add_theme_constant_override("separation", 14)
	cuerpo.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	cuerpo.size_flags_vertical = Control.SIZE_EXPAND_FILL
	columna_principal.add_child(cuerpo)

	var marcoNav := _crearMarcoPanel()
	marcoNav.custom_minimum_size = Vector2(180, 0)
	marcoNav.size_flags_horizontal = Control.SIZE_FILL
	marcoNav.size_flags_vertical = Control.SIZE_EXPAND_FILL
	cuerpo.add_child(marcoNav)

	var navLista := VBoxContainer.new()
	navLista.add_theme_constant_override("separation", 4)
	navLista.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	navLista.size_flags_vertical = Control.SIZE_EXPAND_FILL
	marcoNav.add_child(navLista)

	var navTitulo := Label.new()
	navTitulo.text = "Categories"
	navTitulo.add_theme_color_override("font_color", COLOR_TEXTO_TENUE)
	navLista.add_child(navTitulo)

	var separacionSuperior := Control.new()
	separacionSuperior.custom_minimum_size = Vector2(0, 4)
	navLista.add_child(separacionSuperior)

	var marcoContenido := _crearMarcoPanel()
	marcoContenido.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	marcoContenido.size_flags_vertical = Control.SIZE_EXPAND_FILL
	cuerpo.add_child(marcoContenido)

	var paginas := VBoxContainer.new()
	paginas.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	paginas.size_flags_vertical = Control.SIZE_EXPAND_FILL
	marcoContenido.add_child(paginas)

	var pagina_instrucciones := VBoxContainer.new()
	pagina_instrucciones.add_theme_constant_override("separation", 12)
	pagina_instrucciones.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	pagina_instrucciones.size_flags_vertical = Control.SIZE_EXPAND_FILL
	pagina_instrucciones.visible = false
	paginas.add_child(pagina_instrucciones)
	_construirPestanaInstrucciones(pagina_instrucciones)

	var pagina_permisos := VBoxContainer.new()
	pagina_permisos.add_theme_constant_override("separation", 12)
	pagina_permisos.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	pagina_permisos.size_flags_vertical = Control.SIZE_EXPAND_FILL
	pagina_permisos.visible = false
	paginas.add_child(pagina_permisos)
	_construirPestanaPermisos(pagina_permisos)

	var pagina_modelo := VBoxContainer.new()
	pagina_modelo.add_theme_constant_override("separation", 12)
	pagina_modelo.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	pagina_modelo.size_flags_vertical = Control.SIZE_EXPAND_FILL
	pagina_modelo.visible = false
	paginas.add_child(pagina_modelo)
	_construirPestanaModelo(pagina_modelo)

	var pagina_agentes := VBoxContainer.new()
	pagina_agentes.add_theme_constant_override("separation", 12)
	pagina_agentes.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	pagina_agentes.size_flags_vertical = Control.SIZE_EXPAND_FILL
	pagina_agentes.visible = false
	paginas.add_child(pagina_agentes)
	_construirPestanaAgentes(pagina_agentes)

	var pagina_cuenta := VBoxContainer.new()
	pagina_cuenta.add_theme_constant_override("separation", 12)
	pagina_cuenta.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	pagina_cuenta.size_flags_vertical = Control.SIZE_EXPAND_FILL
	pagina_cuenta.visible = false
	paginas.add_child(pagina_cuenta)
	_construirPestanaCuenta(pagina_cuenta)

	var pagina_actualizaciones := VBoxContainer.new()
	pagina_actualizaciones.add_theme_constant_override("separation", 12)
	pagina_actualizaciones.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	pagina_actualizaciones.size_flags_vertical = Control.SIZE_EXPAND_FILL
	pagina_actualizaciones.visible = false
	paginas.add_child(pagina_actualizaciones)
	_construirPestanaActualizaciones(pagina_actualizaciones)

	# Todas las paginas, para que cambiar de categoria sea ensenar una y esconder
	# el resto sin enumerar a mano las otras en cada llamada.
	_paginas = [pagina_instrucciones, pagina_permisos, pagina_modelo, pagina_agentes, pagina_cuenta, pagina_actualizaciones]
	_pagina_cuenta = pagina_cuenta

	var grupo := ButtonGroup.new()
	var btnInstr := _crearBotonNavegacion("Custom Instructions", "Personal context for the AI", grupo)
	btnInstr.button_pressed = true
	btnInstr.pressed.connect(func(): _cambiarPagina(pagina_instrucciones))
	navLista.add_child(btnInstr)

	var btnPermisos := _crearBotonNavegacion("Tool Permissions", "Choose which tools can run in Auto mode", grupo)
	btnPermisos.pressed.connect(func(): _cambiarPagina(pagina_permisos))
	navLista.add_child(btnPermisos)

	var btnModelo := _crearBotonNavegacion("Models", "Pick the model Dotti uses", grupo)
	btnModelo.pressed.connect(func():
		_refrescarDatosModelo()
		_cambiarPagina(pagina_modelo))
	navLista.add_child(btnModelo)

	var btnAgentes := _crearBotonNavegacion("Agents", "Extra personas you can call with @name", grupo)
	btnAgentes.pressed.connect(func():
		_refrescarListaAgentes()
		_cambiarPagina(pagina_agentes))
	navLista.add_child(btnAgentes)

	var btnCuenta := _crearBotonNavegacion("Account", "Sign in and see what you have spent today", grupo)
	btnCuenta.pressed.connect(_abrirCuenta)
	navLista.add_child(btnCuenta)
	_btn_cuenta = btnCuenta

	var btnActualizaciones := _crearBotonNavegacion("Updates", "Keep the plugin up to date", grupo)
	btnActualizaciones.pressed.connect(func():
		_refrescarActualizaciones()
		_cambiarPagina(pagina_actualizaciones))
	navLista.add_child(btnActualizaciones)

	var expansor := Control.new()
	expansor.size_flags_vertical = Control.SIZE_EXPAND_FILL
	navLista.add_child(expansor)

	_cargar_instrucciones_actuales()
	# La pagina inicial hay que ensenarla A MANO: marcar el boton por codigo
	# (button_pressed = true) pinta el boton pero NO emite "pressed" -y con
	# toggle_mode el que emite es "toggled"-, asi que el lambda de arriba no
	# corria y las tres paginas, que nacen ocultas, se quedaban fuera: la ventana
	# salia con la barra de categorias y el panel de la derecha literalmente vacio.
	_cambiarPagina(pagina_instrucciones)
	popup_centered()

## Cambia de categoria: se ensena una y se esconden las demas.
func _cambiarPagina(mostrar: Control) -> void:
	for pagina in _paginas:
		pagina.visible = pagina == mostrar

## La pestana de la cuenta, tal como la abre su boton: refrescar el estado y el
## consumo, y ensenarla.
func _abrirCuenta() -> void:
	_refrescarCuenta()
	_refrescarConsumo()
	_cambiarPagina(_pagina_cuenta)

## Abre la ventana ya en la pestana de la cuenta. Lo pide el chat cuando falta
## entrar: el aviso que pinta lleva aqui, y no puede dejar al usuario buscando la
## pestana que acaba de pedirle. Marcar el boton a mano no emite `pressed` (es un
## boton de grupo, y con `toggle_mode` quien emite es `toggled`), asi que el
## trabajo se hace llamando a lo mismo que llama el boton.
func abrirEnCuenta() -> void:
	if is_instance_valid(_btn_cuenta):
		_btn_cuenta.button_pressed = true
	_abrirCuenta()

## La pagina de la cuenta. El estado vive en `Sesion` (un fichero en `user://`) y
## el protocolo en `ChatCuenta`; aqui solo se pinta y se lanzan las llamadas.
func _construirPestanaCuenta(contenedor: VBoxContainer) -> void:
	_sesion = Sesion.unica()

	var marco := _crearMarcoPanel()
	marco.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	marco.size_flags_vertical = Control.SIZE_EXPAND_FILL
	contenedor.add_child(marco)

	var vbox := VBoxContainer.new()
	vbox.add_theme_constant_override("separation", 10)
	vbox.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	vbox.size_flags_vertical = Control.SIZE_EXPAND_FILL
	marco.add_child(vbox)

	var titulo := Label.new()
	titulo.text = "Account"
	titulo.add_theme_color_override("font_color", COLOR_TEXTO)
	vbox.add_child(titulo)

	var subtitulo := Label.new()
	subtitulo.text = "Signing in is what lets the plugin ask for anything. Your plan counts the tokens and holds the daily limit."
	subtitulo.add_theme_color_override("font_color", COLOR_TEXTO_SUAVE)
	subtitulo.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	vbox.add_child(subtitulo)

	var scroll := ScrollContainer.new()
	scroll.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	vbox.add_child(scroll)

	_contenedor_cuenta = VBoxContainer.new()
	_contenedor_cuenta.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_contenedor_cuenta.add_theme_constant_override("separation", 8)
	scroll.add_child(_contenedor_cuenta)

	_temporizador_dispositivo = Timer.new()
	_temporizador_dispositivo.wait_time = _intervalo_dispositivo
	_temporizador_dispositivo.timeout.connect(_consultarDispositivo)
	add_child(_temporizador_dispositivo)

	_refrescarCuenta()

## Rehace el cuerpo de la pagina segun el estado de la cuenta. Se llama al abrir
## la pestana, al terminar de entrar y despues de cada refresco, asi que lo que
## se ensena son las ultimas cifras que contesto la pasarela.
func _refrescarCuenta() -> void:
	if not is_instance_valid(_contenedor_cuenta):
		return
	# remove_child ademas de queue_free, por lo mismo que en la pagina de
	# modelos: el contenedor queda limpio en el acto y un refresco dentro del
	# mismo frame no duplica filas.
	for hijo in _contenedor_cuenta.get_children():
		_contenedor_cuenta.remove_child(hijo)
		hijo.queue_free()
	if _sesion == null:
		_sesion = Sesion.unica()
	if _sesion.estaDentro():
		_anexarCuentaDentro()
	else:
		_anexarCuentaFuera()

	# El aviso va al final y sin temporizador: aqui no es un "guardado" que se
	# borra solo, sino el estado de una entrada que puede estar esperando.
	_label_estado_cuenta = Label.new()
	_label_estado_cuenta.text = ""
	_label_estado_cuenta.add_theme_color_override("font_color", COLOR_TEXTO_TENUE)
	_label_estado_cuenta.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_contenedor_cuenta.add_child(_label_estado_cuenta)

## Sin cuenta: se explica para que hace falta y se ofrece pedir el codigo. Con un
## codigo pedido y sin aprobar, se ensena el bloque de espera.
func _anexarCuentaFuera() -> void:
	if _dispositivo_codigo != "":
		_anexarCuentaEsperando()
		return

	var texto := Label.new()
	texto.text = "This install has no account yet. Sign in to let the plugin ask for anything; nothing else changes: the chat, the tools and the models work the same."
	texto.add_theme_color_override("font_color", COLOR_TEXTO_SUAVE)
	texto.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_contenedor_cuenta.add_child(texto)

	var boton := _crearBotonAcento("Get a device code")
	boton.pressed.connect(_empezarEntrada)
	_contenedor_cuenta.add_child(boton)

## Con un codigo pedido: el codigo grande, donde aprobarlo y el aviso de espera.
func _anexarCuentaEsperando() -> void:
	var paso := Label.new()
	paso.text = "Open the Dotti panel in your browser, go to the device page and approve this code:"
	paso.add_theme_color_override("font_color", COLOR_TEXTO_SUAVE)
	paso.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_contenedor_cuenta.add_child(paso)

	var codigo := Label.new()
	codigo.text = _dispositivo_usuario
	codigo.add_theme_font_size_override("font_size", 34)
	codigo.add_theme_color_override("font_color", COLOR_ACENTO)
	codigo.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_contenedor_cuenta.add_child(codigo)

	if _dispositivo_url != "":
		var url := Label.new()
		url.text = _dispositivo_url
		url.add_theme_color_override("font_color", COLOR_TEXTO)
		url.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		url.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		_contenedor_cuenta.add_child(url)
	else:
		var sin_url := Label.new()
		sin_url.text = "There is no page to approve it on. Open the Dotti panel you use and look for the device page."
		sin_url.add_theme_color_override("font_color", COLOR_TEXTO_TENUE)
		sin_url.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		_contenedor_cuenta.add_child(sin_url)

	var fila := HBoxContainer.new()
	fila.add_theme_constant_override("separation", 8)
	var btn_copiar := _crearBotonSecundario("Copy the code")
	btn_copiar.pressed.connect(func(): _copiarAlPortapapeles(_dispositivo_usuario))
	fila.add_child(btn_copiar)
	if _dispositivo_url != "":
		var btn_abrir := _crearBotonAcento("Open the page")
		btn_abrir.pressed.connect(func(): OS.shell_open(_dispositivo_url))
		fila.add_child(btn_abrir)
	var btn_cancelar := _crearBotonSecundario("Cancel")
	btn_cancelar.pressed.connect(func(): _terminarEspera("Cancelled here. The code will expire on its own."))
	fila.add_child(btn_cancelar)
	_contenedor_cuenta.add_child(fila)

	var espera := Label.new()
	espera.text = "Asking again every %d seconds. This window can stay open." % int(_intervalo_dispositivo)
	espera.add_theme_color_override("font_color", COLOR_TEXTO_TENUE)
	espera.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_contenedor_cuenta.add_child(espera)

## Con cuenta: quien es, su gasto de hoy y los dos botones que se usan.
func _anexarCuentaDentro() -> void:
	var filas := VBoxContainer.new()
	filas.add_theme_constant_override("separation", 6)
	filas.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_contenedor_cuenta.add_child(filas)

	var quien := _sesion.correo if _sesion.correo != "" else "this account"
	filas.add_child(_crearFilaDato("Signed in as", quien))
	if _sesion.rol != "":
		filas.add_child(_crearFilaDato("Role", _sesion.rol))
	filas.add_child(_crearFilaDato("Spent today", _textoGastoCuenta()))
	if _sesion.inicio_dia != "":
		filas.add_child(_crearFilaDato("The day counts from", _sesion.inicio_dia))
	if _sesion.obtenido_en > 0:
		filas.add_child(_crearFilaDato("Signed in on", Time.get_datetime_string_from_unix_time(_sesion.obtenido_en) + " UTC"))

	var fila := HBoxContainer.new()
	fila.add_theme_constant_override("separation", 8)
	var btn_refrescar := _crearBotonAcento("Refresh")
	btn_refrescar.pressed.connect(_refrescarConsumo)
	fila.add_child(btn_refrescar)
	var btn_salir := _crearBotonSecundario("Sign out")
	btn_salir.pressed.connect(_salirDeLaCuenta)
	fila.add_child(btn_salir)
	_contenedor_cuenta.add_child(fila)

## Los numeros del dia en una linea. Sin limite conocido se dice, en vez de
## ensenar un cero que pareceria "no has gastado nada".
func _textoGastoCuenta() -> String:
	if _sesion.limite_usd <= 0.0:
		return "%s (the limit is not known yet: press Refresh)" % _dinero(_sesion.gastado_usd)
	return "%s of %s" % [_dinero(_sesion.gastado_usd), _dinero(_sesion.limite_usd)]

func _dinero(valor: float) -> String:
	return "$%.2f" % valor

## La pagina de actualizaciones: que version hay puesta, cuando se miro por
## ultima vez y -si la hay- la version nueva con lo que trae y el boton de
## instalarla.
func _construirPestanaActualizaciones(contenedor: VBoxContainer) -> void:
	var marco := _crearMarcoPanel()
	marco.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	marco.size_flags_vertical = Control.SIZE_EXPAND_FILL
	contenedor.add_child(marco)

	var vbox := VBoxContainer.new()
	vbox.add_theme_constant_override("separation", 10)
	vbox.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	vbox.size_flags_vertical = Control.SIZE_EXPAND_FILL
	marco.add_child(vbox)

	var titulo := Label.new()
	titulo.text = "Updates"
	titulo.add_theme_color_override("font_color", COLOR_TEXTO)
	vbox.add_child(titulo)

	var subtitulo := Label.new()
	subtitulo.text = "Dotti looks for a new version once a day and tells you when there is one. Nothing is installed until you say so, and what is installed is checked against the hash the versions list publishes."
	subtitulo.add_theme_color_override("font_color", COLOR_TEXTO_SUAVE)
	subtitulo.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	vbox.add_child(subtitulo)

	var scroll := ScrollContainer.new()
	scroll.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	vbox.add_child(scroll)

	_contenedor_actualizaciones = VBoxContainer.new()
	_contenedor_actualizaciones.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_contenedor_actualizaciones.add_theme_constant_override("separation", 8)
	scroll.add_child(_contenedor_actualizaciones)

	_refrescarActualizaciones()

## Rehace el cuerpo de la pagina con lo que se sabe ahora mismo. Se llama al
## abrir la pestana y despues de cada comprobacion o instalacion.
func _refrescarActualizaciones() -> void:
	if not is_instance_valid(_contenedor_actualizaciones):
		return
	# remove_child ademas de queue_free, como en las otras paginas: si no, un
	# refresco dentro del mismo frame duplica filas.
	for hijo in _contenedor_actualizaciones.get_children():
		_contenedor_actualizaciones.remove_child(hijo)
		hijo.queue_free()

	var estado := ChatActualizaciones.estado()
	var puesta := ChatActualizaciones.instalada()
	_contenedor_actualizaciones.add_child(_crearFilaDato("Installed version", puesta if puesta != "" else "not known yet"))
	_contenedor_actualizaciones.add_child(_crearFilaDato("Last check", ChatActualizaciones.haceCuanto(int(estado.get("ultima_comprobacion", 0)))))

	# La casilla: apagada no se mira sola nunca mas, y a mano se puede seguir
	# mirando cuando se quiera.
	_casilla_actualizaciones = CheckBox.new()
	_casilla_actualizaciones.text = "Look for a new version once a day"
	_casilla_actualizaciones.button_pressed = bool(estado.get("automatica", true))
	_casilla_actualizaciones.add_theme_color_override("font_color", COLOR_TEXTO_SUAVE)
	_casilla_actualizaciones.add_theme_color_override("font_hover_color", COLOR_TEXTO)
	_casilla_actualizaciones.toggled.connect(_alCambiarAutomaticas)
	_contenedor_actualizaciones.add_child(_casilla_actualizaciones)

	var fila := HBoxContainer.new()
	fila.add_theme_constant_override("separation", 8)
	var btn_mirar := _crearBotonAcento("Check now")
	btn_mirar.disabled = _consultando_actualizaciones
	btn_mirar.pressed.connect(_comprobarActualizaciones)
	fila.add_child(btn_mirar)
	var ignorada := str(estado.get("ignorada", ""))
	if ignorada != "":
		var btn_olvidar := _crearBotonSecundario("Offer %s again" % ignorada)
		btn_olvidar.pressed.connect(_olvidarIgnorada)
		fila.add_child(btn_olvidar)
	_contenedor_actualizaciones.add_child(fila)

	_anexarTarjetaActualizacion(ignorada)

	_label_estado_actualizaciones = Label.new()
	_label_estado_actualizaciones.text = ""
	_label_estado_actualizaciones.add_theme_color_override("font_color", COLOR_TEXTO_TENUE)
	_label_estado_actualizaciones.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_contenedor_actualizaciones.add_child(_label_estado_actualizaciones)

## La version nueva, si la hay y si el usuario no la rechazo. Con una ya
## instalada lo que toca no es instalar otra vez, sino reiniciar.
func _anexarTarjetaActualizacion(ignorada: String) -> void:
	if _actualizacion_instalada != "":
		_contenedor_actualizaciones.add_child(_crearAvisoActualizacion(
			"Version %s is installed. Close the editor and open it again so the new code loads." % _actualizacion_instalada, COLOR_ACENTO))
		return
	if _actualizacion.is_empty() or not bool(_actualizacion.get("hay_nueva", false)):
		return
	var version := str(_actualizacion.get("version", ""))
	if version == ignorada:
		return

	var tarjeta := _crearMarcoAcento()
	tarjeta.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_contenedor_actualizaciones.add_child(tarjeta)

	var caja := VBoxContainer.new()
	caja.add_theme_constant_override("separation", 8)
	tarjeta.add_child(caja)

	var titulo := Label.new()
	titulo.text = "Version %s is out" % version
	titulo.add_theme_color_override("font_color", COLOR_TEXTO)
	caja.add_child(titulo)

	var notas := str(_actualizacion.get("notas", ""))
	if notas != "":
		caja.add_child(_crearAvisoActualizacion(notas, COLOR_TEXTO_SUAVE))

	if bool(_actualizacion.get("obligatoria", false)):
		caja.add_child(_crearAvisoActualizacion("This one is marked as required: the version you have is no longer served.", COLOR_PELIGRO))

	var acciones := HBoxContainer.new()
	acciones.add_theme_constant_override("separation", 8)
	var btn_instalar := _crearBotonAcento("Install")
	btn_instalar.disabled = _consultando_actualizaciones
	btn_instalar.pressed.connect(_instalarActualizacion)
	acciones.add_child(btn_instalar)
	var btn_luego := _crearBotonSecundario("Not now")
	btn_luego.pressed.connect(_noInstalarActualizacion)
	acciones.add_child(btn_luego)
	caja.add_child(acciones)

## Un texto que se puede leer en varias lineas dentro de la pagina.
func _crearAvisoActualizacion(texto: String, color: Color) -> Label:
	var etiqueta := Label.new()
	etiqueta.text = texto
	etiqueta.add_theme_color_override("font_color", color)
	etiqueta.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	etiqueta.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	return etiqueta

## El marco de la tarjeta: el mismo panel de siempre con el borde de acento, que
## es lo que la separa de las filas de solo lectura.
func _crearMarcoAcento() -> PanelContainer:
	var panel := _crearMarcoPanel()
	var estilo := panel.get_theme_stylebox("panel").duplicate() as StyleBoxFlat
	estilo.border_color = COLOR_ACENTO_SUAVE
	estilo.border_width_left = 2
	estilo.border_width_top = 2
	estilo.border_width_right = 2
	estilo.border_width_bottom = 2
	panel.add_theme_stylebox_override("panel", estilo)
	return panel

## Mira si hay version nueva. Es una ida y vuelta a la red, asi que el boton se
## apaga mientras dura y se vuelve a encender al final, pase lo que pase.
func _comprobarActualizaciones() -> void:
	if _consultando_actualizaciones:
		return
	_consultando_actualizaciones = true
	_actualizacion_instalada = ""
	_refrescarActualizaciones()
	_mostrarEstadoActualizaciones("Asking the versions list...", false)

	var info := await ChatActualizaciones.comprobar(self)
	_consultando_actualizaciones = false
	if not bool(info.get("ok", false)):
		_actualizacion = {}
		_refrescarActualizaciones()
		_mostrarEstadoActualizaciones(str(info.get("error", "")), true)
		return
	_actualizacion = info
	_refrescarActualizaciones()
	if not bool(info.get("hay_nueva", false)):
		_mostrarEstadoActualizaciones("You are on the latest version.", false)
		return
	var version := str(info.get("version", ""))
	if ChatActualizaciones.yaIgnorada(version):
		_mostrarEstadoActualizaciones("%s is out, and you said not now. It will not be offered again." % version, false)
		return
	_mostrarEstadoActualizaciones("%s is out." % version, false)

## Baja e instala la version que se esta ofreciendo. Al terminar, el editor sigue
## con el codigo viejo cargado: lo que queda por hacer es reiniciarlo, y eso se
## dice aqui y se repite en la tarjeta.
func _instalarActualizacion() -> void:
	if _actualizacion.is_empty() or _consultando_actualizaciones:
		return
	_consultando_actualizaciones = true
	var version := str(_actualizacion.get("version", ""))
	_refrescarActualizaciones()
	_mostrarEstadoActualizaciones("Downloading %s..." % version, false)

	var resultado := await ChatActualizaciones.instalar(self, _actualizacion)
	_consultando_actualizaciones = false
	if not bool(resultado.get("ok", false)):
		_refrescarActualizaciones()
		_mostrarEstadoActualizaciones(str(resultado.get("error", "")), true)
		return
	_actualizacion_instalada = version
	_actualizacion = {}
	_refrescarActualizaciones()
	var respaldo := str(resultado.get("respaldo", ""))
	_mostrarEstadoActualizaciones("Version %s is installed. Restart the editor to use it.%s" % [
		version,
		"" if respaldo == "" else " Your previous version is backed up in %s." % respaldo
	], false)
	configuracionGuardada.emit()

## Que el usuario dijo que no. No se le vuelve a ofrecer esa version; una mas
## nueva si.
func _noInstalarActualizacion() -> void:
	var version := str(_actualizacion.get("version", ""))
	if version == "":
		return
	ChatActualizaciones.ignorar(version)
	_actualizacion = {}
	_refrescarActualizaciones()
	_mostrarEstadoActualizaciones("%s will not be offered again. A newer version still will." % version, false)

## Volver a ofrecer una rechazada. El olvido se guarda vacio, que es como esta
## cuando nunca se rechazo nada.
func _olvidarIgnorada() -> void:
	ChatActualizaciones.ignorar("")
	_refrescarActualizaciones()
	_mostrarEstadoActualizaciones("Noted. Press Check now to see it again.", false)

func _alCambiarAutomaticas(puesta: bool) -> void:
	ChatActualizaciones.ponerAutomatica(puesta)
	if puesta:
		_mostrarEstadoActualizaciones("Dotti will look for a new version once a day.", false)
	else:
		_mostrarEstadoActualizaciones("Dotti will not look on its own. Check now still works.", false)

## El aviso de la pagina. Se queda puesto, como el de la cuenta: hay mensajes que
## hay que seguir leyendo cuando el usuario vuelve de mirar la tarjeta.
func _mostrarEstadoActualizaciones(mensaje: String, error: bool) -> void:
	if not is_instance_valid(_label_estado_actualizaciones):
		return
	_label_estado_actualizaciones.text = mensaje
	_label_estado_actualizaciones.add_theme_color_override("font_color", COLOR_PELIGRO if error else COLOR_TEXTO_TENUE)

func _construirPestanaInstrucciones(contenedor: VBoxContainer) -> void:
	var marco := _crearMarcoPanel()
	marco.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	marco.size_flags_vertical = Control.SIZE_EXPAND_FILL
	contenedor.add_child(marco)

	var vbox := VBoxContainer.new()
	vbox.add_theme_constant_override("separation", 10)
	vbox.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	vbox.size_flags_vertical = Control.SIZE_EXPAND_FILL
	marco.add_child(vbox)

	var titulo := Label.new()
	titulo.text = "Custom instructions"
	titulo.add_theme_color_override("font_color", COLOR_TEXTO)
	vbox.add_child(titulo)

	var subtitulo := Label.new()
	subtitulo.text = "This text is always sent to the AI as part of the system prompt."
	subtitulo.add_theme_color_override("font_color", COLOR_TEXTO_SUAVE)
	subtitulo.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	vbox.add_child(subtitulo)

	var marco_input := PanelContainer.new()
	marco_input.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	marco_input.size_flags_vertical = Control.SIZE_EXPAND_FILL
	marco_input.add_theme_stylebox_override("panel", _estiloInput(false))
	vbox.add_child(marco_input)

	_input_instrucciones = TextEdit.new()
	_input_instrucciones.placeholder_text = "Write your custom instructions here..."
	_input_instrucciones.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_input_instrucciones.size_flags_vertical = Control.SIZE_EXPAND_FILL
	_input_instrucciones.wrap_mode = TextEdit.LINE_WRAPPING_BOUNDARY
	_input_instrucciones.scroll_fit_content_height = false
	_input_instrucciones.custom_minimum_size = Vector2(0, 220)
	_input_instrucciones.add_theme_color_override("font_color", COLOR_TEXTO)
	_input_instrucciones.add_theme_color_override("font_placeholder_color", COLOR_TEXTO_TENUE)
	var vacio := StyleBoxEmpty.new()
	_input_instrucciones.add_theme_stylebox_override("normal", vacio)
	_input_instrucciones.add_theme_stylebox_override("focus", vacio)
	_input_instrucciones.add_theme_stylebox_override("read_only", vacio)
	marco_input.add_child(_input_instrucciones)

	var fila_acciones := HBoxContainer.new()
	fila_acciones.add_theme_constant_override("separation", 8)
	fila_acciones.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	vbox.add_child(fila_acciones)

	_label_estado_instrucciones = Label.new()
	_label_estado_instrucciones.text = ""
	_label_estado_instrucciones.add_theme_color_override("font_color", COLOR_TEXTO_TENUE)
	_label_estado_instrucciones.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_label_estado_instrucciones.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	fila_acciones.add_child(_label_estado_instrucciones)

	var btn_limpiar := _crearBotonSecundario("Clear")
	btn_limpiar.pressed.connect(_on_limpiar_instrucciones)
	fila_acciones.add_child(btn_limpiar)

	_boton_guardar_instrucciones = _crearBotonAcento("Save Instructions")
	_boton_guardar_instrucciones.pressed.connect(_on_guardar_instrucciones)
	fila_acciones.add_child(_boton_guardar_instrucciones)

func _construirPestanaPermisos(contenedor: VBoxContainer) -> void:
	var marco := _crearMarcoPanel()
	marco.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	marco.size_flags_vertical = Control.SIZE_EXPAND_FILL
	contenedor.add_child(marco)

	var vbox := VBoxContainer.new()
	vbox.add_theme_constant_override("separation", 10)
	vbox.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	vbox.size_flags_vertical = Control.SIZE_EXPAND_FILL
	marco.add_child(vbox)

	var titulo := Label.new()
	titulo.text = "Tool permissions"
	titulo.add_theme_color_override("font_color", COLOR_TEXTO)
	vbox.add_child(titulo)

	var subtitulo := Label.new()
	subtitulo.text = "Toggle the tools the AI can run without asking."
	subtitulo.add_theme_color_override("font_color", COLOR_TEXTO_SUAVE)
	subtitulo.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	vbox.add_child(subtitulo)

	var marco_busqueda := PanelContainer.new()
	marco_busqueda.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	marco_busqueda.add_theme_stylebox_override("panel", _estiloInput(false))
	vbox.add_child(marco_busqueda)

	var fila_busqueda := HBoxContainer.new()
	fila_busqueda.add_theme_constant_override("separation", 8)
	fila_busqueda.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	marco_busqueda.add_child(fila_busqueda)

	_input_busqueda_permisos = LineEdit.new()
	_input_busqueda_permisos.placeholder_text = "Search tools..."
	_input_busqueda_permisos.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_input_busqueda_permisos.add_theme_color_override("font_color", COLOR_TEXTO)
	_input_busqueda_permisos.add_theme_color_override("font_placeholder_color", COLOR_TEXTO_SUAVE)
	_input_busqueda_permisos.add_theme_color_override("caret_color", COLOR_TEXTO)
	var vacio := StyleBoxEmpty.new()
	_input_busqueda_permisos.add_theme_stylebox_override("normal", vacio)
	_input_busqueda_permisos.add_theme_stylebox_override("focus", vacio)
	_input_busqueda_permisos.text_changed.connect(_alCambiarBusquedaPermisos)
	fila_busqueda.add_child(_input_busqueda_permisos)

	var scroll := ScrollContainer.new()
	scroll.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	vbox.add_child(scroll)

	_contenedor_lista_permisos = VBoxContainer.new()
	_contenedor_lista_permisos.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_contenedor_lista_permisos.add_theme_constant_override("separation", 6)
	scroll.add_child(_contenedor_lista_permisos)

	_label_vacio_permisos = Label.new()
	_label_vacio_permisos.text = "No tools registered."
	_label_vacio_permisos.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_label_vacio_permisos.add_theme_color_override("font_color", COLOR_TEXTO_TENUE)
	_label_vacio_permisos.visible = false
	vbox.add_child(_label_vacio_permisos)

func _alCambiarBusquedaPermisos(texto: String) -> void:
	_filtro_permisos = texto.strip_edges().to_lower()
	_refrescarListaPermisos()

const PERMISOS_CONFIG_PATH := "user://permisos_herramientas.cfg"

func _cargarConfigPermisos() -> ConfigFile:
	var cfg := ConfigFile.new()
	cfg.load(PERMISOS_CONFIG_PATH)
	return cfg

func _obtenerHerramientasPermitidas() -> Array:
	var cfg := _cargarConfigPermisos()
	var permitidas = cfg.get_value("permisos", "herramientas_permitidas", [])
	if typeof(permitidas) != TYPE_ARRAY:
		return []
	var salida: Array = []
	for item in permitidas:
		salida.append(str(item))
	return salida

func _guardarHerramientasPermitidas(lista: Array) -> void:
	var cfg := _cargarConfigPermisos()
	cfg.set_value("permisos", "herramientas_permitidas", lista)
	cfg.save(PERMISOS_CONFIG_PATH)
	configuracionGuardada.emit()

func _alternarHerramientaPermitida(nombre: String, habilitado: bool) -> void:
	var permitidas := _obtenerHerramientasPermitidas()
	if habilitado:
		if not (nombre in permitidas):
			permitidas.append(nombre)
	else:
		permitidas.erase(nombre)
	_guardarHerramientasPermitidas(permitidas)

func _refrescarListaPermisos() -> void:
	if not is_instance_valid(_contenedor_lista_permisos):
		return
	for hijo in _contenedor_lista_permisos.get_children():
		hijo.queue_free()

	var nombres: Array = []
	for nombre in _herramientasDisponibles.keys():
		nombres.append(str(nombre))
	nombres.sort()

	var permitidas := _obtenerHerramientasPermitidas()
	var mostradas := 0
	for nombre in nombres:
		if _filtro_permisos != "" and nombre.to_lower().find(_filtro_permisos) == -1:
			var descripcionFiltro: String = str(_herramientasDisponibles[nombre].get("descripcion", ""))
			if descripcionFiltro.to_lower().find(_filtro_permisos) == -1:
				continue
		var habilitado = nombre in permitidas
		var descripcion: String = str(_herramientasDisponibles[nombre].get("descripcion", ""))
		var fila := _crearFilaPermiso(nombre, descripcion, habilitado)
		_contenedor_lista_permisos.add_child(fila)
		mostradas += 1

	if is_instance_valid(_label_vacio_permisos):
		if nombres.is_empty():
			_label_vacio_permisos.text = "No tools registered."
			_label_vacio_permisos.visible = true
		elif mostradas == 0:
			_label_vacio_permisos.text = "No tools match your search."
			_label_vacio_permisos.visible = true
		else:
			_label_vacio_permisos.visible = false

## Pagina "Models": el catalogo de modelos que ofrece Dotti. Pulsar uno lo deja
## como activo y muestra su ficha (contexto, tope de salida, tools,
## razonamiento...). Sin datos de integracion: al usuario no le dicen nada.
func _construirPestanaModelo(contenedor: VBoxContainer) -> void:
	var marco := _crearMarcoPanel()
	marco.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	marco.size_flags_vertical = Control.SIZE_EXPAND_FILL
	contenedor.add_child(marco)

	var vbox := VBoxContainer.new()
	vbox.add_theme_constant_override("separation", 10)
	vbox.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	vbox.size_flags_vertical = Control.SIZE_EXPAND_FILL
	marco.add_child(vbox)

	var titulo := Label.new()
	titulo.text = "Models"
	titulo.add_theme_color_override("font_color", COLOR_TEXTO)
	vbox.add_child(titulo)

	var subtitulo := Label.new()
	subtitulo.text = "Dotti works with the model marked as active. Press one to switch and see what it can do."
	subtitulo.add_theme_color_override("font_color", COLOR_TEXTO_SUAVE)
	subtitulo.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	vbox.add_child(subtitulo)

	var scroll := ScrollContainer.new()
	scroll.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	vbox.add_child(scroll)

	_contenedor_datos_modelo = VBoxContainer.new()
	_contenedor_datos_modelo.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_contenedor_datos_modelo.add_theme_constant_override("separation", 6)
	scroll.add_child(_contenedor_datos_modelo)
	_refrescarDatosModelo()

## Se rehace cada vez que se abre la pagina y cada vez que se elige un modelo,
## para que muestre el vigente aunque el usuario lo haya cambiado en el chat con
## Settings ya abierto.
func _refrescarDatosModelo() -> void:
	if not is_instance_valid(_contenedor_datos_modelo):
		return
	# remove_child ademas de queue_free: el contenedor queda limpio en el acto y
	# un refresco dentro del mismo frame (pulsar un modelo) no duplica filas.
	for hijo in _contenedor_datos_modelo.get_children():
		_contenedor_datos_modelo.remove_child(hijo)
		hijo.queue_free()
	if _apis == null or _apis.proveedores.is_empty():
		_contenedor_datos_modelo.add_child(_crearFilaDato("Models", "None available"))
		return
	for p in _apis.proveedores:
		var id := str(p.get("id", ""))
		var activo := id == _apis.proveedor_actual_id
		_contenedor_datos_modelo.add_child(_crearFilaModelo(str(p.get("nombre", "Unnamed")), activo, id))
	_anexarFichaModelo()

## Deja el modelo pulsado como activo y rehace la pagina con su ficha. Se emite
## configuracionGuardada para que el chat recargue proveedores y actualice sus
## selectores igual que si se hubiera cambiado desde el chat.
func _seleccionarModeloConfig(id: String) -> void:
	if _apis == null or id == "":
		return
	var prov: Dictionary = _apis.obtener_proveedor(id)
	if prov.is_empty():
		return
	_apis.establecer_proveedor_actual(id)
	var config := _apis.obtener_configuracion_chat()
	config["proveedor_id"] = id
	config["modelo"] = str(prov.get("model_id", ""))
	_apis.guardar_configuracion_chat(config)
	_refrescarDatosModelo()
	configuracionGuardada.emit()

## Ficha del modelo vigente: lo que hace falta para elegirlo (contexto, tope de
## salida y lo que acepta y sabe hacer).
##
## Las dos cifras van en casillas y lo demas en etiquetas, no en filas de
## "nombre: si/no": asi el modelo que acepta imagenes, el que no las acepta y el
## que no esta en el catalogo se distinguen de un vistazo, sin leer seis lineas.
## Las etiquetas envuelven solas, que la ventana de Ajustes se puede arrastrar a
## lo ancho y a lo estrecho.
func _anexarFichaModelo() -> void:
	var prov: Dictionary = _apis.obtener_proveedor_actual()
	if prov.is_empty():
		return

	var espacio := Control.new()
	espacio.custom_minimum_size = Vector2(0, 8)
	_contenedor_datos_modelo.add_child(espacio)

	var encabezado := Label.new()
	encabezado.text = str(prov.get("nombre", "Unnamed"))
	encabezado.add_theme_color_override("font_color", COLOR_TEXTO)
	_contenedor_datos_modelo.add_child(encabezado)

	var caps := ChatModelos.capacidades(str(prov.get("model_id", "")))
	if caps.is_empty():
		# Sin ficha en el catalogo no se inventan capacidades.
		_contenedor_datos_modelo.add_child(_crearFilaDato("Capabilities", "Unknown for this model"))
		return

	var ficha := VBoxContainer.new()
	ficha.name = "FichaModelo"
	ficha.add_theme_constant_override("separation", 8)
	ficha.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_contenedor_datos_modelo.add_child(ficha)

	# HFlowContainer en las dos lineas: con una caja rigida, o se salian de la
	# ventana o se quedaban en una columna larguisima al estrecharla.
	var cifras := HFlowContainer.new()
	cifras.name = "CifrasModelo"
	cifras.add_theme_constant_override("h_separation", 8)
	cifras.add_theme_constant_override("v_separation", 8)
	ficha.add_child(cifras)
	cifras.add_child(_crearCasillaDato("Context window", _formato_tokens(int(caps.get("contexto", 0)))))
	cifras.add_child(_crearCasillaDato("Max output", _formato_tokens(int(caps.get("salida_max", 0)))))

	var etiquetas := HFlowContainer.new()
	etiquetas.name = "EtiquetasModelo"
	etiquetas.add_theme_constant_override("h_separation", 6)
	etiquetas.add_theme_constant_override("v_separation", 6)
	ficha.add_child(etiquetas)
	# "Text" va siempre: es lo unico que Dotti manda seguro. Las demas dicen lo
	# que el modelo acepta (Images) o lo que sabe hacer, y la que no tiene se
	# apaga en vez de desaparecer: saber que no acepta imagenes es tan util como
	# saber que si, y una lista que cambia de largo al cambiar de modelo se lee
	# peor.
	etiquetas.add_child(_crearEtiquetaCapacidad("Text", true))
	etiquetas.add_child(_crearEtiquetaCapacidad("Images", bool(caps.get("multimodal", false))))
	etiquetas.add_child(_crearEtiquetaCapacidad("Tools", bool(caps.get("tools", false))))
	etiquetas.add_child(_crearEtiquetaCapacidad("Reasoning", bool(caps.get("thinking", false))))
	etiquetas.add_child(_crearEtiquetaCapacidad("Web search", bool(caps.get("busqueda", false))))
	etiquetas.add_child(_crearEtiquetaCapacidad("Streaming", bool(caps.get("streaming", false))))

	var niveles := _niveles_razonamiento(caps)
	if niveles != "":
		var linea := Label.new()
		linea.name = "NivelesModelo"
		linea.text = "Reasoning levels: " + niveles
		linea.add_theme_color_override("font_color", COLOR_TEXTO_TENUE)
		linea.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		ficha.add_child(linea)

## Casilla de una cifra: el nombre arriba, apagado, y el numero debajo. El contexto
## y el tope de salida son las dos cifras que se comparan al elegir modelo, asi que
## van juntas y separadas del resto por el hueco de la linea de etiquetas.
func _crearCasillaDato(nombre: String, valor: String) -> Control:
	var panel := PanelContainer.new()
	panel.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	panel.custom_minimum_size = Vector2(140, 0)
	panel.add_theme_stylebox_override("panel", _estiloFila())

	var caja := VBoxContainer.new()
	caja.add_theme_constant_override("separation", 2)
	panel.add_child(caja)

	var titulo := Label.new()
	titulo.text = nombre
	titulo.add_theme_color_override("font_color", COLOR_TEXTO_TENUE)
	titulo.text_overrun_behavior = TextServer.OVERRUN_TRIM_ELLIPSIS
	caja.add_child(titulo)

	var numero := Label.new()
	numero.text = valor
	numero.add_theme_color_override("font_color", COLOR_TEXTO)
	numero.text_overrun_behavior = TextServer.OVERRUN_TRIM_ELLIPSIS
	caja.add_child(numero)

	return panel

## Etiqueta de capacidad: la marca (si o no) y el nombre dentro de una pastilla.
## La que el modelo no tiene se apaga -fondo del color del panel y texto tenue- en
## vez de desaparecer.
func _crearEtiquetaCapacidad(nombre: String, disponible: bool) -> Control:
	var panel := PanelContainer.new()
	panel.name = "Etiqueta" + nombre.replace(" ", "")

	var estilo := StyleBoxFlat.new()
	estilo.bg_color = COLOR_PANEL_HOVER if disponible else COLOR_PANEL
	estilo.border_color = COLOR_BORDE if disponible else COLOR_BORDE_SUAVE
	estilo.border_width_left = 1
	estilo.border_width_top = 1
	estilo.border_width_right = 1
	estilo.border_width_bottom = 1
	estilo.corner_radius_top_left = 2
	estilo.corner_radius_top_right = 2
	estilo.corner_radius_bottom_left = 2
	estilo.corner_radius_bottom_right = 2
	estilo.content_margin_left = 9
	estilo.content_margin_right = 9
	estilo.content_margin_top = 3
	estilo.content_margin_bottom = 3
	panel.add_theme_stylebox_override("panel", estilo)

	var fila := HBoxContainer.new()
	fila.add_theme_constant_override("separation", 5)
	panel.add_child(fila)

	var marca := Label.new()
	marca.text = GLIFO_SI if disponible else GLIFO_NO
	marca.add_theme_color_override("font_color", COLOR_TEXTO_SUAVE if disponible else COLOR_TEXTO_TENUE)
	fila.add_child(marca)

	var etiqueta := Label.new()
	etiqueta.text = nombre
	etiqueta.add_theme_color_override("font_color", COLOR_TEXTO if disponible else COLOR_TEXTO_TENUE)
	fila.add_child(etiqueta)

	return panel

## Fila del catalogo: se pulsa entera, no solo una esquina. La marca de la derecha
## distingue el modelo que Dotti esta usando ahora mismo.
func _crearFilaModelo(nombre: String, activo: bool, id: String) -> Control:
	var panel := PanelContainer.new()
	panel.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	var normal := _estiloFila(false)
	var resaltado := _estiloFila(false)
	resaltado.bg_color = COLOR_PANEL_HOVER
	panel.add_theme_stylebox_override("panel", normal)

	var relleno := MarginContainer.new()
	relleno.add_theme_constant_override("margin_left", MARGEN_FILA_H)
	relleno.add_theme_constant_override("margin_right", MARGEN_FILA_H_DERECHA)
	relleno.add_theme_constant_override("margin_top", MARGEN_FILA_V)
	relleno.add_theme_constant_override("margin_bottom", MARGEN_FILA_V)
	relleno.mouse_filter = Control.MOUSE_FILTER_IGNORE
	panel.add_child(relleno)

	var fila := HBoxContainer.new()
	fila.add_theme_constant_override("separation", 10)
	fila.mouse_filter = Control.MOUSE_FILTER_IGNORE
	relleno.add_child(fila)

	var labelNombre := Label.new()
	labelNombre.text = nombre
	labelNombre.add_theme_color_override("font_color", COLOR_TEXTO)
	labelNombre.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	labelNombre.mouse_filter = Control.MOUSE_FILTER_IGNORE
	fila.add_child(labelNombre)

	if activo:
		var marca := Label.new()
		marca.text = "Active"
		marca.add_theme_color_override("font_color", COLOR_ACENTO)
		marca.size_flags_vertical = Control.SIZE_SHRINK_CENTER
		marca.mouse_filter = Control.MOUSE_FILTER_IGNORE
		fila.add_child(marca)

	# Boton transparente encima de la fila: da el clic y el cursor de mano sin
	# tener que maquetar el contenido dentro de un Button. Al no llevar margenes
	# el estilo, cubre la fila entera (el relleno lo pone el MarginContainer).
	var boton := Button.new()
	boton.flat = true
	boton.text = ""
	boton.focus_mode = Control.FOCUS_NONE
	boton.tooltip_text = "Use this model"
	boton.mouse_default_cursor_shape = Control.CURSOR_POINTING_HAND
	boton.pressed.connect(func(): _seleccionarModeloConfig(id))
	boton.mouse_entered.connect(func(): panel.add_theme_stylebox_override("panel", resaltado))
	boton.mouse_exited.connect(func(): panel.add_theme_stylebox_override("panel", normal))
	panel.add_child(boton)

	return panel

# ---------------------------------------------------------------------------
# Pagina "Agents" (P9)
#
# Un agente es un archivo markdown: nombre de archivo, descripcion, modelo y
# lista de herramientas en el frontmatter, y el prompt en el cuerpo. El chat los
# llama escribiendo @nombre. Aqui se crean, se editan y se borran.
#
# De fuera de user://dotti_agentes/ llegan dos clases: los que trae Dotti dentro
# del addon (res://addons/Dotti/data/agentes/) y los del proyecto
# (res://.dotti/agentes/), que son del equipo y van en el repo. Los dos salen en
# la lista con su origen en una pastilla. Los del proyecto no se tocan desde aqui;
# los de fabrica se pueden retocar enteros porque guardar deja copia del usuario.
# ---------------------------------------------------------------------------

func _construirPestanaAgentes(contenedor: VBoxContainer) -> void:
	var marco := _crearMarcoPanel()
	marco.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	marco.size_flags_vertical = Control.SIZE_EXPAND_FILL
	contenedor.add_child(marco)

	var columnas := HBoxContainer.new()
	columnas.add_theme_constant_override("separation", 14)
	columnas.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	columnas.size_flags_vertical = Control.SIZE_EXPAND_FILL
	marco.add_child(columnas)

	# Izquierda: la lista de los que hay.
	var izquierda := VBoxContainer.new()
	izquierda.add_theme_constant_override("separation", 8)
	izquierda.custom_minimum_size = Vector2(240, 0)
	izquierda.size_flags_vertical = Control.SIZE_EXPAND_FILL
	columnas.add_child(izquierda)

	var titulo := Label.new()
	titulo.text = "Agents"
	titulo.add_theme_color_override("font_color", COLOR_TEXTO)
	izquierda.add_child(titulo)

	var subtitulo := Label.new()
	subtitulo.text = "Personas for the chat: type @name in a message to bring one in, or click one here to open it in the form."
	subtitulo.add_theme_color_override("font_color", COLOR_TEXTO_SUAVE)
	subtitulo.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	izquierda.add_child(subtitulo)

	var btn_nuevo := _crearBotonAcento("New agent")
	btn_nuevo.pressed.connect(_nuevoAgente)
	izquierda.add_child(btn_nuevo)

	# Va aqui arriba y no dentro del scroll: con la lista vacia el scroll se
	# queda sin contenido y el aviso acababa pegado al fondo de la columna.
	_label_vacio_agentes = Label.new()
	_label_vacio_agentes.text = "No agents yet. Write one and save it; it shows up in the chat with @name."
	_label_vacio_agentes.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_label_vacio_agentes.add_theme_color_override("font_color", COLOR_TEXTO_TENUE)
	_label_vacio_agentes.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_label_vacio_agentes.visible = false
	izquierda.add_child(_label_vacio_agentes)

	var scroll := ScrollContainer.new()
	scroll.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	izquierda.add_child(scroll)

	_contenedor_lista_agentes = VBoxContainer.new()
	_contenedor_lista_agentes.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_contenedor_lista_agentes.add_theme_constant_override("separation", 6)
	scroll.add_child(_contenedor_lista_agentes)

	# Derecha: el editor del que este seleccionado.
	var derecha := VBoxContainer.new()
	derecha.add_theme_constant_override("separation", 10)
	derecha.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	derecha.size_flags_vertical = Control.SIZE_EXPAND_FILL
	columnas.add_child(derecha)

	# Quien se esta editando. El formulario es el mismo para todos, asi que sin
	# esta linea hay que adivinar de quien son los campos que se tienen delante.
	var cabecera := HBoxContainer.new()
	cabecera.add_theme_constant_override("separation", 8)
	cabecera.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	derecha.add_child(cabecera)

	_label_titulo_agente = Label.new()
	_label_titulo_agente.text = "New agent"
	_label_titulo_agente.add_theme_color_override("font_color", COLOR_TEXTO)
	_label_titulo_agente.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_label_titulo_agente.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	cabecera.add_child(_label_titulo_agente)

	_chip_agente = Label.new()
	# El texto lo pone el formulario al abrir un agente: depende de donde venga.
	_chip_agente.add_theme_color_override("font_color", COLOR_TEXTO_TENUE)
	_chip_agente.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	_chip_agente.visible = false
	cabecera.add_child(_chip_agente)

	# El formulario no cabe entero en la ventana (son cuatro campos y la lista de
	# herramientas), asi que va en un scroll y lo unico que se queda fijo abajo es
	# la fila de acciones: el boton de guardar tiene que estar siempre a la vista.
	var scroll_form := ScrollContainer.new()
	scroll_form.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	scroll_form.size_flags_vertical = Control.SIZE_EXPAND_FILL
	scroll_form.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	derecha.add_child(scroll_form)
	_scroll_formulario_agente = scroll_form

	var formulario := VBoxContainer.new()
	formulario.add_theme_constant_override("separation", 10)
	formulario.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	scroll_form.add_child(formulario)

	_input_nombre_agente = _crearEntradaLinea("reviewer")
	_input_nombre_agente.text_changed.connect(func(_t): _desarmarBorrado())
	formulario.add_child(_crearCampoAgente("Name", _input_nombre_agente,
		"Lowercase letters, digits and hyphens. It is also the file name, so changing it renames the file."))

	_input_descripcion_agente = _crearEntradaLinea("Looks for bugs and never touches a file")
	_input_descripcion_agente.text_changed.connect(func(_t): _desarmarBorrado())
	formulario.add_child(_crearCampoAgente("Description", _input_descripcion_agente,
		"One line saying what this agent is for."))

	_selector_modelo_agente = _crearSelectorOpcionesAgente()
	_selector_modelo_agente.item_selected.connect(func(_i): _desarmarBorrado())
	formulario.add_child(_crearCampoAgente("Model", _selector_modelo_agente,
		"Leave it on the project default unless this agent needs another one."))

	formulario.add_child(_construirCajaHerramientasAgente())

	_input_prompt_agente = TextEdit.new()
	_input_prompt_agente.placeholder_text = "You are a code reviewer. You read everything and change nothing..."
	_input_prompt_agente.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_input_prompt_agente.wrap_mode = TextEdit.LINE_WRAPPING_BOUNDARY
	_input_prompt_agente.scroll_fit_content_height = false
	_input_prompt_agente.custom_minimum_size = Vector2(0, 140)
	_input_prompt_agente.add_theme_color_override("font_color", COLOR_TEXTO)
	_input_prompt_agente.add_theme_color_override("font_placeholder_color", COLOR_TEXTO_TENUE)
	var vacio := StyleBoxEmpty.new()
	_input_prompt_agente.add_theme_stylebox_override("normal", vacio)
	_input_prompt_agente.add_theme_stylebox_override("focus", vacio)
	_input_prompt_agente.add_theme_stylebox_override("read_only", vacio)
	_input_prompt_agente.text_changed.connect(_desarmarBorrado)
	formulario.add_child(_crearCampoAgente("Prompt", _input_prompt_agente,
		"These instructions go into the system prompt, before everything else."))

	var fila_acciones := HBoxContainer.new()
	fila_acciones.add_theme_constant_override("separation", 8)
	fila_acciones.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	derecha.add_child(fila_acciones)

	_label_estado_agente = Label.new()
	_label_estado_agente.text = ""
	_label_estado_agente.add_theme_color_override("font_color", COLOR_TEXTO_TENUE)
	_label_estado_agente.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_label_estado_agente.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	_label_estado_agente.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	fila_acciones.add_child(_label_estado_agente)

	_boton_borrar_agente = _crearBotonSecundario("Delete")
	_boton_borrar_agente.tooltip_text = "Deletes the file. It asks for a second click, and the file goes to the backups."
	_boton_borrar_agente.pressed.connect(_borrarAgenteActual)
	fila_acciones.add_child(_boton_borrar_agente)

	var btn_guardar := _crearBotonAcento("Save agent")
	btn_guardar.pressed.connect(_guardarAgenteDesdeFormulario)
	fila_acciones.add_child(btn_guardar)

	_refrescarListaAgentes()
	_cargarAgenteEnFormulario({})

## Herramientas del agente. Arriba los tres atajos, debajo la linea que dice lo
## que se va a guardar, y la lista entera detras de un desplegable que arranca
## cerrado. Antes la lista de ochenta y pico interruptores estaba siempre a la
## vista: empujaba el prompt fuera de la ventana y no habia forma de saber que
## habia quedado elegido sin contarlos a mano.
func _construirCajaHerramientasAgente() -> Control:
	var caja := VBoxContainer.new()
	caja.add_theme_constant_override("separation", 6)
	caja.size_flags_horizontal = Control.SIZE_EXPAND_FILL

	var cabecera := HBoxContainer.new()
	cabecera.add_theme_constant_override("separation", 6)
	cabecera.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	caja.add_child(cabecera)

	var etiqueta := Label.new()
	etiqueta.text = "Tools"
	etiqueta.add_theme_color_override("font_color", COLOR_TEXTO_SUAVE)
	etiqueta.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	etiqueta.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	cabecera.add_child(etiqueta)

	_preset_todas = _crearBotonPreset("All")
	_preset_todas.tooltip_text = "Every tool Dotti has"
	_preset_todas.pressed.connect(_elegirTodasLasHerramientasAgente)
	cabecera.add_child(_preset_todas)

	_preset_lectura = _crearBotonPreset("Read-only")
	_preset_lectura.tooltip_text = "Only the tools that look, never the ones that change the project"
	_preset_lectura.pressed.connect(_elegirHerramientasLecturaAgente)
	cabecera.add_child(_preset_lectura)

	_preset_ninguna = _crearBotonPreset("None")
	_preset_ninguna.tooltip_text = "No tools at all: the agent only talks"
	_preset_ninguna.pressed.connect(_elegirNingunaHerramientaAgente)
	cabecera.add_child(_preset_ninguna)

	var linea := HBoxContainer.new()
	linea.add_theme_constant_override("separation", 8)
	linea.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	caja.add_child(linea)

	_label_resumen_herramientas_agente = Label.new()
	_label_resumen_herramientas_agente.text = ""
	_label_resumen_herramientas_agente.add_theme_color_override("font_color", COLOR_TEXTO_SUAVE)
	_label_resumen_herramientas_agente.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_label_resumen_herramientas_agente.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	_label_resumen_herramientas_agente.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	linea.add_child(_label_resumen_herramientas_agente)

	_boton_customizar_agente = _crearBotonSecundario("Pick them one by one")
	_boton_customizar_agente.tooltip_text = "Show the whole list to turn tools on and off yourself"
	_boton_customizar_agente.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	_boton_customizar_agente.pressed.connect(
		func(): _mostrarListaHerramientas(not _marco_herramientas_agente.visible))
	linea.add_child(_boton_customizar_agente)

	_marco_herramientas_agente = PanelContainer.new()
	_marco_herramientas_agente.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_marco_herramientas_agente.custom_minimum_size = Vector2(0, 170)
	_marco_herramientas_agente.visible = false
	_marco_herramientas_agente.add_theme_stylebox_override("panel", _estiloInput(false))
	caja.add_child(_marco_herramientas_agente)

	var scroll := ScrollContainer.new()
	scroll.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	_marco_herramientas_agente.add_child(scroll)

	_caja_herramientas_agente = VBoxContainer.new()
	_caja_herramientas_agente.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_caja_herramientas_agente.add_theme_constant_override("separation", 4)
	scroll.add_child(_caja_herramientas_agente)

	return caja

## Boton de atajo. No es un interruptor: el que esta puesto se pinta con fondo
## mas claro y borde de acento, y el resto como un boton normal (los botones de
## categoria de la izquierda son los unicos interruptores de la ventana, y
## mezclarlos confunde). Los dos estilos se guardan en el propio boton.
func _crearBotonPreset(texto: String) -> Button:
	var boton := _crearBoton(texto, COLOR_PANEL, COLOR_BORDE_SUAVE, COLOR_TEXTO_SUAVE)
	boton.focus_mode = Control.FOCUS_NONE
	boton.mouse_default_cursor_shape = Control.CURSOR_POINTING_HAND
	var elegido := (boton.get_theme_stylebox("normal") as StyleBoxFlat).duplicate() as StyleBoxFlat
	elegido.bg_color = COLOR_PANEL_HOVER
	elegido.border_color = COLOR_ACENTO
	var elegidoHover := elegido.duplicate() as StyleBoxFlat
	elegidoHover.bg_color = COLOR_PANEL_HOVER.lightened(0.05)
	boton.set_meta("estilo_normal", boton.get_theme_stylebox("normal"))
	boton.set_meta("estilo_hover", boton.get_theme_stylebox("hover"))
	boton.set_meta("estilo_puesto", elegido)
	boton.set_meta("estilo_puesto_hover", elegidoHover)
	return boton

## Abre o cierra la lista de interruptores. El texto del boton dice lo que hace
## el clic siguiente, que es lo unico que se ve del estado. Al abrir se baja el
## scroll hasta ella: la caja nace fuera de la parte visible del formulario, y sin
## esto el boton parece no hacer nada.
func _mostrarListaHerramientas(abierta: bool) -> void:
	if not is_instance_valid(_marco_herramientas_agente):
		return
	_marco_herramientas_agente.visible = abierta
	if is_instance_valid(_boton_customizar_agente):
		_boton_customizar_agente.text = "Hide the list" if abierta else "Pick them one by one"
	if abierta and is_instance_valid(_scroll_formulario_agente):
		_scroll_formulario_agente.ensure_control_visible(_marco_herramientas_agente)

## La linea que dice lo que se va a guardar, con la cuenta. Es lo unico que hay
## debajo de los atajos, asi que tiene que decir la verdad tambien cuando la
## seleccion es a mano y no es ninguno de los tres.
func _refrescarResumenHerramientasAgente() -> void:
	if not is_instance_valid(_label_resumen_herramientas_agente):
		return
	var total := _todosLosNombresDeHerramientas().size()
	var cuenta := _herramientas_agente_elegidas.size()
	var soloLectura := cuenta > 0 and cuenta < total and _esSeleccionSoloLectura()
	if total == 0:
		_label_resumen_herramientas_agente.text = "No tools are registered yet."
	elif cuenta == 0:
		_label_resumen_herramientas_agente.text = "No tools: the agent only talks."
	elif cuenta == total:
		_label_resumen_herramientas_agente.text = "All %d tools." % total
	elif soloLectura:
		_label_resumen_herramientas_agente.text = "The %d tools that only look." % cuenta
	else:
		_label_resumen_herramientas_agente.text = "%d of %d tools." % [cuenta, total]
	# A lo sumo uno de los tres queda marcado: las tres condiciones no pueden
	# ser ciertas a la vez (ni con "todas" ni con "ninguna" hay lectura sola).
	_marcarPreset(_preset_todas, total > 0 and cuenta == total)
	_marcarPreset(_preset_lectura, soloLectura)
	_marcarPreset(_preset_ninguna, cuenta == 0)

func _marcarPreset(boton: Button, puesto: bool) -> void:
	if not is_instance_valid(boton):
		return
	var texto := COLOR_TEXTO if puesto else COLOR_TEXTO_SUAVE
	boton.add_theme_color_override("font_color", texto)
	boton.add_theme_color_override("font_hover_color", Color(1, 1, 1, 1).lerp(texto, 0.3))
	if puesto:
		boton.add_theme_stylebox_override("normal", boton.get_meta("estilo_puesto"))
		boton.add_theme_stylebox_override("hover", boton.get_meta("estilo_puesto_hover"))
	else:
		boton.add_theme_stylebox_override("normal", boton.get_meta("estilo_normal"))
		boton.add_theme_stylebox_override("hover", boton.get_meta("estilo_hover"))

## True si lo elegido es exactamente el juego de herramientas que solo miran.
func _esSeleccionSoloLectura() -> bool:
	var lectura := _herramientasDeRegla(Agentes.SOLO_LECTURA)
	if lectura.is_empty() or _herramientas_agente_elegidas.size() != lectura.size():
		return false
	for nombre in _herramientas_agente_elegidas:
		if not lectura.has(nombre):
			return false
	return true

## True si lo elegido es uno de los tres atajos. Se usa al abrir un agente: si su
## lista es a mano, el desplegable se abre para que se vea cual es.
func _esSeleccionPreset() -> bool:
	var total := _todosLosNombresDeHerramientas().size()
	var cuenta := _herramientas_agente_elegidas.size()
	return cuenta == 0 or cuenta == total or _esSeleccionSoloLectura()

## Lista con interruptor por herramienta registrada. Igual que la de permisos,
## pero aqui la seleccion vive en _herramientas_agente_elegidas hasta que se
## guarda el agente.
func _refrescarHerramientasAgente() -> void:
	if not is_instance_valid(_caja_herramientas_agente):
		return
	for hijo in _caja_herramientas_agente.get_children():
		_caja_herramientas_agente.remove_child(hijo)
		hijo.queue_free()
	var nombres: Array = []
	for nombre in _herramientasDisponibles.keys():
		nombres.append(str(nombre))
	nombres.sort()
	for nombre in nombres:
		_caja_herramientas_agente.add_child(
			_crearFilaHerramientaAgente(nombre, _herramientas_agente_elegidas.has(nombre)))
	_refrescarResumenHerramientasAgente()

func _crearFilaHerramientaAgente(nombre: String, activada: bool) -> Control:
	var fila := HBoxContainer.new()
	fila.add_theme_constant_override("separation", 8)
	fila.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	var etiqueta := Label.new()
	etiqueta.text = nombre
	etiqueta.add_theme_color_override("font_color", COLOR_TEXTO)
	etiqueta.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	etiqueta.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	var detalle: Dictionary = _herramientasDisponibles.get(nombre, {})
	etiqueta.tooltip_text = str(detalle.get("descripcion", ""))
	fila.add_child(etiqueta)
	var interruptor := _crearInterruptor(activada)
	interruptor.disabled = _agenteBloqueado()
	interruptor.toggled.connect(func(encendido: bool): _alternarHerramientaAgente(nombre, encendido))
	fila.add_child(interruptor)
	return fila

func _alternarHerramientaAgente(nombre: String, encendido: bool) -> void:
	if encendido:
		if not _herramientas_agente_elegidas.has(nombre):
			_herramientas_agente_elegidas.append(nombre)
	else:
		_herramientas_agente_elegidas.erase(nombre)
	_actualizarEstadoAgente("")
	_refrescarResumenHerramientasAgente()
	_desarmarBorrado()

func _elegirTodasLasHerramientasAgente() -> void:
	_ponerHerramientasAgente(_todosLosNombresDeHerramientas())

func _elegirHerramientasLecturaAgente() -> void:
	var soloLectura: Array = []
	for nombre in Agentes.HERRAMIENTAS_SOLO_LECTURA:
		if _herramientasDisponibles.has(str(nombre)):
			soloLectura.append(str(nombre))
	_ponerHerramientasAgente(soloLectura)

func _elegirNingunaHerramientaAgente() -> void:
	_ponerHerramientasAgente([])

func _ponerHerramientasAgente(nombres: Array) -> void:
	_herramientas_agente_elegidas = nombres.duplicate()
	_refrescarHerramientasAgente()

func _todosLosNombresDeHerramientas() -> Array:
	var nombres: Array = []
	for nombre in _herramientasDisponibles.keys():
		nombres.append(str(nombre))
	nombres.sort()
	return nombres

# ---------------------------------------------------------------------------
# Lista y formulario
# ---------------------------------------------------------------------------

func _refrescarListaAgentes() -> void:
	if not is_instance_valid(_contenedor_lista_agentes):
		return
	for hijo in _contenedor_lista_agentes.get_children():
		_contenedor_lista_agentes.remove_child(hijo)
		hijo.queue_free()
	if _apis != null:
		_apis.cargar_proveedores()
	_refrescarModelosAgente()
	var agentes := Agentes.listar()
	for agente in agentes:
		_contenedor_lista_agentes.add_child(_crearFilaAgente(agente))
	if is_instance_valid(_label_vacio_agentes):
		_label_vacio_agentes.visible = agentes.is_empty()
		_label_vacio_agentes.text = "No agents yet. Write one and save it; it shows up in the chat with @name."

func _crearFilaAgente(agente: Dictionary) -> Control:
	var nombre := str(agente.get("nombre", ""))
	var elegido := nombre == _agente_en_edicion and nombre != ""
	var panel := PanelContainer.new()
	panel.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	var normal := _estiloFila(false)
	var resaltado := _estiloFila(false)
	resaltado.bg_color = COLOR_PANEL_HOVER
	# El que se esta editando lleva el borde de acento: es lo que ata la fila con
	# el formulario de la derecha, que si no parecen dos cosas sueltas.
	if elegido:
		normal.border_color = COLOR_ACENTO
		resaltado.border_color = COLOR_ACENTO
	panel.add_theme_stylebox_override("panel", normal)

	var relleno := MarginContainer.new()
	relleno.add_theme_constant_override("margin_left", MARGEN_FILA_H)
	relleno.add_theme_constant_override("margin_right", MARGEN_FILA_H_DERECHA)
	relleno.add_theme_constant_override("margin_top", MARGEN_FILA_V)
	relleno.add_theme_constant_override("margin_bottom", MARGEN_FILA_V)
	relleno.mouse_filter = Control.MOUSE_FILTER_IGNORE
	panel.add_child(relleno)

	var caja := VBoxContainer.new()
	caja.add_theme_constant_override("separation", 2)
	caja.mouse_filter = Control.MOUSE_FILTER_IGNORE
	relleno.add_child(caja)

	var fila := HBoxContainer.new()
	fila.add_theme_constant_override("separation", 8)
	fila.mouse_filter = Control.MOUSE_FILTER_IGNORE
	caja.add_child(fila)

	var etiqueta := Label.new()
	etiqueta.text = "@" + nombre
	etiqueta.add_theme_color_override("font_color", COLOR_TEXTO)
	etiqueta.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	etiqueta.mouse_filter = Control.MOUSE_FILTER_IGNORE
	if elegido:
		etiqueta.add_theme_color_override("font_color", COLOR_ACENTO)
	fila.add_child(etiqueta)

	var etiquetaOrigen := Agentes.etiquetaOrigen(agente)
	if etiquetaOrigen != "":
		# El de fuera lleva su origen en una pastilla en vez del resumen de sus
		# herramientas: lo que hay que saber de el de un vistazo es que no es tuyo, y
		# una pastilla se lee como un dato de la fila y no como otra frase.
		fila.add_child(_crearPastillaOrigen(etiquetaOrigen))
	else:
		var marca := Label.new()
		marca.text = Agentes.etiquetaHerramientas(agente)
		marca.add_theme_color_override("font_color", COLOR_TEXTO_TENUE)
		marca.size_flags_vertical = Control.SIZE_SHRINK_CENTER
		marca.mouse_filter = Control.MOUSE_FILTER_IGNORE
		fila.add_child(marca)

	var descripcion := str(agente.get("descripcion", "")).strip_edges()
	if descripcion != "":
		var sub := Label.new()
		sub.text = descripcion
		sub.add_theme_color_override("font_color", COLOR_TEXTO_SUAVE)
		sub.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		sub.mouse_filter = Control.MOUSE_FILTER_IGNORE
		caja.add_child(sub)

	var boton := Button.new()
	boton.flat = true
	boton.text = ""
	boton.focus_mode = Control.FOCUS_NONE
	# El tooltip dice que pasa al abrirlo: de los de fuera no se guarda en su sitio.
	match Agentes.etiquetaOrigen(agente):
		"Built-in":
			boton.tooltip_text = "Open it: saving leaves a copy of your own"
		"Project":
			boton.tooltip_text = "Open it: it belongs to the project, so it is read-only here"
		_:
			boton.tooltip_text = "Edit this agent"
	boton.mouse_default_cursor_shape = Control.CURSOR_POINTING_HAND
	boton.pressed.connect(func(): _cargarAgenteEnFormulario(agente))
	boton.mouse_entered.connect(func(): panel.add_theme_stylebox_override("panel", resaltado))
	boton.mouse_exited.connect(func(): panel.add_theme_stylebox_override("panel", normal))
	panel.add_child(boton)
	return panel

## Pastilla con el origen de un agente ("Built-in", "Project"): del alto de una
## fila de la lista, para que no la descuadre.
func _crearPastillaOrigen(texto: String) -> Control:
	var panel := PanelContainer.new()
	panel.name = "PastillaOrigen"
	panel.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	panel.mouse_filter = Control.MOUSE_FILTER_IGNORE

	var estilo := StyleBoxFlat.new()
	estilo.bg_color = COLOR_PANEL_HOVER
	estilo.border_color = COLOR_BORDE
	estilo.set_border_width_all(1)
	estilo.set_corner_radius_all(2)
	estilo.content_margin_left = 6
	estilo.content_margin_right = 6
	estilo.content_margin_top = 1
	estilo.content_margin_bottom = 1
	panel.add_theme_stylebox_override("panel", estilo)

	var etiqueta := Label.new()
	etiqueta.text = texto
	etiqueta.add_theme_color_override("font_color", COLOR_TEXTO_SUAVE)
	etiqueta.mouse_filter = Control.MOUSE_FILTER_IGNORE
	panel.add_child(etiqueta)
	return panel

## Si el agente abierto se puede cambiar en su sitio. Solo los del proyecto no:
## viven en el repo del equipo y desde aqui se leen.
func _agenteBloqueado() -> bool:
	return _agente_origen == "proyecto"

## Lo que dice el cartel de la cabecera cuando el agente no es del usuario: de
## donde viene y que se puede hacer con el. Vacio para los propios.
func _textoOrigenAgente() -> String:
	match _agente_origen:
		"proyecto":
			return "From the project: read-only here"
		"incluido":
			return "Built-in: saving keeps your own copy"
	return ""

## Lleva un agente al formulario. {} deja el formulario en blanco y en modo
## "nuevo"; un agente del proyecto se ensena pero no se deja guardar, y uno de
## fabrica se puede retocar entero porque guardar deja una copia del usuario.
func _cargarAgenteEnFormulario(agente: Dictionary) -> void:
	if not is_instance_valid(_input_nombre_agente):
		return
	_agente_en_edicion = str(agente.get("nombre", ""))
	_agente_original = _agente_en_edicion
	_agente_origen = str(agente.get("origen", ""))
	var nuevo := agente.is_empty()
	var bloqueado := _agenteBloqueado()
	_input_nombre_agente.text = _agente_en_edicion
	# El nombre se puede cambiar siempre que el agente se pueda guardar: es el
	# nombre del archivo, y guardar con otro renombra. Del proyecto no se toca
	# nada, y de los de fabrica se guarda una copia con el nombre que se escriba.
	_input_nombre_agente.editable = not bloqueado
	_input_descripcion_agente.text = str(agente.get("descripcion", ""))
	_input_prompt_agente.text = str(agente.get("prompt", ""))
	_seleccionarModeloEnSelector(str(agente.get("modelo", "")))
	var regla := str(agente.get("herramientas", Agentes.TODAS))
	if nuevo:
		_ponerHerramientasAgente(_todosLosNombresDeHerramientas())
	else:
		_ponerHerramientasAgente(_herramientasDeRegla(regla))
	_actualizarEstadoAgente("")
	_desarmarBorrado()
	if is_instance_valid(_label_titulo_agente):
		_label_titulo_agente.text = "New agent" if nuevo else "@" + _agente_en_edicion
	if is_instance_valid(_chip_agente):
		var chapa := _textoOrigenAgente()
		_chip_agente.text = chapa
		_chip_agente.visible = chapa != ""
	if is_instance_valid(_boton_borrar_agente):
		_boton_borrar_agente.disabled = nuevo or _agente_origen != "usuario"
	if is_instance_valid(_input_prompt_agente):
		_input_prompt_agente.editable = not bloqueado
	if is_instance_valid(_input_descripcion_agente):
		_input_descripcion_agente.editable = not bloqueado
	# De un agente del proyecto no se eligen herramientas: se leen. De uno de
	# fabrica si, que se esta escribiendo la copia propia.
	if is_instance_valid(_preset_todas):
		_preset_todas.disabled = bloqueado
		_preset_lectura.disabled = bloqueado
		_preset_ninguna.disabled = bloqueado
	if is_instance_valid(_boton_customizar_agente):
		_boton_customizar_agente.disabled = bloqueado
	# Con una lista a mano (ni todas, ni ninguna, ni las de solo leer) el
	# desplegable se abre solo: es la unica forma de ver que hay dentro.
	_mostrarListaHerramientas(not bloqueado and not _esSeleccionPreset())

## Nombres de herramienta que implica una regla del archivo.
func _herramientasDeRegla(regla: String) -> Array:
	match regla:
		Agentes.NINGUNA:
			return []
		Agentes.SOLO_LECTURA:
			var soloLectura: Array = []
			for nombre in Agentes.HERRAMIENTAS_SOLO_LECTURA:
				if _herramientasDisponibles.has(str(nombre)):
					soloLectura.append(str(nombre))
			return soloLectura
		Agentes.TODAS:
			return _todosLosNombresDeHerramientas()
	var nombres: Array = []
	for item in regla.split(",", false):
		var nombre := str(item).strip_edges()
		if nombre != "" and _herramientasDisponibles.has(nombre):
			nombres.append(nombre)
	return nombres

func _nuevoAgente() -> void:
	_cargarAgenteEnFormulario({})
	_actualizarEstadoAgente("New agent. Give it a name and save it.")
	_refrescarListaAgentes()

func _guardarAgenteDesdeFormulario() -> void:
	if _agenteBloqueado():
		_actualizarEstadoAgente("This agent belongs to the project (res://.dotti/agentes). Edit the file there.", true)
		return
	var nombre := _input_nombre_agente.text.strip_edges()
	var problema := Agentes.problemaDeNombre(nombre)
	if problema != "":
		_actualizarEstadoAgente(problema, true)
		return
	if _nombreDeOtroAgente(nombre):
		_actualizarEstadoAgente("There is already an agent with that name. Delete it first or pick another name.", true)
		return
	var regla := _reglaDesdeSeleccion()
	var error := Agentes.guardar(nombre, _input_descripcion_agente.text, _modeloElegidoAgente(),
		regla, _input_prompt_agente.text)
	if error != "":
		_actualizarEstadoAgente(error, true)
		return
	# El nombre es el archivo. Guardar con otro nombre deja el archivo viejo al
	# lado, asi que el renombrado se lleva el viejo (y lo deja en las copias).
	# Solo se renombra lo que era del usuario: de un agente de fabrica no hay
	# archivo viejo que llevarse.
	var anterior := _agente_original
	var eraCopia := _agente_origen == "incluido"
	var renombrado := anterior != "" and anterior != nombre and _agente_origen == "usuario"
	if renombrado:
		Agentes.borrar(anterior)
	# Volver a leerlo deja el formulario en su estado nuevo: ya es un agente del
	# usuario, con su nombre editable y su boton de borrar.
	_cargarAgenteEnFormulario(Agentes.cargar(nombre))
	_refrescarListaAgentes()
	if renombrado:
		_actualizarEstadoAgente("Saved as @%s. The old @%s is in the backups." % [nombre, anterior])
	elif eraCopia:
		_actualizarEstadoAgente("Saved to " + Agentes.RUTA_AGENTES + nombre + Agentes.EXTENSION + ", as a copy of the built-in one.")
	else:
		_actualizarEstadoAgente("Saved to " + Agentes.RUTA_AGENTES + nombre + Agentes.EXTENSION)
	configuracionGuardada.emit()

## Si el nombre ya lo tiene un agente del usuario. Al del proyecto y al de fabrica
## se les puede pasar por encima con uno propio -es la regla de precedencia, y el
## de abajo no se pierde: sigue en su archivo-, pero a otro agente del usuario no,
## que escribir encima de el es perderlo.
func _nombreDeOtroAgente(nombre: String) -> bool:
	if nombre == _agente_en_edicion:
		return false
	return str(Agentes.cargar(nombre).get("origen", "")) == "usuario"

## La forma corta del campo "tools" cuando la seleccion coincide con un atajo.
func _reglaDesdeSeleccion() -> String:
	var todas := _todosLosNombresDeHerramientas()
	if _herramientas_agente_elegidas.is_empty():
		return Agentes.NINGUNA
	if _herramientas_agente_elegidas.size() == todas.size():
		return Agentes.TODAS
	if _esSeleccionSoloLectura():
		return Agentes.SOLO_LECTURA
	var nombres: Array = _herramientas_agente_elegidas.duplicate()
	nombres.sort()
	return ", ".join(nombres)

## Borrar un agente pide dos clics: el archivo se va, y aunque quede copia en las
## copias de seguridad, perder un agente por rozar el boton no tiene vuelta.
func _borrarAgenteActual() -> void:
	# Solo se borra lo que es del usuario: los del proyecto y los de fabrica no
	# tienen archivo propio que borrar.
	if _agente_en_edicion == "" or _agente_origen != "usuario":
		return
	if not _borrado_armado:
		_armarBorrado()
		return
	var borrado := _agente_en_edicion
	if not Agentes.borrar(borrado):
		_desarmarBorrado()
		_actualizarEstadoAgente("The agent file could not be deleted.", true)
		return
	_cargarAgenteEnFormulario({})
	_refrescarListaAgentes()
	_actualizarEstadoAgente("Agent @%s deleted. A copy is in the backups." % borrado)
	configuracionGuardada.emit()

func _armarBorrado() -> void:
	_borrado_armado = true
	if is_instance_valid(_boton_borrar_agente):
		_boton_borrar_agente.text = "Delete for good?"
		_boton_borrar_agente.add_theme_color_override("font_color", COLOR_PELIGRO)
	_actualizarEstadoAgente("Deleting @%s. Click the same button again to go ahead." % _agente_en_edicion, true)

## Desarma el borrado. Lo llama cualquier otra cosa que se toque en el
## formulario, para que el segundo clic no llegue cuando ya no se acuerda de esto.
func _desarmarBorrado() -> void:
	if not _borrado_armado:
		return
	_borrado_armado = false
	if is_instance_valid(_boton_borrar_agente):
		_boton_borrar_agente.text = "Delete"
		_boton_borrar_agente.add_theme_color_override("font_color", COLOR_TEXTO_SUAVE)
	_actualizarEstadoAgente("")

func _modeloElegidoAgente() -> String:
	if not is_instance_valid(_selector_modelo_agente):
		return ""
	var id := _selector_modelo_agente.get_selected_id()
	return "" if id < 0 else str(id)

## Selector de modelo: el primero es "el de siempre" (vacio en el archivo) y
## detras van los modelos del catalogo, que son los que Dotti sabe usar.
func _crearSelectorOpcionesAgente() -> OptionButton:
	var selector := OptionButton.new()
	selector.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	selector.add_theme_color_override("font_color", COLOR_TEXTO)
	selector.add_theme_stylebox_override("normal", _estiloInput(false))
	selector.add_theme_stylebox_override("hover", _estiloInput(true))
	selector.add_theme_stylebox_override("focus", _estiloInput(true))
	selector.add_theme_stylebox_override("pressed", _estiloInput(true))
	ChatUIFactory.estilizarPopupMenu(selector.get_popup())
	return selector

func _refrescarModelosAgente() -> void:
	if not is_instance_valid(_selector_modelo_agente):
		return
	var elegido := _modeloElegidoAgente()
	_selector_modelo_agente.clear()
	_selector_modelo_agente.add_item("Project default")
	_selector_modelo_agente.set_item_metadata(0, "")
	if _apis != null:
		for prov in _apis.proveedores:
			var modelo := str(prov.get("model_id", ""))
			if modelo == "":
				continue
			var indice := _selector_modelo_agente.item_count
			_selector_modelo_agente.add_item("%s (%s)" % [str(prov.get("nombre", "Unnamed")), modelo])
			_selector_modelo_agente.set_item_metadata(indice, modelo)
	_seleccionarModeloEnSelector(elegido)

func _seleccionarModeloEnSelector(modelo: String) -> void:
	if not is_instance_valid(_selector_modelo_agente):
		return
	var elegido := 0
	for i in range(_selector_modelo_agente.item_count):
		if str(_selector_modelo_agente.get_item_metadata(i)) == modelo:
			elegido = i
			break
	_selector_modelo_agente.select(elegido)

## Linea de texto con el estilo de la ventana, sin marco (el marco lo pone
## _crearCampoAgente).
func _crearEntradaLinea(marcador: String) -> LineEdit:
	var campo := LineEdit.new()
	campo.placeholder_text = marcador
	campo.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	campo.add_theme_color_override("font_color", COLOR_TEXTO)
	campo.add_theme_color_override("font_placeholder_color", COLOR_TEXTO_SUAVE)
	campo.add_theme_color_override("caret_color", COLOR_TEXTO)
	var vacio := StyleBoxEmpty.new()
	campo.add_theme_stylebox_override("normal", vacio)
	campo.add_theme_stylebox_override("focus", vacio)
	campo.add_theme_stylebox_override("read_only", vacio)
	return campo

## Etiqueta encima del control y, si la hay, una linea de ayuda debajo. Los
## campos de texto van dentro del mismo marco de la ventana.
func _crearCampoAgente(nombre: String, control: Control, ayuda: String = "") -> Control:
	var caja := VBoxContainer.new()
	caja.add_theme_constant_override("separation", 4)
	caja.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	var etiqueta := Label.new()
	etiqueta.text = nombre
	etiqueta.add_theme_color_override("font_color", COLOR_TEXTO_SUAVE)
	caja.add_child(etiqueta)
	if control is LineEdit or control is TextEdit:
		var marco := PanelContainer.new()
		marco.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		marco.size_flags_vertical = Control.SIZE_EXPAND_FILL if control is TextEdit else Control.SIZE_FILL
		marco.add_theme_stylebox_override("panel", _estiloInput(false))
		marco.add_child(control)
		caja.add_child(marco)
	else:
		caja.add_child(control)
	if ayuda != "":
		var tip := Label.new()
		tip.text = ayuda
		tip.add_theme_color_override("font_color", COLOR_TEXTO_TENUE)
		tip.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		caja.add_child(tip)
	return caja

## La linea de estado es solo para mensajes. La cuenta de herramientas que
## ensenaba antes vive ahora en el resumen de la seccion de herramientas, que es
## donde se eligen.
func _actualizarEstadoAgente(mensaje: String, error: bool = false) -> void:
	if not is_instance_valid(_label_estado_agente):
		return
	_label_estado_agente.text = mensaje
	_label_estado_agente.add_theme_color_override("font_color", COLOR_PELIGRO if error else COLOR_TEXTO_TENUE)

## Los niveles de razonamiento del modelo en una linea ("Off, High, Max"), o ""
## si el modelo no razona. La ficha le pone delante "Reasoning levels: "; la
## etiqueta de Reasoning ya dice el si o el no.
func _niveles_razonamiento(caps: Dictionary) -> String:
	if not bool(caps.get("thinking", false)):
		return ""
	var etiquetas: Array = []
	for nivel in caps.get("niveles", []):
		match str(nivel):
			"none": etiquetas.append("Off")
			"high": etiquetas.append("High")
			"max": etiquetas.append("Max")
			_: etiquetas.append(str(nivel))
	return ", ".join(etiquetas)

## "1000000" -> "1M tokens". El selector usaba el formato compacto ("1M ctx");
## aqui hay espacio para escribirlo entero.
func _formato_tokens(cantidad: int) -> String:
	if cantidad <= 0:
		return "Unknown"
	if cantidad >= 1000000:
		return "%sM tokens" % _numero_corto(float(cantidad) / 1000000.0)
	if cantidad >= 1000:
		return "%sK tokens" % _numero_corto(float(cantidad) / 1000.0)
	return "%d tokens" % cantidad

## "1.0" -> "1" (y deja "1.5" como esta).
func _numero_corto(valor: float) -> String:
	var texto := "%.1f" % valor
	if texto.ends_with(".0"):
		texto = texto.left(texto.length() - 2)
	return texto

## Fila de solo lectura: nombre a la izquierda, dato a la derecha.
func _crearFilaDato(nombre: String, valor: String) -> Control:
	var panel := PanelContainer.new()
	panel.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	panel.add_theme_stylebox_override("panel", _estiloFila())

	var fila := HBoxContainer.new()
	fila.add_theme_constant_override("separation", 10)
	fila.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	panel.add_child(fila)

	var labelNombre := Label.new()
	labelNombre.text = nombre
	labelNombre.add_theme_color_override("font_color", COLOR_TEXTO_SUAVE)
	labelNombre.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	fila.add_child(labelNombre)

	var labelValor := Label.new()
	labelValor.text = valor
	labelValor.add_theme_color_override("font_color", COLOR_TEXTO)
	labelValor.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	labelValor.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	labelValor.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	fila.add_child(labelValor)

	return panel

## El relleno va en el estilo, no en el contenido, para que las filas de solo
## lectura queden iguales en toda la ventana. Las filas pulsables lo piden sin
## margenes: un boton superpuesto se ajusta al area de contenido del panel, y con
## margenes la franja de relleno se quedaria sin recibir el clic.
func _estiloFila(con_margenes: bool = true) -> StyleBoxFlat:
	var estilo := StyleBoxFlat.new()
	estilo.bg_color = COLOR_PANEL_ALT
	estilo.border_color = COLOR_BORDE_SUAVE
	estilo.border_width_left = 1
	estilo.border_width_top = 1
	estilo.border_width_right = 1
	estilo.border_width_bottom = 1
	estilo.corner_radius_top_left = 2
	estilo.corner_radius_top_right = 2
	estilo.corner_radius_bottom_left = 2
	estilo.corner_radius_bottom_right = 2
	if con_margenes:
		estilo.content_margin_left = MARGEN_FILA_H
		estilo.content_margin_right = MARGEN_FILA_H_DERECHA
		estilo.content_margin_top = MARGEN_FILA_V
		estilo.content_margin_bottom = MARGEN_FILA_V
	return estilo

func _crearFilaPermiso(nombre: String, descripcion: String, habilitado: bool) -> Control:
	var panel := PanelContainer.new()
	panel.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	panel.add_theme_stylebox_override("panel", _estiloFila())

	var fila := HBoxContainer.new()
	fila.add_theme_constant_override("separation", 10)
	fila.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	panel.add_child(fila)

	var info := VBoxContainer.new()
	info.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	info.add_theme_constant_override("separation", 2)
	fila.add_child(info)

	var labelNombre := Label.new()
	labelNombre.text = nombre
	labelNombre.add_theme_color_override("font_color", COLOR_TEXTO)
	info.add_child(labelNombre)

	if descripcion.strip_edges() != "":
		var labelDescripcion := Label.new()
		labelDescripcion.text = descripcion
		labelDescripcion.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		labelDescripcion.add_theme_color_override("font_color", COLOR_TEXTO_SUAVE)
		info.add_child(labelDescripcion)

	var toggle := _crearInterruptor(habilitado)
	toggle.toggled.connect(func(pulsado): _alternarHerramientaPermitida(nombre, pulsado))
	fila.add_child(toggle)

	return panel

func _crearInterruptor(activado: bool) -> Button:
	var boton := Button.new()
	boton.toggle_mode = true
	boton.button_pressed = activado
	boton.focus_mode = Control.FOCUS_NONE
	boton.mouse_default_cursor_shape = Control.CURSOR_POINTING_HAND
	var anchoTrack := 44
	var altoTrack := 24
	var ladoPerilla := 14
	var margenPerilla := 5.0

	boton.custom_minimum_size = Vector2(anchoTrack, altoTrack)
	boton.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	boton.text = ""

	var apagado := StyleBoxFlat.new()
	apagado.bg_color = Color(0.10, 0.10, 0.10, 1.0)
	apagado.border_color = COLOR_BORDE
	apagado.border_width_left = 1
	apagado.border_width_top = 1
	apagado.border_width_right = 1
	apagado.border_width_bottom = 1
	apagado.corner_radius_top_left = altoTrack / 2
	apagado.corner_radius_top_right = altoTrack / 2
	apagado.corner_radius_bottom_left = altoTrack / 2
	apagado.corner_radius_bottom_right = altoTrack / 2

	var encendido := apagado.duplicate() as StyleBoxFlat
	encendido.bg_color = Color(0.82, 0.82, 0.82, 1.0)
	encendido.border_color = Color(0.9, 0.9, 0.9, 1.0)

	boton.add_theme_stylebox_override("normal", apagado)
	boton.add_theme_stylebox_override("hover", apagado)
	boton.add_theme_stylebox_override("focus", apagado)
	boton.add_theme_stylebox_override("pressed", encendido)
	boton.add_theme_stylebox_override("hover_pressed", encendido)
	boton.add_theme_stylebox_override("disabled", apagado)

	# La perilla es hija del boton y un Button no coloca a sus hijos, asi que se
	# le da sitio a mano y se rehace al cambiar de estado o de tamano. Con los
	# margenes del estilo no sale: la perilla se quedaba pegada a la esquina y con
	# el alto entero del boton, que es lo que hacia que el interruptor se viera
	# como dos manchas.
	var perilla := Panel.new()
	perilla.name = "Perilla"
	perilla.custom_minimum_size = Vector2(ladoPerilla, ladoPerilla)
	perilla.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var estiloPerillaOff := StyleBoxFlat.new()
	estiloPerillaOff.bg_color = Color(0.55, 0.55, 0.55, 1.0)
	estiloPerillaOff.corner_radius_top_left = ladoPerilla / 2
	estiloPerillaOff.corner_radius_top_right = ladoPerilla / 2
	estiloPerillaOff.corner_radius_bottom_left = ladoPerilla / 2
	estiloPerillaOff.corner_radius_bottom_right = ladoPerilla / 2
	var estiloPerillaOn := estiloPerillaOff.duplicate() as StyleBoxFlat
	estiloPerillaOn.bg_color = Color(0.12, 0.12, 0.12, 1.0)
	perilla.add_theme_stylebox_override("panel", estiloPerillaOn if activado else estiloPerillaOff)
	boton.add_child(perilla)

	var colocarPerilla := func() -> void:
		if not is_instance_valid(perilla) or not is_instance_valid(boton):
			return
		var lado := float(ladoPerilla)
		var y := (boton.size.y - lado) * 0.5
		var x := boton.size.x - lado - margenPerilla if boton.button_pressed else margenPerilla
		perilla.position = Vector2(x, y)
		perilla.size = Vector2(lado, lado)

	boton.resized.connect(colocarPerilla)
	boton.toggled.connect(func(pulsado: bool):
		if is_instance_valid(perilla):
			perilla.add_theme_stylebox_override("panel",
				estiloPerillaOn if pulsado else estiloPerillaOff)
		colocarPerilla.call()
	)
	colocarPerilla.call()
	return boton

func _crearBotonNavegacion(texto: String, tooltip: String, grupo: ButtonGroup) -> Button:
	var boton := Button.new()
	boton.text = texto
	boton.tooltip_text = tooltip
	boton.toggle_mode = true
	boton.button_group = grupo
	boton.alignment = HORIZONTAL_ALIGNMENT_LEFT
	boton.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	boton.add_theme_color_override("font_color", COLOR_TEXTO_SUAVE)
	boton.add_theme_color_override("font_hover_color", COLOR_TEXTO)
	boton.add_theme_color_override("font_pressed_color", COLOR_TEXTO)
	boton.add_theme_color_override("font_focus_color", COLOR_TEXTO)
	boton.add_theme_color_override("font_hover_pressed_color", COLOR_TEXTO)

	var vacio := StyleBoxEmpty.new()
	vacio.content_margin_left = 12
	vacio.content_margin_right = 12
	vacio.content_margin_top = 8
	vacio.content_margin_bottom = 8

	var hover := StyleBoxFlat.new()
	hover.bg_color = COLOR_PANEL_HOVER
	hover.corner_radius_top_left = 2
	hover.corner_radius_top_right = 2
	hover.corner_radius_bottom_left = 2
	hover.corner_radius_bottom_right = 2
	hover.content_margin_left = 12
	hover.content_margin_right = 12
	hover.content_margin_top = 8
	hover.content_margin_bottom = 8

	var seleccionado := StyleBoxFlat.new()
	seleccionado.bg_color = COLOR_PANEL_ALT
	seleccionado.border_color = COLOR_ACENTO_SUAVE
	seleccionado.border_width_left = 2
	seleccionado.corner_radius_top_left = 2
	seleccionado.corner_radius_top_right = 2
	seleccionado.corner_radius_bottom_left = 2
	seleccionado.corner_radius_bottom_right = 2
	seleccionado.content_margin_left = 10
	seleccionado.content_margin_right = 12
	seleccionado.content_margin_top = 8
	seleccionado.content_margin_bottom = 8

	boton.add_theme_stylebox_override("normal", vacio)
	boton.add_theme_stylebox_override("hover", hover)
	boton.add_theme_stylebox_override("pressed", seleccionado)
	boton.add_theme_stylebox_override("focus", vacio)
	boton.add_theme_stylebox_override("disabled", vacio)
	boton.add_theme_stylebox_override("hover_pressed", seleccionado)
	return boton

func _estiloFondo() -> StyleBoxFlat:
	var e := StyleBoxFlat.new()
	e.bg_color = COLOR_FONDO
	return e

func _estiloInput(foco: bool) -> StyleBoxFlat:
	var e := StyleBoxFlat.new()
	e.bg_color = COLOR_PANEL_ALT
	e.border_color = COLOR_ACENTO_SUAVE if foco else COLOR_BORDE
	e.border_width_left = 1
	e.border_width_top = 1
	e.border_width_right = 1
	e.border_width_bottom = 1
	e.corner_radius_top_left = 2
	e.corner_radius_top_right = 2
	e.corner_radius_bottom_left = 2
	e.corner_radius_bottom_right = 2
	e.content_margin_left = 10
	e.content_margin_right = 10
	e.content_margin_top = 8
	e.content_margin_bottom = 8
	return e

func _crearEncabezado(titulo: String, subtitulo: String) -> Control:
	var panel := PanelContainer.new()
	var estilo := StyleBoxFlat.new()
	estilo.bg_color = COLOR_PANEL
	estilo.border_color = COLOR_BORDE
	estilo.border_width_left = 1
	estilo.border_width_top = 1
	estilo.border_width_right = 1
	estilo.border_width_bottom = 1
	estilo.corner_radius_top_left = 2
	estilo.corner_radius_top_right = 2
	estilo.corner_radius_bottom_left = 2
	estilo.corner_radius_bottom_right = 2
	estilo.content_margin_left = 16
	estilo.content_margin_right = 16
	estilo.content_margin_top = 12
	estilo.content_margin_bottom = 12
	panel.add_theme_stylebox_override("panel", estilo)

	var vbox := VBoxContainer.new()
	vbox.add_theme_constant_override("separation", 2)
	panel.add_child(vbox)

	var titulo_label := Label.new()
	titulo_label.text = titulo
	titulo_label.add_theme_color_override("font_color", COLOR_TEXTO)
	vbox.add_child(titulo_label)

	var subtitulo_label := Label.new()
	subtitulo_label.text = subtitulo
	subtitulo_label.add_theme_color_override("font_color", COLOR_TEXTO_SUAVE)
	vbox.add_child(subtitulo_label)

	return panel

func _crearMarcoPanel() -> PanelContainer:
	var panel := PanelContainer.new()
	var estilo := StyleBoxFlat.new()
	estilo.bg_color = COLOR_PANEL
	estilo.border_color = COLOR_BORDE
	estilo.border_width_left = 1
	estilo.border_width_top = 1
	estilo.border_width_right = 1
	estilo.border_width_bottom = 1
	estilo.corner_radius_top_left = 2
	estilo.corner_radius_top_right = 2
	estilo.corner_radius_bottom_left = 2
	estilo.corner_radius_bottom_right = 2
	estilo.content_margin_left = 14
	estilo.content_margin_right = 14
	estilo.content_margin_top = 12
	estilo.content_margin_bottom = 12
	panel.add_theme_stylebox_override("panel", estilo)
	return panel

func _crearBotonSecundario(texto: String) -> Button:
	return _crearBoton(texto, COLOR_PANEL, COLOR_BORDE_SUAVE, COLOR_TEXTO_SUAVE)

func _crearBotonAcento(texto: String) -> Button:
	return _crearBoton(texto, COLOR_PANEL, COLOR_BORDE, COLOR_TEXTO)

func _crearBoton(texto: String, bg: Color, borde: Color, color_texto: Color) -> Button:
	var b := Button.new()
	b.text = texto
	b.add_theme_color_override("font_color", color_texto)
	b.add_theme_color_override("font_hover_color", Color(1, 1, 1, 1).lerp(color_texto, 0.3))
	b.add_theme_color_override("font_pressed_color", color_texto)
	b.add_theme_color_override("font_disabled_color", Color(color_texto.r, color_texto.g, color_texto.b, 0.35))
	var normal := StyleBoxFlat.new()
	normal.bg_color = bg
	normal.border_color = borde
	normal.border_width_left = 1
	normal.border_width_top = 1
	normal.border_width_right = 1
	normal.border_width_bottom = 1
	normal.corner_radius_top_left = 2
	normal.corner_radius_top_right = 2
	normal.corner_radius_bottom_left = 2
	normal.corner_radius_bottom_right = 2
	normal.content_margin_left = 12
	normal.content_margin_right = 12
	normal.content_margin_top = 8
	normal.content_margin_bottom = 8
	var hover := normal.duplicate() as StyleBoxFlat
	hover.bg_color = bg.lightened(0.06)
	hover.border_color = borde.lightened(0.12)
	var pressed := normal.duplicate() as StyleBoxFlat
	pressed.bg_color = bg.darkened(0.08)
	var disabled := normal.duplicate() as StyleBoxFlat
	disabled.bg_color = bg.darkened(0.15)
	disabled.border_color = borde.darkened(0.2)
	var focus := normal.duplicate() as StyleBoxFlat
	focus.border_color = COLOR_ACENTO_SUAVE
	b.add_theme_stylebox_override("normal", normal)
	b.add_theme_stylebox_override("hover", hover)
	b.add_theme_stylebox_override("pressed", pressed)
	b.add_theme_stylebox_override("disabled", disabled)
	b.add_theme_stylebox_override("focus", focus)
	return b

func _estiloLista() -> StyleBoxFlat:
	var e := StyleBoxFlat.new()
	e.bg_color = COLOR_PANEL_ALT
	e.border_color = COLOR_BORDE
	e.border_width_left = 1
	e.border_width_top = 1
	e.border_width_right = 1
	e.border_width_bottom = 1
	e.corner_radius_top_left = 2
	e.corner_radius_top_right = 2
	e.corner_radius_bottom_left = 2
	e.corner_radius_bottom_right = 2
	e.content_margin_left = 4
	e.content_margin_right = 4
	e.content_margin_top = 4
	e.content_margin_bottom = 4
	return e

func _cargar_instrucciones_actuales() -> void:
	if not _input_instrucciones:
		return
	var desde_archivo := cargarInstruccionesUsuario()
	if desde_archivo != "":
		_input_instrucciones.text = desde_archivo
		return
	var config := _apis.obtener_configuracion_chat() if _apis else {}
	_input_instrucciones.text = str(config.get("instruccionesUsuario", ""))

func _on_guardar_instrucciones() -> void:
	if not _input_instrucciones:
		return
	var texto := _input_instrucciones.text
	guardarInstruccionesUsuario(texto)
	if _apis:
		var config := _apis.obtener_configuracion_chat()
		config["instruccionesUsuario"] = texto
		_apis.guardar_configuracion_chat(config)
	_mostrarEstadoInstrucciones("Saved", Color(0.5, 0.75, 0.55, 1.0))
	configuracionGuardada.emit()

func _on_limpiar_instrucciones() -> void:
	if _input_instrucciones:
		_input_instrucciones.text = ""
	guardarInstruccionesUsuario("")

func _mostrarEstadoInstrucciones(mensaje: String, color: Color) -> void:
	_mostrarEstadoEn(_label_estado_instrucciones, mensaje, color)

## --- Cuenta: las acciones ------------------------------------------------

## La direccion que manda la pasarela para aprobar el codigo, lista para
## ensenarse y para abrirse en el navegador. Si viene sin esquema (una direccion
## pelada en el entorno del servidor), se le pone https://, que sin eso
## OS.shell_open no la abre y el boton parece roto.
static func _normalizarUrlExterna(url: String) -> String:
	var texto := url.strip_edges().rstrip("/")
	if texto == "":
		return ""
	if texto.find("://") < 0:
		texto = "https://" + texto.lstrip("/")
	return texto

## Pide un codigo de dispositivo y se pone a esperar. El sondeo lo lleva el
## temporizador, no un bucle con esperas: la ventana tiene que seguir viva
## mientras el usuario aprueba en la web.
func _empezarEntrada() -> void:
	if _sesion == null:
		return
	_mostrarEstadoCuenta("Asking for a code...", false)
	var respuesta := await ChatCuenta.iniciarDispositivo(self, _sesion.direccionActual(), _nombreDelCliente())
	if not respuesta.get("ok", false):
		_mostrarEstadoCuenta(str(respuesta.get("error", "No code came back. Try again.")), true)
		return
	_dispositivo_codigo = str(respuesta.get("device_code", ""))
	_dispositivo_usuario = str(respuesta.get("codigo_usuario", ""))
	_dispositivo_url = _normalizarUrlExterna(str(respuesta.get("url_verificacion", "")))
	# El intervalo lo manda la pasarela; se respeta pero nunca por debajo de dos
	# segundos, que es donde el sondeo se vuelve un martilleo.
	_intervalo_dispositivo = maxf(float(respuesta.get("intervalo", ChatCuenta.SONDEO_POR_DEFECTO)), 2.0)
	if is_instance_valid(_temporizador_dispositivo):
		_temporizador_dispositivo.wait_time = _intervalo_dispositivo
		_temporizador_dispositivo.start()
	_refrescarCuenta()
	_mostrarEstadoCuenta("Waiting for you to approve the code. This window can stay open.", false)

## Una vuelta del sondeo. Se llama desde el temporizador.
func _consultarDispositivo() -> void:
	if _sesion == null or _dispositivo_codigo == "" or _consultando_cuenta:
		return
	_consultando_cuenta = true
	var respuesta := await ChatCuenta.consultarDispositivo(self, _sesion.direccionActual(), _dispositivo_codigo)
	_consultando_cuenta = false
	if not respuesta.get("ok", false):
		# Un fallo de red no cancela la entrada: el codigo sigue esperando al otro
		# lado, asi que se avisa y se vuelve a preguntar en la vuelta siguiente.
		_mostrarEstadoCuenta(str(respuesta.get("error", "")), true)
		return
	match str(respuesta.get("estado", "")):
		"approved":
			if is_instance_valid(_temporizador_dispositivo):
				_temporizador_dispositivo.stop()
			_dispositivo_codigo = ""
			_dispositivo_usuario = ""
			_dispositivo_url = ""
			_sesion.entrar({
				"token": str(respuesta.get("token", "")),
				"correo": str(respuesta.get("correo", "")),
				"rol": str(respuesta.get("rol", "")),
				"direccion": _sesion.direccionActual(),
			})
			_refrescarCuenta()
			_mostrarEstadoCuenta("Signed in. The chat already uses this account.", false)
			configuracionGuardada.emit()
			_refrescarConsumo()
		"denied":
			_terminarEspera("The code was denied from the web.")
		"expired", "not_found":
			_terminarEspera("That code is no longer valid. Ask for a new one.")

## Corta la espera y deja el aviso puesto.
func _terminarEspera(mensaje: String) -> void:
	if is_instance_valid(_temporizador_dispositivo):
		_temporizador_dispositivo.stop()
	_dispositivo_codigo = ""
	_dispositivo_usuario = ""
	_dispositivo_url = ""
	_refrescarCuenta()
	_mostrarEstadoCuenta(mensaje, true)

## Pregunta a la pasarela el catalogo y el gasto del dia, y lo deja anotado.
##
## El catalogo se adopta ANTES de mirar el consumo porque de el salen los
## proveedores: si el administrador anadio un modelo desde el panel, esta es la
## llamada que lo hace aparecer en el chat sin tocar nada mas.
func _refrescarConsumo() -> void:
	if _sesion == null or not _sesion.estaDentro() or _consultando_cuenta:
		return
	_consultando_cuenta = true
	var direccion := _sesion.direccionActual()
	var catalogo := await ChatCuenta.catalogo(self, _sesion.cabeceras(), direccion)
	var fallo := ""
	if catalogo.get("ok", false):
		_apis.adoptarCatalogo(catalogo.get("modelos", []))
		_sesion.anotarDia(catalogo.get("uso", {}))
	else:
		fallo = str(catalogo.get("error", ""))
	var consumo := await ChatCuenta.consumo(self, _sesion.cabeceras(), direccion)
	if consumo.get("ok", false):
		_sesion.anotarDia(consumo.get("uso", {}))
	elif fallo == "":
		fallo = str(consumo.get("error", ""))
	_consultando_cuenta = false
	_refrescarDatosModelo()
	_refrescarCuenta()
	if fallo != "":
		_mostrarEstadoCuenta(fallo, true)
		return
	_mostrarEstadoCuenta("Up to date.", false)
	configuracionGuardada.emit()

## Salir: se olvida el token y con el la foto del dia, que era de esa cuenta.
func _salirDeLaCuenta() -> void:
	_terminarEspera("")
	if _sesion == null:
		return
	_sesion.cerrar()
	_refrescarCuenta()
	_mostrarEstadoCuenta("Signed out. From now on requests go without an account.", false)

func _copiarAlPortapapeles(texto: String) -> void:
	DisplayServer.clipboard_set(texto)
	_mostrarEstadoCuenta("Copied.", false)

## Como se llama este equipo donde el usuario aprueba el codigo: con varios
## dispositivos, es lo que le dice cual esta pidiendo entrar.
func _nombreDelCliente() -> String:
	return "Godot editor on %s" % OS.get_name()

## El aviso de la cuenta: se escribe, se pinta y se queda. A diferencia del de
## las cajas de texto, aqui no se borra solo: hay mensajes que tienen que seguir
## leyendose cuando el usuario vuelve de aprobar el codigo en el navegador.
func _mostrarEstadoCuenta(mensaje: String, error: bool) -> void:
	if not is_instance_valid(_label_estado_cuenta):
		return
	_label_estado_cuenta.text = mensaje
	_label_estado_cuenta.add_theme_color_override("font_color", COLOR_PELIGRO if error else COLOR_TEXTO_TENUE)

## El aviso de "guardado" de cualquiera de las dos cajas: se escribe, se pinta y
## se borra solo. Va con la etiqueta por delante porque hay dos.
func _mostrarEstadoEn(etiqueta: Label, mensaje: String, color: Color) -> void:
	if not is_instance_valid(etiqueta):
		return
	etiqueta.text = mensaje
	etiqueta.add_theme_color_override("font_color", color)
	var timer := get_tree().create_timer(2.2)
	timer.timeout.connect(func():
		if is_instance_valid(etiqueta):
			etiqueta.text = ""
	)
